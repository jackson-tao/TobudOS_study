#ifndef _nand_flash_h_
#define _nand_flash_h_

//--------------------------------------------------------------------------------------
#define		ENCODE						(0 << 7)
#define		DECODE						(1 << 7)
#define		CE0							0
#define		CE1							1
#define		NFRB0						0
#define		NFRB1						1
//--------------------------------------------------------------------------------------

#define		DATA_BUF_DMA_ADDR_L			(((unsigned short)(_DATA_BUF))/4/1)
#define		DATA_BUF_DMA_ADDR_H			(((unsigned short)(_DATA_BUF))/4/256)

#define		Prepare_Write_LBA_INDEX			0
#define		Write_LBA_NewBlock_INDEX		1
#define		Write_LBA_CacheBlock_INDEX		2
#define		Write_LBA_Over_INDEX			3


//#define RAM_SIZE		  				40		//KBytes

//+++++++++++++++++++++++++++++++++++++++++++
//Nand Flash Command
//+++++++++++++++++++++++++++++++++++++++++++

#define NF_TWO_PLANE_PROGRAM_1			0X11
#define NF_TWO_PLANE_PROGRAM_2_SUMSUNG	0X81
#define NF_TWO_PLANE_PROGRAM_2_MICRON	0X80

#define NF_RESET 						0XFF	
#define NF_READ_STATUS					0X70
#define NF_READ_ID 						0X90
#define NF_READ_1ST		  				0X00	
#define NF_READ_2ND		  				0X30	
#define NF_READ_COPY_BACK_1				0X00	
#define NF_READ_COPY_BACK_2				0X35	
#define NF_PAGE_PROGRAM_1  				0X80
#define NF_PAGE_PROGRAM_2  				0X10
#define NF_CACHE_PROGRAM	  			0X15
#define NF_COPY_BACK_PROGRAM_1  		0X85
#define NF_COPY_BACK_PROGRAM_2  		0X10
#define NF_BLOCK_ERASE_1				0X60
#define NF_BLOCK_ERASE_2				0XD0
#define	NF_BLOCK_ERASE_2_SMIC		    0XD1
#define NF_RANDOM_DATA_INPUT			0X85
#define NF_RANDOM_DATA_OUTPUT_1			0X05
#define NF_RANDOM_DATA_OUTPUT_2			0XE0

#define NF_SLC_MODE_TOSHIBA				0XDA
#define NF_TLC_MODE_TOSHIBA				0XDF
#define PAGE_STAGE_LOWER				0
#define PAGE_STAGE_MIDDLE				1
#define PAGE_STAGE_UPPER				2

#define		MODE_1K_EN					1 //�ص�1K��֧�֣���ʡ�ռ�


#define		DEBUG_EN					0
#define		UART_EN						0
#define		SPECIAL_ADDR_CHANGE			0
#define		PRINTF_ERR_EN				1

#define		RETRY_EN					1
#define		RETRY_NUBER					(RETRY_TABLE_SIZE*2+10)
#define		RETRY_TABLE_SIZE			57
#define		_PagePhAddr_Buf_SIZE	    8//4
#define		BCM_MAX_SECTOR				32	
#define		BE_CNT_MAX					200
         
#define		_882B_					5
#define		_882M_					5
#define		_8M2M_					4
#define		_TOSHIBA_15NM_			3
#define		_TOSHIBA_19NM_			2
#define		_T2J_					1
#define		_FPL9_					7
#define		_SUMSUNG_19_			2
#define		_SUMSUNG_16_			3
#define		_SUMSUNG_21_			19
#define		_SUMSUNG_14_			20
//#define		ECC_MODE					2//4


#define		ZonePhBlockNum				5708 /*SS 3plane flash,block����5708��ʵ��plane3һ���ǻ��ģ�ʵ��block��ֻ��4281��*/ //ZONE_SIZE		//���ڿ����ϵ���ѯĳ��zoneʱ���ʵ�PhBlock��Ŀ
/*
TOSHIBA:
4G:1064
8G:2084
SUMSUNG:
4G:2788
8G:5166/2=5788
*/



#define 	BLANK_BLOCK					0xCFFF//3FFF
//#define 	CODE_BLOCK					0x3FFE
//#define 	BAD_BLOCK_TABLE_BLOCK		0x3FFD
//#define 	LG2PH_TABLE_BLOCK			0x3F1F//ֻ�е�byte=01~1F����ӳ���
//#define 	PASSWORD_BLOCK				0x3FFB
#define 	SDBUF_BLOCK					0xCFF0//3FF0

#define 	LG_ADDR_MAX_H				0x3F//0F
#define 	BLOCK_ADDR_MAX				0xFFFF

#define 	DATA_BLOCK					0x00
//#define 	INIT_DATA_BLOCK				0x10
#define 	DATA_CACHE_BLOCK			0x80//20
#define 	OTHER_BLOCK					0xC0//30

#define		BadBlockAddrTable_SIZE			0x70//8
#define		BCH_MODE_EC_TAB_SIZE	    	8
#define		BCH_MODE_DC_TAB_SIZE	    	8
#define		NF_SECTOR_SIZE_TAB_SIZE			4
#define		ZoneLgBlockNumBuf_SIZE			((32*2)-4)//��4Byte����ECC������չ
#define		Reserved_Blocks_Buf_SIZE		64
#define		SectorLg2PhTable_SIZE			(32+32)
#define		PageLg2PhTable_SIZE				256
#define		SectorLg2PhTable_Plane1_SIZE	0//32
#define		PageLg2PhTable_Plane1_SIZE		0//256

#define 	PAGE_GROUP_NUMBER				3//SLC:1;MLC:2;TLC:3
#define		CACHE_BLOCK_TOTAL_NUM_MAX		0x0F//ȡSpareArea2��3bit���ϵ�ʱ���øò�����SpareArea2����Ϊ���������������ECC
#define		SECTOR_PER_SMALL_PAGE			32//16k

//����Ķ�
#define			BlockLgAddrH_INDEX					0			
#define			BlockLgAddrL_INDEX					1
//#define			NewBlockNextPagePhAddrH_INDEX    	
//#define			NewBlockNextPagePhAddrL_INDEX    	
#define			CacheBlockNextPagePhAddrH_INDEX     2
#define			CacheBlockNextPagePhAddrL_INDEX     3                     
#define			OrderH_INDEX						4		
#define			OrderL_INDEX						5		
#define			CacheLgPageH_INDEX					6		
#define			CacheLgPageL_INDEX					7
#define			NewBlockPhAddrH_INDEX				8		
#define			NewBlockPhAddrL_INDEX				9
#define			NewBlockNextPagePhAddrH_INDEX		10		
#define			NewBlockNextPagePhAddrL_INDEX		11		
		
#define			CacheBlockPhAddrH_INDEX             16 
                     
#define			WritingBlockBuf_SIZE		32


#if !RANDOMIZE_NF
	#define			XRAM_SECTOR_SIZE					1028
#else 
	#define			XRAM_SECTOR_SIZE					1024
#endif
#define			READ_BUF_NUM						16				//ע����NAND_FLASH.Hͬ������
#define 		_BadBlockTable				SD_HS_CACHE_BUF_START_ADDR				//�����ϵ���̸�bufֻ�����ڻ����
#define 		_Lg2PhTableTmp				_NF_DATA_BUF_2//BBT 440*2+128<1024����1K����
#define			_PowerUp_ReadBuf_INDEX		(0*2)


#define			ZONE_SIZE						  4336//3000//14nm:2822;16nm 16g:4202;16nm 4G:2101
#define			SWAP_SIZE							6
#define		PAGE_PH2LG_TABLE_SIZE		576
#define		BUFFER_START_ADDR			(0x7100)//(0x8000UL)//(0x33C0UL)//(0x3bd4 - 0x600)//(0x4300+0x294-0x50-0x70-0x900) //0x4740//0x3598//0x2A00
#define 	SLC_BLOCK_TABLE 			0x9C10//5d00	//�ϵ���256 byte
#define 	_FLASH_BAD_BLOCK_TABLEADDR	 (SLC_BLOCK_TABLE + 256)
#define		_FLASH_CODEBLOCK_ADDR		(_FLASH_BAD_BLOCK_TABLEADDR + 0x70)	

#define		_FLASH_BCMCfg_ADDR_Tmp			0x3800//��פ 0x240
#define 	_FLASH_BLOCK_PAGE_MODE_TABLE	0x3D00//A40//��פ 0x200
#define 		_FLASH_RRT						0x4200

//#define		XDATAGROUP_BASE				0xEA00 //ע���ֵҪ��ͷ�ļ�ͬ���޸�  xdata ram��ʼλ��,Ҫ�������������һ��
#define 	NFF_BUF								(TIMING_BUF-0x300)
#define		TIMING_BUF						(_SPARE_AREA_BUF-16)    //ע��Ŀǰ����ֻ��load��0xc000,û��load�ĵط�ram��0x00
#define		_SPARE_AREA_BUF				(BUFFER_START_ADDR - 160)//164)//28)			//80 byte
#define		_NF_DATA_BUF_0				BUFFER_START_ADDR
#define 	_NF_DATA_BUF_1				(_NF_DATA_BUF_0  + XRAM_SECTOR_SIZE)
#define 	_NF_DATA_BUF_2				(_NF_DATA_BUF_1  + XRAM_SECTOR_SIZE)
#define 	_NF_DATA_BUF_3				(_NF_DATA_BUF_2  + XRAM_SECTOR_SIZE)
#define 	_NF_DATA_BUF_4				(_NF_DATA_BUF_3  + XRAM_SECTOR_SIZE)
#define 	_NF_DATA_BUF_5				(_NF_DATA_BUF_4  + XRAM_SECTOR_SIZE)
#define 	_NF_DATA_BUF_6				(_NF_DATA_BUF_5  + XRAM_SECTOR_SIZE)
#define 	_NF_DATA_BUF_7				(_NF_DATA_BUF_6  + XRAM_SECTOR_SIZE)
#define 	_NF_DATA_BUF_8				(_NF_DATA_BUF_7  + XRAM_SECTOR_SIZE)
#define 	_NF_DATA_BUF_9				(_NF_DATA_BUF_8  + XRAM_SECTOR_SIZE)
#define 	_NF_DATA_BUF_10				(_NF_DATA_BUF_9  + XRAM_SECTOR_SIZE)
#define 	_NF_DATA_BUF_11				(_NF_DATA_BUF_10 + XRAM_SECTOR_SIZE)
#define 	_NF_DATA_BUF_12				(_NF_DATA_BUF_11 + XRAM_SECTOR_SIZE)
#define 	_NF_DATA_BUF_13				(_NF_DATA_BUF_12 + XRAM_SECTOR_SIZE)
#define 	_NF_DATA_BUF_14				(_NF_DATA_BUF_13 + XRAM_SECTOR_SIZE)
#define 	_NF_DATA_BUF_15				(_NF_DATA_BUF_14 + XRAM_SECTOR_SIZE)

#define		_PAGE_MAX_SIZE				16									   //8K page * 2	  //ע����NAND_FLASH.Hͬ������
#define 	_DATA_BUF					(_NF_DATA_BUF_0  + XRAM_SECTOR_SIZE * _PAGE_MAX_SIZE)	  //ע����NAND_FLASH.Hͬ������ //C000
#define 	_DATA_BUF_INDEX				(_PAGE_MAX_SIZE*2)						   				   //ע����NAND_FLASH.Hͬ������
#define		SLC_BLANK_MAX					60		   //64
#define		BLANK_MAX							12   //64

#define		WrLg2phTable_SIZE			((ZONE_SIZE)*3/2)  //����4�ı���
//ע��:chk_cacheblock_full���������Ҫ��PAGE_PH2LG_TABLE_SIZE�󶨼���
//��Ҫ����16�ı���(������ʼ��ַ)
#define		BlankBlockTable_SIZE		((SLC_BLANK_MAX+BLANK_MAX)*3/2*8/*s/tlc & zone*/)  //288 //4*72   //((ZONE_SIZE/8)+1)///4*4+4)

/************************************************************/
#define 	_WrLg2phTableL				((_DATA_BUF + XRAM_SECTOR_SIZE) - 512)  //C200
#define 	PAGE_PH2LG_TABLE_ADDR		(_WrLg2phTableL 	+ WrLg2phTable_SIZE) //����4�ı���,���浽flash
#define 	_BlankBlockTable			(PAGE_PH2LG_TABLE_ADDR 	+ (PAGE_PH2LG_TABLE_SIZE*SWAP_SIZE))
/************************************************************/
#define 	_WritingBlockBuf			(((_BlankBlockTable 	+ BlankBlockTable_SIZE))+64)
/*
writting_buf:
{
������Ϣ:CacheBlockPhAddrH_INDEX
cacheBlock:32-CacheBlockPhAddrH_INDEX
}
*/

#define		_BlankBlockIndexBuf			(_WritingBlockBuf + WritingBlockBuf_SIZE * SWAP_SIZE+64)//4�ı���
#define		_EndBuf						(_BlankBlockIndexBuf+128)//4�ı���//��û���λ�� ��Ҫ����Щ������д��buf����һ��

#define		Lg2phTable_SIZE				(_EndBuf - _WrLg2phTableL)
		
/*
_CurPlaneCfgBuf
0 1:_PageLg2PhTable
2 3:_SectorLg2PhTable
4 5 6 7:SectorPerBlockPlane0 SectorPerBlockPlane1
*/
#define		_PageLg2PhTable_INDEX		0
#define		_SectorLg2PhTable_INDEX		2
#define		SectorPerBlock_INDEX		4
#define		SmallPagePerBlockL_INDEX	8


#endif