#ifndef _timer_isr_spi_h_

#define _timer_isr_spi_h_
extern volatile unsigned char idata virtual_lbabuf_emptycnt;
extern unsigned char code sd_virtual_data_buf_lba[][4];
extern unsigned char code sd_virtual_data_buf_cnt[];
extern unsigned char code sd_virtual_data_buf [];

#endif