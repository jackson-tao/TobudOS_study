/** \file common.h	
 * Project Common Header
 * This program is created by yanqiang_chen on 2011.11.16
 * It is used for the whole project with some common used
 * function and defination in it.
 */


#ifndef __COMMON_H__
#define __COMMON_H__

#include <intrins.h>
#include <string.h>
#include "inc\tank.h"
#include "inc\printf.h"
#include "inc\uart.h"

#define BIT(X)	 (1<<X)

#define HIGH(X)	 (X>>8)
#define LOW(X)   (X)

#define false    0
#define true     1

//ϵͳʱ��30MHZ
#define _SYSCLK_30MHZ  1


typedef bit           bool;

typedef unsigned char u8;
typedef unsigned int  u16;
typedef unsigned long u32;
typedef unsigned long WORD32;

typedef unsigned char byte;
typedef unsigned int  word;

typedef char s8;
typedef int  s16;
typedef long s32;


void sfrpage(byte pgnum);	
void datapage(u8 pgnum);
void delay(unsigned int);






#endif

