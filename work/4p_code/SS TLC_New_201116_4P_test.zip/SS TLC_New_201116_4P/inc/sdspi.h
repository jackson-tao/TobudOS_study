#ifndef _sdspi_h_
#define _sdspi_h_

#include "inc\sd_spi_com_define.h"

//extern unsigned short code sd_hs_cache_buf_dma_addr[SD_HS_CACHE_BUF_CNT];
//unsigned char code sd_hs_cache_data_buf [SD_HS_CACHE_BUF_CNT * 512]	     _at_ (SD_HS_CACHE_BUF_START_ADDR);
//unsigned char code sd_hs_cache_data_buf_lba [SD_HS_CACHE_BUF_CNT][4]	 _at_ (SD_HS_CACHE_BUF_LBA_START_ADDR);


//	#if 1//(SD_VIRTUAL_BUF_CNT <= (VIRTUAL_BUF_MAX_NF_LG_PAGE_CNT * VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE))
//	unsigned char code sd_virtual_data_buf_lba [SD_VIRTUAL_BUF_CNT][4]	 	 _at_ (SD_VIRTUAL_BUF_LBA_START_ADDR);
//	unsigned char code sd_virtual_data_buf_cnt [SD_VIRTUAL_BUF_CNT]	 	 _at_ (SD_VIRTUAL_BUF_LBA_START_ADDR+SD_VIRTUAL_BUF_CNT*4);
//	#elif (EN_VIRTUAL_BUF)
//	 Error:  //SD_VIRTUAL_BUF_CNT ���� <= VIRTUAL_BUF_MAX_NF_LG_PAGE_CNT
//	#elif ( ! EN_VIRTUAL_BUF)
//	unsigned char code sd_virtual_data_buf_lba [SD_VIRTUAL_BUF_CNT][4]	 	 _at_ (SD_VIRTUAL_BUF_LBA_START_ADDR);
//	unsigned char code sd_virtual_data_buf_cnt [SD_VIRTUAL_BUF_CNT]	 	 _at_ (SD_VIRTUAL_BUF_LBA_START_ADDR+SD_VIRTUAL_BUF_CNT*4);
//	#endif

/**********************************************************************************************************************************************************
***********************************************************************************************************************************************************/
#endif
