										
/* 
The cipher has 10 rounds: 
*/ 
#define MaxRound 10		/* 
Logical left rotate macros: 
*/ 
#define lrot8(x,n)    (((x)<<(n))|((x)>>(8-(n)))) 
#define lrot32(x,n)   (((WORD32)(x)<<(n))|((WORD32)(x)>>(32-(n))))		

									 
void C2_D(byte key[7], WORD32 *inout); 
WORD32 F(WORD32 dat, WORD32 key);							 
