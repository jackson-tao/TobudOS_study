
#ifndef _nand_flash_var_h_
#define _nand_flash_var_h_

unsigned char data SdDmaReadLBACnt	      _at_ 0x3c;
unsigned char data CurLg2PhTableAddrH	  	_at_ 0x3d;
unsigned char data CurLg2PhTableAddrL	  	_at_ 0x3e;
unsigned char data LargePagePerBlockL	  	_at_ 0x3f;
unsigned char data PlaneNum	  			  		_at_ 0x40;                            	                             
unsigned char data RdCurZone              _at_ 0x41;   	//current rd zone
unsigned char data BlockAddrTmpH          _at_ 0x42;
unsigned char data BlockAddrTmpL          _at_ 0x43;
unsigned char data BlankBlockIndexH       _at_ 0x44;
unsigned char data planReleaseBufCnt      _at_ 0x44;
unsigned char data BlankBlockIndexL       _at_ 0x45;
unsigned char data WriteLBAIndex       		_at_ 0x45;
unsigned char data SectorPerSmallPage     _at_ 0x46;
unsigned char data SpareAreaH             _at_ 0x47;
unsigned char data SpareAreaL             _at_ 0x48;
unsigned char data ReadLBACnt			  			_at_ 0x49;
unsigned char data HalfSectorPerSmallPage _at_ 0x4a;
unsigned char data ProgramCMD1 		    		_at_ 0x4b;
unsigned char data BBTIndex 		    			_at_ 0x4c;
unsigned char data KeepSWAPIndex 		    	_at_ 0x4c;
unsigned char data CacheBlockLgPageNumL   _at_ 0x4d;
unsigned char data LargePagePerBlockH    	_at_ 0x4e;
unsigned char data ZoneLBA       					_at_ 0x4f;
unsigned char data SectorPerSmallPage1    _at_ 0x50;
unsigned char data HalfSectorPerSmallPage1 _at_ 0x51;
unsigned char data DataCoDecKeyIndex1     _at_ 0x52;
unsigned char data DataCoDecKeyIndex      _at_ 0x53;
unsigned char data BBTBlockIndex          _at_ 0x54;	  //Only Used in NF_Power_Up
unsigned char data PageLBAH         			_at_ 0x54;
unsigned char data sysBlk   			_at_ 0x55;
unsigned char data NfEmptyBufCnt          _at_ 0x56;
unsigned char data SectorPerSmallPageTotal _at_ 0x57;
unsigned char data CacheBlockNextPagePhAddrL   _at_ 0x58;
unsigned char data FlashType       		 		_at_ 0x59;   //��bankʹ��
unsigned char data PlanRcvSDDataCnt   	  _at_ 0x5a;   //�����������ݵİ���
unsigned char data ActualRcvSDDataCnt     _at_ 0x5b;   //ʵ�ʽ������ݵİ���	

unsigned char data PageGroupNumber     	  _at_ 0x5c; 
unsigned char data blank_swap     	  		_at_ 0x5d; 
//unsigned char data empty_occupy     	      	_at_ 0x5e; 
unsigned char data SpareArea2     	      _at_ 0x5f; 
unsigned char data SectorNum     	      	_at_ 0x60;

unsigned char data yBuffer_Index_Start	  _at_ 0x61;   //��ǰ������ݵ�buf_index
unsigned char data NewBlockNextPagePhAddrL	_at_ 0x62;
unsigned char data FlashIndex	  	      	_at_ 0x63;
unsigned char data SWAPIndex	  	      	_at_ 0x64;
unsigned char data SWAPIndexTmp	  	      _at_ 0x65;
unsigned char data yBuffer_Index          _at_ 0x66;   //������BUFF Index
unsigned char data NfEmptyBufCntTmp       _at_ 0x67; 
unsigned char data RandomIndex        _at_ 0x68; 
unsigned char data NewBlockNextPagePhAddrH  _at_ 0x69;
unsigned char data PageLBAL		           	_at_	0x6c;
unsigned char data ProgramCMD0		       	_at_	0x6d;
unsigned char data SectorInLargePage	    _at_	0x6e;
unsigned char data R8Tmp                  _at_  0x6F;
unsigned char data ProgramCMD2            _at_  0x70;
unsigned char data BECNTTmp              	_at_  0x71;
unsigned char data CacheBlockNextPagePhAddrH 	_at_  0x72;
unsigned char data CacheBlockLgPageNumH 	_at_  0x73;
unsigned char data BlockLBAH 					   	_at_  0x74;
unsigned char data BlockLBAL 							_at_  0x75;
unsigned char data OldBlockPhAddrH 				_at_  0x76;
unsigned char data OldBlockPhAddrL 				_at_  0x77;
unsigned char data BlockLgAddrH 					_at_  0x78;
unsigned char data BlockLgAddrL 					_at_  0x79;
unsigned char data NewBlockPhAddrH 				_at_  0x7a;
unsigned char data NewBlockPhAddrL 				_at_  0x7b;
//unsigned char data empty_occupy 		_at_  0x7c;
//unsigned char data empty_occupy 		_at_  0x7d;
//unsigned char data empty_occupy 	  _at_  0x7e;
//unsigned char data empty_occupy 		_at_  0x7f;
unsigned int  idata RetryCnt;
unsigned short data WORD_LINE_NUMBER;
unsigned short data WordLineNumber;
unsigned short data WordLineNumberTLC;
unsigned short data CopyWLNumber;
unsigned char  data boundIndex;
unsigned char  idata SWAPIndexTmp1;
unsigned short idata FirstGoodWL;
//λ����

//0x20 										//sd ռ��	
//0x21										//sd ռ��
//0x22										//sd ռ��
//0x23										//sd ռ��
//0x24										//sd ռ��
//0x25										//sd ռ��
//0x26										//sd ռ��
//0x27										//sd ռ��

//flashʹ����data 0x28 ~ 0x2d

//0x28									   //flash ռ��
unsigned char bdata addr_0x28 _at_ 0x28;   
sbit bSLC2TLCProg        		= addr_0x28^0;
sbit bTerribleError      		= addr_0x28^1;
sbit bRcvSDDataKickStart 		= addr_0x28^2;
sbit b2PlaneTrue         		= addr_0x28^3;
sbit emptybit    		= addr_0x28^4;
sbit bLg2PhVerifyError   		= addr_0x28^5;
sbit bNeedChkBlockPageModeIndex	= addr_0x28^6;	
sbit bWriteLastLgPage    		= addr_0x28^7;		

//0x29										//flash ռ��
unsigned char bdata addr_0x29 _at_ 0x29;
sbit bProgCacheBlockPageTrue = addr_0x29^0;
sbit bFindBlankBlockTrue     = addr_0x29^1;	//bOldBlockNotTrue
sbit bStr_MulRead_SD         = addr_0x29^2;	//������ʼ��־
sbit bReadBlankBlock_0       = addr_0x29^3;
sbit bRwDataBlockSpareArea   = addr_0x29^4;
sbit bCopyBackNotOver 	     = addr_0x29^5;	//0:���հ�Ǩ�ƻ���� 1��û�����	//sd & flash ʹ��
sbit bEraseCacheBlock        = addr_0x29^6;
sbit bPageGroupSLC           = addr_0x29^7;

//0x2A  									//flash ռ��
unsigned char bdata FlashCfg _at_ 0x2a; 
sbit  bNfInReadLbaFun		 		= FlashCfg^0;
sbit  bSendReadRandomCmd		= FlashCfg^1;
sbit  bReadNeedChkBankBlk		= FlashCfg^2;	
sbit  bEnReadLBACnt          = FlashCfg^3;	 	//1: ReadLBACnt������Ч��0 < ReadLBACnt < 255��
sbit  bWriteLastButOneLgPage = FlashCfg^4;
sbit  bBlockMode             = FlashCfg^5;
sbit  bSectorSize            = FlashCfg^6;
sbit  btmp                   = FlashCfg^7;


//0x2B										//flash ռ��
unsigned char bdata addr_0x2b _at_ 0x2b;
sbit  bCopyStart          	= addr_0x2b^0;	   	//1:��ʼ�������������Ǩ	//sd & flash ʹ��
sbit  bCopyNeedStop      	 	= addr_0x2b^1;	   	//1:��Ҫ��ǰ�˳�	//sd & flash ʹ��
sbit  bWriteLastCachePage 	= addr_0x2b^2;	 
sbit  bSDStop             	= addr_0x2b^3;		   //1:SD host stop cmd ֹͣ����
sbit  bDataEncodeTure     	= addr_0x2b^4;
sbit  bNeedRetryTrue      	= addr_0x2b^5;
sbit  bReadingCacheBlock  	= addr_0x2b^6;
sbit  bRetryBlockMode     	= addr_0x2b^7;

//0x2C										//flash ռ��
unsigned char bdata BitData _at_ 0x2c;	
sbit 	bRemedyPage  = BitData^0;
sbit	bVirtuallba_continue_in_page = BitData^1;
sbit  bPlaneMag              = BitData^2;
sbit  bNeedSend5DCMDTLC      = BitData^3;
sbit  bEnReleaseNfBufRcvData = BitData^4;
sbit  bReadBlankBlock        = BitData^5;
sbit  bFlashRetryTimeOut     = BitData^6;
sbit  emptybit2           = BitData^7;
	

//0x2D 									   	//flash ռ��
unsigned char bdata FunctionCfg _at_ 0x2d;
sbit 	empty0							 = FunctionCfg^1;
sbit 	bFlashMode2			 		 = FunctionCfg^2;
sbit  bCacheCmd            = FunctionCfg^3;
sbit  bNeedSend5DCMDSLC    = FunctionCfg^4;
sbit  bToggleTrue          = FunctionCfg^5;
sbit  bCopyBackNeedReWrite = FunctionCfg^6;
sbit  bNeedRandomizer      = FunctionCfg^7;

//0x2e										//sd ռ��
//0x2f										//sd ռ��
	 							  									
//volatile unsigned char idata last_lba[4];
unsigned char idata blankBlock_0, blankBlock_1;
volatile unsigned char idata R3_BlockAddrH;
volatile unsigned char idata R2_BlockAddrL;
volatile unsigned char idata R3_BlockAddrH_P1;
volatile unsigned char idata R2_BlockAddrL_P1;

volatile unsigned char idata R4_PageAddrH;
volatile unsigned char idata R0_PageAddrL;
volatile unsigned char idata R1_Sector,R1_SectorTmp,BlockLBAHTmp,BlockLBALTmp,DelayCopyCnt;
volatile unsigned char idata PlanCopyBackNum;
volatile unsigned int idata Order;
volatile unsigned int idata OrderTotal;
volatile unsigned int idata CacheLgPage;
volatile unsigned char idata ChkNeedCache2Cache;
volatile unsigned char idata host_to_sd_buf_ptr;
volatile unsigned char idata sd_to_nf_buf_ptr;
volatile unsigned char idata sd_ready_for_nf_buf_cnt;

volatile unsigned char idata SDBufBlockAddrH	;//	  _at_ 0x39;
volatile unsigned char idata SDBufBlockAddrL	;//	  _at_ 0x3a;
volatile unsigned char idata SDBufPageAddr     ;//     _at_ 0x3b; //0=< <WORD_LINE_NUMBER 

volatile unsigned char idata virtual_sd_data_buf_cnt;					//����sd data buf��cnt
volatile unsigned char idata hs_to_virtual_buf_ptr;
volatile unsigned char idata virtual_to_nf_buf_ptr; 
volatile unsigned char idata virtual_to_nf_buf_in_per_page_sector_ptr;		 //page�ڵ�sector index	[0,VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE]	 

volatile unsigned char idata virtual_sd_buf_map_w_nf_page_ptr;
volatile unsigned char idata virtual_sd_buf_map_r_nf_page_ptr;
volatile unsigned char idata virtual_lbabuf_emptycnt;

volatile unsigned char idata sectors_in_virtual_page_total;
volatile unsigned char idata sectors_in_virtual_page_w;
volatile unsigned char idata  sdbuf_planCopyPackets;


volatile unsigned char idata dma_out_r_cur_virtual_buf_map_r_nf_page_ptr;	  			//sd dma out ������ƥ��LBA��Ӧ�� nf page index
volatile unsigned char idata dma_out_r_cur_virtual_buf_map_r_nf_sec_in_page_ptr;	  	//sd dma out ������ƥ��LBA��Ӧ�� nf page index ��sectorƫ��
volatile unsigned char idata UartIndex;
#endif