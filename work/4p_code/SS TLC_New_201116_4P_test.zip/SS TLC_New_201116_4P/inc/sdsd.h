#ifndef _sdsd_h_
#define _sdsd_h_

extern unsigned char idata host_to_sd_buf_ptr,sd_to_nf_buf_ptr,sd_ready_for_nf_buf_cnt;
extern unsigned char idata sd_to_host_buf_ptr;
extern unsigned char idata dma_out_r_cur_virtual_buf_map_r_nf_page_ptr, dma_out_r_cur_virtual_buf_map_r_nf_sec_in_page_ptr;
extern unsigned char code sd_hs_cache_data_buf[];
extern unsigned short code sd_hs_cache_buf_dma_addr[SD_HS_CACHE_BUF_CNT];

extern unsigned char code TAB_R3_ACK,CSD,CSD_50M_CRC7,CSD_25M_CRC7,FUNCTION;
extern unsigned char code W_BUF_ADDR_H,W_BUF_ADDR_L;

extern unsigned char code UART_SND_BYTE_PTR;
extern unsigned char code DATA_TOTAL_LEN_UART_BUF;
extern unsigned char code CHK_UART_IN_CNT, CHK_UART_OUT_CNT;
extern unsigned char code TIMER_UART_IN_OUT_WORKING;
extern unsigned char code sd_uart_out_buf[];
extern unsigned char code BankCodeInFlashAddr;


extern bit bSDHC,bCMD8Rcv,READY_FOR_DATA,bFirstActive,bNandPowerup,bCMDRps_Flag,bCMD0Rcv,bDataStop_Flag,bRcvCMD7InDataOrDisState,bVisitCprmDataMode;
extern bit bSingleReadTask,bReadType,bMulRFlag,bStopEn,bCprmDmaDataMode,bWriteType,bDataIn_Flag,bSingleWriteTask,bInEraseTask,bStopMulWriteData;
extern bit bMulWriteTask,bStopRcvCprmData,bSwitch50M,bTmpWriteProtect,WP_ERASE_SKIP,bStr_MulRead,bStr_MulRead_SD,bBlockLenLess512Byte;
extern bit bStr_MulWrite,bCallWriteLBA, bInWriteLbaFun;
extern bit bAKERcvType,bAKEVerifyErr;
extern bit bDataOut_Flag;
extern bit bLbaSeq, bReadDataInHsBuf, bForceDly, bReadDataInVirtualBuf;
extern bit bCopyBackNotOver, bCopyNeedStop, bLastReadDataInHsBuf; 
extern bit bRcvSDDataKickStart;
extern bit bSDStop, bEnReadLBACnt;
extern bit bSDStop;
extern bit bInReadLba;
extern bit bBankTrue;
extern bit bEnVirtualBuf2Nf;

extern u8 data ReadLBACnt;
extern u8 data NfEmptyBufCnt;
extern u8 data yCMD_Index;
extern unsigned char bdata bCPRMFlag;
extern u8 data yBlockLen1,yBlockLen0,yTast_Index,yBuffer_Index,yScrtyUnitCnt;
extern u8 data RdCurZone;
extern u16 idata u16RCA;
extern unsigned char code sd_hs_cache_data_buf_lba[SD_HS_CACHE_BUF_CNT][4];
extern unsigned char idata last_lba[4];
extern unsigned char data PlanRcvSDDataCnt, ActualRcvSDDataCnt, yBuffer_Index_Start;
extern unsigned char idata virtual_sd_data_buf_cnt, hs_to_virtual_buf_ptr, virtual_to_nf_buf_ptr, write_virtual_sd_buf_data_to_nf_state;
extern unsigned char idata virtual_sd_buf_map_w_nf_page_ptr, virtual_sd_buf_map_r_nf_page_ptr;
extern unsigned char idata u8_pwr_active_cnt;
extern unsigned char idata virtual_to_nf_buf_in_per_page_sector_ptr;

extern void check_addr_out_of_range(void);
extern void write_block_tab(void);
extern void rca_inc(void);
bit erase_task_parameter_analysis(void);

extern void read_lba(void);
extern void write_lba(void);
//extern void write_lba_over(void);
extern void sel_dma_addr(void);
extern void nf_power_up(void);
extern void initial_cprm_pamameter(void);
extern void copy_lba(void);

extern void dma_mkb_pro(void);
extern void ake_rev_data_process(void);
extern void copy_dptr1_8_byte_data_to_dptr0(void);
extern void ake_send_data_process(void);
extern void get_scrty_lba(void);
extern void cprm_en_de_code_buf_point_to_cur_buf(void);
extern void cprm_encode_data(void);
extern void cprm_decode_data(void);

extern void Sel_Buffer_Addr(void);
extern void system_initial(void);  
extern void save_hs_buf_data_to_virtual_sd_buf(void);
extern void updata_cur_virtual_sd_buf_data_to_nf(unsigned char r_virtual_buf_ptr, unsigned char r_virtual_buf_sec_in_page_ptr, unsigned char w_nf_buf);
extern void erase_lba(void);
extern void initial_vitrual_buf_parameter_in_powerup(void);
extern bit Read_Bank_Codes(void);
extern void initial_rcv_data_par(void);
extern void uart_send_one_byte(unsigned char val);
extern void config_first_rcv_buf(void);
extern void SD_init(void);
extern void reset_bch(void);


void delay_2n_sd_clk(unsigned char n_sd_clk);
	

void nf_power_up_pro(void);
void power_down(void);
void wait_cmd_rps_ready_and_en_sdodly(void);
void dma_data_out_kict_and_wait_ready(unsigned char dly);
void change_state_machine_in_data_state(void);
void get_lba(void);
void read_lba_data(void);
void mul_read_process(void);
void write_lba_data(void);
void wait_cmd_rps_ready(void);
void rcv_one_packet_case_in_pro_state_process(void);
void change_state_machine_in_pro_dis_state(void);
void clr_d0_busy_in_rcv_end(void);
void cprm_mul_write_end(void);
void wait_for_enter_sleep_mode(void);
void switch_clk_frq(void);
void erase_data_process(void);
void wait_dma_in_ready(void);
void uart_send_byte(u8 val);
void uart_sent_byte(void);
void power_down(void);
void config_hs_cache_buf_dma_addr(unsigned char buf_ptr);
void write_data_from_hs_buf_to_flash(void);
void config_cur_buf_data_lba(unsigned char buf_ptr);
void copy_512byte_data(unsigned char src_buf_index, unsigned char target_buf_index);
void cur_map_lba_inc(void);
void get_er1_to_cur_lba(void);
void judge_cprm_data_dma_out_complete(void);
void cprm_mul_read_end(void);
void clr_sd_read_data_flag(void);
void sd_lg_write_data(void);
void debug_uart_send_data(void);
void sd_2_uart_send_data(void);
void read_only_tasks(unsigned char task_index);
void erase_lba_change_sector_mode(void);
void update_er3_to_r_random_lba_var(void);
u8 get_mem_copy_hw_status(void);
u8 chk_sd_d0_busy(u8  dly_n_sd_clk);

void set_p1(u8 dat);
void clr_p1(u8 dat);
void xrl_p1(u8 dat);
void xrl_p3(u8 dat);

u16 idata u16_offset_in_buf;
extern u8 idata rcv_data_state;
extern u8 idata write_hs_data_to_flash_state;
extern unsigned char idata  before_cpy_max_sd_ready_for_nf_buf_cnt, max_sd_ready_for_nf_buf_cnt, use_debug_lba_cnt;	//debug
extern unsigned short idata max_n_10ms;
extern unsigned short idata  cal_erase_virtual_sd_buf_map_blk_cnt;
extern unsigned char idata  cal_map_blk_max_page_number;
extern unsigned char idata  cal_max_virtual_buf_cnt;



unsigned char code sd_hs_cache_data_buf [SD_HS_CACHE_BUF_CNT * 512]	     _at_ (SD_HS_CACHE_BUF_START_ADDR);
unsigned char code sd_hs_cache_data_buf_lba [SD_HS_CACHE_BUF_CNT][4]	 _at_ (SD_HS_CACHE_BUF_LBA_START_ADDR);


	#if 1//(SD_VIRTUAL_BUF_CNT <= (VIRTUAL_BUF_MAX_NF_LG_PAGE_CNT * VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE))
	unsigned char code sd_virtual_data_buf_lba [SD_VIRTUAL_BUF_CNT][4]	 	 _at_ (SD_VIRTUAL_BUF_LBA_START_ADDR);
	unsigned char code sd_virtual_data_buf_cnt [SD_VIRTUAL_BUF_CNT]	 	 _at_ (SD_VIRTUAL_BUF_LBA_START_ADDR+SD_VIRTUAL_BUF_CNT*4);
	#elif (EN_VIRTUAL_BUF)
	 Error:  //SD_VIRTUAL_BUF_CNT ���� <= VIRTUAL_BUF_MAX_NF_LG_PAGE_CNT
	#elif ( ! EN_VIRTUAL_BUF)
	unsigned char code sd_virtual_data_buf_lba [SD_VIRTUAL_BUF_CNT][4]	 	 _at_ (SD_VIRTUAL_BUF_LBA_START_ADDR);
	unsigned char code sd_virtual_data_buf_cnt [SD_VIRTUAL_BUF_CNT]	 	 _at_ (SD_VIRTUAL_BUF_LBA_START_ADDR+SD_VIRTUAL_BUF_CNT*4);
	#endif



//sd hs_buf_dma_addr,  ��˶��� 
unsigned short code sd_hs_cache_buf_dma_addr[SD_HS_CACHE_BUF_CNT] = {	
#if (SD_HS_CACHE_BUF_CNT == 1)		
	SD_HS_CACHE_DMA_ADDR_BUF_0

#elif (SD_HS_CACHE_BUF_CNT == 2)
	SD_HS_CACHE_DMA_ADDR_BUF_0,
	SD_HS_CACHE_DMA_ADDR_BUF_1

#elif (SD_HS_CACHE_BUF_CNT == 3)
	SD_HS_CACHE_DMA_ADDR_BUF_0,
	SD_HS_CACHE_DMA_ADDR_BUF_1,
	SD_HS_CACHE_DMA_ADDR_BUF_2

#elif (SD_HS_CACHE_BUF_CNT == 4)
	SD_HS_CACHE_DMA_ADDR_BUF_0,
	SD_HS_CACHE_DMA_ADDR_BUF_1,
	SD_HS_CACHE_DMA_ADDR_BUF_2,
	SD_HS_CACHE_DMA_ADDR_BUF_3

#elif (SD_HS_CACHE_BUF_CNT == 5)
	SD_HS_CACHE_DMA_ADDR_BUF_0,
	SD_HS_CACHE_DMA_ADDR_BUF_1,
	SD_HS_CACHE_DMA_ADDR_BUF_2,
	SD_HS_CACHE_DMA_ADDR_BUF_3,
	SD_HS_CACHE_DMA_ADDR_BUF_4

#elif (SD_HS_CACHE_BUF_CNT == 6)
	SD_HS_CACHE_DMA_ADDR_BUF_0,
	SD_HS_CACHE_DMA_ADDR_BUF_1,
	SD_HS_CACHE_DMA_ADDR_BUF_2,
	SD_HS_CACHE_DMA_ADDR_BUF_3,
	SD_HS_CACHE_DMA_ADDR_BUF_4,
	SD_HS_CACHE_DMA_ADDR_BUF_5

#elif (SD_HS_CACHE_BUF_CNT == 7)
	SD_HS_CACHE_DMA_ADDR_BUF_0,
	SD_HS_CACHE_DMA_ADDR_BUF_1,
	SD_HS_CACHE_DMA_ADDR_BUF_2,
	SD_HS_CACHE_DMA_ADDR_BUF_3,
	SD_HS_CACHE_DMA_ADDR_BUF_4,
	SD_HS_CACHE_DMA_ADDR_BUF_5,
	SD_HS_CACHE_DMA_ADDR_BUF_6

#elif (SD_HS_CACHE_BUF_CNT == 8)
	SD_HS_CACHE_DMA_ADDR_BUF_0,
	SD_HS_CACHE_DMA_ADDR_BUF_1,
	SD_HS_CACHE_DMA_ADDR_BUF_2,
	SD_HS_CACHE_DMA_ADDR_BUF_3,
	SD_HS_CACHE_DMA_ADDR_BUF_4,
	SD_HS_CACHE_DMA_ADDR_BUF_5,
	SD_HS_CACHE_DMA_ADDR_BUF_6,
	SD_HS_CACHE_DMA_ADDR_BUF_7

#elif (SD_HS_CACHE_BUF_CNT == 9)
	SD_HS_CACHE_DMA_ADDR_BUF_0,
	SD_HS_CACHE_DMA_ADDR_BUF_1,
	SD_HS_CACHE_DMA_ADDR_BUF_2,
	SD_HS_CACHE_DMA_ADDR_BUF_3,
	SD_HS_CACHE_DMA_ADDR_BUF_4,
	SD_HS_CACHE_DMA_ADDR_BUF_5,
	SD_HS_CACHE_DMA_ADDR_BUF_6,
	SD_HS_CACHE_DMA_ADDR_BUF_7,
	SD_HS_CACHE_DMA_ADDR_BUF_8

#elif (SD_HS_CACHE_BUF_CNT == 10)
	SD_HS_CACHE_DMA_ADDR_BUF_0,
	SD_HS_CACHE_DMA_ADDR_BUF_1,
	SD_HS_CACHE_DMA_ADDR_BUF_2,
	SD_HS_CACHE_DMA_ADDR_BUF_3,
	SD_HS_CACHE_DMA_ADDR_BUF_4,
	SD_HS_CACHE_DMA_ADDR_BUF_5,
	SD_HS_CACHE_DMA_ADDR_BUF_6,
	SD_HS_CACHE_DMA_ADDR_BUF_7,
	SD_HS_CACHE_DMA_ADDR_BUF_8,
	SD_HS_CACHE_DMA_ADDR_BUF_9

#elif (SD_HS_CACHE_BUF_CNT == 11)
	SD_HS_CACHE_DMA_ADDR_BUF_0,
	SD_HS_CACHE_DMA_ADDR_BUF_1,
	SD_HS_CACHE_DMA_ADDR_BUF_2,
	SD_HS_CACHE_DMA_ADDR_BUF_3,
	SD_HS_CACHE_DMA_ADDR_BUF_4,
	SD_HS_CACHE_DMA_ADDR_BUF_5,
	SD_HS_CACHE_DMA_ADDR_BUF_6,
	SD_HS_CACHE_DMA_ADDR_BUF_7,
	SD_HS_CACHE_DMA_ADDR_BUF_8,
	SD_HS_CACHE_DMA_ADDR_BUF_9,
	SD_HS_CACHE_DMA_ADDR_BUF_10

#elif (SD_HS_CACHE_BUF_CNT == 12)
	SD_HS_CACHE_DMA_ADDR_BUF_0,
	SD_HS_CACHE_DMA_ADDR_BUF_1,
	SD_HS_CACHE_DMA_ADDR_BUF_2,
	SD_HS_CACHE_DMA_ADDR_BUF_3,
	SD_HS_CACHE_DMA_ADDR_BUF_4,
	SD_HS_CACHE_DMA_ADDR_BUF_5,
	SD_HS_CACHE_DMA_ADDR_BUF_6,
	SD_HS_CACHE_DMA_ADDR_BUF_7,
	SD_HS_CACHE_DMA_ADDR_BUF_8,
	SD_HS_CACHE_DMA_ADDR_BUF_9,
	SD_HS_CACHE_DMA_ADDR_BUF_10,
	SD_HS_CACHE_DMA_ADDR_BUF_11

#elif (SD_HS_CACHE_BUF_CNT == 13)
	SD_HS_CACHE_DMA_ADDR_BUF_0,
	SD_HS_CACHE_DMA_ADDR_BUF_1,
	SD_HS_CACHE_DMA_ADDR_BUF_2,
	SD_HS_CACHE_DMA_ADDR_BUF_3,
	SD_HS_CACHE_DMA_ADDR_BUF_4,
	SD_HS_CACHE_DMA_ADDR_BUF_5,
	SD_HS_CACHE_DMA_ADDR_BUF_6,
	SD_HS_CACHE_DMA_ADDR_BUF_7,
	SD_HS_CACHE_DMA_ADDR_BUF_8,
	SD_HS_CACHE_DMA_ADDR_BUF_9,
	SD_HS_CACHE_DMA_ADDR_BUF_10,
	SD_HS_CACHE_DMA_ADDR_BUF_11,
	SD_HS_CACHE_DMA_ADDR_BUF_12

#elif (SD_HS_CACHE_BUF_CNT == 14)
	SD_HS_CACHE_DMA_ADDR_BUF_0,
	SD_HS_CACHE_DMA_ADDR_BUF_1,
	SD_HS_CACHE_DMA_ADDR_BUF_2,
	SD_HS_CACHE_DMA_ADDR_BUF_3,
	SD_HS_CACHE_DMA_ADDR_BUF_4,
	SD_HS_CACHE_DMA_ADDR_BUF_5,
	SD_HS_CACHE_DMA_ADDR_BUF_6,
	SD_HS_CACHE_DMA_ADDR_BUF_7,
	SD_HS_CACHE_DMA_ADDR_BUF_8,
	SD_HS_CACHE_DMA_ADDR_BUF_9,
	SD_HS_CACHE_DMA_ADDR_BUF_10,
	SD_HS_CACHE_DMA_ADDR_BUF_11,
	SD_HS_CACHE_DMA_ADDR_BUF_12,
	SD_HS_CACHE_DMA_ADDR_BUF_13

#elif (SD_HS_CACHE_BUF_CNT == 15)
	SD_HS_CACHE_DMA_ADDR_BUF_0,
	SD_HS_CACHE_DMA_ADDR_BUF_1,
	SD_HS_CACHE_DMA_ADDR_BUF_2,
	SD_HS_CACHE_DMA_ADDR_BUF_3,
	SD_HS_CACHE_DMA_ADDR_BUF_4,
	SD_HS_CACHE_DMA_ADDR_BUF_5,
	SD_HS_CACHE_DMA_ADDR_BUF_6,
	SD_HS_CACHE_DMA_ADDR_BUF_7,
	SD_HS_CACHE_DMA_ADDR_BUF_8,
	SD_HS_CACHE_DMA_ADDR_BUF_9,
	SD_HS_CACHE_DMA_ADDR_BUF_10,
	SD_HS_CACHE_DMA_ADDR_BUF_11,
	SD_HS_CACHE_DMA_ADDR_BUF_12,
	SD_HS_CACHE_DMA_ADDR_BUF_13,
	SD_HS_CACHE_DMA_ADDR_BUF_14

#elif (SD_HS_CACHE_BUF_CNT == 16)
	SD_HS_CACHE_DMA_ADDR_BUF_0,
	SD_HS_CACHE_DMA_ADDR_BUF_1,
	SD_HS_CACHE_DMA_ADDR_BUF_2,
	SD_HS_CACHE_DMA_ADDR_BUF_3,
	SD_HS_CACHE_DMA_ADDR_BUF_4,
	SD_HS_CACHE_DMA_ADDR_BUF_5,
	SD_HS_CACHE_DMA_ADDR_BUF_6,
	SD_HS_CACHE_DMA_ADDR_BUF_7,
	SD_HS_CACHE_DMA_ADDR_BUF_8,
	SD_HS_CACHE_DMA_ADDR_BUF_9,
	SD_HS_CACHE_DMA_ADDR_BUF_10,
	SD_HS_CACHE_DMA_ADDR_BUF_11,
	SD_HS_CACHE_DMA_ADDR_BUF_12,
	SD_HS_CACHE_DMA_ADDR_BUF_13,
	SD_HS_CACHE_DMA_ADDR_BUF_14,
	SD_HS_CACHE_DMA_ADDR_BUF_15

#else
	... //���������������������ʾ�������Ӷ���
#endif 
};

#endif