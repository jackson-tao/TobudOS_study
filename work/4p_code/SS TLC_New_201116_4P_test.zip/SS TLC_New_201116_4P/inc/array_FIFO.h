#ifndef __ARRAY_FIFO_H__
#define __ARRAY_FIFO_H__

#define FIFO_LENGTH		512

void uart_array_init(void);
int array_get_length(void);
int array_add_tail(byte dat);
int array_get_head(void);		 


#endif