extern bit  RESERVED        ;                  
extern bit  PARAMETER_ERROR ;                  
extern bit  ADDRESS_ERROR   ;                  
extern bit  ERASE_SEQ_ERROR ;                  
extern bit  COM_CRC_ERROR   ;                  
extern bit  ILLEGAL_COMMAND ;                  
extern bit  ERASE_RESET     ;                  
extern bit  IDLE_STATE      ;                  
                                               
                                               
extern bit  OUT_OF_RANGE    ;                  
extern bit  ERASE_PARAM     ;                  
extern bit  WP_VIOLATION    ;                  
extern bit  CARD_ECC_FAILED ;                  
extern bit  CC_ERROR        ;                  
extern bit  ERROR           ;                  
extern bit  WP_ERASE_SKIP   ;                  
extern bit  CARD_IS_LOCKED  ;                  
                                               
                                               
extern bit  bAppo_CMD_Flag  ;                  
extern bit  bCMDRec_Flag    ;                  
extern bit  bCMDRps_Flag    ;                  
extern bit  bDataIn_Flag    ;                  
extern bit  bDataOut_Flag   ;                  
extern bit  bDataStop_Flag  ;                  
extern bit  bStr_MulRead    ;                  
extern bit  bStr_MulWrite   ;                  
                                               
                                               
extern bit  bSpeedClass_Flag    ;              
extern bit  bSPI_CRC_Check_Flag ;              
extern bit  bSPICMDInR2Rps		  ;              
extern bit  bEnCheckEraseSeq    ;              
extern bit  bEnVirtualBuf2Nf	  ;              
extern bit  bInEraseTask        ;              
extern bit  bMulRFlag           ;              
extern bit  bEnterReadDmaOut	  ;              
                                               
extern bit  bHwEnBusyCmd			  ;              
extern bit  bCMD8Rcv            ;              
extern bit  bSingleWriteTask    ;              
extern bit  bMulWriteTask       ;              
extern bit  bBlockLenLess512Byte;              
extern bit  bSDHC               ;              
extern bit  bSwitch50M          ;              
extern bit  bCallWriteLBA       ;              
                                               
extern bit  bReadType         ;                 
extern bit  bWriteType         ;               
extern bit  bInWriteLbaFun		 ;               
extern bit  bStopMulWriteData  ;               
extern bit  bNandPowerup       ;               
extern bit  bSpiMulReadAddrErr ;               
extern bit  bTmpWriteProtect   ;               
extern bit  bRomCard					 ;               
                                               
extern bit bEnForceEraseVirtualBufBlk;         
extern bit bReadDataInHsBuf		       ;         
extern bit bInReadLba					       ;         
extern bit bForceDly					       ;         
extern bit bEnIsrDmaOut				       ;         
extern bit bTimeout					         ;         
extern bit bReadDataInVirtualBuf	   ;         
                                               
extern bit  bCPRM_E_D_Flag      ;              
extern bit  bAKERcvType         ;              
extern bit  bScrtyMode          ;              
extern bit  bCprmDmaDataMode    ;              
extern bit  bAKEVerifyErr       ;              
extern bit  bFirstEnDecodeData  ;              
extern bit  bVisitCprmDataMode  ;              
extern bit  bStopRcvCprmData    ;              
                                               
extern unsigned char data yCMD_Index      ;    
extern unsigned char data yTast_Index     ;    
extern unsigned char data yScrtyUnitCnt   ;    
extern unsigned char data yBufIndexCopyTmp;    
extern unsigned char data yBlockLen1      ;    
extern unsigned char data yBlockLen0      ;    
                                               
extern unsigned char data addr_0x20; 
extern unsigned char data addr_0x21;   
#define	R1_REG  addr_0x20
#define R2_REG0   addr_0x20
#define R2_REG1   addr_0x21