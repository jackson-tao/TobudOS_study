#ifndef __TIMER_H__
#define __TIMER_H__

#define		TEST_TIMER

void timer_main();
void uart0_init();
void uart1_init();
void timer0_init(void);
void timer1_init(void);
void timer2_init(void);
void timer3_init(void);		   
void set_timer_IP(byte TimerNum, byte Priority);   
void SetPort1InOut(byte PinNum, bit Direction);	 //0:out	1:in
void cal_sd_dma_out_addr(void);
void CRC16_test(void);

#endif
