#ifndef	_bank_config_h_
#define _bank_config_h_


#define			BANK_CODE_CELL_LEN				5
#define			BANK_CODE_BANKS					6		
#define 		BANK_CODE_MUL_TIMES				4				   	//bank code �ZZz
#define    		BANK_CODE_LINK_ADDR_XRAM_SIZE	(BANK_CODE_BANKS * 7 * BANK_CODE_MUL_TIMES)
#define 		BANK_CODE_START_IRAM			0x9700
//#define    		BANK_CODE_LINK_ADDR_XRAM_OFFSET	0x500	   //


#define			CodeCell			 (unsigned short)(528) //89

#define EN_USE_AX215S_CHIP_MASK_ROM_FUN		1


#if  EN_USE_AX215S_CHIP_MASK_ROM_FUN


#define KickLoadFlash_MaskRom 						(*((void (*)(void))0xa02f))
#define KickLoadFlash_MaskRom_Not_FixNormal 		(*((void (*)(void))0xa032))
#define KickLoadFlash_MaskRom_FixNormal 			(*((void (*)(void))0xa035))

#define NF_Read_Data_MaskRom 						(*((void (*)(void))0xa741))
#define NF_Read_Data_MaskRom_Not_FixNormal 			(*((void (*)(void))0xa744))
#define NF_Read_Data_MaskRom_FixNormal 				(*((void (*)(void))0xa747))

#define L_NF_ECC_MaskRom 				(*((void (*)(void))0xa6e2))
#define BCH_XOR_ERR_Load_Code_MaskRom 	(*((void (*)(void))0xa644))


#endif


#endif