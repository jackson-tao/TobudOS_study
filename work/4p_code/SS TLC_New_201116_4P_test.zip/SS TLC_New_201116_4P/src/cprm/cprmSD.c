#include "inc\nand_flash.h"
#include "inc\sd_spi_com_define.h"
#include "tank.h"
#include "ax215_exinst.h"
	
extern u8 data yScrtyUnitCnt,LBATmp3,LBATmp2,LBATmp1,LBATmp0;
extern bit bCPRM_E_D_Flag,bFirstEnDecodeData,bScrtyMode,bVisitCprmDataMode,bAKERcvType,bAKEVerifyErr,bCprmDmaDataMode;
extern bit bCMD0Rcv,bSingleWriteTask, READY_FOR_DATA, bReadType;

EXTRN CODE (SD_STATE,CPRM_User_Cap,SecurityArgm)
EXTRN CODE (Sel_Buffer_Addr,wait_cmd_rps_ready,wait_dma_in_ready)
EXTRN CODE (AKE_CHALLENGE_2_BUF,AKE_CHALLENGE_1_RPS_BUF,AKE_CHALLENGE_2_RPS_BUF,AKE_CHALLENGE_1_BUF)
EXTRN CODE (COPY_DPTR1_8_BYTE_DATA_TO_DPTR0,READ_LBA_IN_TAB)
EXTRN CODE (Ks,Kmu_x,KmuTmp,Kmu_array,CPRM_MKB_OFFSET,C2_G,PUSH_ER0_TO_ER4,CPRM_EN_DE_CODE_BUF_FETCH_CUR_BUF_DPTR,C2_ECBC_DCBC,C2_E_D)
EXTRN CODE (POP_ER0_TO_ER4)
//PUBLIC GET_SCRTY_LBA
//PUBLIC DMA_MKB_PRO 							;dma_mkb_pro
//PUBLIC AKE_REV_DATA_PROCESS 			;ake_rev_data_process
//PUBLIC CPRM_ENCODE_DATA	

//?PR?SD_CPRM	SEGMENT CODE
//RSEG  ?PR?SD_CPRM
/************************************************************************************************************************
GetScrtyLBA:
;input:  none
;output: ER3 = LBA[22:0],yScrtyUnitCnt,bScrtyMode,bFirstEnDecodeData
;		// ER1 = SecurityArgm[3:0] 
************************************************************************************************************************/

#define 	get_scrty_lba	getScrtyLBA
void getScrtyLBA(void)
{
#if EN_CPRM
				_push_(DPCON);
				DPCON = ((1<<4)|(1<<3));//		;??;??????,DPTR ??,??DPTR0

			  bFirstEnDecodeData = 1;				;First encode/decode data.
#pragma asm
 			  MOV		DPTR, # SecurityArgm
				MOV32_ER3_EDP0
//				MOV32	ER1, ER3						;ER1 as copy from @SecurityArgm
				MOV		yScrtyUnitCnt, ER33
				MOV		ER33, # 0x00

				MOV		A,	ER32
				RLC		A
				MOV		bScrtyMode, C
				ANL		ER32, # ~(1<<7)

				MOV		DPTR, # SD_STATE
				MOVX	A,	@DPTR

				JNB		bScrtyMode, IS_NOT_SCRTY_MODE	;?SD state?,???????Security state?
				
				ORL		A,	# (1<<5)
				JMP		WRITE_STATE_TAB

	IS_NOT_SCRTY_MODE:
				
				ANL		A,	# ~(1<<5)

	WRITE_STATE_TAB:

				MOV		DPTR, # SD_STATE
				MOVX	@DPTR, A
	

//				MOV		DPTR, # CPRM_User_Cap		  	;??Protected area?LBA???
//				MOV32	ER0, EDP0
//				ADD32	ER3, ER0, ER3

				MOV		DPTR, # CPRM_User_Cap		  	;??Protected area?LBA???
//				MOV32	ER2, EDP0
//				ADD32	ER3, ER2, ER3
				ADD32_ER3_EDP0_ER3
#pramga endasm
				_pop_(DPCON);

#endif
}				
				
				
; /*********************************MKB deal**********************************************/
; /************************************************************************************************************************
; DMA_MKB_Task
; ;input:	LBATmp0,LBATmp1,LBATmp2,LBATmp3
; ;output: MKB_LBA, bCprmDmaDataMode, A
; ;A , B : 0:Normal DMA; 1: err, do not DMA
; ;MKB_LBA  = 64 * 2(Sector) * MKB_ID + Unit_offset + @CPRM_MKB_OFFSET
; ************************************************************************************************************************/
void dma_mkb_pro(void)
{
//DMA_MKB_PRO:
#if EN_CPRM	
				_push_(ACC);
				_push_(DP0H);
				_push_(DP0L);	
				
			if (LBATmp2 & (~15) == 0)					//;MID_ID???15
			{				
		#pragma asm
				MOV		A, LBATmp2					//;MKB_Index???????
//				MOV		MKB_index, A				;MKB_ID copy

				//;???MKB???Kmu???Kmu_x?
				//;@Kmu_x = @(Kmu_0 + 8 * MKB_index)	
				MOV		DPTR, # Kmu_x
			
				CLR32_ER0
				
				MOV		ER01, # HIGH (Kmu_array)
				MOV		ER00, # LOW	(Kmu_array)	

				RL		A
				RL		A
				RL		A		//MKB ID * 8

				CLR32_ER1
				MOV		ER10, A
				ADD32_ER0_ER0_ER1
				MOV		DP1H, ER01
				MOV		DP1L, ER00		
							
				CALL	copy_dptr1_8_byte_data_to_dptr0			//GET Kmu 2 Kmu_x

				MOV		DPTR, # Kmu_x				//HIGHEST BYTE CLEAR(BIG ENDIAN),WE JUST NEED LAST 7 BYTE
				CLR		A
				MOVX	@DPTR, A

//;				MOV		yScrtyUnitCnt, LBATmp3		//;Unit_Count
				MOV		A, LBATmp3
				DEC		A
				ANL		A, # (128-1)				 
				INC		A
				MOV		yScrtyUnitCnt, A			 //;Unit_Count,?????,????128?sector cnt

				CLR32_ER0
				MOV		ER00,  LBATmp0	 //  			;Unit_offset[0]
				MOV		ER01,  LBATmp1	 // 			;Unit_offset[1]

				CLR32_ER1
				MOV		ER10, # (64 * 2)	//			;64KB = 64 * 2 Sector
				MOV		ER12, LBATmp2		//		;MKB_ID

				MUL16_ER1							//;ER1 = 64 * 2 * MKB_ID
				ADD32_ER0_ER0_ER1			//	;ER2 = 64 * 2 * MKB_ID + Unit_offset

				MOV		DPTR, # CPRM_MKB_OFFSET
				CALL	READ_LBA_IN_TAB		//		;ER3 = 	@ CPRM_MKB_OFFSET

				ADD32_ER3_ER0_ER3				//;ER3 = 64 * 2(Sector) * MKB_ID + Unit_offset + @CPRM_MKB_OFFSET

				SETB	bCprmDmaDataMode		//	;Read MKB data
			
				CLR		bVisitCprmDataMode

				CLR		A						//	;Normal DMA
		#pragma endasm
		} else {
//	DMA_MKB_Task_NOT_DMA_DATA:
		#pragma asm
				MOV		A, 		# 1			//			;err
				MOV		SSTA_P1,	# 4	//				;Turn to transfer state
		#pragma endasm
		}
//	DMA_MKB_PRO_END:
		#pramga asm
				MOV		B,  A	
		#pragma endasm
		
				_pop_(DP0L);
				_pop_(DP0H);
				_pop_(ACC);
#endif
}		
				
				
/***********************************************************************************************************************
;AKE_REV_DATA_PROCESS:
;input:	 bAKERcvType
;0: AKE Rcv challenge1; 1: AKE Rcv challenge2_rps 
;output:
/***********************************************************************************************************************/
void ake_rev_data_process(void)
{
#if EN_CPRM
				_push_(DPCON);
				_push_(DP0H);
				_push_(DP0L);
				_push_(PAGEMAP);
				PAGEMAP = 0x01;
				
				DPCON = ((1<<4)|(1<<3))	;//	;??;??????,DPTR ??,??DPTR0

				wait_cmd_rps_ready(); //Wait_CMD_Rps_Only
//;-----------------------------------------------------------------------------------------------------------------------

//				CALL	wait_dma_in_ready//Wait_DMA_In_Ready
		do {
				if (bCMD0Rcv)
					goto	wait_ake_rev_data_end
		} while(!SDIPND);
	
				SDIPND = 0; //							;??????
				READY_FOR_DATA = 0;

//	WAIT_AKE_REV_DATA_END:
			   	
				bSingleWriteTask = 0;
				SDIIE = 1;						//  	;Enable sd dma in isr.							 
//;-----------------------------------------------------------------------------------------------------------------------
																						
				SDICON_P1 &= ~(1 << 0);//	   			;Disable receive data on SD bus.

 				if (SCCRC) {
					goto	rcv_ake_data_stop			//	;Data CRC err,data should not be programed.
				}
//	ake_data_crc_ok:
									
				 SSTA_P1 = 0x07;	   				//	;DMA IN complete,then go to "program" state.
				
//;-----------------------------------------------------------------------------------------------------------------------
				if (bAKERcvType)//AKE_CHALLENGE2_RPS_PROCESS
				{
//JMP		AKE_RCV_DATA_RPOCESS_END
//;-----------------------------------------------------------------------------------------------------------------------						
//	AKE_CHALLENGE2_RPS_PROCESS:

				//;Verify challenge2 & Rps.--> C2_G(Kmu,challenge2) =? challenge2_rps

				DPTR1 = (u16)(AKE_CHALLENGE_2_BUF);

				DPTR =  AKE_CHALLENGE_1_RPS_BUF;//				  	;AKE_CHALLENGE_1_RPS_BUF as tmp. 
				
				copy_dptr1_8_byte_data_to_dptr0();

			  DPTR = Kmu_x;

				DPTR1 = (u16)(AKE_CHALLENGE_1_RPS_BUF);//		   	;AKE_CHALLENGE_1_RPS_BUF as tmp. 
				
				bFirstEnDecodeData = 1;
				c2_g();
				bFirstEnDecodeData = 0;
	#pragma asm
				MOV		DPTR, # AKE_CHALLENGE_2_RPS_BUF
				MOV32_ER0_EDP0
				MOV32_ER1_EDP0

				MOV		DPTR, # AKE_CHALLENGE_1_RPS_BUF			//	 	;AKE_CHALLENGE_1_RPS_BUF as tmp. 

				MOV32_ER2_EDP0
				MOV32_ER3_EDP0
	
	
				//;challenge2 =? challenge2_rps

				XRL32_ER0_ER2
				JNB		EZ, C2G_VERIFY_ERR						//		;EZ=0 -> ER0 != ER2 -> AKE Verify Err
				XRL32_ER1_ER3
				JNB		EZ, C2G_VERIFY_ERR						//		;EZ=0 -> ER1 != ER3 -> AKE Verify Err
#pragma endasm				
			//	;challenge2 == challenge2_rps...

			//	;Cal. challenge_1_rps

				DPTR1 = (u16)(AKE_CHALLENGE_1_BUF);

				DPTR = AKE_CHALLENGE_1_RPS_BUF;
				copy_dptr1_8_byte_data_to_dptr0();

			  DPTR = Kmu_x;
				DPTR1 = (u16)(AKE_CHALLENGE_1_RPS_BUF);

				c2_g();
				
	#pragma asm
				;KmuTmp = ~Kmu
				MOV		DPTR, # Kmu_x
				MOV32_ER0_EDP0
				MOV32_ER1_EDP0

				NOT32_ER0
				NOT32_ER1

				MOV		DPTR, # KmuTmp
				MOV32_EDP0_ER0
				MOV32_EDP0_ER1
			
				//;Initial Ks;   Ks = Challenge1 ? Challenge2 

				MOV		DPTR, # AKE_CHALLENGE_1_BUF
				MOV32_ER0_EDP0
				MOV32_ER1_EDP0
			
				MOV		DPTR, # Ks

				MOV32_EDP0_ER0
				MOV32_EDP0_ER1

				MOV		DPTR, # AKE_CHALLENGE_2_BUF
				MOV32_ER0_EDP0
				MOV32_ER1_EDP0

				MOV		DPTR, # Ks
				
				XRL32_EDP0_ER0
				XRL32_EDP0_ER1
	#pragma endasm					
						    
				//;Ks = C2_G(~Kmu,challenge1?challenge2)

				DPTR = KmuTmp;
				DPTR1 = (u16)Ks;
				
				bFirstEnDecodeData = 1;
				c2_g();
				bFirstEnDecodeData = 0;

				//;Pick up the argument in challenge1, then save...

				DPTR = Kmu_x;

				DPTR1 = (u16)(AKE_CHALLENGE_1_BUF);

				bCPRM_E_D_Flag = 1;
				
				bFirstEnDecodeData = 1;
				c2_e_d();
				bFirstEnDecodeData = 0;
#pragma asm
				MOV		DPTR, # AKE_CHALLENGE_1_BUF
				
				MOV32_ER0_EDP0
				MOV		DPTR, # SecurityArgm
				MOV32_EDP0_ER0				
#pragma endasm

				goto ake_rcv_data_process_end
#pragma asm
 	C2G_VERIFY_ERR:
#pragma endasm

				bAKEVerifyErr = 1;
			}
//;-----------------------------------------------------------------------------------------------------------------------
ake_rcv_data_process_end:
				SDICON_P1 |= (1 << 1);//				;D0 CLR busy 
RCV_AKE_DATA_STOP:
				EA = 0;
				if (!bCMD0Rcv) {
						SSTA_P1 = 0x04;//	 					;Go to transfer state
				}
rcv_ake_data_end:

				EA = 1;
			
				bCMD0Rcv = 0;
//				CLR		bSingleWriteTask
				READY_FOR_DATA = 1;
				
				_pop_(PAGEMAP);
				_pop_(DP0L);
				_pop_(DP0H);
				_pop_(DPCON);
#endif
}				


/*************************************************************************************************************************
CPRM_ENCODE_DATA
;input: CPRM_EN_DE_CODE_BUF_DPTR_H/CPRM_EN_DE_CODE_BUF_DPTR_L
2 byte CPRM_BUF_DPTR??,???XDATA?,(DPTR_H??0x4098 ?,DPTR_L??0x4099 ?)
//????flash???XOR??,???flash?XOR???,???,?C2_ECBC????????data???,?SD DMA????XOR??
//Encode time 978us @80MHz
***************************************************************************************************************************/
void cprm_encode_data(void)
{
#if EN_CPRM
 			if (bVisitCprmDataMode)
			{
				_push_(DPCON);
				_push_(R8);
				_push_(DP1H);
				_push_(DP1L);
					
				push_er0_to_er4();
																				
//				MOV		PSW, # 0x00	   							;Register BANK 0

//				;C2_ECBC data
//				MOV		R02,yBuffer_Index
//				CALL	Sel_Buffer_Addr
//				MOV		DP1H, R01								;DPTR1
//				MOV		DP1L, R00
				cprm_en_de_code_buf_fetch_cur_buf_dptr();					

//				MOV		DPTR, # Ks								;DPTRk0 = key[]

				DPTR0 = Ks;					//	;DPTRk0 = key[]
		#pragma asm
				MOV		R3, # (512/8)							;data_len/8
		#pragma endasm
		
				bCPRM_E_D_Flag = 0;
				c2_ecbc_dcbc();
				//CALL	C2_ECBC

				bFirstEnDecodeData = 0;
							
				pop_er0_to_er4();
						
//				POP		PSW

				_pop_(DP1L);
				_pop_(DP1H);
				_pop_(R8);
				_pop_(DPCON);
			}
//	DO_NOT_ENCODE_DATA:
#endif			
}				

	
//CTB:CPRM DEBUG	
/***************************************************************************************
��ʱ����޷���C��Ƕ���HIGH,LOW���⣬�������ĺ���ʹ��,numΪ16�ı���
�ⲿ��ҪPUSH/POP DPTR1��R8,��ת
****************************************************************************************/
void GET_KS(void)
{
#if EN_DEBUG_DMA_KMU		
#pragma asm
		MOV 	DP1H,#HIGH (Ks)
		MOV 	DP1L,#LOW (Ks)
		MOV 	R8,#16															
#pragma endasm
		opy_data_2_dmaStart();
#endif
}

void get_challenge1(void)
{
#if	EN_DEBUG_DMA_KMU
#pragma asm
		MOV 	DP1H,#HIGH (AKE_CHALLENGE_1_BUF)
		MOV 	DP1L,#LOW (AKE_CHALLENGE_1_BUF)
		MOV 	R8,#32
#pragma endasm																	
		copy_data_2_dmaStart();
#endif
}


void GET_KMU(void)
{
#if	EN_DEBUG_DMA_KMU
#pragma asm
		MOV 	DP1H,#HIGH (Kmu_array)
		MOV 	DP1L,#LOW (Kmu_array)
		MOV 	R8,#128
#pragma endasm
		copy_data_2_dmaStart();
#endif		
}		
		/**********************************************************************
		copy dataͨ��COPY�ӿڣ�����copy��DMA OUT��ʼ��
		***********************************************************************/
void copy_data_2_dmaStart(void)
{
#if EN_DEBUG_DMA
#pragma asm
		PUSH 	ACC
		PUSH	DPCON
		MOV 	A,R8
		MOV 	DP0H,#HIGH	(BUFFER_START_ADDR)
		MOV		DP0L,#LOW	(BUFFER_START_ADDR)
		MOV 	DPCON,#0x30 		//big endian,DPTR0 Start,auto inc,toggle mode
		CLR 	C
		COPY_DATA_LOOP:
		MOV32_ER1_EDP1
		MOV32_EDP0_ER1

		MOV32_ER1_EDP1
		MOV32_EDP0_ER1

		MOV32_ER1_EDP1
		MOV32_EDP0_ER1

		MOV32_ER1_EDP1
		MOV32_EDP0_ER1

		SUBB	A,#16
		JNZ 	COPY_DATA_LOOP
		POP		DPCON
		POP 	ACC
#pragma endasm
#endif	
}

//PUBLIC FILL0								
void fill0(void)
{
#if EN_DEBUG_DMA
#pragma asm
	PUSH 	ACC
	PUSH	DPCON
	CLR 	A
	MOV 	ER10,A
	MOV 	ER11,A
	MOV 	ER12,#0xaa
	MOV 	ER13,A

	MOV 	DP0H,#HIGH	(BUFFER_START_ADDR)
	MOV		DP0L,#LOW	(BUFFER_START_ADDR)
	MOV 	DPCON,0X10		//DPTR0 AUTO INC
	MOV		B,#2
UPPER_LOOP:
	CLR		A
	CLR		C
FILL0_LOOP:
	MOV32_EDP0_ER1
	MOV32_EDP0_ER1			
	MOV32_EDP0_ER1							
	MOV32_EDP0_ER1
	SUBB	A,16
	JNZ		FILL0_LOOP
	MOV		A,B
	DEC		A
	MOV		B,A
	JNZ	UPPER_LOOP
	
//	;MOV 	DP1H,#HIGH (Ks)
//	;MOV 	DP1L,#LOW (Ks)														
//	;MOV 	DP0H,#HIGH	(BUFFER_START_ADDR)
//	;MOV		DP0L,#LOW	(BUFFER_START_ADDR)
//	;MOV 	DPCON,#0x30 		//big endian,DPTR0 Start,auto inc,toggle mode
//	;MOV 	A,#16	
//	;CLR 	C
//;COPY_LOOP:
//	;MOV32_ER1_EDP1
//	;MOV32_EDP0_ER1
//	;MOV32_ER1_EDP1
//	;MOV32_EDP0_ER1
//	;MOV32_ER1_EDP1
//	;MOV32_EDP0_ER1
//	;MOV32_ER1_EDP1
//	;MOV32_EDP0_ER1
//	;SUBB	A,#16
//	;JNZ 	COPY_LOOP
	
	POP		DPCON
	POP 	ACC
#pragma endasm	
#endif		
	//SJMP	GET_KS	
}