#include "nand_flash.h"
#include "tank.h"
#include "ax215_exinst.h"
#include "sd_spi_com_define.h"
;$include (..\inc\extern_data.h)

EXTRN CODE (_SK_TMP,_Key,_Inkey,C2_GKeyTmp,Ks,Kmu_x,KmuTmp)
EXTRN BIT (bCPRM_E_D_Flag,bFirstEnDecodeData,bScrtyMode,bVisitCprmDataMode)
EXTRN CODE (SD_Km_DPTR,Kmu_array,MID,SBOX_EN_DECODE_KEY,Kmux_DPTR_tmp,CPRM_User_Cap,SecurityArgm,AKE_CHALLENGE_2_BUF)
EXTRN CODE (COPY_DPTR1_8_BYTE_DATA_TO_DPTR0,C2_G,AKE_CHALLENGE_1_BUF,AKE_CHALLENGE_1_RPS_BUF)
EXTRN DATA (yScrtyUnitCnt)
;EXTRN CODE (_SecretConstant)
/***************************************************************************************************************************
;void initial_cprm_pamameter(void)
;Cprm������ʼ��
***************************************************************************************************************************/
; void initial_cprm_pamameter(void)
?PR?INITIAL_CPRM_PAMAMETER?CPRM_INITIAL SEGMENT CODE
RSEG  ?PR?INITIAL_CPRM_PAMAMETER?CPRM_INITIAL
PUBLIC 	INITIAL_CPRM_PAMAMETER
void initial_cprm_pamameter(void)
{
		init_sd_cprm_parameter();
}
			
/***************************************************************************************************************************
***************************************************************************************************************************/
?PR?CPRM_INITIAL?CPRM_INITIAL	SEGMENT CODE
RSEG  ?PR?CPRM_INITIAL?CPRM_INITIAL
/***************************************************************************************************************************
DPTR1_TO_DPTR0_COPY_MAX_256BYTE_DATA:
Copy @DPTR1 to @DPTR0. 
R0: data_len
***************************************************************************************************************************/
void dptr1_to_dptr0_copy_max_256byte_data(void)
{
#if EN_CPRM
#pragma asm
		PUSH	DPCON
	
		MOV	    DPCON,#31H							;Enable DPTR0/DPTR1 Auto INC ,select toggle enable,select DPTR1

	COPY_256BYTE_GO_ON:

		MOVX	A,@DPTR
		MOVX	@DPTR,A

		DJNZ	R0, COPY_256BYTE_GO_ON	

		POP		DPCON
#pragma endasm
#endif
}



/***************************************************************************************************************************/
;INIT_SD_CPRM_PARAMETER
/***************************************************************************************************************************/
void init_sd_cprm_parameter(void)
{
#if EN_CPRM

		_push_(DPCON);
		_push_(PSW);
//		MOV		PSW,  # 0x00

		DPCON = ((1<<4)|(1<<3));//���;Ĭ��ѭ����λ,DPTR �Լ�,Ĭ��DPTR0

#pragma asm
	  MOV		DPTR, #  SD_Km_DPTR
		MOVX	A,	@DPTR
		MOV		ER01,	A						;Km_DPTR_H
			  	
		MOV		DPTR, #  (SD_Km_DPTR + 1 )
		MOVX	A,	@DPTR
		MOV		ER00,	A						;Km_DPTR_L

	
		MOV		DP1H, 	ER01	 					;Src data
		MOV		DP1L,	ER00
		MOV		DP0H, # HIGH (SD_HS_CACHE_BUF_START_ADDR)			;Target buf
		MOV		DP0L, # LOW (SD_HS_CACHE_BUF_START_ADDR)
		MOV		R0, # (16*8)

		CALL	dptr1_to_dptr0_copy_max_256byte_data

 //-----------------------------------------------------------------------------------------------------------------------------
 //Copy MID to Kmu_x buf(Kmu_array)

		CLR32_ER0
 		MOV		ER01, # HIGH (Kmu_array)
		MOV		ER00, # LOW  (Kmu_array)
		MOV		B,	# 16


	COPY_MID_GO_ON:
	
		MOV		DP1H, # HIGH (MID)			   ;Cal. Kmu, MID as data ,Km_x as key 
		MOV		DP1L, # LOW  (MID)
		MOV		DP0H, ER01
		MOV		DP0L, ER00
								
	   	CALL	COPY_DPTR1_8_BYTE_DATA_TO_DPTR0

		CLR32_ER1
		MOV		ER10, # 8
		ADD32_ER0_ER0_ER1
		DJNZ	B, COPY_MID_GO_ON
#pragma endasm

#if 0
MOV		A, # 0xbb
CALL	Uart_Sent_Byte

MOV		B, # 8
MOV		DPTR, # MID
CALL	DEBUG_PRINTF_

MOV		B, # 128
MOV		DPTR, # _DATA_BUF		//KMx
CALL	DEBUG_PRINTF_

#endif
//-----------------------------------------------------------------------------------------------------------------------------
//Cal Kmu_x
	   		
		ER01 = ((u16)(SD_HS_CACHE_BUF_START_ADDR)>>8);		//;Kmx buf; Kmx as key
		ER00 = (u16)(SD_HS_CACHE_BUF_START_ADDR);		

		ER02 = (u16)(Kmu_array);
		ER03 = ((u16)(Kmu_array)>>8);//		;as data 

		yScrtyUnitCnt = 16;//			;as tmp Cnt 

	CAL_KMU_GO_ON:

		MOV		DP0H, 	# HIGH (Kmux_DPTR_tmp)	 
		MOV		DP0L,	# LOW (Kmux_DPTR_tmp)
		MOV32_EDP0_ER0

		MOV		DP0L, 	ER00
		MOV		DP0H, 	ER01  ;Km_n

		MOV		DP1L,	ER02		 
		MOV		DP1H, 	ER03  ;MID_n-->Kmu_n
			
		SETB	bFirstEnDecodeData
		CALL	C2_G
		CLR		bFirstEnDecodeData
			
		MOV		DP0H, 	# HIGH (Kmux_DPTR_tmp)	 
		MOV		DP0L,	# LOW  (Kmux_DPTR_tmp)
		MOV32_ER0_EDP0
		CLR32_ER1
		MOV		ER10,  # 8
		MOV		ER12,  # 8
		ADD32_ER0_ER0_ER1

		DJNZ	 yScrtyUnitCnt, CAL_KMU_GO_ON
		
#if EN_DEBUG_DMA_C1RSP	
		MOV		DP0H, # HIGH (AKE_CHALLENGE_1_BUF)	
  		MOV		DP0L, # LOW  (AKE_CHALLENGE_1_BUF)
		MOV 	ER03,#0xdd  //��˸�ʽ
		MOV 	ER02,#0xb3
		MOV 	ER01,#0xe7
		MOV 	ER00,#0x1a
		MOV32_EDP0_ER0
		MOV 	ER03,#0x55
		MOV 	ER02,#0xe9
		MOV 	ER01,#0x8f
		MOV 	ER00,#0x29
		MOV32_EDP0_ER0
		//;MOV 	ER03,#0x29	//С�˸�ʽ
		//;MOV 	ER02,#0x8f
		//;MOV 	ER01,#0xe9
		//;MOV 	ER00,#0x55
		//;MOV32_EDP0_ER0
		//;MOV 	ER03,#0x1a
		//;MOV 	ER02,#0xe7
		//;MOV 	ER01,#0xb3
		//;MOV 	ER00,#0xdd
		//;MOV32_EDP0_ER0
		DP1H = ((u16)(AKE_CHALLENGE_1_BUF)>>8);
		DP1L = (u16)(AKE_CHALLENGE_1_BUF);
		DPTR = AKE_CHALLENGE_1_RPS_BUF;
		copy_dptr1_8_byte_data_to_dptr0();

		DPTR = Kmu_x;
		ER03 = 0x00;	//��˸�ʽ
	#pragma asm
		MOV 	ER02,#0x7c
		MOV 	ER01,#0x4d
		MOV 	ER00,#0xc6
		MOV32_EDP0_ER0
		MOV 	ER03,#0x03
		MOV 	ER02,#0x20
		MOV 	ER01,#0x2b
		MOV 	ER00,#0x01
		MOV32_EDP0_ER0		
	#pragma endasm
	
		DPTR = Kmu_x;
		DP1H = ((u16)(AKE_CHALLENGE_1_RPS_BUF)>>8);
		DP1L = (u16)(AKE_CHALLENGE_1_RPS_BUF);
		c2_g();
		
		DP1H = ((u16)(Kmu_x)>>8);
		DP1L = (u16)(Kmu_x);
		DPTR = AKE_CHALLENGE_2_BUF;
		copy_dptr1_8_byte_data_to_dptr0();
#endif				
 	
		_pop(PSW);
		_pop(DPCON);
#endif

}


