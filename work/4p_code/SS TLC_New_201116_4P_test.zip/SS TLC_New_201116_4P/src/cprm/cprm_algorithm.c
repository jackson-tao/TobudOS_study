#include "tank.h"
#include "ax215_exinst.h"
#include "sd_spi_com_define.h"
#include "..\inc\extern_data.h"

extern bit bCPRM_E_D_Flag,bFirstEnDecodeData,bScrtyMode,bVisitCprmDataMode;
EXTRN DATA (yBuffer_Index)
EXTRN CODE (_SK_TMP,_Key,_Inkey,C2_GKeyTmp,Ks,Kmu_x,KmuTmp)
EXTRN CODE (CPRM_EN_DE_CODE_BUF_DPTR_H,CPRM_EN_DE_CODE_BUF_DPTR_L)
EXTRN CODE (Sel_Buffer_Addr)
EXTRN CODE (POP_ER0_TO_ER4,PUSH_ER0_TO_ER4,DPTR_Add_AB)
;EXTRN CODE (_SecretConstant)
	
PUBLIC COPY_DPTR1_8_BYTE_DATA_TO_DPTR0,READ_LBA_IN_TAB,C2_ECBC_DCBC,C2_E_D,C2_G
PUBLIC CPRM_EN_DE_CODE_BUF_POINT_TO_CUR_BUF,CPRM_DECODE_DATA

PUBLIC CPRM_EN_DE_CODE_BUF_FETCH_CUR_BUF_DPTR//,C2_ECBC_DCBC


?PR?CPRM_ALGORITHM	SEGMENT CODE
RSEG  ?PR?CPRM_ALGORITHM
									 
/***************************************************************************************************************************/
;input: R1, DPTR0
;function:DPTR0 = DPTR0 + R1 * 4
;output: DPTR0
/***************************************************************************************************************************/
void dptr0_4B_offset(void)
{
#if EN_CPRM
#pragma asm
		MOV		B,R1
		MOV		A,#4
#pragma endasm
		DPTR_Add_AB();
#endif		
}

/***************************************************************************************************************************/
;C2_ECBC_DCBC:
;input:DPTR0/DPTR1/R3
;DPTR0: Key pointer		  ;input key[6:0]
;DPTR1: Data pointer	  ;input data[7:0]
;R3:data_len/8  (R3==1 --> 1 * 8 byte)
;bCPRM_E_D_Flag: ;0: C2_E/C2_ECBC   1: C2_D/C2_DCBC.
;bFirstEnDecodeData 	;1:reload key 	0:keep  key and not reload
/***************************************************************************************************************************/
void c2_ecbc_dcbc(void)
{	
#if EN_CPRM
 		_push_(DPCON);
		_push_(PAGEMAP);
		_push_(ACC);
		
		PAGEMAP = 0X01;
		DPCON = 0x02; //�߼���λ	
#pragma asm
		MOV		ER00,DP1L
		MOV		ER01,DP1H
		MOV 	ER02,#0
		MOV		R8,#2		
		ROTR32_ER0_ER8		
	
		MOV		BCRADR0_P1,ER00
		MOV		BCRADR1_P1,ER01
		MOV		A,R3
		DEC		A
		MOV		BCBCNT0_P1,A
		MOV 	BCBCNT1_P1,#0
#pragma endasm		 
		
		DPCON = 0x1A; //dptr0 auto inc,logic rot,big endian
//		JNB		bFirstEnDecodeData,SKIP_LOADKEY
		if (bFirstEnDecodeData) {
	#pragma asm 
		MOV32_ER0_EDP0
	#pragma endasm
			BCKEY2_P1 = ER00;
			BCKEY1_P1 = ER01;
			BCKEY0_P1 = ER02;
	#pragma asm
		MOV32_ER0_EDP0
	#pragma endasm
			BCKEY6_P1 = ER00;
			BCKEY5_P1 = ER01;
			BCKEY4_P1 = ER02;
			BCKEY3_P1 = ER03;
			BCCON1_P1 = 0x01;		//load new key
		}
skip_loadkey:
	{		//using soft const 
		//;MOV		ER00,#LOW	(_SecretConstant)
		//;MOV 	ER01,#HIGH (_SecretConstant)
		//;MOV		ER02,#0
		//;ROTR32_ER0_ER8
		//;MOV 	BCRCADR0_P1,ER00
		//;MOV		BCRCADR1_P1,ER01  //using soft const
		//;MOV		BCCON1_P1,#0x01		;load new key
	}
		if (!bCPRM_E_D_Flag) {//ECBC
			BCCON_P1 = 0x65;		
		} else {							//DCBC
			BCCON_P1 = 0x75;
		}

		while((BCCON_P1 & 0X80) == 0);  //WAIT DONE
		BCCON_P1 |= 0x40;
	{	
		//;MOV		DPCON,	# ((1<<4)|(1<<3))	 		 ;���;Ĭ��ѭ����λ,DPTR �Լ�,Ĭ��DPTR0
		//;MOV32_ER0_EDP0							 ;fetch key
		//;MOV		ER03, # 0x00
		//;MOV32_ER1_EDP0
		//;SETB	bCPRM_E_D_Flag
		//;CALL	C2_ECBC_DCBC
	}
		_pop_(ACC);
		_pop_(PAGEMAP);
		_pop_(DPCON);

#endif
}		
		
/***************************************************************************************************************************
;C2_D:
;input:DPTR0/DPTR1
;DPTR0: Key pointer		 ;input key[6:0]
;DPTR1: Data pointer	 ;input data[7:0]
;bCPRM_E_D_Flag: ;0: C2_E/C2_ECBC   1: C2_D/C2_DCBC.
;bFirstEnDecodeData 	;1:reload key 	0:keep  key and not reload
/***************************************************************************************************************************/
void c2_e_d(void)
{
#if EN_CPRM
 		_push_(DPCON);
		_push_(PAGEMAP);
		_push_(ACC);

		PAGEMAP = 0x01;
		DPCON = 0x02;//�߼���λ	
	#pragma asm	
		MOV		ER00,DP1L
		MOV		ER01,DP1H
		MOV 	ER02,#0
		MOV		R8,#2		
		ROTR32_ER0_ER8		
	#pragma endasm
		BCRADR0_P1 = ER00;
		BCRADR1_P1 = ER01;
		
		BCBCNT0_P1 = 0;
		BCBCNT1_P1 = 0;
		 
		DPCON = 0x1A;//dptr0 auto inc,logic rot,big endian
		if (bFirstEnDecodeData) {
	#pragma asm		
			MOV32_ER0_EDP0
			MOV		BCKEY2_P1,ER00
			MOV		BCKEY1_P1,ER01
			MOV		BCKEY0_P1,ER02
			MOV32_ER0_EDP0
			MOV		BCKEY6_P1,ER00
			MOV		BCKEY5_P1,ER01
			MOV		BCKEY4_P1,ER02
			MOV		BCKEY3_P1,ER03
			MOV		BCCON1_P1,#0x01		//;load new keys
	#pragma endasm
		}
skip_loadkey2:
{//ʹ������SBOX	
	//	;MOV		ER00,#LOW (_SecretConstant)
	//	;MOV 	ER01,#HIGH (_SecretConstant)  
	//	;MOV		ER02,#0
	//	;ROTR32_ER0_ER8		
	//	;MOV 	BCRCADR0_P1,ER00
	//	;MOV		BCRCADR1_P1,ER01  ;using soft const
		
	//	;MOV		BCCON1_P1,#0x01		;load new key
//;bCPRM_E_D_Flag: ;0: C2_E/C2_ECBC   1: C2_D/C2_DCBC.	
}	
		if (!bCPRM_E_D_Flag) {//EEBC
			BCCON_P1 = 0x45;
		} else {//DEBC
//��ʱȡ��
			BCCON_P1 = 0x55;//DEBC 
		}
//;PUSH	PAGEMAP
//;MOV		PAGEMAP,#0x00		
//;ANL		P3DIR_P0,#NOT (1<<6)
//;XRL		P3_P0,#(1<<6)		
//;POP		PAGEMAP
wait_EBC_end:
		while((BCCON_P1 & 0X80) == 0);//WAIT DONE
		BCCON_P1 |= 0x40;
//EBC_end:
//;PUSH	PAGEMAP
//;MOV		PAGEMAP,#0x00		
//;ANL		P3DIR_P0,#NOT (1<<6)
//;XRL		P3_P0,#(1<<6)		
//;POP		PAGEMAP		
		_pop_(ACC);
		_pop_(PAGEMAP);
		_pop_(DPCON);
#endif
}		

/***************************************************************************************************************************
;C2_G(d1, d2) = C2_E(d1, d2) ? d2. 
;input:DPTR0/DPTR1
;DPTR0: Key pointer	 	;input key[6:0],for cal Kmu,that is Km
;DPTR1: Data pointer	;input data[7:0],for cal Kmu,that is MID
;TMP:C2_GKeyTmp
;bFirstEnDecodeData 	;1:reload key 	0:keep  key and not reload
/***************************************************************************************************************************/
void c2_g(void) 
{
#if EN_CPRM
#pragma asm
		PUSH	DPCON
		PUSH	DP1H
		PUSH	DP1L

		//;MOV		DPCON,	# ((1<<4)|(1<<3))		//;??;??????,DPTR ??,??DPTR0
		//;MOV32_ER0_EDP0						//;fetch key
		//;MOV		ER03, # 0x00					//	;??byte?�0�
		//;MOV32_ER1_EDP0
				
		//;MOV		DPTR, # C2_GKeyTmp 			//	;key_tmp
		//;CALL	COPY_DPTR1_8_BYTE_DATA_TO_DPTR0
		
		MOV		DPCON,#0x19 //;dptr1 auto inc,big endian
		MOV32_ER1_EDP1
		MOV32_ER0_EDP1
		MOV		DP1H,#HIGH C2_GKeyTmp
		MOV		DP1L,#LOW  C2_GKeyTmp
		MOV32_EDP1_ER1
		MOV32_EDP1_ER0
		
		MOV		DP1H,#HIGH C2_GKeyTmp
		MOV		DP1L,#LOW  C2_GKeyTmp
		CLR		bCPRM_E_D_Flag
		CALL	C2_E_D

		MOV		DP1H,#HIGH C2_GKeyTmp
		MOV		DP1L,#LOW  C2_GKeyTmp
		MOV32_ER0_EDP1
		MOV32_ER1_EDP1
		
		POP		DP1L
		POP		DP1H

		XRL32_EDP1_ER0					//	;C2_G result
		XRL32_EDP1_ER1

		POP		DPCON
#pragam endasm
#endif
}

;/************************************************************************************************************************
;* �Ρ�����:A B
;* ��������:����A B����DPTR��ַƫ�� 
;************************************************************************************************************************/
;DPTR_Add_AB:
				;MUL		AB
				;MOV		R8,B
				;MOV		B ,A						;low				
				;ADDDP0								;DPTR0 + (R8 B)				
				;RET	
/************************************************************************************************************************
READ_LBA_IN_TAB
;input: DPTR0
;Function: ER3 = @DPTR0 ;��˶���
************************************************************************************************************************/
void read_lba_in_tab(void)
{				
#pragma asm
		PUSH	DPCON

		MOV		DPCON,	# ((1<<4)|(1<<3))			;���;Ĭ��ѭ����λ,DPTR �Լ�,Ĭ��DPTR0
		MOV32_ER3_EDP0
	
		POP		DPCON
#pragma endasm
}
/***************************************************************************************************************************/
;input: DPTR0,DPTR1
;function: DPTR1[7:0] --> DPTR0[7:0]
;TMP: ER2,ER3
/***************************************************************************************************************************/
void copy_dptr1_8_byte_data_to_dptr0(void)
{
#if EN_CPRM
#pragma asm
		PUSH	DPCON

		MOV		DPCON,	# ((1<<4)|(1<<3))		;���;Ĭ��ѭ����λ,DPTR �Լ�,Ĭ��DPTR0
		MOV32_ER2_EDP1
		MOV32_ER3_EDP1
		MOV32_EDP0_ER2
		MOV32_EDP0_ER3

		POP		DPCON
#pragma endasm 
#endif
}



/*************************************************************************************************************************
CPRM_EN_DE_CODE_BUF_POINT_TO_CUR_BUF
;input: B
B: buf index
***************************************************************************************************************************/
void cprm_en_de_code_buf_point_to_cur_buf(void)
{
#if EN_CPRM	
				push_er0_to_er4();

//				MOV		ER02,yBuffer_Index
				R02 = B;
				Sel_Buffer_Addr();
//				MOV		DP1H, ER01								;DPTR1
//				MOV		DP1L, ER00
				DPTR = CPRM_EN_DE_CODE_BUF_DPTR_H;
	#pragma asm
				MOV		A,	ER01
				MOVX	@DPTR, A
	#pragma endasm
	
				DPTR = CPRM_EN_DE_CODE_BUF_DPTR_L;
	#pragma asm
				MOV		A,	ER00
				MOVX	@DPTR, A
	#pragma endasm
	
				pop_er0_to_er4();
#endif
}

/*************************************************************************************************************************
CPRM_EN_DE_CODE_BUF_FETCH_CUR_BUF_DPTR
***************************************************************************************************************************/
void cprm_en_de_code_buf_fetch_cur_buf_dptr(void)
{
#if EN_CPRM
				DPTR = CPRM_EN_DE_CODE_BUF_DPTR_H;
	#pragma asm
				MOVX	A, @DPTR
				MOV		B, A
	#pragma endasm
	
				DPTR = CPRM_EN_DE_CODE_BUF_DPTR_L;
	#pragma asm
				MOVX	A, @DPTR
	#pragma endasm
	
				DP1L = ACC;	//	;DPTR1							
				DP1H = B;										
#endif
}

/*************************************************************************************************************************
CPRM_DECODE_DATA
;input: CPRM_EN_DE_CODE_BUF_DPTR_H/CPRM_EN_DE_CODE_BUF_DPTR_L
Decode time 990us @80MHz
***************************************************************************************************************************/
void cprm_decode_data(void)
{
#if EN_CPRM
			if (bVisitCprmDataMode) 
			{

				_push_(DPCON);
				_push_(R8);
				_push_(DP1H);
				_push_(DP1L);
//				PUSH	PSW

				push_er0_to_er4();
															
//				MOV		PSW, # 0x00	   						;Register BANK 0

//				MOV		R8Tmp,yBuffer_Index
//				CALL	Sel_Buffer_Addr
//				MOV		DP1H, ER01							;DPTR1
//				MOV		DP1L, ER00
				cprm_en_de_code_buf_fetch_cur_buf_dptr();			
						
//				MOV		DPTR, # Ks							;DPTRk0 = key[]
				dptr0 = Ks;				//		;DPTRk0 = key[]
			
	#pragma asm
				MOV		R3, # (512/8)						;data_len/8
	#pragma endasm
				bCPRM_E_D_Flag = 1;
				c2_ecbc_dcbc();
				//;CALL	C2_DCBC

				bFirstEnDecodeData = 0;
			
				pop_er0_to_er4();

//				POP		PSW
				_pop_(DP1L);
				_pop_(DP1H);
				_pop_(R8);
				_pop_(DPCON);
			}
		
   //DO_NOT_DECODE_DATA:
#endif
}

