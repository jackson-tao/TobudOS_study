#include "inc\common.h"	
#include "inc\uart.h"	
#include "inc\sd_spi_com_define.h"

//uart tx P01(NCE1)
//      rx P36(NRB1)
void uart_init_timer0(void)
{	
	_push_(PAGEMAP);
	
	sfrpage(0);  
			
	CLKCON1_P0 |= 1<<4;   //PPGA 60MHZ ----> div2 SYSCLK 30MHZ
	
#if !_SYSCLK_30MHZ	
	CLKCON1_P0 &= ~(1<<2);//not div 2
#endif

	P0DIR_P0 &= ~(1<<1);
	
//SDD2 TX	
#if EN_UART_IO_MAP_2_SD_D2
	PORTCON_P0 |= (1 << 3);
#else 
	PORTCON_P0 &= ~(1<<3);
#endif
	
	sfrpage(3);	 
 	TMRCNT_P3  = 0;
		
	TMRPR_P3   = 0xa5;//0x9d;//ab;  //0xa2; //0xA1;    //k8
	
	TMRCON_P3  = 0x11;

#if (!UART_SYN)
//��ӡ1byte��Ч���ַ���Ŀ���Ǳ�֤done��pendingΪ1,putchar()�ȵ�pending���ٴ�ӡ��һbyte
  TMRCON_P3 &= ~BIT(3);				//clr pending
	TMRSPBUF_P3 = 0x0d;					//�س�����
	TMRCON_P3 |= BIT(3); 	            //kick
  while((TMRCON_P3 & BIT(3)) == 0);
//   TMRCON_P3 &= ~BIT(3);				//������
	putchar(0x0a);
 #endif
	
	_pop_(PAGEMAP);
	
}



/*****************************

*****************************/
void Uart_Send_Byte(u8 dat)
{
#if BAUDRATE
	  _push_(PAGEMAP);
		_push_(ACC);
		PAGEMAP = 0x03;
		TMRSPBUF_P3 = dat;
		
  	TMRCON_P3 |= (1<<3);	//kick
		while(!(TMRCON_P3&(1<<3)));
   	TMRCON_P3 &= ~(1<<3);	
		_pop_(ACC);
  	_pop_(PAGEMAP);
#else 
//		dat;
	
#endif
}

/*****************************
*****************************/
char code HexTable[16]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
void printHexSync(u8 dat)
{
		_push_(DPCON);
		_push_(DP0H);
		_push_(DP0L);
		DPCON = 0;
		Uart_Send_Byte(HexTable[dat>>4]);
		Uart_Send_Byte(HexTable[dat&0x0F]);
		_pop_(DP0L);
		_pop_(DP0H);
		_pop_(DPCON);
}

/*****************************
void prints
�ı�R1,R2,R3
*****************************/
void prints(u8 *p)
{
#if BAUDRATE
	while(*p)
	{
		Uart_Send_Byte(*p);
		p++;
	}
#else 
	if (*p == 0) { };
#endif	
}



						   
void printf_buf_fun(unsigned char xdata *ptr, unsigned short len)
{
		printf("\n");
}
