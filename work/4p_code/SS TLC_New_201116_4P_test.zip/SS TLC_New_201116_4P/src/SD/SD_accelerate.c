
#include "inc\common.h"				 
#include "inc\ax215_exinst.h"	
#include "inc\nand_flash.h"	
#include "inc\SD_accelerate.h"		
#include "inc\sd_spi_com_define.h"		
#include "inc\array_FIFO.h"	

extern u8 data yBlockLen0, yBlockLen1, yCMD_Index/*, LBATmp3, LBATmp2, LBATmp1, LBATmp0*/;
extern bit bDataIn_Flag;
extern bit bSDHC;
extern u8 code LBA_TMP;

//xdata u8 buf_addr_tab[BUF_ADDR_TAB_LEN] _at_ BUF_ADDR_TAB_ADDR;
//xdata u8 buf_LBA_tab [BUF_LBA_TAB_LEN]  _at_ BUF_LBA_TAB_ADDR;
//xdata u8 sd_hs_buf   [SD_HS_BUF_LEN] 	_at_ SD_HS_BUF_ADDR;

u8 code code_sd_hw_dma_in_addr_lba_buf [SD_HS_CACHE_BUF_CNT * 4] _at_ (SD_HW_DMA_IN_BUF_LBA_TAB_START_ADDR);
u8 xdata sd_hw_dma_in_addr_lba_buf [SD_HS_CACHE_BUF_CNT * 4] _at_ (SD_HW_DMA_IN_BUF_LBA_TAB_START_ADDR);

u8 code code_sd_hw_dma_out_addr_buf [READ_BUF_NUM * 4]           _at_ (SD_HW_DMA_OUT_BUF_TAB_START_ADDR);
u8 xdata sd_hw_dma_out_addr_buf [READ_BUF_NUM * 4]           _at_ (SD_HW_DMA_OUT_BUF_TAB_START_ADDR);

void init_read_acce_buf_config(u8 buf_start_index)
{	
	_push_(DPCON);
	
	DPCON = 0x18;				//���� ���  dptr0
	DPTR0 = sd_hw_dma_out_addr_buf;
	R8 = buf_start_index;		
	
	for(B = 0; B < READ_BUF_NUM; B++){
		
		ER02 = R8;
		Sel_Buffer_Addr();		//buf = (ER01, ER00)	
		ER13 = ER01;
		ER12 = ER00;
		ER11 = 0;
		ER10 = 0;
		
		#pragma asm
		MOV32_EDP0_ER1
		#pragma endasm
		
		if(++R8 == READ_BUF_NUM){
			R8 = 0;
		}
			
	}			
	_pop_(DPCON);
}

//RBLKCNT_P1 !=0 ������dma out
void sd_pre_read_config(u8 buf_start_index)
{	
	init_read_acce_buf_config(buf_start_index);	
	
	_push_(PAGEMAP);	
	PAGEMAP = 0x01;	

//			SDDL0_P1 = yBlockLen0;
//			SDDL1_P1 = yBlockLen1;
	SDDL0_P1 = 0xff;  //��֧�ֱ䳤
	SDDL1_P1 = 0x01;
		
	ACCON1_P1 |= BIT(4);//reset	
	ACCON1_P1 &= ~(BIT(1)  | BIT(0));		//�ֶ����hold/enable bit. Ӳ��bug.
	ACCON1_P1 |= BIT(7);//���	
	
	RCFGA1_P1 = (u8)((SD_HW_DMA_OUT_BUF_TAB_START_ADDR >> 8) & 0x00FF);
	RCFGA0_P1 = (u8)((SD_HW_DMA_OUT_BUF_TAB_START_ADDR >> 0) & 0x00FF);
	
	RBLKLEN_P1 = READ_BUF_NUM;	//				
	RBLKCNT_P1 = 0;

	ACCON1_P1 |= BIT(0);		//enable	
	
	_pop_(PAGEMAP);
	
}


//extern unsigned char data yBufIndexCopyTmp;
void sd_pre_write_config(void)
{
	_push_(PAGEMAP);
	PAGEMAP = 0x01;	 
	
	ACCON0_P1 |= BIT(4);	//reset	
	ACCON0_P1 &= ~(BIT(1)  | BIT(0));		//�ֶ����hold/enable bit. Ӳ��bug.
	
//	ACCON1_P1 |= BIT(7);	//��� ???�������óɴ��,LBA��ʽĬ�ϳ�С��

	WCFGA1_P1 = (u8)((SD_HW_DMA_IN_BUF_LBA_TAB_START_ADDR >> 8) & 0x00FF);
	WCFGA0_P1 = (u8)((SD_HW_DMA_IN_BUF_LBA_TAB_START_ADDR >> 0) & 0x00FF);	
	
	WBLKLEN_P1 = SD_HS_CACHE_BUF_CNT;	//plan to rcv.
	WBLKCNT_P1 = 0;						//received cnt.
//yBufIndexCopyTmp = 0x12;	
	enable_write_acce_hold_in_next_pkt();
	
	_pop_(PAGEMAP);
}



/************************************************************************************************************************
* void write_acce_hold_config(u8 switch)
* input: 1 -> hold; 0 -> not hold.
* output:
************************************************************************************************************************/
void write_acce_hold_config(u8 en_hold)
{			 	
	_push_(PAGEMAP);
	PAGEMAP = 0x01;
	if(en_hold){
		ACCON0_P1 |= BIT(1);	
	}else{
		ACCON0_P1 &= ~ BIT(1);	
	}

	_pop_(PAGEMAP);
}

/************************************************************************************************************************
* void enable_write_acce_hold_in_next_pkt(void)
* 
* 
************************************************************************************************************************/
//extern unsigned char data yBufIndexCopyTmp;  
extern void prints(u8 *p); 
void enable_write_acce_hold_in_next_pkt(void)
{
//prints("hold\n");
	write_acce_hold_config(1);
}

/************************************************************************************************************************
* void release_write_acce_hold_rcv_data(void)
* 
* 
************************************************************************************************************************/
void release_write_acce_hold_rcv_data(void)
{
	write_acce_hold_config(0);
}


/************************************************************************************************************************
* void read_acce_hold_config(u8 switch)
* input: 1 -> hold; 0 -> not hold.
* output:
************************************************************************************************************************/
void read_acce_hold_config(u8 en_hold)
{			 	
	_push_(PAGEMAP);
	PAGEMAP = 0x01;
	if(en_hold){
		ACCON1_P1 |= BIT(1);	
	}else{
		ACCON1_P1 &= ~BIT(1);	
	}
	_pop_(PAGEMAP);
}

/************************************************************************************************************************
* void enable_read_acce_hold_in_next_pkt(void)
* 
* 
************************************************************************************************************************/
void enable_read_acce_hold_in_next_pkt(void)
{
	read_acce_hold_config(1);
}

/************************************************************************************************************************
* void release_read_acce_hold_tx_data(void)
* 
* 
************************************************************************************************************************/
void release_read_acce_hold_tx_data(void)
{
	read_acce_hold_config(0);
}
/************************************************************************************************************************
* u8 chk_read_acce_holding(void)
* output: 1 - holding; 0 - not hold.
* 
************************************************************************************************************************/
u8 chk_read_acce_holding(void)
{
	u8 ret;
	
	_push_(PAGEMAP);
	
	PAGEMAP = 0x01;
	ret = ACCON1_P1 & BIT(1);
	
	_pop_(PAGEMAP);
	
	return ret;
}

	



















