#include "inc\common.h"
#include "inc\sd_spi_com_define.h"
#include "inc\sd_var.h"			
#include "inc\ax215_exinst.h"				 
#include "inc\array_FIFO.h"			 
#include "inc\nand_flash.h"			 
#include "inc\extern_data.h"
#include "inc\sd_isr.h"	
#include "inc\mrom_func.h"
extern  void xrl_p0(u8 dat);					
extern void prints(u8 *p);
extern void printHexSync(u8 dat);
extern void change_state_machine_in_pro_dis_state(void);
extern void enable_write_acce_hold_in_next_pkt(void);	
extern u8 code LBA_TMP;
#pragma asm
	EXTRN CODE(ERASE_START_LBA, ERASE_END_LBA, LBA_TMP)
#pragma endasm


#if EN_CPRM
#pragma asm
	CSEG	AT 	0x1464				//????CPRM��ʱoverlap,֮�����
#pragma endasm
#else
#pragma asm
	CSEG	AT 	0x12D0		//0x1000 overlap
#pragma endasm
#endif							
													
#pragma asm
PUBLIC	AUTO_CMD_TAB_ADDR, AUTO_CMD_JMP_ADDR
AUTO_CMD_JMP_ADDR:
DW	AUTO_CMD_JMP_ADDR_CODE
AUTO_CMD_TAB_ADDR:
DW	SD_STAN_CMD0 , SD_STAN_CMD1 , SD_STAN_CMD2 , SD_STAN_CMD3 , SD_STAN_CMD6
DW	SD_STAN_CMD7 , SD_STAN_CMD8 , SD_STAN_CMD9 , SD_STAN_CMD10, SD_STAN_CMD12
DW	SD_STAN_CMD13, SD_STAN_CMD15, SD_STAN_CMD16, SD_STAN_CMD17, SD_STAN_CMD18
DW	SD_STAN_CMD19, SD_STAN_CMD24, SD_STAN_CMD25, SD_STAN_CMD27, SD_STAN_CMD28
DW	SD_STAN_CMD29, SD_STAN_CMD30, SD_STAN_CMD32, SD_STAN_CMD33, SD_STAN_CMD38 
DW	SD_STAN_CMD41, SD_STAN_CMD42, SD_STAN_CMD55, SD_STAN_CMD56, SD_STAN_CMD58
DW	SD_STAN_CMD59	

DW	SD_APPO_CMD6 , SD_APPO_CMD13, SD_APPO_CMD18, SD_APPO_CMD22, SD_APPO_CMD23  
DW	SD_APPO_CMD25, SD_APPO_CMD26, SD_APPO_CMD38, SD_APPO_CMD41, SD_APPO_CMD42
DW	SD_APPO_CMD43, SD_APPO_CMD44, SD_APPO_CMD45, SD_APPO_CMD46, SD_APPO_CMD47
DW	SD_APPO_CMD48, SD_APPO_CMD49, SD_APPO_CMD51, SD_APPO_CMD55, DEFAULT_CMD
#pragma endasm

#pragma ot(7, SPEED)

void cmd_isr(void) interrupt 0  using 1
{
	_push_(R8);
	_push_(DPCON);
	_push_(PAGEMAP);

//putchar('q');
	
	PAGEMAP = 0x01;						//sfr page 1
	
	SDRONE_P1 &= ~(0x13);				//	;CLR (APP_CMD_Flag & R6_En & R1_En).
	if ((SDLASTCMD_P1&0x3f) == 55) bAppo_CMD_Flag = 1;//��Ӱ�죬IDLE��ΨһAPP CMDֻ��A41
	if(bAppo_CMD_Flag){//��bitֻ��cmd55������֮����һ��cmd����0
		bAppo_CMD_Flag = 0; 	
		SDRONE_P1 |= (1<<4);		  	//;SET APP_CMD_Flag in R1 Rps.��bitΪ����Ӧ
		ACCON1_P1 |= (1<<6) ;           //Select app_cmd_tab in hardware calculation cmd entrance address automatic.
	}
	
	ACCON1_P1 |= (1<<5) ;				 //kick start auto cal cmd entrance address

	yCMD_Index = SINDEX_P1;				//copy cmd index
//yBufIndexCopyTmp = yCMD_Index;	

#if SYNC_CLRBUSY_SSTA	 
if (bStopClearBusyIng && (yCMD_Index==13) /*&& (!bAppo_CMD_Flag)*/) 
{
		if( ! (SHCON_P1 & BIT(3))){			/// 1 means in busy state.; 0--sd_d0 ready
			if ((SSTA_P1 & 0x0F) == 7) {
				SSTA_P1 = 4;	
				READY_FOR_DATA = 1;
				bStopClearBusyIng = 0;
			}
//״̬����ʱ��ô���������������ܻ����ϣ����뵽��������ǰ������
		} else {
//			if ((SSTA_P1 & 0x0F) == 7) {
//				READY_FOR_DATA = 0;
//			}
		}
}						
#endif	
	
	
	DPCON = 0x08;		   				//���, �ر�����, DPTR0
	SCPND = 0;							//CLR CMD pending			
	bCMDRps_Flag = 0;       			//CLR RPS pending
	SCCON_P1 |= ( 1 << 0);				//;Ready for next CMD(Don't care CMD response whether or not)	  

	while( ! SAJPND) { }				//waiting for hardware checked cmd entrance address.
	SAJPND = 0;

//xrl_p1(1<<2);

	//while(!SCEND) {}	
	while( !ATCFG){}					//wait for hw excuse SSTA_P1 |= (1<<4); // ATCFG is after SCEND done.

#pragma asm														 
	DB 0x02								//LJMP
	AUTO_CMD_JMP_ADDR_CODE:
	DB	0x00, 0x00	
#pragma endasm	

		do
		{			
#pragma asm	
	SD_STAN_CMD0:
#pragma endasm	
//xrl_p3(1 << 6);	
					isr_cmd0_process();
					continue;
#pragma asm	
	SD_STAN_CMD2:
#pragma endasm
//					while(!SCEND) {}
//					SSTA_P1 |= (1<<4);
					
					if (!SRPSTS)
					{
						kick_dma_cid();
						//considering some host may ignore the last ACMD41,set it here after card ready
//						bFirstActive=1;

#if EN_AUTO_REDUCE_AND_FIX_25M_CLK
						if (u8_pwr_active_cnt < 100){		  //��ֹ���
							u8_pwr_active_cnt++;				
						}
#endif
						break;
					}
					continue;
#pragma asm	
	SD_STAN_CMD3: 
#pragma endasm
 //					while(!SCEND) 
//					{}
 //					SSTA_P1 |= (1<<4);
					if (!SRPSTS)
					{
						SRXADR0_P1 = TAB_R6_ACK_DMA_ADDR_L;
					  SRXADR1_P1	= TAB_R6_ACK_DMA_ADDR_H;
						SDRONE_P1 |= 0x02;					
						SRDL0_P1 = 3;
//						SRDL1_P1 = 0;					
						SRCON_P1 = (1<<0);//R6 respond enalbe
						*((char idata *)(&u16RCA) + 0) = SRCA1_P1;
						*((char idata *)(&u16RCA) + 1) = SRCA0_P1;							 
						rca_inc();
						break;											
					}
					continue;
		
#pragma asm	
	SD_STAN_CMD6:
#pragma endasm

  //			while(!SCEND) 
//				{}
					if (! chk_single_r_cmd(SD_Fun_Task)){
						ER33 = SARG7_P1;
						ER32 = SARG6_P1;
						ER31 = SARG5_P1;
						ER30 = SARG4_P1;						
							break;
					}else{
						continue;
					}

#pragma asm	
	SD_STAN_CMD7:
#pragma endasm	
  //					while(!SCEND) 
//					{}
					if (!SCCRC)
					{
						if (last_SSTA_P1 == 5)
						{
							if ( ! isr_check_rca_match()) //match in u16RCA,but may be not match in SRCA1_P1,we just use u16RCA to judge
							{
								bRcvCMD7InDataOrDisState = 1;
								SSTA_P1 = 3;
								if (bMulRFlag)
								{
									bMulRFlag = 0;
									bDataStop_Flag = 1;
									bSDStop = 1;
									SDICON_P1 &= ~(1<<2);	   //;disable cmd12_en	
								}
								SDICON_P1 &= ~(1<<3);	   //;disable busycmd_en
								break;
							}else{
								SSTA_P1 = 5;
							}
						}
						if (last_SSTA_P1 == 7)
						{
							if ( ! isr_check_rca_match())//Ϊ������dis-->pro�ڼ�Ӳ��MATCH RCA����Ҫ��PRO-->DIS�Ĺ����лָ�RCA
							{
								bRcvCMD7InDataOrDisState = 1;
								SSTA_P1 = 8;
								SRCA1_P1 = *((char idata *)(&u16RCA) + 0);
								SRCA0_P1 = *((char idata *)(&u16RCA) + 1);
							
								ILLEGAL_COMMAND = 0;
								COM_CRC_ERROR = 0;	
								
								if ( (bInEraseTask || bMulWriteTask) || ( ! SDCRC) )
								{
									SDICON_P1 |= (1<<1);		//	;CLR data rcv busy in rcv state.	
								}
								SDICON_P1 &= ~(1<<3);	   //;disable busycmd_en
								break;
							}
							else
							{
								SSTA_P1 = 7;
								if (bMulWriteTask)
								{
									break;								
								}	
							}				
						}
						if (last_SSTA_P1 == 8)
						{
							if (isr_check_rca_match())
							{
								cmd_r1_rps();
								SSTA_P1 = 7;
								bRcvCMD7InDataOrDisState = 0;
								rca_inc();
								SDICON_P1 |= (1<<3);						//;Busy command enable (RW)
								break;
							}else{
								SSTA_P1 = 8;
							}
						}
						if (last_SSTA_P1 == 3)
						{
							if (isr_check_rca_match())	
							{
								cmd_r1_rps();
								SSTA_P1 = 4;
								SDICON_P1 |= (1<<3);						//;Busy command enable (RW)
								break;															
							}
							else
							{
								SSTA_P1 = 3;
							  ILLEGAL_COMMAND = 0;
								COM_CRC_ERROR = 0;
								break;
							}				
						}
						if (last_SSTA_P1 == 4)
						{
							if ( ! isr_check_rca_match())
							{
								SSTA_P1 = 3;
								ILLEGAL_COMMAND = 0;
								COM_CRC_ERROR = 0;
								SDICON_P1 &= ~(1<<3);						//;Busy command disable (RW)
								break;
							}else{
								SSTA_P1 = 4;
							}
						}
					
					}
					continue;
#pragma asm	
	SD_STAN_CMD8:
#pragma endasm
 // 					while(!SCEND) 
//					{}
 //					SSTA_P1 |= (1<<4);
//	xrl_p0(1 << 1);
					if (!SRPSTS)
					{
						*((char xdata *)(&TAB_R7_ACK) + 3) = SARG0_P1;
						bCMD8Rcv = 1;						
						SRXADR0_P1 = 	TAB_R7_ACK_DMA_ADDR_L;
						SRXADR1_P1 = 	TAB_R7_ACK_DMA_ADDR_H;
						SRDL0_P1 = 3;
//						SRDL1 = 0;
						SRCON_P1 = (1<<0);
						break;
					}
					continue;
#pragma asm	
	SD_STAN_CMD9:
#pragma endasm
  //					while(!SCEND) 
//					{}
					if (isr_check_rca_match())
					{
 //						SSTA_P1 |= (1<<4);
						if (!SRPSTS)
						{							  
							SRXADR0_P1 = CSD_DMA_ADDR_L;
							SRXADR1_P1 = CSD_DMA_ADDR_H;
						SRDL0_P1 = 15;
//							SRDL1 = 0;			
						SRCON_P1 = (1<<6)|(1<<5)|(1<<4)|(1<<0);	
							
//							SRDL0_P1 = 14;  
////						SRDL1 = 0;
//							SRCON_P1 = (1<<6)|(1<<4)|(1<<0);	//��ʱ����Ӳ������CRC������֮����				
							break;
						}
					}else{
						SSTA_P1 = last_SSTA_P1;
					}
					continue;
#pragma asm	
	SD_STAN_CMD10:
#pragma endasm
  //					while(!SCEND) 
//					{}
					if (isr_check_rca_match())
					{
 //						SSTA_P1 |= (1<<4);
						if (!SRPSTS)
						{
							kick_dma_cid();
							break;
						}
					}else{
						SSTA_P1 = last_SSTA_P1;
					}
					continue;
#pragma asm	
	SD_STAN_CMD12:
#pragma endasm
 //					while(!SCEND) 
//					{}				
 //					SSTA_P1 |= (1<<4);

					if (! SRPSTS)
					{
//					 	push_er0();
//						
//						#pragma asm						
//							MOV		DPTR, # VALID_SECTOR_CNT 
//							SUB32_ER0_EDP0_ER2
//						#pragma endasm	
//						if (EC)
//						{
//							OUT_OF_RANGE = 1;	
//						}
											
						if (bMulRFlag)			   //	;CMD12 stop mul_read_task
						{
							cmd_r1_rps();
							bMulRFlag = 0;
							bDataStop_Flag = 1;
							SDICON_P1 &= ~(1<<2);		//;disable cmd12_en
							SDICON_P1 |= (1<<3);		//;enable busycmd_en					
															
							bSDStop = 1;					//nfc read stop
							stop_read_acce();					
							
						}
//						else						//;bMulRFlag ==0 -> stop mul_write_task
						if (bMulWriteTask || bSingleWriteTask )
						{
//						 	if (bMulWriteTask)
//							{
								READY_FOR_DATA = 0;
								bStopMulWriteData = 1;	 //;busying... 
//							}
							cmd_r1_rps();

							stop_write_acce();			//disable д����ģ��
							
//							rcv_data_state = HS_RCV_DATA_IN_STOP;	
							
//							while( ! SRPND)				 //	;Do not enter CMD ISR to clr OUT_OF_RANGE.
//							{}
//							SRPND = 0;
//							bCMDRps_Flag = 1;							
//							OUT_OF_RANGE = 0;							
//							if (bTmpWriteProtect)
//							{
//								WP_VIOLATION = 1;
//							}
							
//							if (sd_dma_in_cnt == 1){				  //data��busy �� cmd12 busy��������2��; ������2��busy���ӣ������˵�һ��busy�󣬲Ż����ڶ���busy������dma in�ж�
//								SDICON_P1 |= (1<<1);				  //CLR busy
//							}							
						}													 
//					 	pop_er0();
						break;
					}
					continue;
#pragma asm	
	SD_STAN_CMD13:
#pragma endasm
 //					while(!SCEND) 
//					{}
					if (isr_check_rca_match())
					{
//	 					SSTA_P1 |= (1<<4);
						if (! SRPSTS)
						{
							if (SSTA_P1 >= 3)
							{
								
//#if SYNC_CLRBUSY_SSTA	  //�ŵ�������ܻ�Ӧ��ʱ 
//if (bStopClearBusyIng) 
//{
//		if( ! (SHCON_P1 & BIT(3))){			/// 1 means in busy state.; 0--sd_d0 ready
//			if ((SSTA_P1 & 0x0F) == 7) {
//				SSTA_P1 = 4;	
//				READY_FOR_DATA = 1;
//				bStopClearBusyIng = 0;
//			}
////״̬����ʱ��ô���������������ܻ����ϣ����뵽��������ǰ������
//		} else {
////			if ((SSTA_P1 & 0x0F) == 7) {
////				READY_FOR_DATA = 0;
////			}
//		}
//}						
//#endif
								
								
//if (SHCON_P1 & BIT(3)) {
//	READY_FOR_DATA = 0;
//}								
								cmd_r1_rps();		
								
								break;	
							}
							else
							{
								bDecteInvalidCmdBySw = 1;
							}
						}
					}else{
						SSTA_P1 = last_SSTA_P1;
					}
					continue;
#pragma asm	
	SD_STAN_CMD15:   //û�ж�cmd15��Ӧ��2 ina״̬��ͨ
#pragma endasm
//					while(!SCEND) 
//					{}
					if (isr_check_rca_match())
					{
//	 					SSTA_P1 |= (1<<4);
					}else{
						SSTA_P1 = last_SSTA_P1;
					}
					continue;
#pragma asm	
	SD_STAN_CMD16: //block len only efficient for SDSC,but affect Error condition for all type of card
#pragma endasm				

					if (! SRPSTS)
					{
						if((ARGSTA_P1 & 0x03) == 0x01){	//arg > 512
							BLOCK_LEN_ERROR = 1;
						}
												
						if (bEnCheckEraseSeq)
						{
							ERASE_RESET = 1;     //����tran--->tran��ת���¶�Ӧ�ô���
						}	
						cmd_r1_rps();
						
						bBlockLenLess512Byte = 0;

						if((! bSDHC) && ((ARGSTA_P1 & 0x03) == 0x02)){	//arg < 512
							bBlockLenLess512Byte = 1;
						}

						if ( (! bSDHC) && (! BLOCK_LEN_ERROR) )
						{
							DP0L = SARG4_P1;
							DP0H = SARG5_P1;
							#pragma asm
							DECDP0
							#pragma endasm
							
//							yBlockLen0 = DP0L;
//							yBlockLen1 = DP0H;
							
//							DIVR0_P1 = SARG4_P1;	 //16bit������byte
//							DIVR1_P1 = SARG5_P1;	 //16bit������byte												
						}
					
						break;
					}
					continue;
					
#pragma asm	
	SD_STAN_CMD17:
#pragma endasm
					if ( ! chk_read_data_cmd(Single_Read_Task))
						break;
					else
						continue;

#pragma asm	
	SD_STAN_CMD18:
#pragma endasm
					if ( ! chk_read_data_cmd(Mul_Read_Task))
						break;
					else
						continue;

#pragma asm	
	SD_STAN_CMD24:
#pragma endasm 	
					if( ! chk_stand_rcv_data(Single_Write_Task)){
						if(SSTA_P1 != 4) {
							bSingleWriteTask = 1;
							enable_write_acce_hold_in_next_pkt();	
						}
						break;
					}else{
						continue;
					}

#pragma asm 	
	SD_STAN_CMD25:
#pragma endasm 	
//if (SHCON_P1 & BIT(3)) {
//	prints("be\n");
//}

					if( ! chk_stand_rcv_data(Mul_Write_Task)){
						if(SSTA_P1 != 4)
							bMulWriteTask = 1;			
						break;
					}else{
						continue;
					}
										
#pragma asm	
	SD_STAN_CMD27:
#pragma endasm
//					while(!SCEND) 
//					{}
 //	 				SSTA_P1 |= (1<<4);
					if ( ! SRPSTS)
					{					
						cmd_r1_rps();
						SDDL0_P1 = 15;
						SDDL1_P1 = 0;
						SDICON_P1 |= (1<<3);						
#if 1	 //config_dma_buf_addr()
						SDXADR1_P1 = DATA_BUF_DMA_ADDR_H;			  //����DATA BUF��
						SDXADR0_P1 = DATA_BUF_DMA_ADDR_L;						
						SDICON_P1 |= (1<<0);
						bDataIn_Flag = 0;
						
						yTast_Index = Pro_CSD_Task;
						u8_extern_dma_in_task = EXTERN_DMA_IN_PRG_CSD; 
#endif
						break;
					}
					continue;
#pragma asm	
	SD_STAN_CMD28:
	SD_STAN_CMD29:
#pragma endasm
 //					while(!SCEND) 
//					{}
					if ( ! bSDHC)
					{
//	 	 				SSTA_P1 |= (1<<4);
						if ( ! SRPSTS)
						{
							SDICON_P1 |= (1<<1);
							SSTA_P1 = 4;
							fetch_agm_addr_to_er3();
							cmd_rps_with_check_range();
							break;
						}
					}
					else
					{
						SSTA_P1 = last_SSTA_P1;
						bDecteInvalidCmdBySw = 1;					
					}

					SDICON_P1 |= (1<<1);					 						
					continue;
#pragma asm	
	SD_STAN_CMD30:
#pragma endasm
//					while(!SCEND) 
//					{}
					if ( ! bSDHC)
					{
						if (! chk_single_r_cmd(WP_STATE_Task))
							break;
						else
							continue;
					}
					else
					{
						SSTA_P1 = last_SSTA_P1;
						bDecteInvalidCmdBySw = 1;					
					}
					continue;
#pragma asm	
	SD_STAN_CMD32:
#pragma endasm
//					while(!SCEND) 
//					{}
//				 	SSTA_P1 |= (1<<4);		
					if ( ! SRPSTS)
					{		
					
						bEnCheckEraseSeq = 1;
						
						ACC = *(char xdata *)(&ERASE_PARAMETER);
						if ((ACC & 0x03) == 0)
						{	
//			printf("e 32\n");	
							 ACC |= (1<<0);
							*(char xdata *)(&ERASE_PARAMETER) = ACC;
							
							cmd_r1_rps();		
							
							get_arg_to_lba_tmp();					
							#pragma asm		//����ER3,��Ҫ��֤��������κζ�д���񲻳�ͻ
								MOV 	DPTR,#LBA_TMP
								MOV32_ER3_EDP0
								MOV		DPTR,#ERASE_START_LBA
								MOV32_EDP0_ER3
							#pragma endasm					
						}
						else
						{
							if (ACC == (1<<0))
							{
								ERASE_RESET = 1;
							}
							else if (ACC == (1<<1))
							{
									ERASE_SEQ_ERROR = 1;
							}
							bEnCheckEraseSeq = 0;
							*(char xdata *)(&ERASE_PARAMETER) = 0;		
							
							cmd_r1_rps();						
						}
	
				
//						DPTR0 = (u16)(& ERASE_START_LBA);
//						chk_erase_cmd_rps_and_save_par();

						break;											
					}
					continue;
#pragma asm	
	SD_STAN_CMD33:
#pragma endasm
//					while(!SCEND) 
//					{}
//				 	SSTA_P1 |= (1<<4);
					if ( ! SRPSTS)
					{

						ACC = *(char xdata *)(&ERASE_PARAMETER);
						if ((ACC & 0x03) == 0x01)
						{
							ACC |= (1<<1);
							*(char xdata *)(&ERASE_PARAMETER) = ACC;
							
							cmd_r1_rps();
							
							get_arg_to_lba_tmp();
							#pragma asm			//����ER3,��Ҫ��֤��������κζ�д���񲻳�ͻ
								MOV 	DPTR,#LBA_TMP
								MOV32_ER3_EDP0
								MOV		DPTR,#ERASE_END_LBA
								MOV32_EDP0_ER3
							#pragma endasm
						}
						else
						{
							ERASE_SEQ_ERROR = 1;
							bEnCheckEraseSeq = 0;
							*(char xdata *)(&ERASE_PARAMETER) = 0;
							
							cmd_r1_rps();
						}
		
											
//						DPTR0 = (u16)(& ERASE_END_LBA);
//						chk_erase_cmd_rps_and_save_par();
											
						break;
					}
					continue;
#pragma asm	
	SD_STAN_CMD38:
#pragma endasm
//					while(!SCEND) 
//					{}
//				 	SSTA_P1 |= (1<<4);
	
					if ( ! SRPSTS)
					{	

						bEnCheckEraseSeq = 0;
						ACC = *(char xdata *)(&ERASE_PARAMETER);
						if ((ACC & 0x03) == 0x03)
						{
							READY_FOR_DATA = 0;						
							cmd_r1_rps();
							bInEraseTask = 1;
							yTast_Index = Erase_Task;
							u8_extern_dma_in_task = EXTERN_DMA_IN_ERASE_DATA;	
//printf("e 38\n");		
//	printf("erase....\n");						
							
						}
						else
						{
							ERASE_SEQ_ERROR = 1;
							cmd_r1_rps();
							SSTA_P1 = 4;
							SDICON_P1 |= (1<<1);
//	printf("erase fail\n");	
						}
						*(char xdata *)(&ERASE_PARAMETER) = 0;
						break;
					}

					SDICON_P1 |= (1<<1);
					continue;
#pragma asm	
	SD_STAN_CMD41:
#pragma endasm
					if ((SDLASTCMD_P1 & 0x3f) == 55)
					{
						SDRONE_P1 |= (1<<4);
						goto SD_APP_CMD41;
					}
					else
					{
						bDecteInvalidCmdBySw = 1;
						continue;
					}
#pragma asm	
	SD_STAN_CMD42:
#pragma endasm
//					while(!SCEND) 
//					{}
//				 	SSTA_P1 |= (1<<4);
					if ( ! SRPSTS)
					{
						cmd_r1_rps();
						break;
					}
					continue;
#pragma asm	
	SD_APPO_CMD55:
	SD_STAN_CMD55:
#pragma endasm

//					while(!SCEND) 
//					{}
					if (isr_check_rca_match())
					{
//					 	SSTA_P1 |= (1<<4);
						if (SSTA_P1  != 9)						  //���ܼ�� SRPSTS���ڶ��cmd55������£����󱨴�
						{
							pre_config_r1_rps();		
							if ((SSTA_P1 != 6) && (SSTA_P1 != 7))		
								READY_FOR_DATA = 1;  //Ϊʲôa55Ҫ����ready for  data????
							bAppo_CMD_Flag = 1;
							SDRONE_P1 |= (1<<4);
							cmd_r1_rps();
							break;
						}										
					}else{
						SSTA_P1 = last_SSTA_P1;
					}
					continue;
#pragma asm	
	SD_STAN_CMD56:
#pragma endasm
//					while(!SCEND) 
//					{}
//				 	SSTA_P1 |= (1<<4);
					if ( ! SRPSTS)
					{
						if ((SARG0_P1 & 0x01) == 0)
						{							
							cmd_r1_rps();
							bSingleWriteTask = 1;
							yTast_Index = GEN_CMD_Write_Task;
							kick_rcv_data();
						}
						else
						{	
							chk_single_r_cmd(GEN_CMD_Read_Task);
							get_arg_to_lba_tmp();						 
						}
						break;
					}
					continue;

#pragma asm	
	SD_APPO_CMD6:
#pragma endasm
//					while(!SCEND) 
//					{}
//				 	SSTA_P1 |= (1<<4);
					if ( ! SRPSTS)
					{
						ACC =  SARG0_P1 & 0x03;
						if (ACC == 0x00)
						{
							*(char xdata *)(&SD_STATE) = 0;
							SDICON_P1 &= 0x7f;
						}
						else if (ACC == 0x02)
						 {
								*(char xdata *)(&SD_STATE) = 0x80;
								SDICON_P1 |= 0x80;				
						 }
						else
						{
								OUT_OF_RANGE = 1;	
						 }
						cmd_r1_rps();
						break;
					}
					continue;
#pragma asm	
	SD_APPO_CMD13:
#pragma endasm
					if (! chk_single_r_cmd(SD_State_Task))
						break;
					else
						continue;
#if EN_CPRM_CMD			   
#pragma asm	
	SD_APPO_CMD18:
#pragma endasm

					if ( ! chk_cprm_send_data_cmd(Security_Mul_Read_Task))
						break;
					else
						continue;
#endif

#pragma asm	
	SD_APPO_CMD22:
#pragma endasm
					if (! chk_single_r_cmd(Get_WellWR_Task))
						break;
					else
						continue;

#pragma asm	
	SD_APPO_CMD23:
#pragma endasm
//					while(!SCEND) 
//					{}
//				 	SSTA_P1 |= (1<<4);
					
//cmd18 + data �ڱ��״̬��host������G3�ֻ�����ʽ����ʱ��ᷢACMD23������Ȼ�󲻶Ϸ�CMD13��ACMD23��ҪӦ��,���򽫳����Զ�����
//					if ( ! SRPSTS)		
					{
						cmd_r1_rps();
						break;
					}
					continue;

#if EN_CPRM_CMD
#pragma asm	
	SD_APPO_CMD25:
#pragma endasm
					if ( ! chk_cprm_rcv_data_cmd(Secutity_Mul_Write_Task)){
						bMulWriteTask = 1;
						break;
					}		
					else
						continue;
#pragma asm	
	SD_APPO_CMD26:
#pragma endasm
					if ( ! chk_cprm_rcv_data_cmd(Update_MKB_Task)){
						bMulWriteTask = 1;
						break;
					}
					else
						continue;
#pragma asm	
	SD_APPO_CMD38:	 
#pragma endasm
//					while(!SCEND) 
//					{}
//				 	SSTA_P1 |= (1<<4);
					if ( ! SRPSTS)
					{
						SSTA_P1 = 7;
						READY_FOR_DATA = 0;
						cmd_r1_rps();
						yTast_Index = Security_Erase_Task;					 	
						break;
					}
					SDICON_P1 |= (1<<1);
					continue;
#endif

#pragma asm	 
	SD_APPO_CMD41:
#pragma endasm
	SD_APP_CMD41:	
					SRXADR0_P1 = TAB_R3_ACK_DMA_ADDR_L;
					SRXADR1_P1 = TAB_R3_ACK_DMA_ADDR_H;
					SRDL0_P1 = 3;
					bCMD8Rcv |= (bit)(SCCON_P1 & (1<<3));	
	//BUG,cmd state��Ϊ״̬��Ӧ��ת��1������ȷ״̬��һ�����A41����Ӧ�ô�idleת��ready״̬
//nokia C6,��55�պ����Զ�Ӧ����Ӧʱ����41��cmd isr��Ӧ������ȷ��ת����ת�����״̬������ת���������ж�Ϊ�Ƿ�״̬
//nokia C6�����ط�ACMD41��ֱ�ӷ�CMD2��������
//				if (! SRPSTS)  //bug modify
					if ((! SRPSTS) || ((SSTA_P1 == 0) && (!(SFLAG_P1&0x08)) && ((SDLASTCMD_P1&0x3f)== 55)))//if last cmd is 55,and idle state and crc right-->go on
					{		
						SSTA_P1 = 1;//bug modify			
						ACC = (SARG1_P1 & ~(1<<7))|(SARG0_P1);
						if (ACC == 0)
						{
							if ( ! bActiveOk)
							{
								*(char xdata *)(&TAB_R3_ACK) &= ~(1<<7);
								SRCON_P1 = (1<<6)|(1<<5)|(1<<0);
//								if (bSDHC && ( ! bCMD8Rcv))
//								{
//									break;			
//								}
								if ((bNandPowerup == 1) && (bCMD0Rcv==0))
								{
								  *(char xdata *)(&SOFT_RESET_ACMD41_CNT_TMP) -= 1;
								  ACC = *(char xdata *)(&SOFT_RESET_ACMD41_CNT_TMP);								 
								  if (ACC == 0)
								  {
									bActiveOk = 1;
								  }
								}
								SSTA_P1 = 0;
							}
							else	// bActiveOk == 1 //ACMD41SD_ACTIVE
							{
							  if (bSDHC && (!((bCMD8Rcv) && (SDLASTCMD_P1& (1<<6))))) //Ϊ����bug,��ʱ  //HCS  ����Ƿ�ᱻ�ú��ֻҪ��reset�Ͳ���仯
								{
									*(char xdata *)(&TAB_R3_ACK) &= ~(1<<7);
									SRCON_P1 = (1<<6)|(1<<5)|(1<<0);	
									SSTA_P1 = 0;																	
								}
								else{ 	//��ʽ����������
									*(char xdata *)(&TAB_R3_ACK) |= (1<<7);
									SRCON_P1 = (1<<6)|(1<<5)|(1<<0);
//									SRCA0_P1 = 0x15;
//									SRCA1_P1 = 0x02;							
									SRCA0_P1 = *(char xdata *)((&CID)+15);			   //CID��CRC7��ΪRCA0�ĳ�ʼֵ,ÿ�ſ���CID��һ�������CID CRCҲ��һ��
									SRCA1_P1 = 0x21;
									bActiveOk = 0;															
									*(char xdata *)(&SOFT_RESET_ACMD41_CNT_TMP) = *(char xdata *)(&SOFT_RESET_ACMD41_CNT);
								}
							}
							break;						
						}
						else
						{
							SSTA_P1 = 9;
						}
					}
					continue;

#pragma asm	
	SD_APPO_CMD42:
#pragma endasm
					if ( ! SRPSTS)
					{
						if (SARG0_P1 & 0x01)
						{	
							PAGEMAP	&= 0xF8;					
							P4PLP_P0 |= (1<<5); 	//ENABLE_SD_D3_PLP
						}
						else
						{				  
							PAGEMAP	&= 0xF8;
							P4PLP_P0 &= ~(1<<5); //DISABLE_SD_D3_PLP
						}  
						PAGEMAP |= 0x01;
						cmd_r1_rps();
						break;
					}
					continue;

#if EN_CPRM_CMD

#pragma asm	
	SD_APPO_CMD43:
#pragma endasm
					if ( ! chk_cprm_send_data_cmd(MKB_Task)){
						get_arg_to_lba_tmp();
						break;
					}
					else
						continue;
#pragma asm	
	SD_APPO_CMD44:
#pragma endasm
					if ( ! chk_cprm_send_data_cmd(MID_Task))
						break;
					else
						continue;
#pragma asm	
	SD_APPO_CMD45:
#pragma endasm
					if ( ! SCCRC)
					{
						if (last_SSTA_P1 == 4)
						{
							yTast_Index = RCV_AKE_CHLG_1_Task;							
							SDXADR1_P1 = AKE_CHALLENGE_1_BUF_DMA_ADDR_H;
							SDXADR0_P1 = AKE_CHALLENGE_1_BUF_DMA_ADDR_L;
							ake_rev_data();
							break;
						}
						else
						{
							bDecteInvalidCmdBySw = 1;
						}				
					}
					continue;	
#pragma asm	
	SD_APPO_CMD46:
#pragma endasm
					if ( ! chk_cprm_send_data_cmd(SEND_AKE_CHLG_2_Task))
						break;
					else
						continue;
#pragma asm	
	SD_APPO_CMD47:
#pragma endasm
					if ( ! SCCRC)
					{
						if (last_SSTA_P1 == 4)
						{
							yTast_Index = RCV_AKE_CHLG_2_RPS_Task;
							SDXADR1_P1 = AKE_CHALLENGE_2_RPS_BUF_DMA_ADDR_H;
							SDXADR0_P1 = AKE_CHALLENGE_2_RPS_BUF_DMA_ADDR_L;
							ake_rev_data();
							break;
						}
						else
						{
							bDecteInvalidCmdBySw = 1;
						}
					}
					continue;
#pragma asm	
	SD_APPO_CMD48:
#pragma endasm
					if ( ! chk_cprm_send_data_cmd(SEND_AKE_CHLG_1_RPS_Task))
						break;
					else
						continue;
#pragma asm	
	SD_APPO_CMD49:
#pragma endasm
					if ( ! SCCRC)
					{
						if ((last_SSTA_P1 == 4)  &&  (! bSDHC))
						{
							SSTA_P1 = 7;
							READY_FOR_DATA = 0;
								cmd_r1_rps();
							yTast_Index = Change_Pro_Area_Task;						   	 							
							break;
						}
						else
						{
							bDecteInvalidCmdBySw = 1;
						}
					}
					continue;
#endif

#pragma asm	
	SD_APPO_CMD51:
#pragma endasm
					if (! chk_single_r_cmd(READ_SCR_Task))
						break;
					else
						continue;

//#pragma asm	
//_SD_STAN_CMD60:
//#pragma endasm					
//					while(!SCEND) 
//					{}
//					if ( !SCCRC)
//					{					
//						if ((SARG3_P1 == 0x02) && 
//						    (SARG2_P1 == 0x15) && 
//							(SARG1_P1 == 0x00) && 
//							(SARG0_P1 == 0x01)){
//						
//							*((char xdata *)(&TAB_R1_ACK) + 0) = 0x15;
//							*((char xdata *)(&TAB_R1_ACK) + 1) = 0x00;
//							*((char xdata *)(&TAB_R1_ACK) + 2) = 0x00;
//							*((char xdata *)(&TAB_R1_ACK) + 3) = 0x01;
//
//						}else {
//							*((char xdata *)(&TAB_R1_ACK) + 0) = 0;
//							*((char xdata *)(&TAB_R1_ACK) + 1) = 0;
//							*((char xdata *)(&TAB_R1_ACK) + 2) = 0;
//							*((char xdata *)(&TAB_R1_ACK) + 3) = 0;
//						}
//
//						 SRXADR0_P1 = 	TAB_R1_ACK_DMA_ADDR_L;
//						 SRXADR1_P1 = 	TAB_R1_ACK_DMA_ADDR_H;
//						 SRDL0_P1 = 3;
//						 SRCON_P1 = (1<<0);
//						
//						bRomCard = 0;							//bRomCard=1 : ROM card; bRomCard=0: R/W card.
//						*(char xdata *)((&SD_STATE) + 3) = 0;	//0: r/w card; 1: rom card.
//
//
//						break;
//					}
//					continue;
//
//#pragma asm	
//_SD_STAN_CMD61:
//#pragma endasm
//					while(!SCEND) 
//					{}
//					if ( !SCCRC)
//					{
//						if ((SARG3_P1 == 0x02) && 
//						    (SARG2_P1 == 0x15) && 
//							(SARG1_P1 == 0x00) && 
//							(SARG0_P1 == 0x01)){
//							
//							cmd_r1_rps();
//						   	bRomCard = 1;			   				//bRomCard=1 : ROM card; bRomCard=0: R/W card.
//						  	*(char xdata *)((&SD_STATE) + 3) = 1;	//0: r/w card; 1: rom card.
//							break;
//						}																				
//					}
//					continue;

#pragma asm	
	DEFAULT_CMD:
	SD_STAN_CMD1:
	SD_STAN_CMD19:
	SD_STAN_CMD58:
	SD_STAN_CMD59:
#pragma endasm
					ILLEGAL_COMMAND = 1;
					continue;

		} while(cmd_no_rps());

#pragma asm
	CMD_ISR_END:
#pragma endasm

		last_SSTA_P1 = SSTA_P1 & 0x0f; 

		ACCON1_P1 &= ~BIT(6);	 //Select cmd_tab in hardware calculation cmd entrance address automatic (default).
		
		if(bEnCheckEraseSeq){
			if ((yCMD_Index != 13) && (yCMD_Index != 32)&&(yCMD_Index != 33)){
				*(char xdata *)(&ERASE_PARAMETER) = 0;
			}				
		}		
	
		_pop_(PAGEMAP);
		_pop_(DPCON);	
		_pop_(R8);
}

unsigned char cmd_no_rps(void)		  
{
	 if (bDecteInvalidCmdBySw)
	 {
		bDecteInvalidCmdBySw = 0;
		ILLEGAL_COMMAND = 1;
	 }
	 if (SSTAINV)
	 {
		ILLEGAL_COMMAND = 1;
	 }
	 if (SCCRC)
	 {
		COM_CRC_ERROR = 1;
	 }
	 return 0;				//always rsp "0"
}

void pre_config_r1_rps(void)
{
	 SRXADR0_P1 = 	TAB_R1_ACK_DMA_ADDR_L;
	 SRXADR1_P1 = 	TAB_R1_ACK_DMA_ADDR_H;
	 SRDL0_P1 = 3;
//	 SRDL1_P1 = 0;

}



void cmd_r1_rps(void)
{
//	DPCON |= 0x10;										//����
	
//	#pragma asm
//	MOV		DPTR, # TAB_R1_ACK
//	MOV		A, CARD_STATUS_0
//	MOVX	@DPTR, A
//	MOV		A, 	CARD_STATUS_1
//	MOVX	@DPTR, A
//	MOV		A, 	CARD_STATUS_2
//	MOVX	@DPTR, A
//	MOV		A, 	CARD_STATUS_3
//	MOVX	@DPTR, A	

//	MOV		SRXADR0_P1, # LOW (TAB_R1_ACK_ADDR/4)
//	MOV		SRXADR1_P1, # HIGH(TAB_R1_ACK_ADDR/4)
//	#pragma endasm

	*((char xdata *)(&TAB_R1_ACK) + 0) = CARD_STATUS_0;//���Ӧ��
	*((char xdata *)(&TAB_R1_ACK) + 1) = CARD_STATUS_1;
	*((char xdata *)(&TAB_R1_ACK) + 2) = CARD_STATUS_2;//����card status����״̬������������Ӧ����ûʲôӰ�죬��ҪӰ����Ӳ����respondʱ���Զ��滻״̬�����������д��ram
	*((char xdata *)(&TAB_R1_ACK) + 3) = CARD_STATUS_3;
	
//	 SRXADR0_P1 = 	TAB_R1_ACK_DMA_ADDR_L;
//	 SRXADR1_P1 = 	TAB_R1_ACK_DMA_ADDR_H;
//	 SRDL0_P1 = 3;
////	 SRDL1_P1 = 0;	 
//	pre_config_r1_rps();

	 SDRONE_P1 |= 0x01;

	 SRCON_P1 = (1<<0);
	 
//if ((SHCON_P1 & BIT(3)) && READY_FOR_DATA) {
//	prints("b3\n");
//}								
				 
//	 DPCON &= ~0x10;										//�ر�����
}


unsigned char isr_check_rca_match(void)
{
	if ( 
		(*((char idata *)(&u16RCA) + 0) == SARG3_P1) && 
		(*((char idata *)(&u16RCA) + 1) == SARG2_P1)		 
		)
	{
		return 1;
	}
	return 0;
}


void rca_inc(void)
{
	SRCA0_P1++;	
}

void kick_dma_cid(void)
{
	SRXADR0_P1 = CID_DMA_ADDR_L;
	SRXADR1_P1 = CID_DMA_ADDR_H;							
	SRDL0_P1 = 15;
	//SRDL1_P1 = 0;						
	SRCON_P1 = (1<<6)|(1<<5)|(1<<4)|(1<<0); 
}

void kick_rcv_data(void)
{
	SDICON_P1 |= (1<<3);   //busy cmd enable
//			SDDL0_P1 = yBlockLen0;
//			SDDL1_P1 = yBlockLen1;
			SDDL0_P1 = 0xff;  //��֧�ֱ䳤
			SDDL1_P1 = 0x01;
	config_dma_buf_addr();
}


void cmd_rps_with_check_range(void)
{
	cmd_r1_rps();
	check_addr_out_of_range();
	while( ! SRPND)
	{}
	SRPND = 0;
	bCMDRps_Flag = 1;

}

#if EN_CPRM_CMD
void ake_rev_data(void)
{		
	SSTA_P1 = 6;
	cmd_r1_rps();
	SDDL0_P1 = 7;
	SDDL1_P1 = 0;
	SDICON_P1 |= (1<<0);
	bSingleWriteTask = 1;

//	bDataIn_Flag = 0;	
	SDIIE = 0;			//disable sd dma in isr.
	
	bInReadLba = 1;
#if EN_STOP_W_FLASH_DATA
	bCopyNeedStop = 1;		//ǿ���˳�flashд���ݺ�������������ѭ����Ӧ������													
#endif

}
#endif

void isr_cmd0_process(void)
{
//	while(!SCEND) {}

	if (SCCRC)
	{
//		xrl_p3(1 << 6);	
		SSTA_P1 = last_SSTA_P1;
		return;
	}
	if (last_SSTA_P1 == 5)
	{
	   SHCON_P1 |= (1<<2);			//;ǿ��SDģʽ,����SD DMA OUT������HOST��CMD0����D3Ϊ�͵�����£��������SPI mode
	}
	
//	SSTA_P1 |= (1<<4);	
	if( !SRPSTS )
	{
		u8_pwr_active_cnt = 0;
		READY_FOR_DATA = 1;	
		if (bMulRFlag)
		{
			bMulRFlag = 0;
			bCMD0Rcv = 1;
			bDataStop_Flag = 1;
			bSDStop = 1;		  //nfc read stop
			SDICON_P1 &= ~(1<<2);	  //	;disable cmd12_en
//			SDICON_P1 |= (1<<3);	  //	;enable busycmd_en	
			stop_read_acce();
		}	
	
		if (bSingleWriteTask || bMulWriteTask)
		{	
		  bCMD0Rcv = 1;			  //	;CMD0 Receive.	
		  bDataIn_Flag = 1;		
		  SDICON_P1 &= ~(1<<2);   //;disable CMD12 busy function.			
		  SDICON_P1 &= ~(1<<0);	  //;Disable receive data on SD bus.
		  READY_FOR_DATA = 0;
		  rcv_data_state = HS_RCV_DATA_IN_STOP;
		  stop_write_acce();			//disable д����ģ��
			
//		  bSingleWriteTask = 0; //bug:�����ڸô���0������timer����//2012.12.11	
//		  bMulWriteTask = 0;	//bug:�����ڸô���0������timer����//2012.12.11	�����ֻ�chanhong008-vi 
		}			

		
		SCCON_P1 &= ~(1<<5);	   //	;Output data at SD CLK Falling Edge	
		*(char xdata *)(&SD_STATE) = 0;		
		SDICON_P1 &= 0x7f;			//1 line mode
//		yBlockLen1 = 0x01;
//		yBlockLen0 = 0xff;	

		DIVR1_P1 = 0x02;	 //16bit������byte		
		DIVR0_P1 = 0x00;	 //16bit������byte
							
		SRCA0_P1 = 0;
		SRCA1_P1 = 0;	
		u16RCA = 0;	
		*((char xdata *)(&TAB_R6_ACK) + 2) = 0x01;
		*((char xdata *)(&TAB_R6_ACK) + 3) = 0x00;					
		*((char xdata *)(&CSD) + 3) = 0x32;							
		*((char xdata *)(&CSD) + 15) = *(char xdata *)(&CSD_25M_CRC7);		
//		bCMD8Rcv = 0;
		bDecteInvalidCmdBySw = 0;
		bAppo_CMD_Flag = 0;	
		bBlockLenLess512Byte = 0;
		bSwitch50M = 0;
							
		CARD_STATUS_0 = 0;			//;Reset R1 rps table
		CARD_STATUS_1 = 0;
		CARD_STATUS_2 = 0;
		CARD_STATUS_3 = 0;
		
		*(char xdata *)(&ERASE_PARAMETER) = 0;
	
		SSTA_P1 = 0;
		SDICON_P1 &= ~(1<<3);	   //;disable busycmd_en
										
	}
	
	SHCON_P1 &= (1<<2);	//;Ӳ���Զ��ж�SD/SPIģʽ				
}

/*************************************
�ú�����Ҫ����������
1:��������Ӧ����ɱ�־
2:�س�ʼ��card status��ӦΪ�üĴ����󲿷��뵱ǰ����״̬������йأ���һ������Ӧ��Ӧ����Ӱ��
3:Ԥ����Respond Dma��ַΪR1 rspond tab
*************************************/
void cmd_rps_isr(void) interrupt 1 using 1
{
	_push_(PAGEMAP);    				  
//	sfrpage(1);	
	PAGEMAP = 0x01;
	
	SRPND = 0;	
						  
	bCMDRps_Flag = 1;
	COM_CRC_ERROR = 0;
	ILLEGAL_COMMAND = 0;
	BLOCK_LEN_ERROR = 0;
	ERASE_SEQ_ERROR = 0;
	ERASE_RESET = 0;
	ERASE_PARAM = 0;
	OUT_OF_RANGE = 0;
	ADDRESS_ERROR = 0;
	WP_ERASE_SKIP = 0;
//	WP_VIOLATION = 0;

	if(bTmpWriteProtect && (yCMD_Index == 12)){
		WP_VIOLATION = 1;
	}else{
		WP_VIOLATION = 0;
	} 
	
	pre_config_r1_rps();
	
	_pop_(PAGEMAP);
}


void dma_data_out_isr(void) interrupt 3
{
	_push_(PAGEMAP);  
		
	PAGEMAP = 0x01;
	
	SDODLY_P1 &= ~(1<<0);	
	SDOPND = 0;
		
	bDataOut_Flag = 1;

	if((! bDataStop_Flag) && (! bBlockLenLess512Byte)){
		if((ReadLBACnt > 0) && (ReadLBACnt <= READ_BUF_NUM)){
			ReadLBACnt--;
			if (ReadLBACnt == 0) {
				bEnReadLBACnt = 0;
			}

#if 0	//debug
			
			yBuffer_Index++;
			if (yBuffer_Index == READ_BUF_NUM) {
				yBuffer_Index = 0;
			}
#endif
		}
	}	
	#pragma asm
	INC32_ER2
	INC32_ER3		//updata LBA++.
	#pragma endasm
	update_er3_to_cur_lba_var(); //DPTR0 
	
	if (bReadType) {	   	
		change_state_machine_in_data_state();
		bDataOut_Flag = 1;
		bDataStop_Flag = 1;
//		bMulRFlag = 0;			//ע��SD/SPI ��������
		bSDStop = 1;			//nfc read stop
	}
	
#if EN_CPRM_CMD
	if (bCprmDmaDataMode){
		judge_cprm_data_dma_out_complete();	
	}
#endif
					 
	_pop_(PAGEMAP);	
}


//C == 0 -> valid cmd
//C == 1 -> invalid cmd
bit chk_cprm_rcv_data_cmd(unsigned char yTast_Index_config)
{
	if ( ! SCCRC)
	{	
		if (last_SSTA_P1 == 4){
			SSTA_P1 = 6;
			cmd_r1_rps();	

			yTast_Index = yTast_Index_config;			
			init_sd_kict_rcv();
					
			return  0;
		}else{
			bDecteInvalidCmdBySw = 1;
		}
	}
	return 1;
}

//C == 0 -> valid cmd
//C == 1 -> invalid cmd
bit chk_cprm_send_data_cmd(unsigned char yTast_Index_config)
{
	if ( ! SCCRC){
		if (last_SSTA_P1 == 4){
			SSTA_P1 = 5;
			cmd_r1_rps(); 

			yTast_Index = yTast_Index_config;

			SDICON_P1 |= (1<<2);		//	;enable cmd12_en
			SDICON_P1 &= ~(1<<3);		//	;disable busycmd_en	
			bMulRFlag = 1;

			bInReadLba = 1;
	#if EN_STOP_W_FLASH_DATA
			bCopyNeedStop = 1;		//ǿ���˳�flashд���ݺ�������������ѭ����Ӧ������													
	#endif
			return 0;
		}else{
			bDecteInvalidCmdBySw = 1;
		}
	}
	return 1;
}


//C == 0 -> valid cmd
//C == 1 -> invalid cmd
bit chk_read_data_cmd(unsigned char yTast_Index_config)
{	
	if (! SRPSTS){					 				
		if ( ! bSDHC){	
			while( ! CDONE){}		//wait div done.
			if(CMP3){				//arg % (blk_len(divr1,divr0)) ������
				ADDRESS_ERROR = 1;
			}																
		}
		cmd_r1_rps();		

		if ( ! ADDRESS_ERROR){
			SDICON_P1 |= (1<<2);		//	;enable cmd12_en
			SDICON_P1 &= ~(1<<3);		//	;disable busycmd_en	
			bMulRFlag = 1;	
			bInReadLba = 1;
			
#if EN_STOP_W_FLASH_DATA							
			bCopyNeedStop = 1;		//ǿ���˳�flashд���ݺ�������������ѭ����Ӧ������																			
#endif
			yTast_Index = yTast_Index_config; 	
			get_arg_to_lba_tmp();		
		}else{
			SSTA_P1 = 4;						
		}
		return 0;	
	}
	return 1;
}

//C == 0 -> valid cmd
//C == 1 -> invalid cmd
bit chk_single_r_cmd(unsigned char yTast_Index_config)
{
	if ( ! SRPSTS)
	{
		cmd_r1_rps();
											
		SDICON_P1 |= (1<<2);		//	;enable cmd12_en
		SDICON_P1 &= ~(1<<3);		//	;disable busycmd_en	
		bMulRFlag = 1;
//		bDataStop_Flag = 0;
//   	bStopEn = 1;
		bInReadLba = 1;
		
#if EN_STOP_W_FLASH_DATA
		bCopyNeedStop = 1;		//ǿ���˳�flashд���ݺ�������������ѭ����Ӧ������													
#endif	
		yTast_Index = yTast_Index_config;			
		return 0;
	}
	return 1;
}

//input: dptr0
//void chk_erase_cmd_rps_and_save_par(void)
//{
//	DPCON |= 0x10;										//����
//	#pragma asm	
//	MOV		A, LBATmp3
//	MOVX	@DPTR, A
//	MOV		A, LBATmp2
//	MOVX	@DPTR, A
//	MOV		A, LBATmp1
//	MOVX	@DPTR, A
//	MOV		A, LBATmp0
//	MOVX	@DPTR, A	
//	#pragma endasm	
//	DPCON &= ~0x10;										//�ر�����
//}


//output: R7
///0: r1 rps,  task.
///1: no rps
bit chk_stand_rcv_data(u8 task_index)
{
	if ( ! SRPSTS)
	{												
		if ( ! bSDHC)
		{					
			if(! CMP2){					//arg % 512 != 0
				ADDRESS_ERROR = 1;
			}
		}
		cmd_r1_rps();	
		if ( (! bBlockLenLess512Byte) && (! ADDRESS_ERROR))
		{
			init_sd_kict_rcv();	
			yTast_Index = task_index;	
		}
		else
		{
			SSTA_P1 = 4;						
		}
		return 0;
	}
	return 1;
}


//void SD_func_test(long l_data, long r_data)
//{	
//	printf("");  	
//	
//	l_data = l_data;
//	r_data = r_data;
//	
//#if 0
//	
//	printf("Here is sd function test!\r\n");   
//	sfrpage(0);
////relese sdc soft reset	
//	CLKCON0_P0 |= BIT(5);						  
//	printf("CLKCON0_P0 is :0x%x\r\n", (int)CLKCON0_P0);
//	sfrpage(1);		  
//	LDAT0_P1 = l_data >> 0;
//	LDAT1_P1 = l_data >> 8;
//	LDAT2_P1 = l_data >> 16;
//	LDAT3_P1 = l_data >> 24;
//	RDAT0_P1 = r_data >> 0;
//	RDAT1_P1 = r_data >> 8;
//	RDAT2_P1 = r_data >> 16;
//	RDAT3_P1 = r_data >> 24;
//	ACCON0_P1 |= BIT(5);	  			
//			  	  
//	printf("PAGEMAP is %x\r\n", (int)PAGEMAP);
//	printf("ACCON0 is :0x%x\r\n", (int)ACCON0_P1);
//	if(ACCON0_P1 & 0x80)	
//		printf("LDAT is smaller than RDAT!\r\n");
//	else if(ACCON0_P1 & 0x40)	
//		printf("LDAT is bigger than RDAT!\r\n");
//	else	
//		printf("LDAT equels to RDAT!\r\n");
//#endif
//}

//void SD_isr_func_test(void)
//{
//#if 0
//	sfrpage(1);	
//					 
//	printf("ARGSTA is :0x%x\r\n", (int)ARGSTA_P1);
//	printf("SARG3-0 is :0x%x 0x%x 0x%x 0x%x\r\n", (int)SARG3_P1, (int)SARG2_P1, (int)SARG1_P1, (int)SARG0_P1);
//	printf("SARG7-4 is :0x%x 0x%x 0x%x 0x%x\r\n", (int)SARG7_P1, (int)SARG6_P1, (int)SARG5_P1, (int)SARG4_P1);	  
//	if(ARGSTA_P1 & 0x02)
//		printf("ARGS is smaller than 512\r\n");
//	else if(ARGSTA_P1 & 0x01)
//		printf("ARGS is bigger than 512\r\n");
//	else
//		printf("ARGS equels to 512\r\n");

//	if(ARGSTA_P1 & 0x04)
//		printf("ARGS is multiple of 512\r\n");
//	else	
//		printf("ARGS isn't multiple of 512\r\n");

//	if(ARGSTA_P1 & 0x80){					 
//		while(!(ARGSTA_P1 & BIT(5)));
//		if(ARGSTA_P1 & 0x08)
//			printf("ARGS isn't multiple of DIVR[0:16]\r\n");
//		else
//			printf("ARGS is multiple of DIVR[0:16]\r\n"); 
//	}
//#endif
//}	




