#include "absacc.h"
#include "intrins.h"
#include "inc\common.h"	
#include "inc\ax215_exinst.h"
#include "inc\sd_spi_com_define.h"
#include "inc\nand_flash.h"	
#include "inc\extern_data.h"
#include "inc\read_write_c.h"
#include "inc\mrom_func.h"

extern void Uart_Send_Byte(u8 dat);
extern void printHexSync(u8 dat);
extern void prints(u8 *p);

/*============================================================
* �Ρ�����:SectorInLargePage,  B
*		   PageLBA
* ��������:
============================================================*/
extern u8 data yScrtyUnitCnt;
void Get_LgAddr(void)     //��δ�޸�
{
	_push_(DPCON);
	DPCON = 0x08;			//���, �ر�����, dptr0			

	if(bStr_MulRead || bStr_MulWrite){
		//������������߽���,д�ǲ��ᳬ������,������ʱҲ�ǲ���ģ����ڶ����Ϳ��ܻ�
		
		DPTR0 = (u16)(& CUR_MAP_LBA);
	/*
		ER0����Get_CurPlaneCfg();���ᱻ�ı�
	*/
		#pragma asm
		MOV32_ER0_EDP0					//ER0 = LBA
		#pragma endasm
//#if BAUDRATE
//if (bStr_MulWrite || bStr_MulRead)
////if (!bLg2PhVerifyError)		
//{		
  //prints("lba:");

	//printHexSync(ER03);
	//printHexSync(ER02);	 
	//printHexSync(ER01);
	//printHexSync(ER00);
	//prints("\n");			
//}	
//#endif
		ZoneLBA = 0;
		while(1){
			//_ZoneLgBlockNumBuf is plane number
			while (*((u16 xdata *)(&_ZoneLgBlockNumBuf + ZoneLBA * 2)) == 0)
			{
				ZoneLBA++;
if (ZoneLBA > 8) 
{
	ZoneLBA = *((u8 xdata *)(&FirstValidZone));  //���������ȡ��������,read lba��ǰ��ȡ�ᳬ������
}				
			}
			
			
			Get_CurPlaneCfg();			   	//;����ı�ER0
			ER13 = (u8)(*((u16 xdata *)(&_ZoneLgBlockNumBuf + ZoneLBA * 2)) >> 8);
			ER12 = (u8)(*((u16 xdata *)(&_ZoneLgBlockNumBuf + ZoneLBA * 2)) >> 0);			
			ER11 = 0;
			ER10 = SectorPerSmallPageTotal + 1;   
			#pragma asm
				MUL16_ER1			//�����з�����16k page 2p or 1p�������num buf����Ϊ1023
			#pragma endasm	
			
			ER13 = LargePagePerBlockH;
			ER12 = LargePagePerBlockL;			
		
			#pragma asm
			MUL16_ER1					 //;_ZoneLgBlockNumBuf[ZoneLBA] * SectorPerBlockPlaneH/L
			SUB32_ER1_ER0_ER1
			#pragma endasm
			
			if( ! EC){
				#pragma asm
				MOV32_ER0_ER1
				#pragma endasm	
				ZoneLBA++;


			}else{
				break;
			}		
		}
		prints("ZLB0 ");
		printHexSync(ZoneLBA);
		//printHexSync(BlockLBAL);
		prints("\n");	
		Get_CurPlaneCfg();	 //;�ֲ�������ER1   //ΪʲôҪ��һ��get cur plane cfg?
		//Get_BlockLBA
		#if 0
		//lba����������0x80����
			prints("lba1:");
		
		  printHexSync(ER03);
		  printHexSync(ER02);  
		  printHexSync(ER01);
		  printHexSync(ER00);
		  prints("\n");   

		#endif
		
		R8 = 0;		
		B =  SectorPerSmallPageTotal + 1; //SectorPerSmallPageTotal = 0x0f;
		#pragma asm			  //	;ER0 = �ڵ���Zone��ƫ��LBA��ַ
	   	DIV16_ER0	//ER0 = ER0 / 16
		#pragma endasm 
		#if 0
			prints("nuf1");
			//printHexSync(ER03);
			//printHexSync(ER02);
			printHexSync(ER01);
			printHexSync(ER00);
			prints("\n");
		#endif
		//get��all page+sector
		SectorInLargePage = B; //SectorInLargePage = 00

		R8 = LargePagePerBlockH;	//	LargePagePerBlock = 0x100;
		B =  LargePagePerBlockL;
		#pragma asm			  //	;ER0 = �ڵ���Zone��ƫ��LBA��ַ
	   	DIV16_ER0				//�̼�������
		#pragma endasm
		
#if 0
			prints("nuf2");
			printHexSync(LargePagePerBlockH);
			printHexSync(LargePagePerBlockL);
			printHexSync(ER01);
			printHexSync(ER00);
			prints("\n");
#endif
		/*
			PageLBAH = 00
			PageLBAL = 00
		*/
		PageLBAH = R8;  
		PageLBAL = B;
		//prints("plb ");
		//printHexSync(PageLBAH);  
		//printHexSync(PageLBAH);
		//prints("\n");	
		/*
			BlockLBAH = 00
			BlockLBAL = 00
		*/
		BlockLBAH = ER01;   //���block
		BlockLBAL = ER00;	
		prints("ZLB ");
		printHexSync(ZoneLBA);
		//printHexSync(BlockLBAL);
		prints("\n");	
		if(ZoneLBA){  
			ER01 = BlockLBAH;
			ER00 = BlockLBAL;
			DPCON = 0x10;
			DPTR0 = (u16)(&_ZoneLgBlockNumBuf);
			#pragma asm
			MOV 	B,ZoneLBA
	plus_loop:
			MOVX	A,@DPTR
			MOV 	ER11,A
			MOVX	A,@DPTR
			MOV 	ER10,A
			
			ADD32_ER0_ER0_ER1
			DJNZ	B,plus_loop
			#pragma endasm

			BlockLBAH = ER01;
			BlockLBAL = ER00;

			
#if 0
						prints("bla");
						//printHexSync(ER03);
						//printHexSync(ER02);
						printHexSync(BlockLBAH);
						printHexSync(BlockLBAL);
						prints("\n");
#endif
		}	
	}else{ //bStr_MulRead = 0 or bStr_MulWrite = 0
	//prints("nrw\n");
		SectorInLargePage = (u8)(B + SectorInLargePage);	//���ܵ���0����SectorPerSmallPage+1��	
		if(SectorInLargePage >= (u8)(SectorPerSmallPageTotal + 1)){		
			SectorInLargePage -= (u8)(SectorPerSmallPageTotal + 1);	  
			if(++PageLBAL == 0){
				PageLBAH++;	
			}
			ER01 = PageLBAH;
			ER00 = PageLBAL;
			ER11 = LargePagePerBlockH;
			ER10 = LargePagePerBlockL;
			Compare_wData();
			if(EZ){
				if(++BlockLBAL == 0){
					BlockLBAH++;	
				}				
				
				ER00 = 0;
				DPTR1 = 0;
				do {
					DPTR1 += *((u16 xdata *)(&_ZoneLgBlockNumBuf + ER00 * 2));
					ER00++;
				} while (ER00 <= ZoneLBA);
				
	
				if ((DP1H == BlockLBAH) && (DP1L == BlockLBAL)) {  //�л�zone
					while (1) {
						ZoneLBA++;	
						if (*((u16 xdata *)(&_ZoneLgBlockNumBuf + ZoneLBA * 2)) != 0)
						{
							break;
						}
						if (ZoneLBA == 8) //���16��zone
						{
							ZoneLBA = *((u8 xdata *)(&FirstValidZone));  //���������ȡ��������,read lba��ǰ��ȡ�ᳬ������
							BlockLBAH = 0;
							BlockLBAL = 10;   //�ص�ǰһ��zone,�˴�ֻ��ȷ��������û����
							break;
						}
					}	
					Get_CurPlaneCfg();		
				}					
				PageLBAH = 0;
				PageLBAL = 0;			    
			}
		}
	}
 	_pop_(DPCON);
}


extern u8 code Retry_Register_Addr_Table;
void Set_Retry_Register_Data(void)
{
//	_push_(NMCON0_P2);

	bNeedSend5DCMDSLC = 0;
	if(RetryCnt < (RETRY_NUBER-10)){		

//prints("Retry1:\n");
//printHexSync(*((u8 xdata *)((&Retry_Register_Addr_Table) + 0)));	
//printHexSync(*((u8 xdata *)((&Retry_Register_Addr_Table) + 2)));	
////printHexSync(*((u8 xdata *)((&Retry_Register_Addr_Table) + 4)));	
//prints("\n");

if(FlashType == _SUMSUNG_21_)
{
		u8 idata tmp;
		for(tmp = 0;tmp < 7;tmp++)//slc��ʱ����retry����	   	
		{	
			NF_Set_Feature_SS21nm(tmp);
		}
}
else
{
		NF_Set_Feature(*((u8 xdata *)((&Retry_Register_Addr_Table) + 0)));//(0x89);
		NF_Set_Feature(*((u8 xdata *)((&Retry_Register_Addr_Table) + 4)));//(0x8A);
		NF_Set_Feature(*((u8 xdata *)((&Retry_Register_Addr_Table) + 7)));//(0x8D);
}
//	prints("GET F 1");
//	printHexSync(RetryCnt >> 8);
//	printHexSync(RetryCnt& 0xFF);
////	printHexSync(Feature_Addr);
//NF_Get_Feature(*((u8 xdata *)((&Retry_Register_Addr_Table) + 0)));
//NF_Get_Feature(*((u8 xdata *)((&Retry_Register_Addr_Table) + 4)));
////NF_Get_Feature(*((u8 xdata *)((&Retry_Register_Addr_Table) + 7)));
//prints("\n");

//		NF_Set_Feature(0x12);
//		NF_Set_Feature(0x13);
//NF_Get_Feature(0x12);
//NF_Get_Feature(0x13);
//NF_Get_Feature(0x14);

		bNeedSend5DCMDSLC = 1;  //????debug 
	}
	else
	{
		unsigned int idata RetryCntTmp = RetryCnt;
		RetryCnt = 0;
//		NF_Set_Feature(*((u8 xdata *)((&Retry_Register_Addr_Table) + 0)));//(0x89);    
//		NF_Set_Feature(*((u8 xdata *)((&Retry_Register_Addr_Table) + 2)));//(0x8A);
		RetryCnt = RetryCntTmp;
		NF_Reset();

//	prints("GET F 2");
//	printHexSync(RetryCnt >> 8);
//	printHexSync(RetryCnt& 0xFF);
////	printHexSync(Feature_Addr);
//NF_Get_Feature(*((u8 xdata *)((&Retry_Register_Addr_Table) + 0)));
//NF_Get_Feature(*((u8 xdata *)((&Retry_Register_Addr_Table) + 2)));
////NF_Get_Feature(*((u8 xdata *)((&Retry_Register_Addr_Table) + 4)));
//prints("\n");

	}

 
 
// 	_pop_(NMCON0_P2);
	

////_push_(DPCON);
////DPCON = 0;
////printf("a\n");	
////_pop_(DPCON);
//	_push_(NMCON0_P2);	

//	if(RetryCnt < (u8)(RETRY_TABLE_SIZE + 1)){		
//		if(bRetryBlockMode){
//			ER40 = 0;
//			ACC = 0x12;
//			NF_Set_Feature();
//			ER40 = 4;
//			ACC = 0x13;
//			NF_Set_Feature();
//		}else{					  //ReadRetry_Send_Config_SUMSUNG_19NM_SLC
//			ER40 = 7;
//			ACC = 0x14;
//			NF_Set_Feature();
//		
//		}
//		if(RetryCnt){
//			bNeedSend5DCMDSLC = 1;
//			bNeedSend5DCMDTLC = 1;
//		
//			_pop_(NMCON0_P2);
//			return;			
//		}
//	}

//	//Set_Retry_Register_Data_Send_ResetCMD	
////	NFIFO0_P2 = NF_RESET;   //NFC�ȴ����д���ݵ�RBΪ�����˳�д���� 
////    NPCON_P2 = 0x01;
////	while( ! NTSKD){};
////	_N_NOP_
////	NTSKD = 0;

//	bNeedSend5DCMDSLC = 0;
//	bNeedSend5DCMDTLC = 0;

// 	_pop_(NMCON0_P2);
}


extern u8 data yBufIndexCopyTmp;
void Chk_Data(void)
{
#if 1
	_push_(DPCON);

	push_reg_bank_0();	
	
	DPCON = 0x00;

	DPTR0 = (u16)(&_PagePhAddr_Buf);	
if(RandomIndex)
	B = (RandomIndex-2)>>1;   //��Ӧ�Ĵ洢��ʱ��ҲҪ��1k=2 sector��
else	
	B = (READ_BUF_NUM-2)>>1;//RandomIndex=0
	ACC = _PagePhAddr_Buf_SIZE;
	DPTR_Add_AB();
	#pragma asm
	MOVX	A,@DPTR//PageLBAL or R0_PageAddrL;//SLCģʽ�����߼�page��Ϊ����	
	INC		DPTR
	MOV		ER13,A
	MOVX	A,@DPTR
	INC		DPTR
	MOV		ER03,A//R1
	MOVX	A,@DPTR
	INC		DPTR
	MOV		ER02,A//R3
	MOVX	A,@DPTR//�����ж�
	INC		DPTR
	MOV		ER01,A//R2
	MOVX	A,@DPTR
	INC		DPTR
	MOV		ER12,A//PageLBAH
	MOVX	A,@DPTR
	INC		DPTR
	MOV		ER00,A//R4//|= 0x80;	//SLC
	MOVX	A,@DPTR
	INC		DPTR
	MOV		ER11,A//R0 R0_PageAddrL;
	#pragma endasm
//printHexSync(ER00);
	if((CurLg2PhTableAddrH == 0xFF) || (CurLg2PhTableAddrH == 0x0f)){
		
#if BAUDRATE		
if(ER02 != 0xFF)
{
yScrtyUnitCnt = 100;	
		printHexSync(BECNTTmp);
		prints("r f");
		printHexSync(CurLg2PhTableAddrL);
		printHexSync(ER02);/*R3_BlockAddrH*/
		printHexSync(ER01);/*R2_BlockAddrL*/
		printHexSync(R4_PageAddrH);/*R4_PageAddrH*/
		printHexSync(R0_PageAddrL);/*R0_PageAddrL*/
		printHexSync(ER03);/*R1_Sector*/
prints("|");
printHexSync(ZoneLBA);
printHexSync(BlockLBAH);
printHexSync(BlockLBAL);	 
printHexSync(PageLBAH);
printHexSync(PageLBAL);
		prints("\n");  		
}
#endif
	
	} else if (CurLg2PhTableAddrH == 0x0b){


#if 0//BAUDRATE
		prints("D p");
		printHexSync(BECNTTmp);/*BECNTTmp*/
		printHexSync(ER02);/*R3_BlockAddrH*/
		printHexSync(ER01);/*R2_BlockAddrL*/
		printHexSync(ER00);/*R4_PageAddrH*/
		printHexSync(ER11);/*R0_PageAddrL*/
		printHexSync(ER03);/*R1_Sector*/
		prints("\n");  		
#endif
	}else if (CurLg2PhTableAddrH == 0x00){
#if BAUDRATE
		printHexSync(BECNTTmp);
		prints("r p");
		printHexSync(CurLg2PhTableAddrL);/*BECNTTmp*/
		printHexSync(ER02);/*R3_BlockAddrH*/
		printHexSync(ER01);/*R2_BlockAddrL*/
		printHexSync(ER00);/*R4_PageAddrH*/
		printHexSync(ER11);/*R0_PageAddrL*/
		printHexSync(ER03);/*R1_Sector*/
prints("|");
printHexSync(ZoneLBA);
printHexSync(BlockLBAH);
printHexSync(BlockLBAL);	 
printHexSync(PageLBAH);
printHexSync(PageLBAL);

		prints("\n");  		
#endif

	}
	
	pop_reg_bank_0();
	_pop_(DPCON);
#endif

}

void Get_RdCurZone_Lg2PhTable(void)
{

}

void Get_WrCurZone_Lg2PhTable(void)
{

}

void Get_WrLg2phTableL_P1(void)
{
	_push_(DPCON);
	DPCON = 0x10;
	DPTR0 = (u16)(&MAP_BOUNDARY + (boundIndex&0x03)*2);
	#pragma asm
		MOVX	A,@DPTR	
		MOV		B,A
		MOVX	A,@DPTR
		MOV 	DP0H,B
		MOV 	DP0L,A
	#pragma endasm
		
	_pop_(DPCON);
} 

void Get_WrLg2phTableL(void)
{
	DPTR0 = _WrLg2phTableL;
	ER03 = 0;
	ER02 = 0;
}

void get_bound_block(void)
{
	if (*((u8 xdata *)(&_PLANE_MODE+ZoneLBA)))  //2P OR 4P
	{		
		ER03 = 0;
		ER02 = 0;
		ER01 = R3_BlockAddrH;
		ER00 = R2_BlockAddrL;
		Get_WrLg2phTableL_P1();
		R8 = 0;
		B = 4;
		#pragma asm
			DIV16_ER0
		#pragma endasm
		Get_Block_PhAddr();
		R3_BlockAddrH_P1 = ER11;
#if 1
if (R1_Sector < (HalfSectorPerSmallPage>>1))
{


} else if (R1_Sector < ((SectorPerSmallPage+1)>>1))
{

	//prints("plus1\n");
	ER10 += 1;
} else if (R1_Sector < ((SectorPerSmallPage+1+HalfSectorPerSmallPage1)>>1))
{

	//prints("plus2\n");
	ER10 += 2;
} else {
	//prints("plus3\n");
	ER10 += 3;
}
#endif
		R2_BlockAddrL_P1 = ER10;
	}	
}

/*============================================================
* �Ρ�����:_WrLg2phTableL _RdLg2phTable
* ��������: 
============================================================*/
void Get_OldBlockPhAddr(void)
{
	ER01 = BlockLBAH;
	ER00 = BlockLBAL;
	Get_WrLg2phTableL();
	Get_Block_PhAddr();
	OldBlockPhAddrH = ER11;
	OldBlockPhAddrL = ER10;
}

static void Rw_DataBlock_SpareArea(void)
{

}
/*============================================================
* �Ρ�����:

* ��������: ��old����cache��һ��page��1~SectorPerSmallPage��sector��
============================================================*/
void Copy_A_Page(void)
{
	R4_PageAddrH = PageLBAH;//=0~257
	R0_PageAddrL = PageLBAL;
	DataCoDecKeyIndex = R0_PageAddrL;//=0~257

	Get_Block_WL_Stage_Addr();
	Read_Sectors();
}

/*============================================================
* �Ρ�����:
	Input��
		R4 R0=0~257
	OutPut:
		R4 R0
		R3 R2
		bBlockMode
	Function��

	���ϵ���������ж������ȵ��ú���

* ��������: 
============================================================*/
void Get_Block_WL_Stage_Addr(void)
{

	if(bReadingCacheBlock)//Write_LBAʱ��bitһ������1(��Ϊ�����������ʱ���Ȼ�Ѿ�֪�����ڷ���SawpIndex)��Read LBAʱ�������������д��block����bit=1������=0
	{
		Get_PagePh2LgTable_StartAddr();
		
		ER01 = R4_PageAddrH;		
		ER00 = R0_PageAddrL;

		Get_Page_PhAddr();
		if(ER11 != 0x0f){		   //HIGH PH_MAX_ADDR_H
			bBlockMode = 0;
			R4_PageAddrH = ER11;		
			R0_PageAddrL = ER10;		
			Get_CacheBlock_Addr();
			return;
		}
	}
	//Get_Block_WL_Stage_Addr_From_OldBlock
	bBlockMode = 1;	 //TLC

	R3_BlockAddrH = OldBlockPhAddrH;
	R2_BlockAddrL = OldBlockPhAddrL;
//  get_bound_block();

//SUMSUNG:���ʵ���page��ַ������WL��ַ
}


/*============================================================
* �Ρ�����:BlockAddrTmpH/L
* ��������:
	�ж�BlockAddrTmpH/L == 0xFFFF
		 = ����Ҫ����
		!= ����BlockAddrTmpH/L,��BlockAddrTmpH/L���յ��տ��	
============================================================*/
void Write_a_Block_Over(void)
{

//	if(BlockAddrTmpH < 0x0f){
	if((BlockAddrTmpH*0x100+BlockAddrTmpL)<BLOCK_ADDR_MAX){
//	if(BlockAddrTmpH != 0xff){
		R3_BlockAddrH = BlockAddrTmpH;	
		R2_BlockAddrL = BlockAddrTmpL;	
	
		NF_Erase_Block();
		Mark_A_Blank_Block();
	} 
}

void Updata_WrLg2phTable(void)
{
	ER01 = BlockLgAddrH;
	ER00 = BlockLgAddrL;
	Get_WrLg2phTableL();
	ER11 = NewBlockPhAddrH;
	ER10 = NewBlockPhAddrL;

	Set_Block_PhAddr();

}


void ReadChk_Sectors(void)
{
	u8 idata try_max_cnt = 0;
	
	RandomIndex = R8Tmp;			
	R1_SectorTmp = R1_Sector;	
	SectorNum = SectorPerSmallPage + 1;
	DataCoDecKeyIndex = PageLBAL;
	do {
		R8Tmp = RandomIndex;
		R1_Sector = R1_SectorTmp;
		DataCoDecKeyIndex1 = R1_Sector;	
		NF_Read_Start();
		NF_Read_Data();
		NF_Wait_Read_Over();
		Chk_Blank_Block();
		BCH_MODE_DC_Wait_Over();
		
if(bReadBlankBlock)//���տ�Ҳ����Ҫ
{
prints("blank\n");
}
			if((BECNTTmp < 0xFF) && (BECNTTmp > 0x20))
			{		
//bLg2PhVerifyError=1;
						prints("NoRe SLC 2:");
						printHexSync(UartIndex);
						printHexSync(BECNTTmp);
						printHexSync(BlockLgAddrH);
						printHexSync(BlockLgAddrL);
						printHexSync(PageLBAH);
						printHexSync(PageLBAL);
							
						printHexSync(R3_BlockAddrH);
						printHexSync(R2_BlockAddrL);		
						printHexSync(R4_PageAddrH);
						printHexSync(R0_PageAddrL);
						prints("\n");
			}
		

		try_max_cnt++;
		if (try_max_cnt > 4) {  //���try 8��
prints("wrVfyTry:");			
printHexSync(R1_Sector);			
printHexSync(R8Tmp);			
printHexSync(try_max_cnt);
printHexSync(UartIndex);
prints("\n");			
			break;
		}
		

		if (!bLg2PhVerifyError) {
			R1_Sector++;
			R1_SectorTmp++;
			SectorNum -= 2;
			
			try_max_cnt = 0;
		}
		
	} while(SectorNum);
	
	reset_bch();
}



void ProgChk_CachePage(u8 need_chk_data)
{
	u8 tmp, tmp2, tmp3;
	
	_push_(DPCON);
	DPCON = 0x00;			//DPTR0������
if(b2PlaneTrue)//2plane��ʱ��֧��
	need_chk_data = 0;	

	tmp3 = bEnReleaseNfBufRcvData;
	if (need_chk_data) {	
		bEnReleaseNfBufRcvData = 0;	
		NF_Read_Status(0);
		ProgramCMD1 = 0x10;//Ҫ���飬�Ͳ���cache
	}
	
	tmp = 0;
	tmp2 = R1_Sector;
do {

	Prog_CacheBlock_Page();   //�˴������program����ͬ�����ݵ�����
	if ((tmp >= 4) || (need_chk_data == 0)) //���д2��,��Ϊ����д��page���ڿ��ܵ���ʱ��̫��
	{
		break;
	}
	tmp++;
	
	R4_PageAddrH = PageLBAH;//(i*3+stage)//0~257
	R0_PageAddrL = PageLBAL;			
	Get_Block_WL_Stage_Addr();  //slcģʽ�Ͳ�copy back 0��  '
	if (bBlockMode == 0) {
		R8Tmp = 32;  //����1k buf
		R1_Sector =  tmp2;
//yScrtyUnitCnt = 100;
		ReadChk_Sectors();
		if ((bReadBlankBlock || bLg2PhVerifyError)) //bWriteLastCachePage���ֻ��һ��page���࣬�����дn������cache��Чlg page����n�ᵼ������
		{
			chk_cacheblock_full();
			if (bWriteLastCachePage) 
			{
				prints("err1\n");
				break;
			}
			else
			{
				prints("err2\n");

//if(UartIndex==0xC2)
//{
//prints("Just read\n");
//break;
//}
			}
		} 
		else 
		{
			break;
		}
	}else 
	{
		break;		
	}	
	
	R1_Sector =  tmp2;
} while(1);	
	

	if (need_chk_data && tmp3) {	
		NfEmptyBufCnt = PlanRcvSDDataCnt;
	}
if(tmp>1)
{
	prints("Try end:");
	printHexSync(tmp);
	Uart_Send_Byte('\n');			
}	
	_pop_(DPCON);
	
}




extern u8 code _PageLg2PhTable, _PageLg2PhTable_SLC_Plane1;
extern bit bRemedyPage;
#define REMEDYPAGE 	20
void Prog_CacheBlock_Page(void)
{
	u8 idata nxtcnt,skipcnt, rlcnt;
	unsigned char tmp, tmp2, tmp3;
	_push_(DPCON);
	DPCON = 0x00;			//DPTR0������
  
  bProgCacheBlockPageTrue = 1;
	
	tmp = R1_Sector;		

	if( !R1_Sector){
		if(((CacheBlockNextPagePhAddrH*0x100+CacheBlockNextPagePhAddrL) % WordLineNumber) == 0){
			NF_Read_Status(0);
	
			bBlockMode = 0;
			Find_A_Blank_Block();
//		R3_BlockAddrH = BlockAddrTmpH = 0x0b;
//		R2_BlockAddrL = BlockAddrTmpL = 0x2a;				

prints("F N SLC");
//printHexSync(ZoneLBA);
printHexSync(BlockLgAddrH);
printHexSync(BlockLgAddrL);
printHexSync(R3_BlockAddrH);
printHexSync(R2_BlockAddrL);  		
//printHexSync(R4_PageAddrH);
//printHexSync(R0_PageAddrL);		
Uart_Send_Byte('\n');			

			if(ChkNeedCache2Cache == 0xFF)//��ʱ���ø���cache block
			{

				u8 idata tmp = (CacheBlockNextPagePhAddrH*0x100+CacheBlockNextPagePhAddrL) / WordLineNumber;
				DPTR0 = _WritingBlockBuf + CacheBlockPhAddrH_INDEX;
				B = SWAPIndex;
				ACC = WritingBlockBuf_SIZE;
				DPTR_Add_AB();
				B = tmp; 
				ACC = 2;
				DPTR_Add_AB();
	
				ACC = BlockAddrTmpH;
				#pragma asm
				MOVX	@DPTR,A
				#pragma endasm
			
				ACC = BlockAddrTmpL;
				#pragma asm
				INC		DPTR
				MOVX	@DPTR,A
				#pragma endasm		
	
			}
			else
			{
				NewBlockPhAddrH = BlockAddrTmpH;
				NewBlockPhAddrL = BlockAddrTmpL;
			}
		}	
	}
	// Prog_CacheBlock_Page_Get_NewCacheBlock_End
//	R8 = R1_Sector;//R1��û�䣬��CE1ʱ�Ÿ���ӳ���

	if((SectorPerSmallPageTotal == SectorPerSmallPage) || R1_Sector){  //���1P����2pʱ��ɵ���plane1(R1!=0)
		Get_PagePh2LgTable_StartAddr();	   //����Pageӳ���	
		
_push_(DP0H);		
_push_(DP0L);		
ER01 = PageLBAH;
ER00 = PageLBAL;
Get_Page_PhAddr();    //cache�ڵ���Ч��������
if((ER11 == 0x0f) && (ER10 == 0xff)){		   //HIGH PH_MAX_ADDR_H
	++CacheBlockLgPageNumL;  //tlc 2 slc
	if( ! CacheBlockLgPageNumL){
		++CacheBlockLgPageNumH;
	}		
}		
_pop_(DP0L);		
_pop_(DP0H);		
		ER01 = PageLBAH;
		ER00 = PageLBAL;
		ER11 = CacheBlockNextPagePhAddrH;
		ER10 = CacheBlockNextPagePhAddrL;
		Set_Page_PhAddr();
	}
	//���
	R4_PageAddrH = CacheBlockNextPagePhAddrH; 
	R0_PageAddrL = CacheBlockNextPagePhAddrL;

	Get_CacheBlock_Addr();

	if(ChkNeedCache2Cache == 0x00)//��ʱ���ø���cache block
	{
		R3_BlockAddrH = NewBlockPhAddrH;
		R2_BlockAddrL = NewBlockPhAddrL;
//		get_bound_block();
	}
		

/**************************************************/
//bNeedRemedyPage = 1;*******/
if (/*1 &&*/ (!b2PlaneTrue) || (b2PlaneTrue && R1_Sector))  //?????debug
{
	DPTR0 = *(u16 xdata *)(&PLANE_REFERENCE + ZoneLBA*4 + 2);
	ER01 = R4_PageAddrH;	
	ER00 = R0_PageAddrL;	
	bit_search();	
	ER13 = ER11;
	ER12 = ER10;
	
	if ((R4_PageAddrH*0x100 + R0_PageAddrL) == (WordLineNumber-1)) {
		ER11 = 0;
		if(FlashType == _SUMSUNG_21_)
			ER10 = 64;
		else if(FlashType == _SUMSUNG_14_)
			ER10 = 133;//2;
		else
			ER10 = 88;
	} else {
		ER00++;
		if (ER00 == 0)
		{
			ER01++;
		}
		bit_search();	
	}  
	
//printHexSync(ER11);	
//printHexSync(ER10);	

	if (((R4_PageAddrH==0) && (R0_PageAddrL==0) && !b2PlaneTrue)) {  //2pʱ��ʱ��û����ǰ����һ��page
		DPTR1 = ER13*0x100+ER12-0;
		if (DPTR1 > (REMEDYPAGE/2))	
		{	
			R4_PageAddrH = (DPTR1 - (REMEDYPAGE/2))>>8;
			R0_PageAddrL = (DPTR1 - (REMEDYPAGE/2));
			rlcnt = (REMEDYPAGE/2);
		} else {
			R4_PageAddrH = 0;
			R0_PageAddrL = 0;
			rlcnt = ER12;  //�豣֤REMEDYPAGE<0xff
		}
//		nxtcnt = 1;
	} else {  //�ǵ�0��
		R4_PageAddrH = ER13;
		R0_PageAddrL = ER12; 
//		nxtcnt = 1;
		rlcnt = 0;
	}
	
	ER13 = 0;
	ER12 = 0;
	ER03 = 0;
	ER02 = 0;
	
	ER01 = R4_PageAddrH;
	ER00 = R0_PageAddrL;
	#pragma asm
	SUB32_ER0_ER1_ER0  //�����page�ĳ���
	#pragma endasm	
	
	if ((ER01*0x100+ER00) > (2*REMEDYPAGE)) {
		nxtcnt = 2*REMEDYPAGE+1;
		skipcnt = (ER01*0x100+ER00)-2*REMEDYPAGE;
	} else {
		nxtcnt = ER00;  //2*REMEDYPAGE���ܳ���0xff
		skipcnt = 1; //���������
	}
	
	bRemedyPage = 1;	

////��Ҫ��page���Ȳ��ͷ�	
//	prints("GGY");		
//	printHexSync(rlcnt);
//	printHexSync(nxtcnt);
//	printHexSync(skipcnt);
//	printHexSync(R4_PageAddrH);
//	printHexSync(R0_PageAddrL);
//	prints("\n");
	
} else {
	bRemedyPage = 0;  
	skipcnt = 1;
	nxtcnt = 1;
	rlcnt = 0;
}


#pragma asm
	MOV		C,bEnReleaseNfBufRcvData
	MOV 	ACC.0,C
	PUSH	ACC
#pragma endasm
bEnReleaseNfBufRcvData = 0;

tmp3 = 1;	
while(1) 
{	
	if ((nxtcnt == 1) && (tmp3 == 1))
	{
		#pragma asm
		POP		ACC
		MOV		C,ACC.0
		MOV		bEnReleaseNfBufRcvData,C
		#pragma endasm
	}
	
	bBlockMode = 0;	  //SLC
	R8Tmp = 0;
	if (!R1_Sector) {  //2p������page
		SectorNum = SectorPerSmallPage + 1;
	} else {
		SectorNum = SectorPerSmallPage1 + 1;	
	}
	
	XBYTE[_SPARE_AREA_BUF + 0] = BlockLgAddrL;
	XBYTE[_SPARE_AREA_BUF + 1] = BlockLgAddrH | DATA_CACHE_BLOCK;
	XBYTE[_SPARE_AREA_BUF + 2] = (R0_PageAddrL&0x1f)|((SpareArea2&0x07)<<5);

	if (rlcnt == 0) { //2pһ����һ��ʼ������

		
		DataCoDecKeyIndex = PageLBAL;	
		rlcnt--;   		
	

		tmp2 = R1_Sector; 
		Prog_A_Page_CacheBlock();			

	} else {
		rlcnt--; //ѭ����������֤������ֻ����һ��0
		DataCoDecKeyIndex = DataCoDecKeyIndex - R0_PageAddrL;
		
		tmp2 = R1_Sector; 
		Prog_A_Page_CacheBlock();	
	}	
		
	if (b2PlaneTrue) {
		if (tmp2 == ((SectorPerSmallPage + 1)>>1)) {
			R1_Sector = 0;
			tmp3 = 0;
		} else if (bRemedyPage && (tmp2==0)) {  //�˴�����һ��page������,2pʱP1���ٲ�һ��page,��Ҫ������bEnReleaseNfBufRcvData 
			R1_Sector = (SectorPerSmallPage + 1) >> 1;
			tmp3 = 1;
			//��ʱΪ80.....10
			continue;
		}
	} else {
		R1_Sector = tmp;
	}
	
	nxtcnt--;
	if (!nxtcnt) {
		R1_Sector = tmp;//R1�ѱ��ı�  
		break;
	}


//�����Ѿ����ı�,���������������prog��Ч����
	DataCoDecKeyIndex1 = tmp2;
	Recover_random_data();  //�����ݻָ�����

	
	
if (nxtcnt == REMEDYPAGE)		
{
	#pragma asm
		CLR32_ER0
		CLR32_ER1
	#pragma endasm
	ER11 = R4_PageAddrH;
	ER10 = R0_PageAddrL;
	ER00 = skipcnt;
	#pragma asm
	ADD32_ER0_ER1_ER0
	#pragma endasm
	R4_PageAddrH = ER01;
	R0_PageAddrL = ER00;
} else {
	R0_PageAddrL++;
	if (R0_PageAddrL == 0)
		R4_PageAddrH++;
}

} 

bRemedyPage = 0;


	if((SectorPerSmallPageTotal == SectorPerSmallPage) || R1_Sector){  
		if(++CacheBlockNextPagePhAddrL == 0){			//�����ɼ��л�����һ��page
			CacheBlockNextPagePhAddrH++;	
		}	
	}
	bProgCacheBlockPageTrue = 0;
	_pop_(DPCON);
}

void Get_CacheBlock_Addr(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����	
 	
	ER03 = 0;
	ER02 = 0;
	ER01 = R4_PageAddrH;//0~(86*7-1)
	ER00 = R0_PageAddrL;
	R8 = WordLineNumber>>8;
	B = WordLineNumber;
	#pragma asm
	DIV16_ER0
	#pragma endasm
	R4_PageAddrH = R8;//MUST BE 0
	R0_PageAddrL = B;//WL
	SpareArea2 = ER00;//��n��CacheBlock��Prog_CacheBlock_Page��Ҫ�õ�

	DPTR0 = _WritingBlockBuf + CacheBlockPhAddrH_INDEX;	
	#pragma asm
	MOV		B,SWAPIndex
	MOV		A,#WritingBlockBuf_SIZE
	CALL	dptr_add_ab_maskrom
	MOV		B,SpareArea2//��B��CacheBlock
	MOV		A,#2//CacheBlockPhAddrH/L
	CALL	dptr_add_ab_maskrom
	MOVX	A,@DPTR
	MOV		B,A
	MOVX	A,@DPTR
	MOV		R8,A
	#pragma endasm
	bBlockMode = 0;
	R3_BlockAddrH = B;
	R2_BlockAddrL = R8;	
				
	_pop_(DPCON);
}

/*============================================================
* �Ρ�����:SWAPIndex
* ��������:��SwapBuf��ȡ��DATA_RAM�У��������ʹ��
============================================================*/
void Read_WritingBlockBuf(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����

	Get_WritingBlockBuf_BlockLgAddrH_INDEX();

	#pragma asm
	MOV32_ER0_EDP0
	#pragma endasm
	BlockLgAddrH = ER00;
	BlockLgAddrL = ER01;
	CacheBlockNextPagePhAddrH = ER02;
	CacheBlockNextPagePhAddrL = ER03;

	#pragma asm
	MOV32_ER0_EDP0
	#pragma endasm
	Order = ER00 * 0x100 + ER01;
	CacheLgPage = ER02 * 0x100 + ER03;

	#pragma asm
	MOV32_ER0_EDP0
	#pragma endasm
	NewBlockPhAddrH = ER00;
	NewBlockPhAddrL = ER01;
	NewBlockNextPagePhAddrH = ER02;
	NewBlockNextPagePhAddrL = ER03;

	#pragma asm
	MOV32_ER0_EDP0
	#pragma endasm
	CacheBlockLgPageNumH = ER03;
	CacheBlockLgPageNumL = ER02;

	_pop_(DPCON);
}

void Write_WritingBlockBuf(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����

	Get_WritingBlockBuf_BlockLgAddrH_INDEX();

	ER00 = BlockLgAddrH;
	ER01 = BlockLgAddrL;
	ER02 = CacheBlockNextPagePhAddrH;
	ER03 = CacheBlockNextPagePhAddrL;
	#pragma asm
	MOV32_EDP0_ER0
	#pragma endasm

	ER00 = Order >> 8;
	ER01 = Order & 0xFF;
	ER02 = CacheLgPage >> 8;
	ER03 = CacheLgPage & 0xFF;
	#pragma asm
	MOV32_EDP0_ER0
	#pragma endasm

	ER00 = NewBlockPhAddrH;
	ER01 = NewBlockPhAddrL;
	ER02 = NewBlockNextPagePhAddrH;
	ER03 = NewBlockNextPagePhAddrL;
	#pragma asm
	MOV32_EDP0_ER0
	#pragma endasm
	

	ER02 = CacheBlockLgPageNumL;
	ER03 = CacheBlockLgPageNumH;
	#pragma asm
	MOV32_EDP0_ER0
	#pragma endasm
	
	_pop_(DPCON);
}

void Get_PagePh2LgTable_StartAddr(void)
{
	DPTR0 = PAGE_PH2LG_TABLE_ADDR;

	ER01 = (u8)(PAGE_PH2LG_TABLE_SIZE >> 8);		
	ER00 = (u8)(PAGE_PH2LG_TABLE_SIZE >> 0);	
	ER03 = 0;
	ER02 = SWAPIndex;

	#pragma asm
	MUL16_ER0
	MOV		R8,ER01
	MOV		B ,ER00
	ADDDP0								//;DPTR0 + (R8 B)	
	#pragma endasm	
}
/*============================================================
* �Ρ�����:ER02
* ��������:
============================================================*/
void Sel_Buffer_Addr(void)
{

	

	if (ER02 &0x01) {
		ER11 = (u8)((BUFFER_START_ADDR+512) >> 8);
		ER10 = (u8)((BUFFER_START_ADDR+512) >> 0);
		
	} else {
		ER11 = (u8)(BUFFER_START_ADDR >> 8);
		ER10 = (u8)(BUFFER_START_ADDR >> 0);		
	}	
	ER02 >>= 1;
	ER01 = (u8)(1028 >> 8);				
	ER00 = (u8)(1028 >> 0);	

	ER03 = 0;
	
	#pragma asm
	MUL16_ER0
	ADD32_ER0_ER0_ER1
	#pragma endasm

}

/*============================================================
* �Ρ�����:ER02
* ��������:
============================================================*/
void Sel_DMA_Addr(void)
{
	

	if (ER02 &0x01) {
		ER11 = (u8)(((BUFFER_START_ADDR+512)/4) >> 8);
		ER10 = (u8)(((BUFFER_START_ADDR+512)/4) >> 0);
	} else {
		ER11 = (u8)((BUFFER_START_ADDR/4) >> 8);
		ER10 = (u8)((BUFFER_START_ADDR/4) >> 0);		
	}	
	ER02 >>= 1;
	ER01 = (u8)((1028/4) >> 8);				
	ER00 = (u8)((1028/4) >> 0);	

 	ER03 = 0;
	#pragma asm
	MUL16_ER0
	ADD32_ER0_ER0_ER1
	#pragma endasm	
}
/*============================================================
* �Ρ�����:ER01 ER00 = LgAddr ER11 ER10 = PhAddr
* ��������: 
============================================================*/
void Get_Block_PhAddr(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����	
	
	#pragma asm
	CALL	get_block_phaddr_maskrom 
	#pragma endasm

	if((ER11 == 0x0f) && (ER10 == 0xff)) {//=0x0FFF ����ΪĿǰ��12bit���洢
		ER11 = 0xff;	
		ER10 = 0xff;
	}else{
//		if( ! bPlaneMag){			//��������,��ӦsetʱҲ����������
		if((!bPlaneMag) || b2PlaneTrue){
			ER13 = 0;
			ER12 = 0;
			R8 = 2;
			#pragma asm
			ROTL32_ER1_ER8
			#pragma endasm	

			ER10 = (u8)(ER10 + (ZoneLBA&0x03));   
		}
	}

		//prints("GET:\n");
		//printHexSync(ZoneLBA);
		//printHexSync(ER11);
		//printHexSync(ER10);	
		//prints("\n");

	_pop_(DPCON);
}



void Get_Page_PhAddr(void)
{
	#pragma asm
	CALL	get_block_phaddr_maskrom 
	#pragma endasm
}
/*============================================================
* �Ρ�����: ER01 ER00 = LgAddr ER11 ER10 = PhAddr
* ��������: 
============================================================*/	
void Set_Block_PhAddr(void)
{

			//prints("SET:\n");
			//printHexSync(ZoneLBA);		
			//printHexSync(ER11);
			//printHexSync(ER10);	
			//prints("\n");

	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����	

	if(ER11 == 0xff){
		ER11 = 0x0f;
		ER10 = 0xff;
	}else if((!bPlaneMag) || b2PlaneTrue){		//��������,��Ӧ��get block��ַʱҲ���ܴ���
		ER13 = 0;
		ER12 = 0;
		R8 = 2;	
		#pragma asm
		ROTR32_ER1_ER8
		#pragma endasm
	}	
 	
	#pragma asm
	CALL	set_block_phaddr_maskrom 
	#pragma endasm
	
	_pop_(DPCON);
}

/*============================================================
* �Ρ�����: ER01 ER00 = LgAddr ER11 ER10 = PhAddr
* ��������: 
============================================================*/	
void Set_Lg2PhAddr(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����	

	#pragma asm
	//*3
	MOV		ER03,#0
	MOV		ER02,#3
	MUL16_ER0
	//2
	MOV		R8,#0
	MOV		B,#2
	DIV16_ER0
	PUSH	B		//����	
	MOV		R8,ER01
	MOV		B ,ER00
	ADDDP0
	MOVX	A,@DPTR//��ԭ��������ȡ����������R01 ER00
	MOV		ER00,A
	MOVX	A,@DPTR
	MOV		ER01,A
	DECDP0
	DECDP0
	POP		ACC
	#pragma endasm
	
	if(ACC & (1 << 0)){
		ER13 = 0;
		#pragma asm
		MOV		R8,#4
		ROTL32_ER1_ER8	
		MOV		ER01,#0
		ANL		ER00,#0x0F
		ANL		ER10,#0xF0
		#pragma endasm	
	}else{
		#pragma asm	
		ANL		ER01,#0xF0
		MOV		ER00,#0
		ANL		ER11,#0x0F
		#pragma endasm		
	}

	#pragma asm
	ORL32_ER1_ER0
	MOV		A,ER10
	MOVX	@DPTR,A
	MOV		A,ER11
	MOVX	@DPTR,A
	#pragma endasm

	_pop_(DPCON);
}

void Set_Page_PhAddr(void)
{
	#pragma asm
	CALL	set_block_phaddr_maskrom 
	#pragma endasm
}



void Get_ZoneLBA(void)
{
	_push_(DPCON);
	DPCON = 0x10;		

	ZoneLBA = 0;
	ER03 = 0;
	ER02 = 0;
	ER01 = BlockLgAddrH;
	ER00 = BlockLgAddrL;

	ER13 = 0;
	ER12 = 0;
	DPTR0 = (u16)(&_ZoneLgBlockNumBuf);
	ZoneLBA = 0xff;
	do 	{
		#pragma asm
		MOVX	A,@DPTR
		MOV 	ER11,A
		MOVX	A,@DPTR
		MOV 	ER10,A
		SUB32_ER0_ER0_ER1
		INC 	ZoneLBA  
		#pragma endasm
	} while(!EC);

	_pop_(DPCON);	
}

void Get_WritingBlockBuf_BlockLgAddrH_INDEX(void)
{
	DPTR0 = _WritingBlockBuf + BlockLgAddrH_INDEX;
	B = SWAPIndex;
	ACC = WritingBlockBuf_SIZE;
	DPTR_Add_AB();
}



