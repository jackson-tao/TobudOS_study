#include "absacc.h"
#include "intrins.h"
#include "inc\common.h"	
#include "inc\ax215_exinst.h"
#include "inc\sd_spi_com_define.h"		
#include "inc\nand_flash.h"	
#include "inc\extern_data.h"
#include "inc\mtd_c.h"
#include "inc\mrom_func.h"

extern bit bFirstEnDecodeData, bFlashMode2;
extern u8 code _PagePhAddr_Buf;
extern void xrl_p3(u8 dat);
void random_inram(void);
void RDC_WaitOver(void);
void Inram_Random_Data(u8 bufindex);
void pr_buf(void);
extern void printHexSync(u8 dat);
extern void prints(u8 *p);
extern u8 data yScrtyUnitCnt;
extern u8 code SectorPerBlock;

#if NFFUSING
#define		NFFINBuf_SIZE	 48//32
xdata unsigned char NFFINBuf[NFFINBuf_SIZE*16] _at_ NFF_BUF;
code unsigned char NFFINBuf_tmp[NFFINBuf_SIZE*16] _at_ NFF_BUF;
#endif


#pragma asm
EXTRN CODE(_FLASH_SHIFTCNT)	
#pragma endasm
static void MLC_Buf_Data_Codec(void)
{
#if EN_RANDOMIZE_DATA
	if(bNeedRandomizer){

#if RANDOMIZE_NF
		HCON_P2 = 0;
#else 
		HCON_P2 = 0x20;
#endif		
		
#if 1
		ER13 = DataCoDecKeyIndex ^ 0xA5;		
		ER12 = DataCoDecKeyIndex ^ 0x5A;		
		ER11 = DataCoDecKeyIndex1 ^ 0xA5;		
		ER10 = DataCoDecKeyIndex1 ^ 0x5A;		

#pragma asm
		MOV		DPTR,#(_SPARE_AREA_BUF + 16)
		RAN32_EDP0_ER1;//Store ERn to XRAM, and ERn updated with 32-bit pseudo random algorithm	
RAN32_EDP0_ER1;
RAN32_EDP0_ER1;
#pragma endasm

		HPAGE0_P2  = ER10;
		HPAGE1_P2  = ER11 & 0x03;//10bit
		HFRAME_P2  = ER12; //homogeous frame
		HSEEDINIT0_P2 = ER10;
		HSEEDINIT1_P2 = ER11;
		HSEEDINIT2_P2 = ER12;
		HSEEDINIT3_P2 = ER13;


#else
		HPAGE0_P2  = DataCoDecKeyIndex; //pgae
		HPAGE1_P2  = 0;//10bit
		HFRAME_P2  = DataCoDecKeyIndex1; //homogeous frame
#endif

#if !RANDOMIZE_NF
	HCON_P2 = 0x20 | BIT(2) | BIT(0);
#else 		
	HCON_P2 = BIT(2) | BIT(0); 
#endif
	}
#endif
}


extern bit bRemedyPage;
#pragma asm
EXTRN CODE(_PageLg2PhTable,_PageLg2PhTable_SLC_Plane1)
#pragma endasm
void Change_CE(void)
{
	_push_(DPCON);
	_push_(ER40);  //plan num
		
	DPCON = 0x10;			//DPTR0����		

	
if (b2PlaneTrue) {
	ER01 = (SectorPerSmallPage+1+HalfSectorPerSmallPage1)>>1;
	ER00 = (SectorPerSmallPage+1)>>1;
	if 	((R1_Sector == ER01) || ((boundIndex==0xff)&&(R1_Sector > ER01))) {
		boundIndex = 2;
		get_bound_block();
		goto get_bound_end;
	} else if ((R1_Sector == ER00) || ((boundIndex==0xff)&&(R1_Sector > ER00))) {
		boundIndex = 1;
		get_bound_block();
		goto get_bound_end;
	}
}
	ER00 = (HalfSectorPerSmallPage>>1);
	if ((R1_Sector == ER00) || ((boundIndex==0xff)&&(R1_Sector > ER00))) {
		boundIndex = 0;
		if ((*((u8 xdata *)(&_PLANE_MODE)) == 1) && (*((u8 xdata *)(&_PLANE_MODE+2)) == 1)) {
			if ((R2_BlockAddrL&0x03) == 2)
			{
				boundIndex = 1;
			}
		}
		get_bound_block();
	}
get_bound_end:			
		
	Get_PageLg2PhTable();  //��ȡgood bad��ʾ��
	if( (! bSLC2TLCProg) && (!bRemedyPage)){
		//get MSB	
		#pragma asm
		CLR32_ER0
		CLR32_ER1
		#pragma endasm
		ER01 = R4_PageAddrH;
		ER00 = R0_PageAddrL;	
		
		if (!bBlockMode)
		{		
			DPTR0 = (u16 xdata *)(&PLANE_REFERENCE + ZoneLBA*4 + 2);
		} else {
//	if (!bPageGroupSLC) {
//		#pragma asm
//		MOV 	R8,#0
//		MOV 	B,PageGroupNumber  //B05A 01 8T23 03
//		DIV16_ER0
//		#pragma endasm  
//	}		
			DPTR0 = (_FLASH_BLOCK_PAGE_MODE_TABLE + ZoneLBA*4);
		}	
		#pragma asm	
		MOVX	A, @DPTR     //ȡ��ַ
		MOV		B, A
		MOVX  A, @DPTR	
		MOV		DPH, B
		MOV		DPL, A
		#pragma endasm
		bit_search();
	}//Get_PageLg2PhTable_End
	else
	{
		bSLC2TLCProg = 0;
		ER11 = R4_PageAddrH;
		ER10 = R0_PageAddrL;//WL  copy backʱ�õ���wl	
	}
	ER13 = 0;
	ER12 = 0;
	
 	//����3byte��ַ
	ER03 = 0;
	ER02 = 0;	
	ER01 = R3_BlockAddrH;
	ER00 = R2_BlockAddrL;
	if 	(R1_Sector >= (HalfSectorPerSmallPage>>1)) {    	
		ER01 = R3_BlockAddrH_P1;
		ER00 = R2_BlockAddrL_P1;
	}	

	#pragma asm
	MOV		DPTR, # _FLASH_SHIFTCNT
	MOVX	A, @DPTR
	MOV		R8, A

	ROTL32_ER0_ER8
	ADD32_ER0_ER0_ER1//3BYTE��ַ�����R02 ER01 ER00
	#pragma endasm
	
	_pop_(ER40);
	_pop_(DPCON);
}

static void Dptr0_Point_To_BlockPageMode_Tab(void)
{
#if EN_MUL_PAGES_MODE
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����

	#pragma asm
	MOVX	A, @DPTR   
	MOV		B, A
	MOVX   	A, @DPTR
	MOV		DPL, A
	MOV		DPH, B
    #pragma endasm
	 
 	_pop_(DPCON);
#endif
}

/*============================================================
* �Ρ�����:	
IN��R3/R2 BlockPageModeIndex
Out��BlockPageModeIndex _PageLg2PhTable
* ��������:
BlockPageModeIndex_Buf[2] == ��ǰģ�Ͷ�Ӧ��zone
_FLASH_BLOCK_PAGE_MODE_TABLE[zone][4]==[2:tlc bad wl tab dptr][2:]
WORD_LINE_NUMBER:slc wl
WordLineNumberTLC:tlc wl
_PageLg2PhTable_Plane1:��һ�׶�����bad wordlineתgood wordline,tlc table
_PageLg2PhTable:zone 0 slc table 
_PageLg2PhTable_SLC_Plane1:zone 1 slc table 
_PageLg2PhTable_ph:�������߼�wordlineӳ�� zone0 or zone1
============================================================*/
void Get_PageLg2PhTable(void)
{
#if EN_MUL_PAGES_MODE
	if( ! bNeedChkBlockPageModeIndex){
		return;
	}
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����
	bNeedChkBlockPageModeIndex = 0;	
	if(*((u8 xdata *)(& BlockPageModeIndex_Buf + 2)) == ZoneLBA){
		 _pop_(DPCON);
		 return;	
	}
	*((u8 xdata *)(& BlockPageModeIndex_Buf + 2)) = ZoneLBA;
	

 	_pop_(DPCON);	
#endif
}

void NF_Send_CMD0_5ByteAddr(void)
{
	NF_Config_5ByteAddr();
	NPCON_P2 = 0x51;
	Wait_Flash_Ready();
}

static void NF_Config_5ByteAddr(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����

	DPTR0 = (u16)(&NF_DATA);

	#pragma asm
 	MOV32_ER0_EDP0
	#pragma endasm
	NFIFO5_P2 = ER00;
	NFIFO4_P2 = ER01;
	NFIFO3_P2 = ER02;
	NFIFO2_P2 = ER03;

	#pragma asm
 	MOV32_ER0_EDP0
	#pragma endasm
	NFIFO1_P2 = ER00;
	NFIFO0_P2 = ER01;

	_pop_(DPCON);
}

static void change_col(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����

	DPTR0 = (u16)(&NF_DATA);

	#pragma asm
 	MOV32_ER0_EDP0
	#pragma endasm
	NFIFO2_P2 = ER03;

	#pragma asm
 	MOV32_ER0_EDP0
	#pragma endasm
	NFIFO1_P2 = ER00;

	_pop_(DPCON);
}

void switch_er40_r1sec(void) 
{
	if (HalfSectorPerSmallPage == (SectorPerSmallPage+1)) {  //1p
		ER40++;

	} else {  //1p(2p�ϲ�) or 2p(4p�ϲ�)
		R8 = R1_Sector;
		if (R8 == 0) {
			R1_Sector = (HalfSectorPerSmallPage>>1);  //NOT OUT
		} else if (R8 == (HalfSectorPerSmallPage>>1)) {
			R1_Sector = ((SectorPerSmallPage+1) >> 1);
			ER40++;
		} else if (R8 == ((SectorPerSmallPage+1) >> 1)) {					
			R1_Sector = (SectorPerSmallPage+1+HalfSectorPerSmallPage1)>>1;
		} else {
			ER40++;
		}
	}
}

/**********************************************
ÿ��sectorǰ��column
***********************************************/
unsigned char Wr_Badcolumn_AfterData(void)
{
	_push_(DPCON);
	DPCON  = 0;
	
	
	if (R1_Sector > ((SectorPerSmallPage+1)>>1)) {  //4p
			DPTR0 = *(u16 xdata *)(&PLANE_REFERENCE + 2*4);
			B = R1_Sector - ((SectorPerSmallPage+1)>>1);
	} else {
			DPTR0 = *(u16 xdata *)(&PLANE_REFERENCE + ZoneLBA*4);
			B = R1_Sector;
	}

	ACC = 2;
	DPTR_Add_AB();
	#pragma asm
	MOVX	A,@DPTR
	MOV 	NPGSZ1_P2,A
	MOV 	B,A	
//MOV ER01,A	
	INCDP0
	MOVX	A,@DPTR
	MOV 	NPGSZ0_P2,A	
//MOV ER00,A	
	ORL  	B,A
	#pragma endasm
	
	
	_pop_(DPCON);
		
	if (B) {  
		MLC_Buf_Data_Codec();//seed
		BCON1_P2 = 0;
	//	NPGSZ1_P2 = 3;
	//	NPGSZ0_P2 = 0;
		BCMCON_P2 = 0;
		NPCON_P2 = 0x08;
		Wait_Flash_Ready();
		

#if !RANDOMIZE_NF
		HCON_P2 = 0x20;
#else 			
		HCON_P2 = 0;		
#endif	
//prints("br\n");		
		return 1;
	}
	
	return 0;
}


void NF_Prog_Data(void)
{
#if 1//DIS_NF_FUNCTION
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����

#if RANDOMIZE_NF	
	MLC_Buf_Data_Codec();
#endif
	
	DPTR0 = (u16)(& NF_DATA + 8);	
	#pragma asm
	MOV32_ER0_EDP0
	MOV32_ER1_EDP0
	#pragma endasm

	BXADR0H_P2 = ER01;//��������
	BXADR0L_P2 = ER00;

//[6]: 1-data from sram to nfc;
//[5:4]:1-encode mode
//[0]:1-kict start
//	BCON1_P2 = BIT(6) | BIT(4) | BIT(0);

	BCON1_P2 = ER03;//ER03 = BIT(6) | BIT(4) | BIT(0);

	change_col();

	NFIFO0_P2 = NF_RANDOM_DATA_INPUT;
	BCM_KickStart();
	
#if 1//EN_NF_RANDOM_WR_CMD
	NPCON_P2 = 0x29;	 //5BYTE ADDR
#else
	if(bSendReadRandomCmd==0){
		NPCON_P2 = 0x08;
	}else{
		bSendReadRandomCmd = 0;
		NPCON_P2 = 0x59; //5BYTE ADDR
	}

#endif

	_pop_(DPCON);
	
#endif
}

static void BCM_KickStart_NFF(void)   //1k change,��ҪMP TOOL���
{
#if NFFUSING
	_push_(DPCON);
 	DPCON = 0x10;			//DPTR0����

	ER00 = R1_Sector<<1;
	if (ER00 < HalfSectorPerSmallPage) {
		DPTR0 = (u16)(& BCH_MODE_DC_TAB + ZoneLBA*2);
	} else if (ER00 < (SectorPerSmallPage+1)) {
		DPTR0 = (u16)(& BCH_MODE_DC_TAB + (ZoneLBA+1)*2);
	} else if (ER00 < (SectorPerSmallPage+1 + HalfSectorPerSmallPage1)) {
		DPTR0 = (u16)(& BCH_MODE_DC_TAB + 2*2);
	} else {
		DPTR0 = (u16)(& BCH_MODE_DC_TAB + 3*2);
	}
	#pragma asm
	CLR32_ER0
	MOVX	A,@DPTR
	MOV		ER01,A	  
	MOVX	A,@DPTR
	MOV		ER00,A
	#pragma endasm

	DPTR0 = _FLASH_BCMCfg_ADDR_Tmp;  //ȡBCM ���õ�ַ
	#pragma asm
	MOV		A,#4
	MOV 	B,ZoneLBA
	MUL		AB  //�����A
	MOV		B,#16		//32  �ĳ�16��sector
	CALL	dptr_add_ab_maskrom
	MOV		B,DPL
	MOV		A,DPH
	#pragma endasm	
	
	if(R1_Sector < ((SectorPerSmallPage + 1)>>1))
	{
		B = R1_Sector;
	}
	else
	{
		B = R1_Sector  - ((SectorPerSmallPage + 1)>>1) + 32 /*����ǰ���*/;   
	}
	
		#pragma asm
		CLR32_ER1
		MOV		A, #4 
		CALL	dptr_add_ab_maskrom	
		MOVX	A,@DPTR//����
		MOV		ER11,A //�����ݴ�
		MOVX	A,@DPTR//����
		MOV		ER10,A //�����ݴ�
#if !EN_BCM     			//��BCM
		MOV		ER11,#0	
		MOV		ER10,#0
#endif
		MOVX	A,@DPTR//�ߵ�ַ
		PUSH	ACC
//		MOV		ER13,A//�ݴ�
		MOVX	A,@DPTR//�͵�ַ
		PUSH	ACC
		ADD32_ER0_ER0_ER1		//����NP��С,���õ�NFF

		MOV 	ER02,#0x04  //1��ʾ���У�bcm disable,�������random��homos��δ����BCM����clear bcm pending
		POP		ER12
		POP		ER13
		MOV		BCMDAT_P2,#0xFF		//Ŀǰ��δ���ݲ������
		#pragma endasm
		if(ER10|ER11){	//bcm kick start
			ER02 |= 0x01;	
		}
		
	_pop_(DPCON);
#endif	
}

extern bit bTimeout;
void Fill_NFFINBuf(void)//�ϵ������ִ��һ�Σ��ô��Ǽ��ٴ����Լ����ٵ�һ��prog������ʱ��   
{
#if NFFUSING
		unsigned char idata planeSecNum;
		planeSecNum =  (SectorPerSmallPage+1);
		if (R1_Sector >= ((SectorPerSmallPage+1)>>1))
		{
			planeSecNum = (SectorPerSmallPage1+1);	
		}
	
		if(R8Tmp< (planeSecNum>>1))//16)
		{
			if(NFFINBuf[((planeSecNum>>1)-1)*NFFINBuf_SIZE+0]!=NFIFO5_P2_NFF)
			{				
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+0]=NFIFO5_P2_NFF;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+2]=NFIFO4_P2_NFF;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+4]=NFIFO3_P2_NFF;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+6]=NFIFO2_P2_NFF;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+8]=NFIFO1_P2_NFF;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+10]=NFIFO0_P2_NFF;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+11]=NF_RANDOM_DATA_INPUT;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+12]=BXADR0H_P2_NFF;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+14]=BXADR0L_P2_NFF;

				NFFINBuf[R8Tmp*NFFINBuf_SIZE+16]=BCON1_P2_NFF;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+17]=BIT(6) | BIT(4) | BIT(0);


				NFFINBuf[R8Tmp*NFFINBuf_SIZE+20]=HFRAME_P2_NFF;

				NFFINBuf[R8Tmp*NFFINBuf_SIZE+22]=HCON_P2_NFF;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+23]=0x00;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+24]=HCON_P2_NFF;
	
				#if (EN_RANDOMIZE_DATA==1)	//debug
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+25]=BIT(2) | BIT(0);
				#else
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+25]=0;		
				#endif					

				NFFINBuf[R8Tmp*NFFINBuf_SIZE+42]=NPCON_P2_NFF;

				NFFINBuf[R8Tmp*NFFINBuf_SIZE+18]=NACMD1_P2_NFF;//NTCON1_P2_NFF;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+19]=0x11;//acmd
					NFFINBuf[R8Tmp*NFFINBuf_SIZE+43]=0x29;//59;

				NFFINBuf[R8Tmp*NFFINBuf_SIZE+26]=BXADR1H_P2_NFF;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+28]=BXADR1L_P2_NFF;
				if(R8Tmp==0)   //sec0.block
				{
					NFFINBuf[R8Tmp*NFFINBuf_SIZE+27]=(u8)((_SPARE_AREA_BUF ) >> 8);
					NFFINBuf[R8Tmp*NFFINBuf_SIZE+29]=(u8)((_SPARE_AREA_BUF ) >> 0);
				}
				else					 //secx.pagelba
				{
					NFFINBuf[R8Tmp*NFFINBuf_SIZE+27]=(u8)(((_SPARE_AREA_BUF+8) ) >> 8);
					NFFINBuf[R8Tmp*NFFINBuf_SIZE+29]=(u8)(((_SPARE_AREA_BUF+8) ) >> 0);
				}
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+30]=BCMADRH_P2_NFF;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+32]=BCMADRL_P2_NFF;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+34]=NPGSZ1_P2_NFF;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+36]=NPGSZ0_P2_NFF;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+38]=BCMCON_P2_NFF;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+40]=BCMCON_P2_NFF;


				ER02 = R8Tmp;
				ER02 <<= 1;  //1k	
		
				Sel_Buffer_Addr();//R8Tmp-->ER01 ER00
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+13]=ER01;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+15]=ER00;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+44]=0xFF;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+45]=0xFF;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+46]=0xFF;
				NFFINBuf[R8Tmp*NFFINBuf_SIZE+47]=0xFF;
			}
			//�Ż��ⲿ�ִ���

			
			NFFINBuf[R8Tmp*NFFINBuf_SIZE+21]=DataCoDecKeyIndex1;

			R1_Sector = DataCoDecKeyIndex1;	
			BCM_KickStart_NFF();								 
			NFFINBuf[R8Tmp*NFFINBuf_SIZE+31]=ER13;
			NFFINBuf[R8Tmp*NFFINBuf_SIZE+33]=ER12;		
			NFFINBuf[R8Tmp*NFFINBuf_SIZE+35]=ER01;
			NFFINBuf[R8Tmp*NFFINBuf_SIZE+37]=ER00;
			NFFINBuf[R8Tmp*NFFINBuf_SIZE+39]=0;
			NFFINBuf[R8Tmp*NFFINBuf_SIZE+41]=ER02;
			R1_Sector = DataCoDecKeyIndex1;
	  		Get_ColAddr();//R1-->ER01 ER00

			NFFINBuf[R8Tmp*NFFINBuf_SIZE+7]=ER01;
			NFFINBuf[R8Tmp*NFFINBuf_SIZE+9]=ER00;
							
			R1_Sector = DataCoDecKeyIndex1;
if (FlashType == _B05A_) {   			

} else {
			Change_CE();//R3 R2 R4 R0 R1-->ER02 ER01 ER00
			NFFINBuf[R8Tmp*NFFINBuf_SIZE+1]=ER02;
			NFFINBuf[R8Tmp*NFFINBuf_SIZE+3]=ER01;
			NFFINBuf[R8Tmp*NFFINBuf_SIZE+5]=ER00;
}	
			R8Tmp++;
			NFFENCNT_P2	= R8Tmp;			//�ܹ����ô���

			DataCoDecKeyIndex1++;
		}
#endif		
}


void NF_Prog_Data_Wait(void)
{
#if 0//DIS_NF_FUNCTION
	
	Wait_Flash_Ready();	

	while(! (BCON1_P2 & (1 << 7))){};
	BCON1_P2 &= 0x7f;	   //;Clr done
	BCMCON_P2= 0;
	
#endif
}



void NF_Prog_Stop(void)
{

	if(ProgramCMD1){
		NACMD1_P2 = ProgramCMD1;	
		NPCON_P2 = 0x80;
		Wait_Flash_Ready();
	}
	
	BCON1_P2 = 0;//�ر�BCM��������data�޹صĺ����Ͳ���Ҫ��ֵ
	BCMCON_P2= 0;
}



void Buf_Data_CoDec(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����

	if(bReadBlankBlock){  //��page
		ER02 = RandomIndex;
		Sel_Buffer_Addr();
		DP0H = ER01;
		DP0L = ER00;
		ER03 = 0xff;
		ER02 = 0xff;
 		ER01 = 0xff;
		ER00 = 0xff;
	#if MODE_1K_EN
		B = (u8)((1024 / (4 * 4)));
	#else
		B = (u8)((512 / (4 * 4)));
	#endif
		do{
			#pragma asm
			MOV32_EDP0_ER0
			MOV32_EDP0_ER0
			MOV32_EDP0_ER0
			MOV32_EDP0_ER0
			#pragma endasm		
			B--;
		}while(B);	
	 }

#if RANDOMIZE_NF	 
	 
#else
	else {
		DPCON = 0x00;
		
		//ֱ�Ӵ�����ȥȡ��page����
		ER02 = RandomIndex;
		Sel_Buffer_Addr();
		DP0H = ER01;
		DP0L = ER00;
		#pragma asm
		MOV		R8,#0x04
		MOV		B ,#0x02
		ADDDP0	
		MOVX 	A,@DPTR
		MOV 	ER00,A
		#pragma endasm
		DataCoDecKeyIndex = ER00&0x1f;
//		
//prints("seed:\n");		
//printHexSync(ER00);			
		
		//��sector����ȡ��
		DPTR0 = (u16)(&_PagePhAddr_Buf+1);
		B = RandomIndex>>1;
		ACC = _PagePhAddr_Buf_SIZE;
		DPTR_Add_AB();
		#pragma asm
		MOVX	A,@DPTR
		MOV		B,A
		#pragma endasm
		DataCoDecKeyIndex1 = B;
		
//printHexSync(DataCoDecKeyIndex1);			
//		ER02 = RandomIndex;
//		pr_buf();
		
		MLC_Buf_Data_Codec();	
		ER02 = RandomIndex;
		random_inram();
		RDC_WaitOver();

//		ER02 = RandomIndex;
//		pr_buf();		
	}
#endif	 
		
		_pop_(DPCON);
}

void BCH_Config_Decode1time(void)//������β���Ҫִ�����������֮ǰ����Ϊax215e���쳣��tankӦ��û������
{
}

void BCH_MODE_DC_Wait_Over(void)
{
	
#if 1 //DIS_NF_FUNCTION
	
	bTerribleError = 0;
	bLg2PhVerifyError = 0;

	while( ! (BCON0_P2 & (1 << 7))){}; 	// done

		
	if(BCON0_P2 & (1 << 5)){		//has err
		BECNTTmp = 0xff;
		if( !(BCON0_P2 & (1 << 6))){	//correctable
			BECNTTmp = BECNT_P2;

		}else{				
			bTerribleError = 1;
			bLg2PhVerifyError = 1;
		}	
	}

	BCON0_P2 &= ~(1 << 7);		//kict start next packet.

#endif

//	if (BlockLBAL == 0)   //??????debug
//	{
//prints("ready retry\n");		
//			bTerribleError = 1;
//			bLg2PhVerifyError = 1;
////		if (!RetryCnt) {
////			RetryCnt =31;
////		}
//	}
}


void Chk_Blank_Block(void)
{
	if( ! bReadNeedChkBankBlk){
		return;	
	}
	bReadNeedChkBankBlk = 0;		//Ĭ��1��pageֻcheckһ��sector���������Ƿ����blank blk���ص�
#if 1
//			prints("blank:");
//			printHexSync((NDCTCNT1_P2*0x100+NDCTCNT0_P2)>>8);
//			printHexSync((NDCTCNT1_P2*0x100+NDCTCNT0_P2)&0xff);
//			prints("\n");
	
	if(/*((NDCTCNT1_P2*0x100+NDCTCNT0_P2) > 0x2000) || */((NDCTCNT1_P2*0x100+NDCTCNT0_P2) < 0x80))//��0�ĸ���
	{
		bReadBlankBlock = 1;
		
	}
	else
	{
		bReadBlankBlock = 0;	
	}
#else	
	_push_(DPCON);
 	DPCON = 0x10;			//DPTR0����

	//����00��FF�ĸ���
	bReadBlankBlock = 0;
//	bReadBlankBlock_0 = 0;

	DPTR0 = (_SPARE_AREA_BUF+8); 

	ER41 = 0;   //FF
	ER42 = 0;   //00
	for(ER40 = 16; ER40 != 0; --ER40){
		#pragma asm
		 MOVX	A,@DPTR
		 MOV	R8, A
		#pragma endasm
		if( ! R8){
			ER42++;		//=0x00
		}else if(R8 == 0xff){
		   	ER41++;		//=0xff
		}	
	}


	//����FF�ĸ����ж��Ƿ�Ϊ�տ�
	if(ER41 < (16 - 3)){
		//����00�ĸ����ж��Ƿ�Ϊ�տ�
		if(ER42 >= (16 - 3)){
//			bReadBlankBlock = 1;	//��page//MT29F8G16ABBCAд00����ʱ�ᴥ����bit��������δ�ҵ�ԭ����ʱ�ر�
//			bReadBlankBlock_0 = 1;
		}
	}else{
		bReadBlankBlock = 1;  //��page
	}
	_pop_(DPCON);
#endif
}

/*============================================================
* �Ρ�����: R0--ubPhLargePageAddr 
*			R1--ubPhSectorAddr
*	    	R3 R2-----uwPhBlockAddr
* ��������: Read a sector
============================================================*/
#pragma asm
		EXTRN CODE(Retry_Register_CMD)
#pragma endasm
void NF_Read_Start(void)
{
//NTCON1_P2=0x0f;
	unsigned char idata tmp=R1_Sector;

	boundIndex = 0xff;//�п��ܲ��Ǵ�һ��page��ʼ������
	
	select_ecc_bits(DECODE | R1_Sector);

	bNeedChkBlockPageModeIndex = 1;
NF_Reset();

	if(bNeedSend5DCMDSLC){
	#pragma asm
		MOV		DPTR,#Retry_Register_CMD		
		MOVX	A,@DPTR					
	#pragma endasm
		NF_Send_CMD_Only(); 
	}

	B = NF_SLC_MODE_TOSHIBA; //A2 CMD
	if((! bPageGroupSLC) && bBlockMode){
	B = NF_TLC_MODE_TOSHIBA;
	}
	ACC = B;
	NF_Send_CMD_Only();
 	
	NF_Write_Addr();
	
	//��00 5byte addr 30������������column��ַ����R1����
	NACMD1_P2 = NF_READ_2ND;	   //;command 1 = 0x30 (start read)
	NF_Config_5ByteAddr();
	NFIFO2_P2 = 0;
	NFIFO1_P2 = 0;
	NFIFO0_P2 = NF_READ_1ST;
	NPCON_P2 = 0xD1;
	Wait_Flash_Ready();

	NXADR1_P2 = _SPARE_AREA_BUF;
#if !RANDOMIZE_NF
	//��ֱ����������buf
	NXCNT0_P2 = 1028 / 4;   //����ʱ����1028��,д��ʱ����1024д
	NXCNT1_P2 = 160/*128*//4;			//use NXADR2_P2   
#else 
	NXCNT0_P2 = 1024 / 4;   //1k change
	NXCNT1_P2 = 160/4;			//use NXADR2_P2   
#endif  


	bReadNeedChkBankBlk = 1;
	bSendReadRandomCmd = 1;

	R1_Sector = tmp;
}


void NF_Read_Start_Copy(void)
{
		R1_Sector = 0;

		bNeedChkBlockPageModeIndex = 1;

		ACC = NF_SLC_MODE_TOSHIBA;	//A2 CMD
		NF_Send_CMD_Only();	

		ER40 = 0;
		do{		
			NACMD1_P2 = 0x32;	//NF_READ_2ND 

			Change_CE();    
//if (yScrtyUnitCnt == 100)
//{
//	prints("cc:");	
//	printHexSync(ER02);
//	printHexSync(ER01);
//	printHexSync(ER00);
////	yScrtyUnitCnt = 0;
//	prints("\n");
//}
	
			NFIFO5_P2 = ER02 ;
			NFIFO4_P2 = ER01 ;//| ER40;
			NFIFO3_P2 = ER00;
			NFIFO2_P2 = 0;//ER10; 
			NFIFO1_P2 = 0;//ER11; 
			NFIFO0_P2 = 0; 
			
			switch_er40_r1sec();
			
			if (ER40 == PlaneNum) {
				
				if(FlashType == _SUMSUNG_21_)
				{							
					NACMD1_P2 = 0x39;//5;	//NF_READ_2ND
				}
				else
				{
					NACMD1_P2 = 0x35;	//NF_READ_2ND
				}
		
			}	
			
			NPCON_P2 = 0xD1;
			Wait_Flash_Ready();
		}while(ER40 != PlaneNum);		
		
		R1_Sector = 0;
}


void NF_Read_Data(void)
{
	_push_(DPCON);
	
	DPCON = 0x00;

	DataCoDecKeyIndex1 = R1_Sector;	

#if RANDOMIZE_NF	
	MLC_Buf_Data_Codec();	
#else 	
	//����sector����,��ʱpage���ӻ�δ֪��
	DPTR0 = (u16)(&_PagePhAddr_Buf)+1;
	B = R8Tmp>>1;
	ACC = _PagePhAddr_Buf_SIZE;
	DPTR_Add_AB();
	B = DataCoDecKeyIndex1;
	#pragma asm
	MOV		A,B
	MOVX	@DPTR,A
	#pragma endasm
	
#endif	

if ((R1_Sector == (HalfSectorPerSmallPage>>1)) || (R1_Sector == ((SectorPerSmallPage+1+HalfSectorPerSmallPage1)>>1))) {  //1p(2p�ϲ�)  2p(4p�ϲ�)
	NF_Write_Addr();   //���һ��ʼ������������µ����ٷ�һ��

	B = NF_SLC_MODE_TOSHIBA; //A2 CMD
	if((! bPageGroupSLC) && bBlockMode){
	B = NF_TLC_MODE_TOSHIBA;
	}
	ACC = B;
	NF_Send_CMD_Only();
 	

	
	//��00 5byte addr 30������������column��ַ����R1����
	NACMD1_P2 = NF_READ_2ND;	   //;command 1 = 0x30 (start read)
	NF_Config_5ByteAddr();
	NFIFO0_P2 = NF_READ_1ST;
	NPCON_P2 = 0xD1;
	Wait_Flash_Ready();
} else {
	Get_ColAddr();
}	
#if 1//DIS_NF_FUNCTION

	ER02 = R8Tmp;

	Sel_Buffer_Addr();
	NXADR0H_P2 = ER01;
	NXADR0L_P2 = ER00;

	BCON1_P2 = BIT(6) | BIT(5) | BIT(0);		//data from nfc, decode, hardware auto error correct, kict start.

#if 1//EN_NF_RANDOM_RD_CMD
	Get_ColAddr();	
	NFIFO3_P2= NF_RANDOM_DATA_OUTPUT_2;
	change_col();
	NFIFO0_P2 = NF_RANDOM_DATA_OUTPUT_1;
	BCM_KickStart();

	NPCON_P2 = 0x27;
#else 
	NFIFO6_P2= NF_RANDOM_DATA_OUTPUT_2;
	NF_Config_5ByteAddr();
	NFIFO0_P2 = NF_RANDOM_DATA_OUTPUT_1;
	BCM_KickStart();
	bSendReadRandomCmd = 0;
	NPCON_P2 = 0x57; //5BYTE ADDR

#endif	

	R1_Sector++;
#endif 

	_pop_(DPCON);
}


/*============================================================
* �Ρ�����: R3 R2 = unsigned int uwPhBlockAddr
* ��������: Performs a Block Erase operation	
============================================================*/
void NF_Erase_Block(void)
{
//prints("PP:");	
//printHexSync(R3_BlockAddrH);
//printHexSync(R2_BlockAddrL);
//prints("\n");	
NF_Reset();	
	R1_Sector = 0;
	R4_PageAddrH = 0;
	R0_PageAddrL = 0; 

	if(bPageGroupSLC || (! bBlockMode)){
		ACC = NF_SLC_MODE_TOSHIBA;	 //SLC mode��send A2 CMD
		NF_Send_CMD_Only();
	}
	else
	{
		ACC = NF_TLC_MODE_TOSHIBA;	 //TLC mode��send DF CMD
		NF_Send_CMD_Only();
	}
	ER40 = 0;
	do{
		bSLC2TLCProg = 1;
	 	Change_CE();     
	
		//1p  1p(2p�ϲ�) or 2p(4p�ϲ�)
		switch_er40_r1sec();
		
		NACMD1_P2 = NF_BLOCK_ERASE_2;
		NFIFO3_P2 = ER02;
		NFIFO2_P2 = ER01 ;//| ER40;
		NFIFO1_P2 = ER00;
		NFIFO0_P2 = NF_BLOCK_ERASE_1;
//printHexSync(ER02);		
//printHexSync(ER01);
//printHexSync(ER00);		

		B = 0x31;
		if(ER40 == PlaneNum){
			B = 0xB1;	//���D0
		}
		NPCON_P2 = B;
		Wait_Flash_Ready();		 	

	}while(ER40 != PlaneNum);		
	R1_Sector =	0;
}


/*============================================================
* �Ρ�����: R0--ubPhPageAddr 
*			R1--ubPhSectorAddr
*	    	R3 R2-----uwPhBlockAddr
* ��������: 
============================================================*/
void NF_Write_Addr(void)
{

	_push_(DPCON);
 	DPCON = 0x10;			//DPTR0����	
	
	Change_CE();
	DPTR0 = (u16)(& NF_DATA);
	
	#pragma asm
	MOV		A,ER02
	MOVX	@DPTR,A//NFIFO5_P2
	MOV		A,ER01
	MOVX	@DPTR,A//NFIFO4_P2
	MOV		A,ER00
	MOVX	@DPTR,A//NFIFO3_P2
	#pragma endasm
#if 0
	if (yScrtyUnitCnt == 100)
	{
		prints("KK:");
		printHexSync(ER02);
		printHexSync(ER01);
		printHexSync(ER00);	
		prints("\n");
		yScrtyUnitCnt = 0;
	}
#endif
	Get_ColAddr();

	_pop_(DPCON);	
}


/*============================================================
* �Ρ�����:R1-->ER01 ER00
* ��������: 
============================================================*/
static void Get_ColAddr(void)
{
	_push_(DPCON);
 	DPCON = 0x10;			//DPTR0����

	if(ZoneLBA == 0) {
		DPTR0 = (u16)(&_SectorLg2PhTable);	
			
	if (R1_Sector >= ((SectorPerSmallPage+1)>>1)) {
		DPTR0 = (u16)(&_SectorLg2PhTable_Plane2);
	}

	} else if(ZoneLBA == 1) {
		DPTR0 = (u16)(&_SectorLg2PhTable_Plane1);
	} else if(ZoneLBA == 2) {
		DPTR0 = (u16)(&_SectorLg2PhTable_Plane2);
if (R1_Sector >= ((SectorPerSmallPage+1)>>1)) {
	DPTR0 = (u16)(&_SectorLg2PhTable_Plane3);
}
		
	} else if(ZoneLBA == 3) {
		DPTR0 = (u16)(&_SectorLg2PhTable_Plane3);	
	}
	
	
	if(b2PlaneTrue){   //2p(4p�ϲ�)  �ϵ��p0/p1  p2/p3 sectorģ�ͷų�����
		if (R1_Sector < ((SectorPerSmallPage+1)>>1)) {  
			B = R1_Sector;
		} else  {
			B = R1_Sector - (u8)((SectorPerSmallPage+1)>>1);	
		}
	} else {  //1p 1p(2p�ϲ�)  �ϵ��Ѱ�����sectorģ�ͺϲ�
		B = R1_Sector;	
	}
	
	ACC = 2;
	
	DPTR_Add_AB();
	#pragma asm
	MOVX	A,@DPTR
//	MOV		NFIFO2_P2,A
	MOV		ER01,A
	MOVX	A,@DPTR
//	MOV		NFIFO1_P2,A
	MOV		ER00,A
	#pragma endasm

	DPTR0 = (u16) (& NF_DATA + 3);
	#pragma asm
	MOV		A,ER01
	MOVX	@DPTR,A//NFIFO2_P2
	MOV		A,ER00
	MOVX	@DPTR,A//NFIFO1_P2
	#pragma endasm

	_pop_(DPCON);

}

void Get_R1_Addr(void)
{

	if(R8 < (u8)(SectorPerSmallPage + 1)){  //plane0

	}else{																	//plane1
		R8 = R8 - (u8)(SectorPerSmallPage + 1);	
	}	
}

/*============================================================
* �Ρ�������ZoneLBA
* ��������:
				��ȡZoneLBA��
				_PageLg2PhTable
				_SectorLg2PhTable
				SectorPerSmallPage
				LargePagePerBlock
				SectorPerBlockH/L
============================================================*/
void Get_CurPlaneCfg(void)
{
	_push_(DPCON);
 	DPCON = 0x00;			//DPTR0������
	//Cur_ZoneLBA init value?
	if (ZoneLBA != *((u8 xdata *)(& Cur_ZoneLBA))){
		*((u8 xdata *)(& Cur_ZoneLBA)) = ZoneLBA;
		_push_(ER00);	
		_push_(ER01);
		_push_(ER02);
		_push_(ER03);

/*
��ѡ2p: *((u8 xdata *)(&_PLANE_MODE+0) = 01
		1st ZoneLBA = 03
		2nd ZoneLBA = 00

		1st *((u8 xdata *)(&_PLANE_MODE+ZoneLBA) = 00
		2nd *((u8 xdata *)(&_PLANE_MODE+ZoneLBA) = 01

		prints("PZ ");
printHexSync(*((u8 xdata *)(&_PLANE_MODE+0)));
printHexSync(ZoneLBA);
printHexSync(*((u8 xdata *)(&_PLANE_MODE+ZoneLBA)));

prints("\n");
*/


if (*((u8 xdata *)(&_PLANE_MODE+ZoneLBA))== 2)
{
prints("2P\n");
	b2PlaneTrue = 1;
	bPlaneMag = 1;	  
} else {
	b2PlaneTrue = 0;
	bPlaneMag = 0;	  
}
		
	
		/*
			_FLASH_SECTORPERSMALLPAGE
			_FLASH_SECTORPERSMLPAGEPLN2
			init value?
		*/
		if (ZoneLBA == 0) {
			//prints("sm0\n");
			DPTR0 = (u16)(& _FLASH_SECTORPERSMALLPAGE);
		} else if (ZoneLBA == 1) {
			//prints("sm1\n");
			DPTR0 = (u16)(& _FLASH_SECTORPERSMLPAGEPLN2);
		} else if (ZoneLBA == 2) {
			//prints("sm2\n");
			DPTR0 = (u16)(& _FLASH_SECTORPERSMLPAGEPLN4);
		} else if (ZoneLBA == 3) {
			//prints("sm3\n");
			DPTR0 = (u16)(& _FLASH_SECTORPERSMLPAGEPLN6);
		}
		DPCON = 0x10;			//DPTR0����
		#pragma asm
		MOVX	A,@DPTR		
		MOV		SectorPerSmallPage,A
		MOVX	A,@DPTR
		MOV 	ER01,A
		MOVX	A,@DPTR
		MOV 	ER00,A			
		MOVX	A,@DPTR
		MOV		PageGroupNumber,A
		MOVX	A,@DPTR
		MOV		HalfSectorPerSmallPage,A
		MOVX	A,@DPTR
		MOV		ER13,A 
		MOVX	A,@DPTR
		MOV		ER12,A
		#pragma endasm					
		WordLineNumberTLC = (ER13*0x100 + ER12);  
		WordLineNumber = (ER01*0x100 + ER00);		
//WordLineNumber--;
//WordLineNumber--;
//WordLineNumber--;
//WordLineNumber--;
	/*
		1st 0000
		2nd 0058
	*/
		//prints("sm ");
		//printHexSync(PageGroupNumber); 
		//printHexSync(WordLineNumber);
		//prints("\n");

		LargePagePerBlockH = ER13;   //��page program
		LargePagePerBlockL = ER12; 

if(FlashType == _SUMSUNG_21_)
{
	WORD_LINE_NUMBER = 192;
	OrderTotal = 192;
}
else if(FlashType == _SUMSUNG_14_)
{
	WORD_LINE_NUMBER = 384;
	OrderTotal = 384;
}
else
{
	WORD_LINE_NUMBER = 256;
	OrderTotal = 256;
}


	*((u8 xdata *)(& ShiftCnt)) = 8;
	bPageGroupSLC = 0;
	if(PageGroupNumber == 1){
		bPageGroupSLC = 1;	
#warning "slc modeǿ�ƹر���cache"
	bCacheCmd = 0;  //disable cache 

if(FlashType == _SUMSUNG_21_)
{
	OrderTotal = 64;
	WORD_LINE_NUMBER = 	64;
}
else if(FlashType == _SUMSUNG_14_)
{
	OrderTotal = 132;
	WORD_LINE_NUMBER = 	132;
}
else
{
	OrderTotal = 88;
//	bCacheCmd = 0;			
	WORD_LINE_NUMBER = 	88;
}
bFlashMode2 = 1;  //slc ��������д,������������Ǹ�ʽ��ʧ�ܲ�����
	}
		

		if(b2PlaneTrue){
		DPTR0 = (u16)(& _FLASH_SECTORPERSMLPAGEPLN4);	
			#pragma asm
			MOVX	A,@DPTR				
			MOV		SectorPerSmallPage1,A
			MOVX	A,@DPTR
			MOVX	A,@DPTR
			MOVX	A,@DPTR
			MOVX	A,@DPTR
			MOV		HalfSectorPerSmallPage1,A
			#pragma endasm		
		}else{
			//prints("zero\n");
			SectorPerSmallPage1 = 0;
			HalfSectorPerSmallPage1 = 0;
		}
		
		ER13 = 0;		
		ER12 = PageGroupNumber;
		ER11 = WordLineNumberTLC>>8;  //slc
		ER10 = WordLineNumberTLC;		
		#pragma asm
		MUL16_ER1
		#pragma endasm
		
		ER03 = 0;		
		ER02 = 0;
		ER01 = WordLineNumber>>8;  //slc
		ER00 = WordLineNumber;			
		B = 1;
		//prints("cn1:");  //ER0 is 0058
		while (1) {
			#pragma asm
			SUB32_ER1_ER1_ER0
			#pragma endasm
			
			//printHexSync(ER11);
			//printHexSync(ER10);
			//prints("\n");
			if (EC || EZ) 
				break;
			B++;  //?
		}
		ER12 = B + 2;
if (ER12 > 8) { //Ϊʲô���ܳ���8?
	ER12 = 8;
}		
//prints("cn:");
//printHexSync(ER12);
//prints("\n");

		ER13 = 0;
		ER11 = WordLineNumber>>8;  //slc
		ER10 = WordLineNumber;		
		#pragma asm
		MUL16_ER1
		#pragma endasm

		DPCON = 0x00;			//DPTR0������
			
		*((u8 xdata *)(& CacheBlockMaxPageH)) = ER11;
		*((u8 xdata *)(& CacheBlockMaxPageL)) = ER10;
if ((CacheBlockMaxPageH*0x100+CacheBlockMaxPageL) > 0xf00)  //���֧�ֶ�д4094-2304��page
{
	*((u8 xdata *)(& CacheBlockMaxPageH)) = 0x0f;
	*((u8 xdata *)(& CacheBlockMaxPageL)) = 0x00;  //0~0xffe  //���4094��   //chk cache full������Ҫ�ı�
}	
		

		SectorPerSmallPageTotal = SectorPerSmallPage;
		PlaneNum = 1;
		if(b2PlaneTrue){
			SectorPerSmallPageTotal = ((SectorPerSmallPage+1) + (SectorPerSmallPage1+1) - 1);//����(u8)�쳣
			PlaneNum = 2;
		}
		
		ER11 = 0;
		ER10 = SectorPerSmallPageTotal + 1;
		ER13 = LargePagePerBlockH;
		ER12 = LargePagePerBlockL;
		#pragma asm
		MUL16_ER1
		#pragma endasm
		DPCON = 0x10;   //setors in block̫����
		DPTR0 = (u16)(&SectorPerBlock);
		#pragma asm
		MOV 	A,ER13
		MOVX	@DPTR,A
		MOV 	A,ER12
		MOVX	@DPTR,A
		MOV 	A,ER11
		MOVX	@DPTR,A
		MOV 	A,ER10
		MOVX	@DPTR,A
		#pragma endasm
		
		DPTR0 = (_FLASH_BLOCK_PAGE_MODE_TABLE + ZoneLBA*4);
		#pragma asm	
		MOVX	A, @DPTR     //ȡ��ַ
		MOV		B, A
		MOVX  A, @DPTR	
		MOV		DPH, B
		MOV		DPL, A
		#pragma endasm
		ER01 = 0;
		ER00 = 0;
		bit_search(); 		
		FirstGoodWL = ER11*0x100+ER10; //�����ҵ��˵�һ��good worl line?
		
		_pop_(ER03);
		_pop_(ER02);
		_pop_(ER01);
		_pop_(ER00);		 					
	}

	_pop_(DPCON);
}


static void Prog_Lg2PhTable_Page(void)
{

}

static void Buf_Lg2PhTable_2_0(void)
{

}

static void Read_Lg2PhTable_Page(void)
{

}

static void Buf_0_2_Lg2PhTable(void)
{

}

void Read_Sectors(void)
{

	DataCoDecKeyIndex1 = R1_Sector;
	if (SectorNum) {
			timer_tick_clr();

			RandomIndex = R8Tmp;
			
			R1_SectorTmp = R1_Sector;
			
			while(1){
				if( ! SectorNum){
					break;
				}

			RdCurZone = SectorNum;
			R1_Sector = R1_SectorTmp;
			R8Tmp = RandomIndex;
			NF_Read_Start();
			NF_Read_Data();
		   
			R8Tmp++;
			R8Tmp++;
			NF_Wait_Read_Over();			
			Chk_Blank_Block();			
			RdCurZone--;
			RdCurZone--;

			if(RdCurZone){
				NF_Read_Data();			   
			   	R8Tmp++;
				R8Tmp++;
			}

//Read_Sectors_Loop
		   	do{
				if(RdCurZone){
					NF_Wait_Read_Over();
//					Chk_Blank_Block();	
	
					RdCurZone--;
					RdCurZone--;
				}
	
				if( ! SectorNum){
					break;
				}
	
				if(RdCurZone){
					NF_Read_Data();
				   	R8Tmp++;
					R8Tmp++;
				}
				BCH_MODE_DC_Wait_Over();

				if((BECNTTmp < 0xFF) && (BECNTTmp > 0x10))
				{
					if(bBlockMode)
					{
//							prints("NoRe TLC:");
					}
					else
					{		
//							prints("NoRe SLC:");//}
							printHexSync(UartIndex);
							printHexSync(BECNTTmp);
							printHexSync(BlockLgAddrH);
							printHexSync(BlockLgAddrL);
							printHexSync(PageLBAH);
							printHexSync(PageLBAL);
								
							printHexSync(R3_BlockAddrH);
							printHexSync(R2_BlockAddrL);		
							printHexSync(R4_PageAddrH);
							printHexSync(R0_PageAddrL);
							prints("\n");
					}
				}

				Chk_Need_Retry();			
			}while( ! bLg2PhVerifyError);	 	//���ж������Ƿ���ȷ	
		}
	}

	reset_bch();

}


static void Chk_Need_Retry(void)
{
	//���ж��Ƿ��δд����block
if (RetryCnt > 0) 
	bReadBlankBlock = 0;   //�������ݱ�try��ff	


	if (!bReadBlankBlock){  
#if	RETRY_EN
#else
		 RetryCnt = 0;
		 bLg2PhVerifyError = 0;
#endif
//		if(bReadBlankBlock || bLg2PhVerifyError){
		if(bLg2PhVerifyError){
//Chk_Need_Retry_Data_Fail:
			if(bFlashRetryTimeOut){
				RetryCnt = RETRY_NUBER;
				prints("time out\n");	
			}
			RetryCnt++;
			if(RetryCnt == RETRY_NUBER + 1){
			//Chk_Need_Retry_GiveUp
				Set_Retry_Register_Default_Data();
				bLg2PhVerifyError = 0;
//#if BAUDRATE
if(bBlockMode)
		prints("Give TLC:");
else
		prints("Give SLC:");
		printHexSync(UartIndex);
		printHexSync(RetryCnt);			
		printHexSync(BlockLgAddrH);
		printHexSync(BlockLgAddrL);
		printHexSync(PageLBAH);
		printHexSync(PageLBAL);
			
		printHexSync(R3_BlockAddrH);
		printHexSync(R2_BlockAddrL);		
		printHexSync(R4_PageAddrH);
		printHexSync(R0_PageAddrL);
			
		prints("\n");
//#endif
				return;
			}else{
				bLg2PhVerifyError = 1;
				Set_Retry_Register_Offset_Data();
				return;
			}					
		}else{	//������ȷ
			if(RetryCnt){	 //������ȷ�����Ѿ�retry��
#if BAUDRATE

if(bBlockMode)
{
//		prints("Pass TLC:");
}
else
{		
		prints("Pass SLC:");
		printHexSync(UartIndex);
		printHexSync(RetryCnt);
		printHexSync(BlockLgAddrH);
		printHexSync(BlockLgAddrL);
		printHexSync(PageLBAH);
		printHexSync(PageLBAL);
			
		printHexSync(R3_BlockAddrH);
		printHexSync(R2_BlockAddrL);		
		printHexSync(R4_PageAddrH);
		printHexSync(R0_PageAddrL);
printHexSync(BECNTTmp);
		prints("\n");}

#endif
				Set_Retry_Register_Default_Data();	
				return;
			}
		}	
	}
	//Chk_Need_Retry_NoNeedRetry_1:
	//����Ҫretry��ֱ�ӷ���
	RetryCnt = 0;
	Buf_Data_CoDec();
	R1_SectorTmp++;

	RandomIndex++;
	RandomIndex++;
	SectorNum--;
	SectorNum--;
	
	bLg2PhVerifyError = 0;
}

static void Set_Retry_Register_Default_Data(void)
{
	Buf_Data_CoDec();
	DataCoDecKeyIndex1++;
	
	R1_SectorTmp++;

	RandomIndex++;
	RandomIndex++;
	SectorNum--;
	SectorNum--;
	
	RetryCnt = 0;
}

static void Set_Retry_Register_Offset_Data(void)
{
	reset_bch();
	bRetryBlockMode = bBlockMode;
	Set_Retry_Register_Data();
}

void Prog_A_Page_CacheBlock(void)
{
#if !NFFUSING
	_push_(DPCON);
 	DPCON = 0x00;			//DPTR0������
	
#if !RANDOMIZE_NF	
	DataCoDecKeyIndex = R0_PageAddrL&0x1f;
#endif
	
	//BCH Encode ��ʼ��
	select_ecc_bits(ENCODE | R1_Sector);

	BXADR1H_P2 = (u8)((_SPARE_AREA_BUF ) >> 8);
	BXADR1L_P2 = (u8)((_SPARE_AREA_BUF ) >> 0);

	BPT0SZ_P2 = 1024 / 4;
	BPT1SZ_P2 = 160/4; 

	bSendReadRandomCmd = 1;

yScrtyUnitCnt = 100;		
  bNeedChkBlockPageModeIndex = 1;
	
	NF_Write_Addr();
//row:NF_DATA[0], NF_DATA[1],NF_DATA[2],
//col :NF_DATA[3],NF_DATA[4]   

	//��ǰrandomһ��
	Inram_Random_Data(R8Tmp);
	RDC_WaitOver();
	Get_Config_Data();

if(ProgramCMD0 == 0x80)
{
	ACC = NF_SLC_MODE_TOSHIBA;	//SLC mode��send A2 CMD
	NF_Send_CMD_Only();			//Input��A
}

	*((u8 xdata *)(& NF_DATA + 5)) = ProgramCMD0;//sumsung ��plane0
	NF_Send_CMD0_5ByteAddr();
	NF_Prog_Data();				//��һ��sector(����1K),�������¹�����Ϣ(�ⲿ����)

//printHexSync(XBYTE[_SPARE_AREA_BUF + 0]);
//printHexSync(XBYTE[_SPARE_AREA_BUF + 1]);
//printHexSync(XBYTE[_SPARE_AREA_BUF + 2]);
//prints("\n");


	R1_Sector++;             //1kʱ,R1��ʾ2��sector
	
	R8Tmp++;                 //1k change
	R8Tmp++; 

	if(SectorNum != 2){	//SectorNumΪ��ǰ��program��sector,���һ�β�����������
		Inram_Random_Data(R8Tmp);
		Get_Config_Data();	
	}

	do{
		ECC_Step1_isr(0);	//ÿ�θ��¹�����Ϣ  //���һ��SectorNum=1.��stop
	}while(SectorNum);
	
if(bEnReleaseNfBufRcvData) {
	_push_(IE1);
	disable_timer_isr();		
			while (planReleaseBufCnt) 
			{
					NfEmptyBufCnt++;
					NfEmptyBufCnt++;
					planReleaseBufCnt--;
			}
	_pop_(IE1);	
}		

	bEnReleaseNfBufRcvData = 0;


	_pop_(DPCON);

#else
//	unsigned char i = 0;
	unsigned char idata NFFAMT_P2Tmp;
	_push_(DPCON);
 	DPCON = 0x00;			//DPTR0������

	select_ecc_bits(ENCODE | R1_Sector);

//	BXADR1H_P2 = (u8)((_SPARE_AREA_BUF ) >> 8);
//	BXADR1L_P2 = (u8)((_SPARE_AREA_BUF ) >> 0);
//NTCON1_P2=0x1f;=
	BPT0SZ_P2 = 1024 / 4;												
//	NXCNT1_P2 = 0;
	BPT1SZ_P2 = 160 / 4;

	if(bProgCacheBlockPageTrue)
	{
		XBYTE[_SPARE_AREA_BUF+8 + 0] = PageLBAL;	
		XBYTE[_SPARE_AREA_BUF+8 + 1] = PageLBAH | DATA_CACHE_BLOCK;
		XBYTE[_SPARE_AREA_BUF+8 + 2] = SpareArea2;	
	}

	DataCoDecKeyIndex1 = R1_Sector;	//��sector

  	bNeedChkBlockPageModeIndex = 1;
  
	NF_Write_Addr();

	Fill_NFFINBuf();
	
if(ProgramCMD0 == 0x80)
{
	ACC = NF_SLC_MODE_TOSHIBA;	//SLC mode��send A2 CMD
	NF_Send_CMD_Only();			//Input��A
}

	*((u8 xdata *)(& NF_DATA + 5)) = ProgramCMD0;//sumsung ��plane0
	NF_Send_CMD0_5ByteAddr();

	HPAGE0_P2 = DataCoDecKeyIndex;

	NFFINBADR_P2 = NFFINBuf;
	NFFOUTBADR_P2 =NFFOutBuf;

	if (R1_Sector < ((SectorPerSmallPage+1)>>1))
	{
		NFFAMT_P2 = (((SectorPerSmallPage+1)>>1)-1);//(16-1);			
	}	else {
		NFFAMT_P2 = (((SectorPerSmallPage1+1)>>1)-1);//(16-1);	
	}

	NFFLEN_P2 = NFFINBuf_SIZE/4;
	NfEmptyBufCntTmp = 0x00;

	NFFCON_P2 = 0x01;		
		
	while((NFFCON_P2&0x80)==0)     //all done  
	{		
		Fill_NFFINBuf();
		if(bEnReleaseNfBufRcvData)
		{
			NFFAMT_P2Tmp = NFFAMT_P2; //loop 
   		if(NfEmptyBufCntTmp != NFFAMT_P2Tmp)
			{  
				if (planReleaseBufCnt) {
					_push_(IE1);
					disable_timer_isr();				
					NfEmptyBufCnt+=NFFAMT_P2Tmp - NfEmptyBufCntTmp;
					NfEmptyBufCnt+=NFFAMT_P2Tmp - NfEmptyBufCntTmp;  		//�Ѿ��ͷŹ��� 					
					_pop_(IE1);	
					planReleaseBufCnt -= NFFAMT_P2Tmp - NfEmptyBufCntTmp;  //�˴�������һ��ֵ���������Ż�
					NfEmptyBufCntTmp = NFFAMT_P2Tmp;
				}	
			}
		}
  }		

if(bEnReleaseNfBufRcvData) {
	_push_(IE1);
	disable_timer_isr();		
			while (planReleaseBufCnt) 
			{
					NfEmptyBufCnt++;
					NfEmptyBufCnt++;
					NFFAMT_P2Tmp++;
					planReleaseBufCnt--;
			}
	_pop_(IE1);	
}	
		
		


	if (Wr_Badcolumn_AfterData() && SectorNum)   
	{
		Get_Config_Data();  //column������Ҫ��������
	}
			
		
	NTSKD = 0;			// clear pending

BSIE = 0;
NF_Prog_Stop();	

	bEnReleaseNfBufRcvData = 0;

	_pop_(DPCON);
	
#endif

}

void CopyBack_Prog_A_Page(void)
{

//		prints("Copy Prog");
//			
//		printHexSync(R3_BlockAddrH);
//		printHexSync(R2_BlockAddrL);		
//		printHexSync(R4_PageAddrH);
//		printHexSync(R0_PageAddrL);	
//
//		prints("\n");


	_push_(DPCON);
 	DPCON = 0x00;			//DPTR0������
bEnReleaseNfBufRcvData = 0;	
	//BCH Encode ��ʼ��
	select_ecc_bits(ENCODE | R1_Sector);
	BXADR1H_P2 = (u8)((_SPARE_AREA_BUF ) >> 8);
	BXADR1L_P2 = (u8)((_SPARE_AREA_BUF ) >> 0);

	BPT0SZ_P2 = 1024 / 4;
	BPT1SZ_P2 = 160/4; 

	bSendReadRandomCmd = 1;

  bNeedChkBlockPageModeIndex = 1;
	
	
	Get_Config_Data();
	NF_Prog_Data();				//��һ��sector(����1K),�������¹�����Ϣ(�ⲿ����)
	R1_Sector++;             //1kʱ,R1��ʾ2��sector
	R8Tmp++;                 //1k change
	R8Tmp++; 

	if(SectorNum != 2){	//SectorNumΪ��ǰ��program��sector,���һ�β�����������
		Get_Config_Data();	
	}

	do{
	
		ECC_Step1_isr(1);	//ÿ�θ��¹�����Ϣ  //���һ��SectorNum=1.��stop
	}while(SectorNum);
			
	bEnReleaseNfBufRcvData = 0;

	_pop_(DPCON);
}

static void ECC_Step1_isr(u8 tmp)
{
#if 1//DIS_NF_FUNCTION
	
	_push_(DPCON);
 	DPCON = 0x00;			//DPTR0������

	//�ȴ���һ��prog��
	Wait_Flash_Ready();
	
	//дʹ��spare buf����ʹ��random buf
	XBYTE[_SPARE_AREA_BUF + 0] = PageLBAL;	
	XBYTE[_SPARE_AREA_BUF + 1] = PageLBAH | DATA_CACHE_BLOCK;
	XBYTE[_SPARE_AREA_BUF + 2] = (R0_PageAddrL&0x1f)|((SpareArea2&0x07)<<5);		

	
	BCMCON_P2 = 0;
	BCON1_P2 &= 0x7f;
	BCON0_P2 &= ~(1 << 7);

	RDC_WaitOver();
//�ݲ�֧�ֲ�col
//	if (Wr_Badcolumn_AfterData() && SectorNum)   
//	{
//		Get_Config_Data();  //column������Ҫ��������
//	}
	
	if(SectorNum != 2){
		if((R1_Sector == (HalfSectorPerSmallPage>>1)) || (R1_Sector == ((SectorPerSmallPage+1+HalfSectorPerSmallPage1)>>1)))
		{				
			NACMD1_P2 = 0x11;	                                                                                                                                                                                                                      
			NPCON_P2 = 0x80;
			Wait_Flash_Ready();
		yScrtyUnitCnt = 100;
			NF_Write_Addr();			
			*((u8 xdata *)(& NF_DATA + 5)) = 0x81;  //2pʱ��81
			NF_Send_CMD0_5ByteAddr();		
		}
		
		NF_Prog_Data();	
	}
	
	if(bEnReleaseNfBufRcvData && planReleaseBufCnt)
	{
		_push_(IE1);
		disable_timer_isr();
		NfEmptyBufCnt++;		//ԭ�Ӳ���	
		NfEmptyBufCnt++;	    //1k change
		planReleaseBufCnt--;  //��1k�������
		_pop_(IE1);	
	}	
	
	SectorNum--;
	SectorNum--;	

	if(SectorNum){
		R8Tmp++;
		R8Tmp++;	

		R1_Sector++;

		if(SectorNum != 2){
			Inram_Random_Data(R8Tmp);
			Get_Config_Data();
		}	
	}
	//ISR_Prog_A_Page_CacheBlock_END
	if( ! SectorNum){
		BSIE = 0;
//		if(tmp == 0)
			NF_Prog_Stop();
//		else
//		{
//		 	
//	BCON1_P2 = 0;//�ر�BCM��������data�޹صĺ����Ͳ���Ҫ��ֵ
//	BCMCON_P2= 0;

//		}	
	}
	_pop_(DPCON);
	
#endif
	
}

void Prog_A_Page_NewBlock(void)
{

}


void Inram_Random_Data(u8 bufindex)
{
#if !RANDOMIZE_NF	
//	ER02 = R8Tmp;
//	pr_buf();
	DataCoDecKeyIndex1 = R1_Sector;

	MLC_Buf_Data_Codec();
	ER02 = bufindex;
	random_inram();
//	RDC_WaitOver();
	
//	ER02 = R8Tmp;
//	pr_buf();
#endif
}

void Recover_random_data(void)
{
#if !RANDOMIZE_NF	
	u8 idata i;
	for (i = 0; i < 16; i++, DataCoDecKeyIndex1++) {	 
		MLC_Buf_Data_Codec();
		ER02 = i<<1;
		random_inram();
		RDC_WaitOver();
	}
#endif
}



void Get_Config_Data(void)
{
	_push_(DPCON);
 	DPCON = 0x00;			//DPTR0������

	RandomIndex = R8Tmp;
	DataCoDecKeyIndex1 = R1_Sector;
	ER02 = R8Tmp;
	
	Sel_Buffer_Addr();
		
//[6]: 1-data from sram to nfc;
//[5:4]:1-encode mode
//[0]:1-kict start
 	ER03 = BIT(6) | BIT(4) | BIT(0);

	DPCON = 0x10;			//DPTR0����
	DPTR0 = (u16)(& NF_DATA + 8);
	#pragma asm
	MOV32_EDP0_ER0		//nf data buf addr
	MOV32_EDP0_ER1		//BUFFER_START_ADDR,BXADR2		
	#pragma endasm

	Get_ColAddr();		  //NF_Write_Addr//�ȸ���R1����2byte column addr

	_pop_(DPCON);
}

unsigned char NF_Read_Status(unsigned char tmp)
{
	_push_(DPCON);

	DPCON = 0x00;
	
	NPGSZ_P2 = 2;
	do{
			NXADR0_P2 = _SPARE_AREA_BUF;// + 80;//�޸�buf��ַ�����+80����slc+copy backд��
			NXCNT0_P2 = 160 / 4;  //�������NPGSZ1_P2 NPGSZ0_P2

			NFIFO0_P2 = NF_READ_STATUS;
			BCON1_P2 = 0;//��data
			NPCON_P2 = 0x05;
			Wait_Flash_Ready();
	
if(tmp == 1)//����bit 5������
	break;

	}while(!(XBYTE[_SPARE_AREA_BUF + 0] & BIT(5)));
	
	_pop_(DPCON);	
	return(XBYTE[_SPARE_AREA_BUF]);
}



void erase_sdbuf_block(void)
{
#if EN_VIRTUAL_BUF
	unsigned char ZoneLBA_backup;
	
	_push_(PAGEMAP);	
	_push_(DPCON);
		
	PAGEMAP = 0x02;
 	DPCON = 0x0;//10;			//DPTR0����
	ZoneLBA_backup = ZoneLBA;

	SDBuf_Block_Init_Zone();
	BlockAddrTmpH = SDBufBlockAddrH;
	BlockAddrTmpL = SDBufBlockAddrL;

	bBlockMode = 0;
	Write_a_Block_Over();
	SDBufBlockAddrH = 0xff;
	SDBufBlockAddrL = 0xff;

	if (ZoneLBA != ZoneLBA_backup) {	 //��ԭ����ȷֵ
		ZoneLBA = ZoneLBA_backup;
		Get_CurPlaneCfg(); 
	}	
	
	_pop_(DPCON);
	_pop_(PAGEMAP);
#endif
}

void program_sdbuf_block(void)
{	
#if EN_VIRTUAL_BUF
	unsigned char ZoneLBA_backup;
	_push_(PAGEMAP);	
	_push_(DPCON);
	
	PAGEMAP = 0x02;
 	DPCON = 0x00;			//DPTR0������

	ZoneLBA_backup = ZoneLBA;
	SDBuf_Block_Init_Zone();
	bEnReleaseNfBufRcvData = 0;

	if(SDBufBlockAddrH == 0xff){
		bBlockMode = 0;
		Find_A_Blank_Block();	
		SDBufBlockAddrH = BlockAddrTmpH;
		SDBufBlockAddrL = BlockAddrTmpL;
	}
	//���¹�����Ϣ

	bProgCacheBlockPageTrue=1;	
	SectorNum = SectorPerSmallPage + 1;
	SDBuf_Block_Init_Addr();
    PageLBAL=DataCoDecKeyIndex;//�����ϵ�ʱ�����ҵ�����
	XBYTE[_SPARE_AREA_BUF + 0] = (u8)(SDBUF_BLOCK >> 0);
	XBYTE[_SPARE_AREA_BUF + 1] = (u8)(SDBUF_BLOCK >> 8);
 	XBYTE[_SPARE_AREA_BUF + 2] = (R0_PageAddrL&0x1f)|((SpareArea2&0x07)<<5);
	
	ProgramCMD1 = 0x10;  	
	Prog_A_Page_CacheBlock();
	bProgCacheBlockPageTrue=0;
	
	if (ZoneLBA != ZoneLBA_backup) {	 //��ԭ����ȷֵ
		ZoneLBA = ZoneLBA_backup;
		Get_CurPlaneCfg(); 
	}	
	
	_pop_(DPCON);
	_pop_(PAGEMAP);
#endif
}

void read_sdbuf_block(void)
{
#if EN_VIRTUAL_BUF
	unsigned char ZoneLBA_backup;
	
	_push_(PAGEMAP);	
	_push_(DPCON);
	
	PAGEMAP = 0x02;
 	DPCON = 0x00;//10;			//DPTR0����

	ZoneLBA_backup = ZoneLBA;
	SDBuf_Block_Init_Zone();
	SectorNum = VIRTUAL_BUF_READ_MAX_SECS_IN_PER_PAGE;
		
#if MODE_1K_EN	  //����1K
	if (SectorNum&0x01)
		SectorNum++;
#endif 
	
  SDBuf_Block_Init_Addr();
	Read_Sectors();

	if (ZoneLBA != ZoneLBA_backup) {	 //��ԭ����ȷֵ
		ZoneLBA = ZoneLBA_backup;
		Get_CurPlaneCfg(); 
	}	
	_pop_(DPCON);
	_pop_(PAGEMAP);
#endif
}


void SDBuf_Block_Init_Zone(void)
{
#if EN_VIRTUAL_BUF
	ZoneLBA = *(u8 xdata *)(&FirstValidZone);
	Get_CurPlaneCfg();	
#endif
}

static void SDBuf_Block_Init_Addr(void)
{
#if EN_VIRTUAL_BUF
	SDBufPageAddr = SDBufPageAddr;	  //���������Զ��Ż�

	R3_BlockAddrH = SDBufBlockAddrH;
	R2_BlockAddrL = SDBufBlockAddrL;
	R4_PageAddrH = 0;
	R0_PageAddrL = SDBufPageAddr;  //�˴�ֻҪ��֤�ⲿ��ʼ��sd buf����ʹ��papge������256��û���� //?????debug��ʱ��������
	R1_Sector = 0;
	bBlockMode = 0;//SLC
	DataCoDecKeyIndex = R0_PageAddrL;
	R8Tmp = 0;
#endif
}

static void BCM_KickStart(void)			
{
	_push_(DPCON);
 	DPCON = 0x10;			//DPTR0����

	ER00 = R1_Sector<<1;
	if (ER00 < HalfSectorPerSmallPage) {
		DPTR0 = (u16)(& BCH_MODE_DC_TAB + ZoneLBA*2);
	} else if (ER00 < (SectorPerSmallPage+1)) {
		DPTR0 = (u16)(& BCH_MODE_DC_TAB + (ZoneLBA+1)*2);
	} else if (ER00 < (SectorPerSmallPage+1 + HalfSectorPerSmallPage1)) {
		DPTR0 = (u16)(& BCH_MODE_DC_TAB + 2*2);
	} else {
		DPTR0 = (u16)(& BCH_MODE_DC_TAB + 3*2);
	}
	#pragma asm	
	CLR32_ER0
	MOVX	A,@DPTR
	MOV		ER01,A	  
	MOVX	A,@DPTR
	MOV		ER00,A
	#pragma endasm
	DPTR0 = _FLASH_BCMCfg_ADDR_Tmp;  //ȡBCM ���õ�ַ
	#pragma asm
	MOV		A,#4
	MOV 	B,ZoneLBA
	MUL		AB  //�����A
	MOV		B,#16		//32  �ĳ�16��sector
	CALL	dptr_add_ab_maskrom
	#pragma endasm	

	if(R1_Sector < ((SectorPerSmallPage + 1)>>1))
	{
		B = R1_Sector;
	}
	else
	{
		B = R1_Sector - ((SectorPerSmallPage+1)>>1) + 32;   //1k change  //��δ�޸�
	}

#pragma asm
		CLR32_ER1
		MOV		A, #4 
		CALL	dptr_add_ab_maskrom	
		MOVX	A,@DPTR//����
		MOV		ER11,A //�����ݴ�
		MOVX	A,@DPTR//����
		MOV		ER10,A //�����ݴ�
#if !EN_BCM
		MOV		ER11,#0
		MOV 	ER10,#0
#endif 
		MOVX	A,@DPTR//�ߵ�ַ
		MOV		BCMADRH_P2,A
		MOVX	A,@DPTR//�͵�ַ
		MOV		BCMADRL_P2,A
		MOV		BCMDAT_P2,#0xFF		//Ŀǰ��δ���ݲ������

		ADD32_ER0_ER0_ER1
		MOV		NPGSZ1_P2,ER01	//����BCM cnt 
		MOV		NPGSZ0_P2,ER00

		MOV BCMCON_P2,#0x04  //1��ʾ���У�bcm disable,�������random��homos��δ����BCM����clear bcm pending
		#pragma endasm
		if(ER10 || ER11){	//bcm kick start
			BCMCON_P2 |= 0x01;	
		}else {
			BCMCON_P2 = 0;//������һ��
		}
	
	_pop_(DPCON);

}



#pragma asm
	EXTRN CODE(Retry_Register_Number)
#pragma endasm
extern u8 code Retry_Register_Addr_Table, Retry_Register_FLASH_RetryCnt;
void NF_Set_Feature(u8 FeatureAddr)
{

	_push_(DPCON);
 	DPCON = 0x10;			//DPTR0����
	_push_(PAGEMAP);
	sfrpage(2);
	
ER00 = Retry_Register_FLASH_RetryCnt;
if(FeatureAddr==(*((u8 xdata *)((&Retry_Register_Addr_Table) + 0))))//0x89/*12*/)
{
		DPTR0 = (u16)(&Retry_Register_Data_Table);
		R8 = ((RetryCnt%ER00) * 8) >> 8;
		B =	 ((RetryCnt%ER00) * 8) & 0xFF;
		#pragma asm
		ADDDP0								//;DPTR0 + (R8 B)	
		MOVX	A,@DPTR
//MOV	ER40,A		
		MOV		ER00,A
		MOVX	A,@DPTR
		MOV		ER01,A
		MOVX	A,@DPTR
		MOV		ER02,A
		MOVX	A,@DPTR
		MOV		ER03,A
		#pragma endasm
}
else if (FeatureAddr==(*((u8 xdata *)((&Retry_Register_Addr_Table) + 4))))//0x8A/*13*/)
{
		DPTR0 = (u16)(&Retry_Register_Data_Table+4);
		R8 = ((RetryCnt%ER00) * 8) >> 8;
		B =	 ((RetryCnt%ER00) * 8) & 0xFF;
		#pragma asm
		ADDDP0								//;DPTR0 + (R8 B)	
		MOVX	A,@DPTR
//MOV	ER40,A				
		MOV		ER00,A
		MOVX	A,@DPTR
		MOV		ER01,A
		MOVX	A,@DPTR
		MOV		ER02,A
//		MOVX	A,@DPTR
//		MOV		ER03,A
		MOV		ER03,#0
		#pragma endasm
}
else//8D 14
{		
		DPTR0 = (u16)(&Retry_Register_Data_Table+7);
 		R8 = ((RetryCnt%ER00) * 8) >> 8;
		B =	 ((RetryCnt%ER00) * 8) & 0xFF;
		#pragma asm
		ADDDP0								//;DPTR0 + (R8 B)	
		MOVX	A,@DPTR		
		CLR32_ER0
		MOV		ER00,A
//		MOVX	A,@DPTR
//		MOV		ER01,A
//		MOVX	A,@DPTR
//		MOV		ER02,A
//		MOVX	A,@DPTR
//		MOV		ER03,A
		#pragma endasm
}


//prints("try:");
////	  printHexSync(((RetryCnt%RETRY_TABLE_SIZE) * 8) >> 8);
////		printHexSync(((RetryCnt%RETRY_TABLE_SIZE) * 8) & 0xff);
////		printHexSync(RetryCnt);
////	  printHexSync(FeatureAddr);
////	  printHexSync(ER00);
////		printHexSync(ER01);
////		printHexSync(ER02);
////		printHexSync(ER03);
////		prints("\n");


	DPCON = 0;
	XBYTE[_SPARE_AREA_BUF + 0] = ER00;
//	if(bToggleTrue == 0)
//	{	
//		XBYTE[_SPARE_AREA_BUF + 1] = ER01;
//	 	XBYTE[_SPARE_AREA_BUF + 2] = ER02;
//	 	XBYTE[_SPARE_AREA_BUF + 3] = ER03;
//		NPGSZ0_P2 = 0x04;
//	}
//	else
//	{

		XBYTE[_SPARE_AREA_BUF + 1] = ER00;
		XBYTE[_SPARE_AREA_BUF + 2] = ER01;
	 	XBYTE[_SPARE_AREA_BUF + 3] = ER01;
	 	XBYTE[_SPARE_AREA_BUF + 4] = ER02;
		XBYTE[_SPARE_AREA_BUF + 5] = ER02;
	 	XBYTE[_SPARE_AREA_BUF + 6] = ER03;
	 	XBYTE[_SPARE_AREA_BUF + 7] = ER03;
		NPGSZ0_P2 = 0x08;
//	}
	DPCON = 0x10;
	NPGSZ1_P2 = 0x00;	
	NXADR2_P2 = _SPARE_AREA_BUF;
	NXCNT0_P2 = 0;
	NXCNT1_P2 = 0;
		
	NFIFO1_P2 = FeatureAddr;
	NFIFO0_P2 = 0xEF;
	NPCON_P2 = 0x19;
	while( ! NTSKD){}
	_N_NOP_
	NTSKD = 0;

	_pop_(PAGEMAP);
	_pop_(DPCON);
}

void NF_Set_Feature_SS21nm(u8 cnt)//������SDR�ӿ�
{

	_push_(DPCON);
 	DPCON = 0x00;			//DPTR0����
	_push_(PAGEMAP);
	sfrpage(2);
	NMCON1_P2 &= ~BIT(4);//�л���SDR�ӿ�

		DPTR0 = (u16)(&Retry_Register_Data_Table+cnt);
		R8 = ((RetryCnt%RETRY_TABLE_SIZE) * 8) >> 8;
		B =	 ((RetryCnt%RETRY_TABLE_SIZE) * 8) & 0xFF;
		#pragma asm
//		ADDDP0								;DPTR0 + (R8 B)	
//		#pragma endasm
//		R8 = cnt;
//		B = R8;
//		R8 = 0;
//		#pragma asm
		ADDDP0
		MOVX	A,@DPTR
		MOV		ER00,A
		#pragma endasm
		
		ER01 = 0xB8 + cnt;
		XBYTE[_SPARE_AREA_BUF + 0] = 0x02;
		XBYTE[_SPARE_AREA_BUF + 1] = ER01;
		XBYTE[_SPARE_AREA_BUF + 2] = ER00;
		XBYTE[_SPARE_AREA_BUF + 3] = ER00;
//		printHexSync(RetryCnt >> 8);
//		printHexSync(RetryCnt & 0xFF);
//		printHexSync(cnt);
//	   	printHexSync(ER00);
//		prints("\n");
	NPGSZ0_P2 = 0x03;
	NPGSZ1_P2 = 0x00;	
	NXADR2_P2 = _SPARE_AREA_BUF;
	NXCNT0_P2 = 0;
	NXCNT1_P2 = 0;
//	NFIFO2_P2 = 0xB8 + cnt;	
//	NFIFO1_P2 = 0x02;
	NFIFO0_P2 = 0xA1;
	NPCON_P2 = 0x09;
	while( ! NTSKD){}
	_N_NOP_
	NTSKD = 0;

	 NMCON1_P2 |= BIT(4);//�л���DDR�ӿ�
	_pop_(PAGEMAP);
	_pop_(DPCON);
}

void NF_Get_Feature(u8 Feature_Addr)
{

	_push_(DPCON);
 	DPCON = 0x0;			//DPTR0������
	_push_(PAGEMAP);
	sfrpage(2);

	if(bToggleTrue == 0)
		NPGSZ0_P2 = 0x04;
	else
		NPGSZ0_P2 = 0x08;
	
	NPGSZ1_P2 = 0x00;
	NXADR2_P2 = _SPARE_AREA_BUF;
	NXCNT0_P2 = 0;
	NXCNT1_P2 = 0;
	NFIFO1_P2 = Feature_Addr;
	NFIFO0_P2 = 0xEE;
	NPCON_P2= 0x15;
	while( ! NTSKD){}
	_N_NOP_
	NTSKD = 0;

//	prints("GET F");
//	printHexSync(RetryCnt);
//	printHexSync(Feature_Addr);
   	printHexSync(XBYTE[_SPARE_AREA_BUF + 0]);
	printHexSync(XBYTE[_SPARE_AREA_BUF + 1]);
	printHexSync(XBYTE[_SPARE_AREA_BUF + 2]);
	printHexSync(XBYTE[_SPARE_AREA_BUF + 3]);
	if(bToggleTrue == 1)
	{
	   	printHexSync(XBYTE[_SPARE_AREA_BUF + 4]);
		printHexSync(XBYTE[_SPARE_AREA_BUF + 5]);
		printHexSync(XBYTE[_SPARE_AREA_BUF + 6]);
		printHexSync(XBYTE[_SPARE_AREA_BUF + 7]);
	}
//	prints("\n");
	_pop_(PAGEMAP);
	_pop_(DPCON);

}
void NF_Reset(void)
{
	NFIFO0_P2 = NF_RESET;
	NPCON_P2 = 0x01;
	Wait_Flash_Ready();
}



void reset_bch(void)
{
	_push_(PAGEMAP);

	sfrpage(2);
	NTSKD = 1;
	_nop_();
	_nop_();
	_nop_();
	NTSKD = 0;

NMCON1_P2 |= BIT(6); 
//while(NTSKD==0);
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
NTSKD = 0;
NMCON1_P2 &= ~BIT(6);
#if !RANDOMIZE_NF
	HCON_P2 = 0x20;
#else 	
	HCON_P2 = 0;	
#endif	
	
	BCMCON_P2 = 0;	
	BCON1_P2 = 0;
	sfrpage(0);
	
	CLKCON0_P0 &= ~ BIT(3);
	_nop_();
	_nop_();
	_nop_();	
	CLKCON0_P0 |= BIT(3);	

	_pop_(PAGEMAP);

}


//u8 idata ecc_encode_bits;
	
//input: u8 config
//config[6:0]: ecc bits
//config[7:7]: 0-encode; 1-decode.
void select_ecc_bits(u8 config)//ֻ��ѡ��ECC��������������Ҫ������Encode����Decode
{
	u8 idata ZoneLBATmp;
	_push_(PAGEMAP);
	sfrpage(2);

	ER00 = (config & 0x7F)<<1;
	if (ER00 < HalfSectorPerSmallPage) {
		ZoneLBATmp = ZoneLBA;
	} else if (ER00 < (SectorPerSmallPage+1)) {
		ZoneLBATmp = ZoneLBA+1;
	} else if (ER00 < (SectorPerSmallPage+1 + HalfSectorPerSmallPage1)) {
		ZoneLBATmp = 2;
	} else {
		ZoneLBATmp = 3;
	}

if((BTSEL_P2 & 0x7F) != (*(u8 xdata *)(& NF_SECTOR_SIZE_TAB + ZoneLBATmp)))
{
//	prints("ECC:");
//	printHexSync(BTSEL_P2 & 0x7F);
//	printHexSync((*(u8 xdata *)(& NF_SECTOR_SIZE_TAB + ZoneLBATmp)));
//	prints("\n");
	BTSEL_P2 = (*(u8 xdata *)(& NF_SECTOR_SIZE_TAB + ZoneLBATmp));

	BCON1_P2 |= BIT(2);					//cal encode polynomial.
	while(!(BTSEL_P2 & BIT(7))) {}	
}


	if((config & 0x80) == ENCODE)
	{
		BPSZH_P2 = *(u8 xdata *)(& BCH_MODE_EC_TAB + ZoneLBATmp*2 + 0);	
		BPSZL_P2 = *(u8 xdata *)(& BCH_MODE_EC_TAB + ZoneLBATmp*2 + 1);	
	}
	else
	{
#if !RANDOMIZE_NF			
		BPT0SZ_P2= (1028 >> 2);//�ϵ縳ֵһ�ζ���
#else 		
		BPT0SZ_P2= (1024 >> 2);//�ϵ縳ֵһ�ζ���
#endif
		BPT1SZ_P2 = 0; //using BXADR0_P2, BXADR2_P2//read���ó�0
		BPSZH_P2 = *((u8 xdata *)(& BCH_MODE_DC_TAB + ZoneLBATmp*2 + 0));//read  
		BPSZL_P2 = *((u8 xdata *)(& BCH_MODE_DC_TAB + ZoneLBATmp*2 + 1));
		BCON1_P2 = BIT(6) | BIT(5);		//data from nfc, decode, hardware auto error correct.//������ʱ����ʼ����read data�ḳֵ
	}

	_pop_(PAGEMAP);
}

//inpput: u8 ce
///0: select CE0
///1:select CE1
void select_ce(u8 ce)
{
	if(ce == 0){
		NCEE_P2 = (NCEE_P2 & 0xfc) | BIT(0) | BIT(6) | BIT(5);
	}else{
		NCEE_P2 = (NCEE_P2 & 0xfc) | BIT(1) | BIT(6);
	}
}

void pr_buf(void)
{
//	Sel_Buffer_Addr();	
//	DP0H = ER01;
//	DP0L = ER00;
//	#pragma asm	
//	MOV32_ER1_EDP0
//	#pragma endasm
//	printHexSync(ER13);
//	printHexSync(ER12);
//	printHexSync(ER11);
//	printHexSync(ER10);
//	prints("\n");
	
//	Sel_Buffer_Addr();	
//	DP0H = ER01;
//	DP0L = ER00;
//	#pragma asm
//	MOV		R8,#0x03
//	MOV		B ,#0xfc
//	ADDDP0		
//	MOV32_ER1_EDP0
//	#pragma endasm
//	printHexSync(ER13);
//	printHexSync(ER12);
//	printHexSync(ER11);
//	printHexSync(ER10);
//	prints("\n");	
}

void random_inram(void)
{
		Sel_Buffer_Addr();	
		CMPADR1_P2 = ER01;
		CMPADR0_P2 = ER00;
		CMPCON_P2 = 0x07;
}


void RDC_WaitOver(void)
{
#if !RANDOMIZE_NF	
		while(CMPCON_P2 & 0x01);
#endif
}






