#include "inc\common.h"

// MACRO TC1~TC8, CAN ONLY enable one at a compiling time
// for TC1,TC3,TC5,TC7, testbech SHOULD NOT define CP_TEST_IO
// for TC2,TC4,TC6,TC8, testbech SHOULD     define CP_TEST_IO
//#define     TC1
//#define     TC2
//#define     TC3
//#define     TC4
//#define     TC5
//#define     TC6
//#define     TC7
#define     TC8

#define NORMAL_IO 		0
#define CP_TEST_IO		1

#define NORMAL_SPEED	0
#define HIGH_SPEED 		1

// normal kick 
void normal_kick(unsigned char io_mapping, unsigned char speed_mode, unsigned char pha_pol_set, int cnt)
{
	int i;
	if(io_mapping == NORMAL_IO)
		AIPCON &= ~BIT(7);	
	else
		AIPCON |= BIT(7);

	for(i=0;i<cnt;i++)
	{
    // 2 wire tx
    SPICON = 0x11 & ~0x06 | (pha_pol_set<<1) ;
	if(speed_mode == NORMAL_SPEED)
		SPICON &= ~BIT(6);
	else
		SPICON |= BIT(6);

    SPICON1 = 0x00;
    SPIBAUD = 0x02;
    SPIBUF = (unsigned char)i;

    while((SPICON & BIT(7)) == 0);
	}

    // 2 wire rx
	for(i=0;i<cnt;i++)
	{
    SPICON = 0x31 & ~0x06 | (pha_pol_set<<1);
	if(speed_mode == NORMAL_SPEED)
		SPICON &= ~BIT(6);
	else
		SPICON |= BIT(6);
    SPICON1 = 0x00;
    SPIBAUD = 0x02;
    SPIBUF = 0xff;
	
    while((SPICON & BIT(7)) == 0);
    P1 = SPIBUF;
	}

    // 3 wire
	P0DIR |= BIT(0);
    P0DIR &= ~BIT(4);
	for(i=0;i<cnt;i++)
	{
    SPICON = 0x21 & ~0x06 | (pha_pol_set<<1);
	if(speed_mode == NORMAL_SPEED)
		SPICON &= ~BIT(6);
	else
		SPICON |= BIT(6);
    SPICON1 = 0x00;
    SPIBAUD = 0x02;
    SPIBUF = (unsigned char)i;
//    SPIBUF = 0xcc;
//    SPIBUF = 0xdd;
    while((SPICON & BIT(7)) == 0);
    P1 = SPIBUF;
	}

    // 2bit data bus tx
	for(i=0;i<cnt;i++)
	{
    SPICON = 0x11 & ~0x06 | (pha_pol_set<<1);
	if(speed_mode == NORMAL_SPEED)
		SPICON &= ~BIT(6);
	else
		SPICON |= BIT(6);
    SPICON1 = 0x01;
    SPIBAUD = 0x02;
    SPIBUF = (unsigned char)i;
    SPIBUF = (unsigned char)(256-i);
    while((SPICON & BIT(7)) == 0);
	}

    // 2bit data bus rx
	for(i=0;i<cnt;i++)
	{
    SPICON = 0x31 & ~0x06 | (pha_pol_set<<1);
	if(speed_mode == NORMAL_SPEED)
		SPICON &= ~BIT(6);
	else
		SPICON |= BIT(6);
    SPICON1 = 0x01;
    SPIBAUD = 0x02;
    SPIBUF = 0xff;

    while((SPICON & BIT(7)) == 0);
    P1 = SPIBUF;
    P1 = SPIBUF;
	}

    // 4bit data bus tx
	for(i=0;i<cnt;i++)
	{
    SPICON = 0x11 & ~0x06 | (pha_pol_set<<1);
	if(speed_mode == NORMAL_SPEED)
		SPICON &= ~BIT(6);
	else
		SPICON |= BIT(6);
    SPICON1 = 0x03;
    SPIBAUD = 0x02;
    SPIBUF = (unsigned char)i;
    SPIBUF = (unsigned char)(256-i);
    SPIBUF = (unsigned char)i+1;
    SPIBUF = (unsigned char)(255-i);
    while((SPICON & BIT(7)) == 0);
	}

    // 4bit data bus rx
	for(i=0;i<cnt;i++)
	{
    SPICON = 0x31 & ~0x06 | (pha_pol_set<<1);
	if(speed_mode == NORMAL_SPEED)
		SPICON &= ~BIT(6);
	else
		SPICON |= BIT(6);
    SPICON1 = 0x03;
    SPIBAUD = 0x02;
    SPIBUF = 0xff;
    while((SPICON & BIT(7)) == 0);
    P1 = SPIBUF;
    P1 = SPIBUF;
    P1 = SPIBUF;
    P1 = SPIBUF;
	}
}

//// cp test mode IO mapping
//void testcase2(unsigned char pha_pol_set,int cnt)
//{
//	int i;
//    AIPCON |= BIT(7);
//    // 2 wire tx
//	for(i=0;i<cnt;i++)
//	{
//    SPICON = 0x11 & ~0x06 | (pha_pol_set<<1);
//    SPICON1 = 0x00;
//    SPIBAUD = 0x02;
//    SPIBUF = (unsigned char)i;
//
//    while((SPICON & BIT(7)) == 0);
//	}
//
//    // 2 wire rx
//	for(i=0;i<cnt;i++)
//	{
//    SPICON = 0x31 & ~0x06 | (pha_pol_set<<1);
//    SPICON1 = 0x00;
//    SPIBAUD = 0x02;
//    SPIBUF = 0xff;
//
//    while((SPICON & BIT(7)) == 0);
//    P1 = SPIBUF;
//	}
//
//    // 3 wire
//    P0DIR |= BIT(0);
//    P0DIR &= ~BIT(5);
//	for(i=0;i<cnt;i++)
//	{
//    SPICON = 0x21 & ~0x06 | (pha_pol_set<<1);
//    SPICON1 = 0x00;
//    SPIBAUD = 0x02;
//    SPIBUF = (unsigned char)i;
////    SPIBUF = 0xcc;
////    SPIBUF = 0xdd;
//    while((SPICON & BIT(7)) == 0);
//    P1 = SPIBUF;
//	}
//
//    // 2bit data bus tx
//	for(i=0;i<cnt;i++)
//	{
//    SPICON = 0x11 & ~0x06 | (pha_pol_set<<1);
//    SPICON1 = 0x01;
//    SPIBAUD = 0x02;
//    SPIBUF = (unsigned char)i;
//    SPIBUF = (unsigned char)(256-i);
//    while((SPICON & BIT(7)) == 0);
//	}
//
//    // 2bit data bus rx
//	for(i=0;i<cnt;i++)
//	{
//    SPICON = 0x31 & ~0x06 | (pha_pol_set<<1);
//    SPICON1 = 0x01;
//    SPIBAUD = 0x02;
//    SPIBUF = 0xff;
//
//    while((SPICON & BIT(7)) == 0);
//    P1 = SPIBUF;
//    P1 = SPIBUF;
//	}
//
//    // 4bit data bus tx
//	for(i=0;i<cnt;i++)
//	{
//    SPICON = 0x11 & ~0x06 | (pha_pol_set<<1);
//    SPICON1 = 0x03;
//    SPIBAUD = 0x02;
//    SPIBUF = (unsigned char)i;
//    SPIBUF = (unsigned char)(256-i);
//    SPIBUF = (unsigned char)i+1;
//    SPIBUF = (unsigned char)(255-i);
//    while((SPICON & BIT(7)) == 0);
//	}
//
//    // 4bit data bus rx
//	for(i=0;i<cnt;i++)
//	{
//    SPICON = 0x31 & ~0x06 | (pha_pol_set<<1);
//    SPICON1 = 0x03;
//    SPIBAUD = 0x02;
//    SPIBUF = 0xff;
//    while((SPICON & BIT(7)) == 0);
//    P1 = SPIBUF;
//    P1 = SPIBUF;
//    P1 = SPIBUF;
//    P1 = SPIBUF;
//	}
//}

// DMA test
void dma_kick(unsigned char io_mapping, unsigned char speed_mode,unsigned char pha_pol_set, unsigned int cnt)
{
 	unsigned int i;
    unsigned char xdata *ptr;

	if(io_mapping == NORMAL_IO)
		AIPCON &= ~BIT(7);	
	else
		AIPCON |= BIT(7);
			
    ptr = 0x2000;
    for(i=0;i<cnt*4;i++)
            *ptr++ = i;

    // 2 wire tx
    SPICON = 0x11 & ~0x06 | (pha_pol_set<<1);
	if(speed_mode == NORMAL_SPEED)
		SPICON &= ~BIT(6);
	else
		SPICON |= BIT(6);
    SPICON1 = 0x00;
    SPIBAUD = 0x02;
    SPIDMASPH = (0x2000)>>8;
    SPIDMASPL = 0x2000;
    SPIDMACNT = cnt-1;
    while((SPICON & BIT(7)) == 0);

	// 2 wire rx
	SPICON = 0x31 & ~0x06 | (pha_pol_set<<1);
	if(speed_mode == NORMAL_SPEED)
		SPICON &= ~BIT(6);
	else
		SPICON |= BIT(6);
    SPICON1 = 0x00;
	SPIBAUD = 0x02;
    SPIDMASPH = (0x2000)>>8;
    SPIDMASPL = 0x2000;
    SPIDMACNT = cnt-1;
    while((SPICON & BIT(7)) == 0);
    
    // 2bit data bus tx
    SPICON = 0x11 & ~0x06 | (pha_pol_set<<1);
	if(speed_mode == NORMAL_SPEED)
		SPICON &= ~BIT(6);
	else
		SPICON |= BIT(6);
    SPICON1 = 0x01;
    SPIBAUD = 0x02;
    SPIDMASPH = (0x2000)>>8;
    SPIDMASPL = 0x2000;
    SPIDMACNT = cnt-1;
    while((SPICON & BIT(7)) == 0);

    // 2bit data bus rx
    SPICON = 0x31 & ~0x06 | (pha_pol_set<<1);
	if(speed_mode == NORMAL_SPEED)
		SPICON &= ~BIT(6);
	else
		SPICON |= BIT(6);
    SPICON1 = 0x01;
    SPIBAUD = 0x02;
    SPIDMASPH = (0x2000)>>8;
    SPIDMASPL = 0x2000;
    SPIDMACNT = cnt-1;
    while((SPICON & BIT(7)) == 0);

    // 4bit data bus tx
    SPICON = 0x11 & ~0x06 | (pha_pol_set<<1);
	if(speed_mode == NORMAL_SPEED)
		SPICON &= ~BIT(6);
	else
		SPICON |= BIT(6);
    SPICON1 = 0x03;
    SPIBAUD = 0x02;
    SPIDMASPH = (0x2000)>>8;
    SPIDMASPL = 0x2000;
    SPIDMACNT = cnt-1;
    while((SPICON & BIT(7)) == 0);

    // 4bit data bus rx
    SPICON = 0x31 & ~0x06 | (pha_pol_set<<1);
	if(speed_mode == NORMAL_SPEED)
		SPICON &= ~BIT(6);
	else
		SPICON |= BIT(6);
    SPICON1 = 0x03;
    SPIBAUD = 0x02;
    SPIDMASPH = (0x2000)>>8;
    SPIDMASPL = 0x2000;
    SPIDMACNT = cnt-1;
    while((SPICON & BIT(7)) == 0);
}

//// DMA test	CP test IO mapping
//void testcase4(unsigned char pha_pol_set, unsigned int cnt)
//{
// 	unsigned int i;
//    unsigned char xdata *ptr;
//	AIPCON |= BIT(7);
//    ptr = 0x2000;
//    for(i=0;i<cnt*4;i++)
//            *ptr++ = i;
//
//    // 2 wire tx
//    SPICON = 0x11 & ~0x06 | (pha_pol_set<<1);
//    SPICON1 = 0x00;
//    SPIBAUD = 0x02;
//    SPIDMASPH = (0x2000)>>8;
//    SPIDMASPL = 0x2000;
//    SPIDMACNT = cnt-1;
//    while((SPICON & BIT(7)) == 0);
//
//	// 2 wire rx
//	SPICON = 0x31 & ~0x06 | (pha_pol_set<<1);
//    SPICON1 = 0x00;
//	SPIBAUD = 0x02;
//    SPIDMASPH = (0x2000)>>8;
//    SPIDMASPL = 0x2000;
//    SPIDMACNT = cnt-1;
//    while((SPICON & BIT(7)) == 0);
//    
//    // 2bit data bus tx
//    SPICON = 0x11 & ~0x06 | (pha_pol_set<<1);
//    SPICON1 = 0x01;
//    SPIBAUD = 0x02;
//    SPIDMASPH = (0x2000)>>8;
//    SPIDMASPL = 0x2000;
//    SPIDMACNT = cnt-1;
//    while((SPICON & BIT(7)) == 0);
//
//    // 2bit data bus rx
//    SPICON = 0x31 & ~0x06 | (pha_pol_set<<1);
//    SPICON1 = 0x01;
//    SPIBAUD = 0x02;
//    SPIDMASPH = (0x2000)>>8;
//    SPIDMASPL = 0x2000;
//    SPIDMACNT = cnt-1;
//    while((SPICON & BIT(7)) == 0);
//
//    // 4bit data bus tx
//    SPICON = 0x11 & ~0x06 | (pha_pol_set<<1);
//    SPICON1 = 0x03;
//    SPIBAUD = 0x02;
//    SPIDMASPH = (0x2000)>>8;
//    SPIDMASPL = 0x2000;
//    SPIDMACNT = cnt-1;
//    while((SPICON & BIT(7)) == 0);
//
//    // 4bit data bus rx
//    SPICON = 0x31 & ~0x06 | (pha_pol_set<<1);
//    SPICON1 = 0x03;
//    SPIBAUD = 0x02;
//    SPIDMASPH = (0x2000)>>8;
//    SPIDMASPL = 0x2000;
//    SPIDMACNT = cnt-1;
//    while((SPICON & BIT(7)) == 0);
//}

void spi_main()
{   
	CCTL |= BIT(2);	// select 70MHz RC  
    // testcase1
    #ifdef TC1
    normal_kick(NORMAL_IO,NORMAL_SPEED,0,256);    // testbench should NOT define CP_TEST_IO    
    normal_kick(NORMAL_IO,NORMAL_SPEED,1,256);    // testbench should NOT define CP_TEST_IO    
    normal_kick(NORMAL_IO,NORMAL_SPEED,2,256);    // testbench should NOT define CP_TEST_IO    
    normal_kick(NORMAL_IO,NORMAL_SPEED,3,256);    // testbench should NOT define CP_TEST_IO
    #endif
    // testcase2
    #ifdef TC2
    normal_kick(CP_TEST_IO,NORMAL_SPEED,0,256);   // testbench should define CP_TEST_IO
    normal_kick(CP_TEST_IO,NORMAL_SPEED,1,256);   // testbench should define CP_TEST_IO
    normal_kick(CP_TEST_IO,NORMAL_SPEED,2,256);   // testbench should define CP_TEST_IO
    normal_kick(CP_TEST_IO,NORMAL_SPEED,3,256);   // testbench should define CP_TEST_IO
    #endif
    //testcase3
    #ifdef TC3
    normal_kick(NORMAL_IO,HIGH_SPEED,0,256);       // testbench should NOT define CP_TEST_IO        
    normal_kick(NORMAL_IO,HIGH_SPEED,1,256);       // testbench should NOT define CP_TEST_IO    
    normal_kick(NORMAL_IO,HIGH_SPEED,2,256);       // testbench should NOT define CP_TEST_IO    
    normal_kick(NORMAL_IO,HIGH_SPEED,3,256);       // testbench should NOT define CP_TEST_IO
    #endif
    //testcase4
    #ifdef TC4
    normal_kick(CP_TEST_IO,HIGH_SPEED,0,256);      // testbench should define CP_TEST_IO
    normal_kick(CP_TEST_IO,HIGH_SPEED,1,256);      // testbench should define CP_TEST_IO
    normal_kick(CP_TEST_IO,HIGH_SPEED,2,256);      // testbench should define CP_TEST_IO
    normal_kick(CP_TEST_IO,HIGH_SPEED,3,256);      // testbench should define CP_TEST_IO
    #endif
    //testcase5
    #ifdef TC5
    dma_kick(NORMAL_IO,NORMAL_SPEED,0,64);           // testbench should NOT define CP_TEST_IO    
    dma_kick(NORMAL_IO,NORMAL_SPEED,1,64);           // testbench should NOT define CP_TEST_IO    
    dma_kick(NORMAL_IO,NORMAL_SPEED,2,64);           // testbench should NOT define CP_TEST_IO    
    dma_kick(NORMAL_IO,NORMAL_SPEED,3,64);           // testbench should NOT define CP_TEST_IO
    #endif
    //testcase6
    #ifdef TC6
    dma_kick(CP_TEST_IO,NORMAL_SPEED,0,64);     // testbench should define CP_TEST_IO
    dma_kick(CP_TEST_IO,NORMAL_SPEED,1,64);     // testbench should define CP_TEST_IO
    dma_kick(CP_TEST_IO,NORMAL_SPEED,2,64);     // testbench should define CP_TEST_IO
    dma_kick(CP_TEST_IO,NORMAL_SPEED,3,64);     // testbench should define CP_TEST_IO
    #endif
    //testcase7
    #ifdef TC7
    dma_kick(NORMAL_IO,HIGH_SPEED,0,64);       // testbench should NOT define CP_TEST_IO    
    dma_kick(NORMAL_IO,HIGH_SPEED,1,64);       // testbench should NOT define CP_TEST_IO    
    dma_kick(NORMAL_IO,HIGH_SPEED,2,64);       // testbench should NOT define CP_TEST_IO    
    dma_kick(NORMAL_IO,HIGH_SPEED,3,64);       // testbench should NOT define CP_TEST_IO
    #endif
    //testcase8
    #ifdef TC8
    dma_kick(CP_TEST_IO,HIGH_SPEED,0,64);     // testbench should define CP_TEST_IO
    dma_kick(CP_TEST_IO,HIGH_SPEED,1,64);     // testbench should define CP_TEST_IO
    dma_kick(CP_TEST_IO,HIGH_SPEED,2,64);     // testbench should define CP_TEST_IO
    dma_kick(CP_TEST_IO,HIGH_SPEED,3,64);     // testbench should define CP_TEST_IO
    #endif
}
