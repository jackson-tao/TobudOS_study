#include "intrins.h"								  
#include "inc\common.h"		
#include "inc\ax215_exinst.h"		 
#include "inc\nand_flash.h"							 
#include "inc\sd_spi_com_define.h"				 				  
#include "inc\array_FIFO.h"
#include "inc\extern_data.h"
#include "inc\spiInc.h"
#include "inc\sdspi.h"
#include "inc\mrom_func.h"

#pragma asm
EXTRN CODE (Get_LgAddr)
EXTRN CODE (CUR_LBA,ERASE_START_LBA, ERASE_END_LBA)
EXTRN CODE (AKE_CHALLENGE_2_BUF,AKE_CHALLENGE_1_BUF) 
#pragma endasm

extern u8 code LBA_TMP;
extern unsigned char idata STACK_TOP;
extern unsigned char idata host_to_sd_buf_ptr,sd_to_nf_buf_ptr,sd_ready_for_nf_buf_cnt;
extern unsigned char idata sd_to_host_buf_ptr;
extern unsigned char idata dma_out_r_cur_virtual_buf_map_r_nf_page_ptr, dma_out_r_cur_virtual_buf_map_r_nf_sec_in_page_ptr;
extern unsigned char code sd_hs_cache_data_buf[];
extern unsigned short code sd_hs_cache_buf_dma_addr[];

extern unsigned char code TAB_R3_ACK,CSD,CSD_50M_CRC7,CSD_25M_CRC7,FUNCTION;
extern unsigned char code VALID_SECTOR_CNT;	
extern unsigned char code W_BUF_ADDR_H,W_BUF_ADDR_L;
extern unsigned char code BankCodeInFlashAddr;


extern bit bCopyBackNotOver, bCopyNeedStop, bLastReadDataInHsBuf;
extern bit bRcvSDDataKickStart;
extern bit bSDStop, bEnReadLBACnt,bReadNewBlockTrue;
extern bit bBankTrue;

extern u8 data ReadLBACnt;
extern u8 data NfEmptyBufCnt;

extern u8 data yBlockLen1,yBlockLen0,yTast_Index,yBuffer_Index,R8Tmp,yScrtyUnitCnt;
extern u8 data RdCurZone;
extern unsigned char code sd_hs_cache_data_buf_lba[][4];
extern unsigned char idata  rcv_data_state;
extern unsigned char data PlanRcvSDDataCnt, ActualRcvSDDataCnt, yBuffer_Index_Start;
extern unsigned char idata  sd_dma_in_cnt;
extern unsigned char idata virtual_sd_data_buf_cnt, hs_to_virtual_buf_ptr, virtual_to_nf_buf_ptr, write_virtual_sd_buf_data_to_nf_state;
extern unsigned char idata virtual_sd_buf_map_w_nf_page_ptr, virtual_sd_buf_map_r_nf_page_ptr;
extern unsigned char idata u8_extern_dma_in_task;
extern unsigned short idata virtual_buf_w_to_nf_thread_tick;
extern unsigned char idata virtual_to_nf_buf_in_per_page_sector_ptr;

//extern void uart_send_byte(u8 val);
extern void config_first_rcv_buf(void);
extern void check_addr_out_of_range(void);
extern void write_block_tab(void);
extern void rca_inc(void);
bit erase_task_parameter_analysis(void);
extern void reset_bch(void);

extern void read_lba(void);
extern void write_lba(void);
extern void write_lba_over(void);
extern void sel_dma_addr(void);
extern void nf_power_up(void);
extern void initial_cprm_pamameter(void);
extern void copy_lba(void);

extern void dma_mkb_pro(void);
extern void ake_rev_data_process(void);
extern void copy_dptr1_8_byte_data_to_dptr0(void);
extern void ake_send_data_process(void);
extern void get_scrty_lba(void);
extern void cprm_en_de_code_buf_point_to_cur_buf(void);
extern void cprm_encode_data(void);
extern void cprm_decode_data(void);

extern void Sel_Buffer_Addr(void);
extern void system_initial(void);
extern void save_hs_buf_data_to_virtual_sd_buf(void);
extern void updata_cur_virtual_sd_buf_data_to_nf(unsigned char r_virtual_buf_ptr, unsigned char r_virtual_buf_sec_in_page_ptr, unsigned char w_nf_buf);
extern void erase_lba(void);
extern void initial_vitrual_buf_parameter_in_powerup(void);
extern bit Read_Bank_Codes(void);
extern void SD_init(void);

void nf_power_up_pro(void);
void power_down(void);
void dma_data_out_kict_and_wait_ready(void);
void change_state_machine_in_data_state(void);
void get_lba(void);
void read_lba_data(void);
void mul_read_process(void);
void write_lba_data(void);
void wait_cmd_rps_ready(void);
void rcv_one_packet_case_in_pro_state_process(void);
void change_state_machine_in_pro_dis_state(void);
void clr_d0_busy_in_rcv_end(void);
void cprm_mul_write_end(void);
void wait_for_enter_sleep_mode(void);
void switch_clk_frq(void);
void erase_data_process(void);
void wait_dma_in_ready(void);

void crc_conf(void);
void dma_out_n_byte_data(u8 data dma_len);
void w_data_end_process(void);

void uart_send_byte(u8 val);
void uart_sent_byte(void);
void power_down(void);
void clr_d0_busy_in_rcv_ing(void);

void config_hs_cache_buf_dma_addr(unsigned char buf_ptr);
void write_data_from_hs_buf_to_flash(void);
void config_cur_buf_data_lba(unsigned char buf_ptr);
void copy_512byte_data(unsigned char src_buf_index, unsigned char target_buf_index);
void cur_map_lba_inc(void);
void clr_sd_read_data_flag(void);
void sd_lg_write_data(void);
void read_only_tasks(unsigned char task_index);
void erase_lba_change_sector_mode(void);
void update_er3_to_r_random_lba_var(void); 
void copy_buf_DP0_to_DP1(u16 length);

u16 idata u16_offset_in_buf;
extern u8 idata rcv_data_state;
extern u8 idata write_hs_data_to_flash_state;
extern unsigned char idata  before_cpy_max_sd_ready_for_nf_buf_cnt, max_sd_ready_for_nf_buf_cnt, use_debug_lba_cnt;	//debug
extern unsigned short idata max_n_10ms;
extern unsigned short idata  cal_erase_virtual_sd_buf_map_blk_cnt;
extern unsigned char idata  cal_map_blk_max_page_number;
extern unsigned char idata  cal_max_virtual_buf_cnt;
unsigned char idata tmp, cur_r_w_status, last_r_w_status;

extern void Uart_Send_Byte(u8 dat);
//extern void printHexSync(u8 dat);
extern void prints(u8 *p);

void main(void)							   
{		
	
	DPCON = 0;
	
	system_initial();		
	bNandPowerup = 0;
#if EN_CPRM	
	initial_cprm_pamameter();
#endif
	

	nf_power_up_pro();

	bNandPowerup = 1;
prints("spi mode\n");
	SD_init();
//	READY_FOR_DATA = 1;	

	crc_conf();	//::SPI CRC init according to SCCON_P1^6	
	
	bInReadLba = 0;	
	IDLE_STATE = 1;		

//	last_r_w_status = 0xff; 

	while(1)
	{
		enable_timer_isr();		 			//�ϵ���ϣ����ߣ���stop�󣬴�timer isr.	
		R8 = yTast_Index;		
		if ((R8 != Single_Write_Task) && 
			(R8 != Mul_Write_Task) && 
			(R8 != Secutity_Mul_Write_Task) && 
			(R8 != Erase_Task) && 
			(R8 != Security_Erase_Task) &&
			(R8 != Idle_Task)){
		
			EA = 0;
	if (R8 == yTast_Index) {							
			R8 = yTast_Index;	  //R8�ٸ�ֵ,if�ڲ���cmd�жϿ��ܻ�����⡣Ҳ���԰�EA�ŵ�ifǰ	
				
			yTast_Index = Idle_Task;			
			bCallWriteLBA = 0;			  	//���read cmd ��timer copy data ���� write_data_from_hs_buf_to_flash֮��
	}
			EA = 1;
		}
//putchar('a');	
//PrintHex(R8);		 				
		switch(R8)
		{

		 case Idle_Task:
			  if ((sd_ready_for_nf_buf_cnt == 0) &&   	//û�����ݵȴ�д��flash������£��Ž���power down
				(virtual_sd_data_buf_cnt == 0) &&
				(rcv_data_state == HS_RCV_DATA_IN_IDLE) &&					//���˳�singe write	 //���˳�mul write
				(write_hs_data_to_flash_state == W_HS_DATA_TO_FLASH_IDLE) &&
				(write_virtual_sd_buf_data_to_nf_state == W_VIRTUAL_SD_BUF_DATA_TO_NF_IDLE)) {				 		 	 
	//			  	 bNandPowerup = 1;						//Re-power up start
//xrl_p3(1 << 6);	
#if POWER_DOWN_EN	
		if (!bMulWriteTask && !bSingleWriteTask) {										
					wait_for_enter_sleep_mode();				 
		}
#endif 					
//xrl_p3(1 << 6);	
//xrl_p3(1 << 6);	
//xrl_p3(1 << 6);	
//xrl_p3(1 << 6);
//xrl_p3(1 << 6);
//xrl_p3(1 << 6);
			   }	
 	  		break;

#if EN_CPRM			
		 case Security_Erase_Task:
		 	  //Auto jmp to Erase_Task
#endif			  	  			                         
		 case Erase_Task:
//P2 ^= (1<<4);
			  if ((sd_ready_for_nf_buf_cnt == 0) && (virtual_sd_data_buf_cnt == 0)) {	  //��֤����buf��û�����ݣ��������ݲ����󣬾������ָ��µ�����LBA��
		 	 			 	 	
//				  wait_cmd_rps_ready();													  //����Ҫ�ȴ�cmd  rpsͬ��
				  if ( ! bTmpWriteProtect)
				  {
//				 	if ( ! Read_Bank_Codes()){
					if(1) {
//						erase_lba_change_sector_mode();	//��ַ512Byte����	
//					   	if ( ! erase_task_parameter_analysis()){  //�����������erase param/out of range
//							erase_data_process();
//						}				
					}
				  }else{
				  	WP_ERASE_SKIP = 1;
				  }

				  yTast_Index = Idle_Task;									//��������ִ����ϣ��Ž���idle״̬
				  
				  SDICON_P1 &= ~(1<<3);		  //	;disable busycmd_en			 
				  SDICON_P1 |= (1<<1);				//	;clr busy			  
				  bInEraseTask = 0;
				  bEnVirtualBuf2Nf = 0;
//P2 ^= (1<<5);
			  }else{
			  	 bEnVirtualBuf2Nf = 1;		//���ϵ�󣬼�ʹbEnVirtualBuf�����ݣ��ȴ�����д���ݺ󣬲Ÿ��µ�flash
			  }
		 	  break; 
			                           
		 case Pro_CSD_Task:
		 	  wait_cmd_rps_ready();
			  wait_dma_in_ready();
			  SDICON_P1 &= 0xfe;		  	//	;disable dat rcv
			  SDOCON_P1 &= 0xbf;		   	//	;enable command rcv			  

			  bTmpWriteProtect = (bit)((*((char xdata *)(_DATA_BUF)+14))& (1<<4));
			  SDICON_P1 |= (1<<1);				  //	;clr busy
		 	  break; 
			                         			                   
		 case GEN_CMD_Write_Task: 
		 	  wait_cmd_rps_ready();
			  wait_dma_in_ready();
			  SDICON_P1 &= 0xfe;		  	//	;disable dat rcv
			  SDOCON_P1 &= 0xbf;		   	//	;enable command rcv			  
			  SDICON_P1 |= (1<<1);			//	;clr busy
		 	  break; 

		case  READ_CID_Task:
			  SDXADR0_P1 = CID_DMA_ADDR_L;
			  SDXADR1_P1 = CID_DMA_ADDR_H;
			  dma_out_n_byte_data(16-1);
//			  clr_sd_read_data_flag();
			  break;

		case  READ_CSD_Task:
			  SDXADR0_P1 = CSD_DMA_ADDR_L;
			  SDXADR1_P1 = CSD_DMA_ADDR_H;
			  dma_out_n_byte_data(16-1);
//			  clr_sd_read_data_flag();
			  break;

		 default:     
		read_only_tasks(R8);

//		 	tmp = R8;
//		    if ( ! cur_r_w_status) {
//
//				if ( ! last_r_w_status )
//					bBankTrue = 1;
//				else
//					bBankTrue = 0;						   //need load				
//				if ( ! Read_Bank_Codes()){
//					read_only_tasks(tmp);
//				}
//				last_r_w_status = 0;
//			}
		 	  break;
		}
	
//		if (sd_ready_for_nf_buf_cnt != 0) {			//���hs_buf�����ݵ�flash��
		if (bCallWriteLBA) {
//			bNandPowerup = 0;						//Re-power up will be waiting.	
//prints("enter\n");
			write_data_from_hs_buf_to_flash();	
//prints("quit\n");
//			last_r_w_status = 1;
//			bBankTrue = 0;
		}else {
//			bNandPowerup = 1;
		}
#if 1		
		clr_sd_read_data_flag();
#endif
	
	}
}


void initial_sd_buf_in_out_ptr(void)
{
	host_to_sd_buf_ptr = 0;
	sd_to_nf_buf_ptr = 0;	
}

void erase_lba_change_sector_mode(void)
{
	#pragma asm	
	PUSH	DPCON
	MOV		DPCON, # 0x08 | (1<<1)					//���, �ر�����, dptr0, ����λ���bit��0		
	MOV		DPTR, # ERASE_START_LBA
	MOV32_ER3_EDP0			
	MOV		DPTR, #	ERASE_END_LBA
	MOV32_ER2_EDP0	
	
	JB		bSDHC, ERASE_SDHC_CARD
	MOV		R8, # 9
	ROTR32_ER2_ER8
	ROTR32_ER3_ER8
	MOV		DPTR, # ERASE_START_LBA		  
	MOV32_EDP0_ER3
	MOV		DPTR, # ERASE_END_LBA	 
	MOV32_EDP0_ER2
	ERASE_SDHC_CARD:								
	POP	  DPCON
	#pragma endasm

}

void read_only_tasks(unsigned char task_index)
{
	switch (task_index){
		 case Idle_Task:

			  break;
			  			  	 		                     
		 case READ_SCR_Task:  			  
			  SDXADR0_P1 = SCR_DMA_ADDR_L;
			  SDXADR1_P1 = SCR_DMA_ADDR_H;
			  dma_out_n_byte_data(8-1);	
//			  clr_sd_read_data_flag();	 	 
			  break; 
			                      
		 case Single_Read_Task:		 	  
			  get_lba(); 
			  bReadType = 1;
			  wait_cmd_rps_ready();				  	  
			  check_addr_out_of_range();
			  bDataOut_Flag = 0;
			  bMulRFlag = 1; 
			  read_lba_data();
		 bInReadLba = 0;
			  bMulRFlag = 0;
			  bDataStop_Flag = 0;		      
			  SDODLY_P1 &= ~0x01;	
//			  clr_sd_read_data_flag();			               
		 	  break;

#if EN_CPRM

		 case Security_Mul_Read_Task:  
		 	  bVisitCprmDataMode = 1;
			  bCprmDmaDataMode = 1;
			  //Auto jmp to Mul_Read_Task
#endif
		 case Mul_Read_Task: 			
			  get_lba();  
			  #pragma asm
			  	CLR32_ER2
			  #pragma endasm			  			 
			  initial_valid_sector_cnt();			  
			  mul_read_process();			//bReadType = 0; 
			  break;  
								  
										
		 case SD_State_Task:
			  SDXADR0_P1 = SD_STATE_DMA_ADDR_L;
			  SDXADR1_P1 = SD_STATE_DMA_ADDR_H;
			  dma_out_n_byte_data(64-1);
 //			  clr_sd_read_data_flag();		 	 
		 	  break;  
			                       
		 case SD_Fun_Task:
 			  switch_clk_frq();
// 			  clr_sd_read_data_flag();
		 	  break;  

		 case Get_WellWR_Task:  
			  SDXADR0_P1 = WR_BLOCKS_TAB_DMA_ADDR_L;
			  SDXADR1_P1 = WR_BLOCKS_TAB_DMA_ADDR_H;
			  dma_out_n_byte_data(4-1);
//			  clr_sd_read_data_flag();
		 	  break; 
			  			                    			                      
		 case GEN_CMD_Read_Task:
		  	  wait_cmd_rps_ready();
//			  SDXADR1_P1 = LBATmp1;
//			  SDXADR0_P1 = LBATmp0;
					SDXADR1_P1 = *(char xdata *)((&LBA_TMP) + 2);
					SDXADR0_P1 = *(char xdata *)((&LBA_TMP) + 3);
		
			  SDDL0_P1 = 0xff;
			  SDDL1_P1 = 0x01;
 			  dma_data_out_kict_and_wait_ready();
//            clr_sd_read_data_flag();
		 	  break; 

#if EN_CPRM			                  
		 case MID_Task: 

			  SDXADR0_P1 = MID_DMA_ADDR_L;
			  SDXADR1_P1 = MID_DMA_ADDR_H;
			  dma_out_n_byte_data(8-1);	 
//            clr_sd_read_data_flag();    
		 	  break; 
			                        
		 case MKB_Task:
			  dma_mkb_pro();
			  if (ACC == 0)
			  {
			  	mul_read_process();
			  }
//			  clr_sd_read_data_flag();			

		 	  break;   
                        
		 case RCV_AKE_CHLG_1_Task: 
			  bAKERcvType = 0;
			  ake_rev_data_process();
//			  clr_sd_read_data_flag();			
		 	  break; 
			                 
		 case RCV_AKE_CHLG_2_RPS_Task: 
			  bAKERcvType = 1;
			  ake_rev_data_process();
//			  clr_sd_read_data_flag();		   	
		 	  break;  
			            
		 case SEND_AKE_CHLG_2_Task:  

				DPTR0 =  AKE_CHALLENGE_2_BUF_ADDR;
				DPTR1 =  AKE_CHALLENGE_1_BUF_ADDR;
				copy_dptr1_8_byte_data_to_dptr0();
	#if 1	//;CHALL_2 come from CHALL_1			
				ER03 = 'Z';
				ER02 = 'G';
				ER01 = 'Z';
				ER00 = 215;	  	 		
				#pragma asm
				XRL32_ER0_ER1									   		//;ER0��Ϊ�����
				MOV		DPTR,	#AKE_CHALLENGE_2_BUF_ADDR
				XRL32_EDP0_ER0	
				MOV		DPTR,	#(AKE_CHALLENGE_2_BUF_ADDR + 4)
				XRL32_EDP0_ER0
				#pragma endasm
   #endif
				SDXADR1_P1 = AKE_CHALLENGE_2_BUF_DMA_ADDR_H;
				SDXADR0_P1 = AKE_CHALLENGE_2_BUF_DMA_ADDR_L;
				ake_send_data_process();
//              clr_sd_read_data_flag();
		 	  break;  
			              
		 case SEND_AKE_CHLG_1_RPS_Task: 
		 	  if (bAKEVerifyErr)
			  {
			  	bAKEVerifyErr = 0;
			  }
			  else
			  {
			  	SDXADR1_P1 = AKE_CHALLENGE_1_RPS_BUF_DMA_ADDR_H;
				SDXADR0_P1 = AKE_CHALLENGE_1_RPS_BUF_DMA_ADDR_L;
				ake_send_data_process();
			  }
//            clr_sd_read_data_flag();
		 	  break;   
            
		 case Change_Pro_Area_Task:	//�Ժ���������		 				
			  SDICON_P1 |= (1<<1);    	//	;CLR D0 busy.
		 	  break;   
			              
		 case Update_MKB_Task:  	//�Ժ���������	
			  SDICON_P1 |= (1<<1);    	//	;CLR D0 busy.
		 	  break;
#endif
		 default:
		 	  break;
	}
}

void nf_power_up_pro(void)
{
	nf_power_up();
	initial_vitrual_buf_parameter_in_powerup();	//����7THL flash��Ƭ���ú����ܳ�ʱ
}

/************************************************************************************************************************
* ��������void config_hs_cache_buf_dma_addr(unsigned char buf_ptr)	 using 3
* ���룺unsigned char buf_ptr ��buf������
* ���ܣ�buf_ptrת����SD DMA ��ַ�����ݴ���XDATA�У�W_BUF_ADDR_H��W_BUF_ADDR_L�������㹫ʽΪDMA addr = buf_ptr * 512 / 4 
* �õ�����ʱ�Ĵ���Ϊ��A,B,DPTR0
************************************************************************************************************************/
void config_hs_cache_buf_dma_addr(unsigned char buf_ptr) 
{
	_push_(DPCON);	

	DPCON = (1<<4);						  //DPTR0 & AUTO_INC 
	DPTR0 = sd_hs_cache_buf_dma_addr;		  //DPTR0 = sd_hs_cache_buf_dma_addr

	ACC =  buf_ptr;
	
	#pragma asm
	RL		A							//A = buf_ptr * 2
	MOV		R8, # 0
	MOV		B, 	A
	ADDDP0								//DPTR0 = sd_hs_cache_buf_dma_addr + buf_ptr * 2
				
	MOVX	A, @DPTR				   	//A = DMA_ADDR_H
	MOV		R8, A						//R8 = DMA_ADDR_H
	MOVX	A, @DPTR					//A = DMA_ADDR_L
	MOV		B, A						//B =  DMA_ADDR_L
	#pragma endasm

	_pop_(DPCON);					  //���Ż�

}

extern void sleep_main(void);
void power_down(void)
{
	
	disable_timer_isr();
	sleep_main();	
}

void wait_cmd_rps_ready()
{
	while( !bCMDRps_Flag)
	{}
	bCMDRps_Flag = 0;
}


void wait_dma_out_ready(void)
{
	while( !bDataOut_Flag)
	{}
	bDataOut_Flag = 0;
}

void dma_data_out_kict_and_wait_ready(void)
{
	SDOTK_P1 = 0xfe;		   //	;start token: 0xfe
	SDOCON_P1 |= (1<<0);
	wait_dma_out_ready();
}

void get_lba(void)
{
	_push_(PAGEMAP);

	PAGEMAP = 0x01;
	
	ER33 = *(char xdata *)((&LBA_TMP) + 0);
	ER32 = *(char xdata *)((&LBA_TMP) + 1);
	ER31 = *(char xdata *)((&LBA_TMP) + 2);
	ER30 = *(char xdata *)((&LBA_TMP) + 3);
	
	if ( ! bSDHC)
	{
		ER30	&= 0;
		ER31 &= 0xfe;
		R8 = 9;						
		#pragma asm
		ROTR32_ER3_ER8 
		#pragma endasm	
	}
#if EN_CPRM	
	if (bVisitCprmDataMode)
	{
		get_scrty_lba();
	}
#endif
	_pop_(PAGEMAP);
} 

//void check_erase_lba_range(void)
//{
//
//}
/************************************************************************************************************************
* ��������	READ_OFFSET_IN_CURRENT_BUF
* ��ڲ�����	yBlockLen0/yBlockLen1/yBuffer_Index/R0(Bank1)/R1(Bank1) 
* ��Ҫ����Դ��ER0 ER2	DPTR0 DPRT1
* ���ڲ�����	��	
* ����˵����	�ѵ�ǰSECTOR����offset��ʼ������copy���Ե�ǰsectorΪ�׵�ַ�ĵط������DMA OUT����512byte������
************************************************************************************************************************/
//void read_offset_in_current_buf()
//{
//#if 0
//	_push_(DPCON);
//
//	ER02 = yBuffer_Index;
//	Sel_Buffer_Addr();
//	DP0L = ER00;
//	DP0H = ER01;
//	
//	#pragma asm
//	CLR32_ER2
//	#pragma endasm
//	R20 = *((char idata *)(&u16_offset_in_buf) + 1);
//	R21 = *((char idata *)(&u16_offset_in_buf) + 0)& 0x01;
//
//	R02 = yBufIndexCopyTmp;
//	Sel_Buffer_Addr();
//	#pragma asm
//	ADD32_ER0_ER2_ER0
//	#pragma endasm
//
//	DP1L = R00;
//	DP1H = R01;
//
//	#pragma asm
//	CLR32_ER0
//	#pragma endasm
//	R00 = yBlockLen0;
//	R01 = yBlockLen1;
//
//	#pragma asm
//	ADD32_ER0_ER0_ER2
//	INC32_ER0	
//	#pragma endasm
//	*((char idata *)(&u16_offset_in_buf) + 1) = R00;
//	*((char idata *)(&u16_offset_in_buf) + 0) = R01;
//
//	#pragma asm
//	MOV		R2,	yBlockLen0	  				//DMA OUT ����
//	MOV		R3,	yBlockLen1
//	MOV	    DPCON,#31H						//Enable DPTR0/DPTR1 Auto INC ,select toggle enable,select DPTR1	
//	INC		R2
//
//CONTINUE_MEMORY_COPY:
//
//	MOVX	A,@DPTR
//	MOVX	@DPTR,A	
//	DJNZ	R2,CONTINUE_MEMORY_COPY
//	MOV		A,R3
//	JZ		EXIT_MEMORY_COPY
//	DEC		R3
//	MOV		R2,#00H
//	JMP		CONTINUE_MEMORY_COPY
//	
//EXIT_MEMORY_COPY:
//
// 	#pragma endasm
//
//	_pop_(DPCON);
//
//#endif
//}

#if EN_CPRM
void judge_cprm_data_dma_out_complete(void)
{
	if (bCprmDmaDataMode)
	{

		yScrtyUnitCnt--;
		if (yScrtyUnitCnt == 0)
		{
			while( ! bDataOut_Flag)
			{}
			bDataStop_Flag = 1;
			bSDStop = 1;			//nfc read stop
			bEnterReadDmaOut = 0;
		}	
	}
}
#endif



/************************************************************************************************************************
* ��������void update_er3_to_r_random_lba_var(void)
* ���룺ER3
* �����RANDOMIZE_LBA_TMP[4],��Ϊflash�Ķ����ݵ� ����� LBA��������˶���
************************************************************************************************************************/
void update_er3_to_r_random_lba_var(void)
{
//	#pragma asm
//	PUSH	DPCON
//	MOV		DPCON,# 0x08					//���, �ر�����, dptr0	
//	MOV		DPTR, # CUR_LBA
//	MOV32_ER0_EDP0
//	MOV		DPTR, # RANDOMIZE_LBA_TMP	 	//LBA��Ϊ����
//	MOV32_EDP0_ER0
//	POP		DPCON
//	#pragma endasm
}

void read_lba_data(void)
{	
	
	while (	(write_hs_data_to_flash_state != W_HS_DATA_TO_FLASH_IDLE) || 
			(write_virtual_sd_buf_data_to_nf_state != W_VIRTUAL_SD_BUF_DATA_TO_NF_IDLE)){};	//ͬ��timerд����������idle״̬�¶�����.

	_push_(PAGEMAP);
	PAGEMAP = 0X01;
	ReadLBACnt = 0;
	SdDmaReadLBACnt = 0;
	bEnReadLBACnt = 0;
	bSDStop = 0;

	update_er3_to_cur_lba_var();

//		bReadNewBlockTrue=0;
//		bCopyNeedStop = 0;
		while( ! bDataStop_Flag) {		//����ֹͣ��־	
			
		update_cur_lba_to_cur_map_lba_var();
		
		bStr_MulRead_SD = 1;							 //timer ��ѯ����bit��ʼ׼��dma out����	
		read_lba();	
		reset_bch();	
		bEnReadLBACnt = 0;
		ReadLBACnt = 0;
		SdDmaReadLBACnt = 0;

		EA = 0;
		if ( ! bDataStop_Flag) {
			bSDStop = 0;
		}
		EA = 1;
	
		if (bReadDataInVirtualBuf){
			bStr_MulRead_SD = 1;							 //timer ��ѯ����bit��ʼ׼��dma out����	
			yBuffer_Index = 0;
			updata_cur_virtual_sd_buf_data_to_nf(dma_out_r_cur_virtual_buf_map_r_nf_page_ptr, dma_out_r_cur_virtual_buf_map_r_nf_sec_in_page_ptr, yBuffer_Index);
			bDataOut_Flag = 0;
			ReadLBACnt = 1;
					SdDmaReadLBACnt = 1;
			bEnReadLBACnt = 1; 

		}
//uart_send_byte(0xa5);			
		while( ( ! bDataStop_Flag) && (bReadDataInHsBuf || bReadDataInVirtualBuf) && ( ! bDataOut_Flag)) {}  //data in hs buf������stop��Ϻ���Ҫͬ���ȴ����һ��data dma out�󣬱���(single read && in hs buf)�ٴν��������
		bDataOut_Flag = 0;				  //dma out finished.
		bReadDataInHsBuf = 0;			  //0:Data is not in hs buf.
		bReadDataInVirtualBuf = 0;		  //0:Data is not is virtual buf.
	}
	bSDStop = 1;
//	bBankTrue = 0;						                              	
	_pop_(PAGEMAP);
}


#if EN_CPRM
void cprm_mul_read_end(void)
{
	if (bCprmDmaDataMode)
	{							 //	;MKB data DMA complete...
		bDataOut_Flag = 0;
		bCprmDmaDataMode = 0;
		bVisitCprmDataMode = 0;
		bMulRFlag = 0;	
	}
}
#endif

void mul_read_process(void)
{
	bMulRFlag = 1;
	bReadType = 0;
	wait_cmd_rps_ready();		
	bDataOut_Flag = 0;
	read_lba_data();
	bDataStop_Flag = 0;
	bMulRFlag = 0;
	SDODLY_P1 &= ~0x01;	
#if EN_CPRM
	cprm_mul_read_end();	
#endif
	bInReadLba = 0;
}

void init_write_task_var(void)
{
	bStr_MulWrite = 1;
//	bCallWriteLBA = 0;
	RdCurZone = 0xff;
	yBuffer_Index = _DATA_BUF_INDEX;
}  

void  sd_stop_single_write_pro(void)
{
}

void check_mul_write_addr_out_of_range(void)
{
	_push_(DPCON);
	_push_(ER03);
	_push_(ER02);
	_push_(ER01);
	_push_(ER00);

	DPCON = 0x08;		 						 //	;���
	DPTR0 = (char xdata *)(&VALID_SECTOR_CNT);
	#pragma asm
	SUB32_ER0_EDP0_ER2
	#pragma endasm
	if (EC)
	{
		OUT_OF_RANGE = 1;	
	}
	if (bTmpWriteProtect)
	{
		WP_VIOLATION = 1;
	}
	_pop_(ER00);
	_pop_(ER01);
	_pop_(ER02);
	_pop_(ER03);
	_pop_(DPCON);
}

void sd_stop_mul_write_pro(void)
{
//	SDICON_P1 &= 0xfe;		  	//	;disable dat rcv
//	SDOCON_P1 &= 0xbf;		   	//	;enable command rcv			  
	check_mul_write_addr_out_of_range();
}

void stop_single_write_fun(void)
{
	sd_stop_single_write_pro();
}
void stop_mul_write_fun(void)
{
	sd_stop_mul_write_pro();
}


void judge_cprm_data_dma_in_complete(void)
{
	if (bCprmDmaDataMode)
	{
#if EN_CPRM
		yScrtyUnitCnt--;
		if (yScrtyUnitCnt == 0)
		{
			bStopRcvCprmData = 1;
		}
#endif
	}
}

void clr_d0_busy_in_rcv_ing(void)
{
	SDICON_P1 |= (1<<1);
}

#if 0
void write_lba_data(void)
{
	init_write_task_var();
	while(1)
	{
		wait_dma_in_ready();
		if ( ! bWriteType)
		{
			if (SDOTK_P1 == 0xfd)	
			{
				break;
			}
		}
		if ( bSPI_CRC_Check_Flag && SDCRC)
		{

		}
		else
		{

			#pragma asm
				INC32_ER2
			#pragma endasm	
#if EN_CPRM
			cprm_en_de_code_buf_point_to_cur_buf();
			cprm_decode_data();
#endif
			bCallWriteLBA = 1;
		
			pop_reg_bank_0();
			write_lba();
			push_reg_bank_0();

			#pragma asm
				INC32_ER3
			#pragma endasm	
		}
		if (bWriteType)
		{
		 	break;
		}
		judge_cprm_data_dma_in_complete();
		if (bStopRcvCprmData)
		{
			break;
		}
		ER02 = yBuffer_Index;
		sel_dma_addr();
		SDXADR1_P1 = ER01;
		SDXADR0_P1 = ER00;
		SDICON_P1 |= (1<<1);
	}
	if (bWriteType)
	{
		stop_single_write_fun();
	}
	else
	{
		stop_mul_write_fun();
	}
	if (bCallWriteLBA)
	{
		bCallWriteLBA = 0;
		
		pop_reg_bank_0();
		write_lba_over();
	}
	config_first_rcv_buf();
}
#endif

void cprm_mul_write_end(void)
{
#if EN_CPRM
	if (bCprmDmaDataMode)
	{							//	;MKB data DMA complete...
		bCprmDmaDataMode = 0;
		bStopRcvCprmData = 0;			
	}

#endif
}

void wait_for_enter_sleep_mode(void)
{	
	_push_(IE1);
	_push_(PAGEMAP);
	PAGEMAP = 3;
	_push_(T3CON_P3);


	#pragma asm
	CLR32_ER0
	#pragma endasm
	
	PAGEMAP = 0;
EA = 0;	
	ER40 = yCMD_Index;
EA = 1;	
	while(1)
	{

		
		if ((PCON0_P0 & (1<<3)) || (yTast_Index != Idle_Task) || (yCMD_Index != ER40))	//�����û������,����cmd trigger���ڵȴ�power down̫��
		{
				PCON0_P0 &= ~(1<<3); //clear wake up pending 
				break;
		}
		
		
		#pragma asm
			INC32_ER0
		#pragma endasm

		if (ER02 & (1<<4)) 	//5*16ms	
		{
	
			power_down();			
	
			break;						
		}


	} 

	PAGEMAP = 3;
	_pop_(T3CON_P3);
	_pop_(PAGEMAP);	
	_pop_(IE1);
}



void switch_clk_frq(void)
{

	wait_cmd_rps_ready();
	#pragma asm
	CLR32_ER2
	#pragma endasm	
	ER40 = 0x64;
	bSwitch50M = 0;	
	for (ER00=6; ER00>0; ER00--)	
	{
		R8 = 4;
		#pragma asm
		ROTR32_ER2_ER8	
		#pragma endasm		
		if (((ER30 & 0x0f) != 0) && ((ER30 & 0x0f) != 0x0f) ) 
		{
#if _50M
			if ((ER00 == 6) && (ER30 & 0x0f) == 0x01 )
			{
				ER23 = 0x10;
				if (ER33 & (1<<7))
				{
					bSwitch50M = 1;
				}
			}
			else
#endif
			{
			   	ER23 |= 0xf0; 
				ER40 = 0;
				bSwitch50M = 0;
			}			  
	}
	R8 = 4;
	#pragma asm
	ROTR32_ER3_ER8	
	#pragma endasm							  
	}		  	
	*((char xdata *)(&FUNCTION) + 1)  = ER40;			 
	*((char xdata *)(&FUNCTION) + 14) = ER23;
	*((char xdata *)(&FUNCTION) + 15) = ER22;
	*((char xdata *)(&FUNCTION) + 16) = ER21;	
	SDXADR0_P1 = FUNCTION_DMA_ADDR_L;
	SDXADR1_P1 = FUNCTION_DMA_ADDR_H;	
	SDDL0_P1 = 63;
	SDDL1_P1 = 0;	
	if (ER40 != 0)
	{
		*((char xdata *)(&CSD)+3) = 0x5a;
		*((char xdata *)(&CSD)+15) = *(char xdata *)(&CSD_50M_CRC7);
	}
	else
	{
		*((char xdata *)(&CSD)+3) = 0x32;
		*((char xdata *)(&CSD)+15) = *(char xdata *)(&CSD_25M_CRC7);
	}
	dma_data_out_kict_and_wait_ready();
#if _50M

	if ((ER40 != 0) && (bSwitch50M == 1))
	{
		SCCON_P1 |= (1<<5);
	}

#endif

}

/************************************************************************************************************************
* ��������void mem_set(unsigned char fill_data)
* ���룺 DPTR0, ER0, fill_data
* DPTR0: buf�׵�ַ
* �̶�512byte
* fill_data: ��Ҫ���������
* ����:	
* �����
* TPM: ER1
************************************************************************************************************************/
void mem_set(unsigned char fill_data)
{
	_push_(DPCON);

	DPCON = 0x18;						//DPTR0 ����,���

	ER10 = fill_data;
	ER11 = fill_data;
	ER12 = fill_data;
	ER13 = fill_data;

	B = 512/4;

	#pragma asm
	MEM_SET_FILL_BUF_LOOP:
	MOV32_EDP0_ER1
	DJNZ	B,	MEM_SET_FILL_BUF_LOOP
	#pragma endasm

	_pop_(DPCON);
}
/************************************************************************************************************************
* ��������sd_lg_write_data
* ���룺ER2(len) 
* ����:	 
* �����
* tmp: 
************************************************************************************************************************/
void sd_lg_write_data(void)
{
	_push_(DPCON);
	DPCON = 0;

	 if (bInEraseTask && (sd_ready_for_nf_buf_cnt == 0) && (virtual_sd_data_buf_cnt == 0)){	
	
	//PlanRcvSDDataCnt ===	NfEmptyBufCnt	 //�������̣�����Ҫnf һ��д���ݣ�һ�������ݵ�buf�У���������ֵ���.
		#pragma asm
		MOV32_ER0_ER2						//�ж�ER2�Ƿ�Ϊ0
		#pragma endasm		
		
		while((EZ == 0) && (PlanRcvSDDataCnt != 0)){
			ER02 =  yBuffer_Index_Start;
			Sel_Buffer_Addr();
			DP0H = ER01;
			DP0L = ER00;
			mem_set(0xff);					//fill 0xff to cur buf 

		   	#pragma asm
			DEC32_ER2
			#pragma endasm

			NfEmptyBufCnt--;			
			yBuffer_Index_Start++;
		   	ActualRcvSDDataCnt++;	 
			if (ActualRcvSDDataCnt == PlanRcvSDDataCnt) {
//				bRcvSDDataKickStart = 0;
				break;	
			}
		}  //end while()
		bRcvSDDataKickStart = 0;

	 }
	 _pop_(DPCON);
}

void get_SectorPerBlock(void)
{
	#pragma asm
	PUSH	DPCON
	MOV		DPCON, #0x10//INC
	
	//����BlockLBA
	SETB	bStr_MulWrite
	MOV 	B,#2
	CALL	Get_LgAddr//bStr_MulWrite=1ʱ����Ҫ�ò����������Ҫ��Ҳ�ض�Ϊ1
	CLR		bStr_MulWrite

	POP		DPCON
	#pragma endasm
} 


/************************************************************************************************************************
* ��������void erase_data_process(void)
* ���룺 ERASE_START_LBA[4], ERASE_END_LBA[4]
* ����:	 [ERASE_START_LBA�� ERASE_END_LBA] ������LBA��ַ��д��0xff
* �����
* tmp: 	ER2
************************************************************************************************************************/
void erase_data_process(void)
{

}

void wait_dma_in_ready(void)
{
	while( !bDataIn_Flag)
	{}
	bDataIn_Flag = 0;
}

void crc_conf(void)
{
	if ((SCCON_P1 & (1<<6)) == 0)
	{
		bSPI_CRC_Check_Flag = 0;
		SCCON_P1 |= (1<<7);
		SDOCON_P1 |= (1<<2); 
		SDOCON_P1 &= ~(1<<1);	
	}
	else
	{
		bSPI_CRC_Check_Flag = 1;
		SCCON_P1 &= ~(1<<7);
		SDOCON_P1 &= ~(1<<2);
		SDOCON_P1 &= ~(1<<1);	
	}
}

//len 0->1
void dma_out_n_byte_data(u8 data dma_len)
{
	while( !bCMDRps_Flag)
	{}
	bCMDRps_Flag = 0;
	SDOTK_P1 = 0xfe;
	SDDL0_P1 = dma_len;
	SDDL1_P1 = 0;
	SDOCON_P1 |= (1<<0);
	while( !bDataOut_Flag)
	{}
	bDataOut_Flag = 0;
	bDataStop_Flag = 0;	
//	prints("csd");
}

void w_data_end_process(void)
{
	SDICON_P1 |= (1<<1);		//	;clr busy
	SDICON_P1 &= 0xfe;		  	//	;disable dat rcv
	SDOCON_P1 &= 0xbf;		   	//	;enable command rcv	
}


void write_data_from_hs_buf_to_flash(void)
{  	
 //uart_send_byte(0xd9);
			
		while(bRcvSDDataKickStart) {}
		
		bInWriteLbaFun = 1;					   //writing lba
		init_write_task_var();	

//uart_send_byte(0xde);	  
		write_lba();
		
		save_hs_buf_data_to_virtual_sd_buf();
	
		bCallWriteLBA = 0;						 //time_isr�õ���bit��Ϣ,�����ж�stop���Ƿ�������ݵĴ���
		while((write_hs_data_to_flash_state == W_HS_DATA_TO_FLASH_END) || 
			  (write_virtual_sd_buf_data_to_nf_state == W_VIRTUAL_SD_BUF_DATA_TO_NF_END )
			 ){}			  					//�ȴ�timer���˳�д����	
		
		bInWriteLbaFun = 0;					   //write lba in idle.
//uart_send_byte(0xdf);		
}


/************************************************************************************************************************
* ��������void cur_map_lba_inc(void)
* ���룺
* ���ܣ�@CUR_LBA++
* �����@CUR_LBA = @CUR_LBA + 1
*tmp�� DPTR0
************************************************************************************************************************/
void cur_map_lba_inc(void)
{
	_push_(ER03);
	_push_(ER02);
	_push_(ER01);
	_push_(ER00);
	_push_(DPCON);
	
	DPCON = 0x08;				//���, �ر�����, dptr0

	#pragma asm
	MOV	 DPTR, # CUR_LBA  
	MOV32_ER0_EDP0
	INC32_ER0
	MOV32_EDP0_ER0
	#pragma endasm

	_pop_(DPCON);
	_pop_(ER00);
	_pop_(ER01);
	_pop_(ER02);
	_pop_(ER03);
}

/************************************************************************************************************************
* ��������void copy_512byte_data(unsigned char src_buf_index, unsigned char target_buf_index)
* ���룺
* unsigned char src_buf_index	 : hs_cache_buf ��������
* unsigned char target_buf_index ��flash����buf��������
* �����target_buf_indexָ���buf���ݡ�
* ���ܣ��� src_buf_indexָ��buf������copy��target_buf_indexָ���buf�С�
************************************************************************************************************************/
void copy_512byte_data(unsigned char src_buf_index, unsigned char target_buf_index)
{ 

#if EN_HW_COPY_512BYTE
	R8 = src_buf_index;	
	ER02 = target_buf_index;		
	Sel_Buffer_Addr();					 			//(target) ER01, ER00

	DPTR0 = sd_hs_cache_data_buf;					//hs_cache_data_buf

	#pragma asm
	CLR32_ER1
	MOV		ER10, R8
	MOV		ER13, # 0x02 		  						
	MUL16_ER1									   //ER1 = src_buf_index * 0x0200
	MOV		R8, ER11									
	MOV		B,  ER10									
	ADDDP0										  //(src)DPTR0= hs_cache_data_buf + buf_ptr * 0x0200
	#pragma endasm
	
	ER11 = DP0H;
	ER10 = DP0L;

	mem_copy_hw(); //mask���ù̶�512 byte
	
#else

	_push_(DP1H);
	_push_(DP1L);

	_push_(DPCON);
	
	DPCON = 0;
	R8 = src_buf_index;	
	ER02 = target_buf_index;	
	DPTR1 = sd_hs_cache_data_buf;					  //hs_cache_data_buf

	Sel_Buffer_Addr();
	#pragma asm
	MOV		DP0H, ER01
	MOV		DP0L, ER00
	CLR32_ER0
	MOV		ER00, R8
	MOV		ER03, #0x02 		  						
	MUL16_ER0									   //ER0 = src_buf_index * 0x0200
	MOV		R8, ER01									
	MOV		B,  ER00									
	ADDDP1											//DPTR1 = hs_cache_data_buf + buf_ptr * 0x0200

	MOV		DPCON, # 0x31							//Enable DPTR0/DPTR1 Auto INC ,select toggle enable,select DPTR1	
	MOV		B, # 512 / (4 * 8)
	
	COPY_512_BYTE_LOOP:	
		 
	MOV32_ER0_EDP1
	MOV32_EDP0_ER0								   //copy 4 byte
	
	MOV32_ER0_EDP1
	MOV32_EDP0_ER0								   //copy 4 byte
	
	MOV32_ER0_EDP1
	MOV32_EDP0_ER0								   //copy 4 byte
	
	MOV32_ER0_EDP1
	MOV32_EDP0_ER0								   //copy 4 byte

	MOV32_ER0_EDP1
	MOV32_EDP0_ER0								   //copy 4 byte
	
	MOV32_ER0_EDP1
	MOV32_EDP0_ER0								   //copy 4 byte
	
	MOV32_ER0_EDP1
	MOV32_EDP0_ER0								   //copy 4 byte
	
	MOV32_ER0_EDP1
	MOV32_EDP0_ER0								   //copy 4 byte
	
	DJNZ	B, COPY_512_BYTE_LOOP

	#pragma endasm
	
	_pop_(DPCON);
	
	_pop_(DP1L);
	_pop_(DP1H);
#endif

}  


/************************************************************************************************************************
* ��������u8 get_mem_copy_hw_status(void)
* ���룺0: copying;  !=0: copy complete.
* ����:
* �����
************************************************************************************************************************/
u8 get_mem_copy_hw_status(void)
{

#if EN_HW_COPY_512BYTE

	_push_(PAGEMAP);

	PAGEMAP = 0x00;
	B = DMACON_P0 & 0x80;
	
	_pop_(PAGEMAP);
	
	return B;
	
#else

	return 1;

#endif

}

/************************************************************************************************************************
* ��������void config_cur_buf_data_lba(unsigned char buf_ptr)
* ���룺unsigned char buf_ptr ��buf������
* ���ܣ���sd_hs_cache_data_buf_lba[buf_ptr][4]��ȡ��LBA����ŵ�CUR_LBA[4]�У���Ϊflash����ڲ���
* �����CUR_LBA[4],ER0.  ER0 = CUR_LBA[4] = LBA.
************************************************************************************************************************/
void config_cur_buf_data_lba(unsigned char buf_ptr)
{
	_push_(DPCON);
	
	DPCON = 0x08;				//���, �ر�����, dptr0
	
	//���»���buf��Ӧ��LBA TABLE, sd_hs_cache_data_buf_lba[buf_ptr][4] = ER3	
	DPTR0 =  sd_hs_cache_data_buf_lba;	
	R8 = 0;
	B = buf_ptr << 2;		  

	#pragma asm
	ADDDP0					//DPTR0 + (R8 B)	
	MOV32_ER0_EDP0
	MOV	 DPTR, # CUR_LBA
	MOV32_EDP0_ER0			 //��˴��LBA
	#pragma endasm
			
	_pop_(DPCON);
}

/************************************************************************************************************************
* ��������void clr_sd_read_data_flag(void)
* ���룺
* ����:
* �����
************************************************************************************************************************/
void clr_sd_read_data_flag(void)
{
	EA = 0;

	if ( ! bEnterReadDmaOut) {		//���dma out �����룬����Ҫ�ı����µĲ���
	 	bInReadLba = 0;
		bCopyNeedStop = 0;
		bSDStop = 0;	
	}
	EA = 1;
}
