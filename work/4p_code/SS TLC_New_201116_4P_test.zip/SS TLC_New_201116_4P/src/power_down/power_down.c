#include "inc\common.h"
extern  void xrl_p0(u8 dat);	
extern unsigned char data yTast_Index ;
extern unsigned char data yCMD_Index;
//δ��clk��Ƶ
void sleep_main(void)
{
//	unsigned char i;
		_push_(PAGEMAP);		
		sfrpage(0);
		_push_(PCON2_P0);
		_push_(PCON1_P0); 
		_push_(CLKCON1_P0);
		
		ER10 = P4DIR_P0;
		ER11 = P4PLP_P0;
		ER12 = P0DIR_P0;
		ER13 = P0PLP_P0;
		ER00 = P1DIR_P0;
		ER01 = P1PLP_P0;
		ER02 = P3DIR_P0;
		ER03 = P3PLP_P0;   //��Ҫ�κ��ж϶����ܸı���Щֵ,sd isr��timer�����ܸı�
	
// =========================================
// io setting: input & pullup
// =========================================
// SDCLK_IO
// high voltage, low drive, have noise limit  
/*****P40~P45 SD IO*****/

/*****P40~P45 SD IO all input & pull up register 30K & defaul driver & defaul noise tolerant*****/	
//		P4PLP_P0 = 0x00;
//		P4PLP_P0 = 0xff;//all SD io pull up 30k register choise   30K������  0x3f  //261uA
//		P4PLP_P0 &= ~(1<<1);	//cmd������
//		P4PLP_P0 &= ~(1<<0);	//clk������
//		P4PD_P0	|= (1<<0);		//clk����
//		P4PLP_P0 &= ~(1<<2)|(1<<3)|(1<<4)|(1<<5);	//data������

//		P4PLP1_P0 = 0xff;		//10Kǿ����  400uA
		//30k 10k��������Ϊ7.5K����
		
//all input & pull up   
/*****P00~P01 NCE0/1*****/
/*****P1 NF data0~7*****/
/****
 *P30	NWP
 *P31 NCLE
 *P32 NALE
 *P33	NWE
 *P34	NRE
 *P35	NRB0
 *P36	NRB1
 *P37	NDQS
******/
		P0DIR_P0 = 0xff;//0x03;
		P0PLP_P0 = 0xff;//0x03;
		
		P1DIR_P0 = 0xff;
		P1PLP_P0 = 0xff;
		
		P3DIR_P0 = 0xff;
		P3PLP_P0 = 0xff;
		

	if ((PCON0_P0 & (1<<3)) || (yTast_Index != Idle_Task) || (yCMD_Index != ER40))
	{
			PCON0_P0 &= ~(1<<3); //clear wake up pending 
			goto wake_up_end;
	}
	
PAGEMAP = 1;
if (SSTA_P1 > 4)
{
	PCON0_P0 &= ~(1<<3); //clear wake up pending 
	goto wake_up_end;
}
PAGEMAP = 0;

	
//sd io���ʼ��
	_push_(IE);
	EA = 0;  //�ȹ��ж���ȥ��ʼ��IO,�����жϻ�ı�ER�Ĵ���	
	
	P4DIR_P0 = 0xff;//all SD io input 0x3f
	P4PLP_P0 |= (1<<5);
/****power down******/
//		PCON0_P0 |= (1<<1)|(1<<0);//FALLING EDGE(default SDCLK)
//		PCON0_P0 |= (1<<2);//wake up enable
//		_nop_();
//		_nop_();
//		_nop_();
//		_nop_();
//		_nop_();//wait power down   //�ŵ��ϵ�
		
	PCON2_P0 |= 0x01;		  //low power enable
//	PCON2_P0 &= ~(1<<1);	  //disable LDO18   //����,��ʱ�ص�
	PCON1_P0 &= ~0x02;		  //lvd disable  
////	PCON2_P0 &= ~(0xf0);	  //ldo12 = 0.8V
////	PCON2_P0 &= ~(0x0c);	  //ldo18 = V
	CLKCON1_P0 |= BIT(3);     // disable RC when power down		
		
	PD = 1;
	_nop_(); 
	_nop_(); 
	_nop_(); 
	_nop_(); 
//	_nop_(); 
//	_nop_(); 
//	_nop_(); 
		PCON0_P0 &= ~(1<<3);//clear wake up pending 
		_nop_();
		_nop_();
		_nop_();
		_nop_();	
/********************/		
		P4DIR_P0 = ER10;
		P4PLP_P0 = ER11;		
		_pop_(IE);   //�ָ���sd IO��
		
wake_up_end:		
		P0DIR_P0 = ER12;
		P0PLP_P0 = ER13;
		P1DIR_P0 = ER00;
		P1PLP_P0 = ER01;
		P3DIR_P0 = ER02;
		P3PLP_P0 = ER03;

		PAGEMAP = 0;
		_pop_(CLKCON1_P0);
		_pop_(PCON1_P0);
		_pop_(PCON2_P0);
		_pop_(PAGEMAP);

//		for(i=0;i<100;i++)
//			_nop_();
//    // ========================================= 
//    RCCTL |= BIT(5);     // disable RC when power down

//    PCTL |= BIT(1);      // set power down mode   
}


