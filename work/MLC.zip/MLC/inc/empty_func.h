

/*****************************************************************************/
//	MTD.ASM
/*****************************************************************************/
//void	NF_Read_Start        (void);
//void	NF_Read_Data         (void);
//void	NF_Prog_Page         (void);
//void	NF_Prog_Data         (void);
//void	NF_Prog_Stop         (void);
//void	NF_Erase_Block       (void);
//void	Change_CE            (void);
//void	NF_Wait_Read_Over    (void);
//void	Get_CurPlaneCfg      (void);
//void	Wait_Flash_Ready     (void);
//void	BCH_MODE_DC_Wait_Over(void);
//void	Get_True_BlockAddr   (void); 
void	Read_SDBuf_Block     (void); 
void	program_sdbuf_block  (void); 
void	erase_sdbuf_block    (void); 


                                           
/*****************************************************************************/
//	READ_WRITE.ASM
/*****************************************************************************/  
//void Write_LBA_Over                   (void);
//void Write_a_Block_Over               (void);
//void Read_WritingBlockBuf             (void);
//void Write_WritingBlockBuf            (void);
//void Updata_WrLg2phTable              (void);
//void Get_OldBlockPhAddr               (void);
//void Get_PagePh2LgTable_StartAddr     (void);
//void Sel_DMA_Addr                     (void);
//void Set_Page_PhAddr                  (void);
//void Get_WrCurZone_Lg2PhTable         (void);
//void Set_Block_PhAddr                 (void);
//void Get_Block_PhAddr                 (void);
//void Get_LgAddr                       (void);
//void Chk_SpareArea_Data               (void);
//void Chk_Need_Retry                   (void);   
void Read_LBA                         (void);
void Write_LBA                        (void);
void Sel_Buffer_Addr                  (void);
void Buf1_2_Buf0	                  (void);
void Copy_LBA                         (void); 
void Erase_LBA            		      (void); 
void NF_POWER_UP   				      (void); 
void READ_BANK_CODES   		  	      (void); 
void CONFIG_FIRST_RCV_BUF             (void);
void AKE_CHALLENGE_2_BUF              (void);
void AKE_CHALLENGE_1_BUF              (void);







