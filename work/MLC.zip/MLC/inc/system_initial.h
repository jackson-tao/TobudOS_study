#ifndef _system_initial_h_
#define _system_initial_h_

extern unsigned short idata u16RCA;
extern unsigned char idata u8_pwr_active_cnt;
extern bit bSDHC,bCMD8Rcv,bFirstActive,bNandPowerup,READY_FOR_DATA,bRomCard, bInReadLba;
extern unsigned char data yBlockLen1,yBlockLen0;
extern unsigned char idata rcv_data_state;
extern unsigned char idata sd_dma_in_cnt;
extern unsigned char idata write_hs_data_to_flash_state;
extern unsigned char idata write_virtual_sd_buf_data_to_nf_state;
extern unsigned char idata u8_extern_dma_in_task;
extern unsigned short idata virtual_buf_w_to_nf_thread_tick;
extern unsigned char idata bank_code_attr;	

extern u8 idata last_SSTA_P1;

extern u8 code AUTO_CMD_TAB_ADDR[],AUTO_CMD_JMP_ADDR, CMP_CMD_TAB_ADDR[];

extern unsigned char code TAB_R3_ACK,CSD,CSD_50M_CRC7,CSD_25M_CRC7, SD_STATE;
extern unsigned char code _FLASH_CARD_TYPE, _FLASH_SYSCLKRE;
extern unsigned char code W_BUF_ADDR_H,W_BUF_ADDR_L;
extern unsigned char code sd_virtual_data_buf_lba[][4];
extern unsigned char code sd_virtual_data_buf_cnt[];
extern unsigned char code BlockPageModeIndex_Infor, MulBlockPageModeTabDptr;

extern void uart_send_byte(u8 val);
extern void uart_sent_byte(void);
extern void power_down(void);
extern void config_hs_cache_buf_dma_addr(unsigned char buf_ptr);
extern void clr_sd_read_data_flag(void);
extern void Sel_Buffer_Addr(void);
extern void read_sdbuf_block(void);
extern void erase_virtual_buf_map_blk(void);
extern void sd_pre_write_config(void);
extern void uart_array_init(void);
extern void initial_sd_buf_in_out_ptr(void);

void system_initial(void);
void ax215_system_intial(void);
void initial_iram(void);
void sd_spi_init(void);
void ext_int_init(void);
unsigned char cal_crc7 (unsigned char xdata *datas);
void uart_send_byte(u8 val);
void uart_sent_byte(void);
void timer_initial(void);
void initial_card_type(void);
void config_first_rcv_buf(void);
void cmd_entrance_tab_init(void);
void ClearDataArea(void);
void timer3_init(void);

extern void set_p1(u8 dat);
extern void clr_p1(u8 dat);
extern void xrl_p1(u8 dat);

static void config_multiple_pages_mode_table(void);


unsigned short idata u16RCA;
unsigned char idata u8_pwr_active_cnt;



#endif