#ifndef __SD_ACCELERATE_H__
#define __SD_ACCELERATE_H__

void sd_pre_read_config(u8 buf_start_index);
void sd_pre_write_config(void);
void enable_write_acce_hold_in_next_pkt(void);
void release_write_acce_hold_rcv_data(void);
void enable_read_acce_hold_in_next_pkt(void);
void release_read_acce_hold_tx_data(void);
u8 chk_read_acce_holding(void);

extern void Sel_Buffer_Addr(void);

#endif