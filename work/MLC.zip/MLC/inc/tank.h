//----- Panda Head Include File -----//   
//                                   //
// Description: Define SFR & EXINST
// Version:     1.0.0
// Author:      
// Date:        12-23-2012
// 
//-----------------------------------//

//======================================//
//----- Special Function Registers -----//
//======================================//
#ifndef TANK_HEAD
#define TANK_HEAD
//.................... 7'h0x ...........................
//public
sfr     DPCON             = 0x80;
sfr     SP                = 0x81;
sfr     DP0L              = 0x82;
sfr     DP0H              = 0x83;
sfr16   DPTR0             = 0x82; 
sfr     DP1L              = 0x84;
sfr     DP1H              = 0x85;
sfr16   DPTR1             = 0x84; 
sfr     IPH0              = 0x86;
sfr     IPH1              = 0x87;
sfr     PAGEMAP           = 0x88;
sfr     IP                = 0x89;
sfr     IP1               = 0x8a;
sfr     R8                = 0x8b;
sfr     ER00              = 0x8c;
sfr     ER01              = 0x8d;
sfr     ER02              = 0x8e;
sfr     ER03              = 0x8f;

//.................... 7'h1x ...........................
sfr     ER10              = 0x90;
sfr     ER11              = 0x91;
sfr     ER12              = 0x92;
sfr     ER13              = 0x93;
sfr     ER20              = 0x94;
sfr     ER21              = 0x95;
sfr     ER22              = 0x96;
sfr     ER23              = 0x97;
sfr     ER30              = 0x98;
sfr     ER31              = 0x99;
sfr     ER32              = 0x9a;
sfr     ER33              = 0x9b;
sfr     ER40              = 0x9c;
sfr     ER41              = 0x9d;
sfr     ER42              = 0x9e;
sfr     ER43              = 0x9f;

//.................... 7'h2x ...........................
//public
sfr     PCON              = 0xa0;
sfr     IE2		  = 0xa1;
sfr     IE1               = 0xa2;
/////////////////////////////////////////////////////////////////////////////////////////////
//                  page0
/////////////////////////////////////////////////////////////////////////////////////////////
sfr     PCON0_P0          = 0xa3;
sfr     PCON1_P0          = 0xa4; 
sfr     PCON2_P0          = 0xa5;
sfr     WKFLAG_P0         = 0xa7;
sfr     IE                = 0xa8;
sfr     CLKCON0_P0        = 0xa9;
sfr     CLKCON1_P0        = 0xaa;
sfr     CLKCON2_P0        = 0xab;
sfr     CLKCON3_P0        = 0xac;
sfr     PORTCON_P0        = 0xaf;

sfr     P0DIR_P0          = 0xb0;
sfr     P1DIR_P0          = 0xb1;
sfr     P3DIR_P0          = 0xb3;
sfr     P4DIR_P0          = 0xb4;
sfr     P0_P0             = 0xb6;
sfr     P1_P0             = 0xb7;
sfr     P3_P0             = 0xb9;
sfr     P4_P0             = 0xba;
sfr     P0PLP_P0          = 0xbc;
sfr     P1PLP_P0          = 0xbd;
sfr     P3PLP_P0          = 0xbf;

sfr     P4PLP_P0          = 0xc0; 
sfr     P4PLP1_P0         = 0xc6; 
sfr     P0PD_P0           = 0xc8; 
sfr     P1PD_P0           = 0xc9; 
sfr     P3PD_P0           = 0xcb; 
sfr     P4PD_P0           = 0xcc; 
sfr     P0HD_P0           = 0xce;
sfr     P1HD_P0           = 0xcf;
                                      
//.................... 7'h5x ...........................
//public
sfr     PSW               = 0xd0;
sfr     P3HD_P0           = 0xd2;
sfr     P4HD_P0           = 0xd3;
sfr     P1HDH_P0          = 0xd8;
sfr     P3HDH_P0          = 0xde;

                                      
//.................... 7'h6x ..........................
//public
sfr     ACC               = 0xe0;
sfr     MBISTCON0_P0      = 0xe1;
sfr     MBISTCON1_P0      = 0xe2;
sfr     MBISTDBG0_P0      = 0xe3;
sfr     MBISTDBG1_P0      = 0xe4;
sfr     MBISTDBG2_P0      = 0xe5;
sfr     CRCREG0_P0        = 0xe6;
sfr     CRCREG1_P0        = 0xe7;
sfr     CRCREG2_P0        = 0xe8;
sfr     CRCREG3_P0        = 0xe9;

//.................... 7'h7x ...........................
//public
sfr     B                 = 0xf0;
sfr     CHIPIDL_P0        = 0xf1;
sfr     CHIPIDH_P0        = 0xf2;
sfr     CHIPDCN_P0        = 0xf3;
sfr     DMACON_P0         = 0xf8;
sfr     DMAWADRL_P0       = 0xf9;
sfr     DMAWADRH_P0       = 0xfa;
sfr     DMARADRL_P0       = 0xfb;
sfr     DMARADRH_P0       = 0xfc;
sfr     DMACNTL_P0        = 0xfd;
sfr     DMACNTH_P0        = 0xfe;
//public
sfr     SPH               = 0xff;

/////////////////////////////////////////////////////////////////////////////////////////////
//                  page1
/////////////////////////////////////////////////////////////////////////////////////////////
sfr     SARG0_P1          = 0xa3;
sfr     SARG1_P1          = 0xa4;
sfr     SARG2_P1          = 0xa5;
sfr     SARG3_P1          = 0xa6;
sfr     SARG4_P1          = 0xa7;
//7'h28 public
sfr     SARG5_P1          = 0xa9;
sfr     SARG6_P1          = 0xaa;
sfr     SARG7_P1          = 0xab;
sfr     SCCON_P1          = 0xac;
sfr     SRCON_P1          = 0xad;
sfr     SDICON_P1         = 0xae;
sfr     SDOCON_P1         = 0xaf;

sfr     SFLAG_P1          = 0xb0;
sfr     SHCON_P1          = 0xb1;
sfr     SDRPSDLY_P1       = 0xb2;
sfr     SDOTK_P1          = 0xb3;
sfr     SDODLY_P1         = 0xb4;
sfr     SSTA_P1           = 0xb5;
sfr     SDRONE_P1         = 0xb6;
sfr     SDSPICNT_P1       = 0xb7;
sfr     SPND_P1           = 0xb8;
sfr     SDDL1_P1          = 0xb9;
sfr     SDLASTCMD_P1      = 0xba;
sfr     SRDL0_P1          = 0xbb;
sfr     SRDL1_P1          = 0xbc;
sfr     SDDL0_P1          = 0xbd;
sfr     SINDEX_P1         = 0xbe;
sfr     SRXADR0_P1        = 0xbf;

sfr     ARGSTA_P1         = 0xc0;
sfr     SRXADR1_P1        = 0xc1;
sfr     SDXADR0_P1        = 0xc2;
sfr     SDXADR1_P1        = 0xc3;
sfr     SRCA0_P1          = 0xc4;
sfr     SRCA1_P1          = 0xc5;
sfr     BCRADR0_P1        = 0xc6;
sfr     BCRADR1_P1        = 0xc7;
sfr     BCCON_P1          = 0xc8;
sfr     BCWADR0_P1        = 0xc9;
sfr     BCWADR1_P1        = 0xca;
sfr     BCBCNT0_P1        = 0xcb;
sfr     BCBCNT1_P1        = 0xcc;
sfr     BCRCADR0_P1       = 0xcd;
sfr     BCRCADR1_P1       = 0xce;
sfr     BCKEY0_P1         = 0xcf;

//7'h50 public
sfr     BCKEY1_P1         = 0xd1;
sfr     BCKEY2_P1         = 0xd2;
sfr     BCKEY3_P1         = 0xd3;
sfr     BCKEY4_P1         = 0xd4;
sfr     BCKEY5_P1         = 0xd5;
sfr     BCKEY6_P1         = 0xd6;
sfr     TABA0_P1          = 0xd7;
//7'hd8
sfr     TABA1_P1          = 0xd9;
sfr     WCMDA0_P1         = 0xda;
sfr     WCMDA1_P1         = 0xdb;
sfr     CINDEX_P1         = 0xdc;
sfr     BCCON1_P1         = 0xdd;

//7'h60 public
sfr     WCFGA0_P1         = 0xe1;         
sfr     WCFGA1_P1         = 0xe2;         
sfr     RCFGA0_P1         = 0xe3;         
sfr     RCFGA1_P1         = 0xe4;         
sfr     WBLKCNT_P1        = 0xe5;
sfr     RBLKCNT_P1        = 0xe6;
sfr     WBLKLEN_P1        = 0xe7;
sfr     ACCON0_P1         = 0xe8;
sfr     RBLKLEN_P1        = 0xe9;
sfr     LBA0_P1           = 0xea;
sfr     LBA1_P1           = 0xeb;
sfr     LBA2_P1           = 0xec;
sfr     LBA3_P1           = 0xed;
sfr     DIVR0_P1          = 0xee;
sfr     DIVR1_P1          = 0xef;

//6'h70 public
sfr     LDAT0_P1          = 0xf1;
sfr     LDAT1_P1          = 0xf2;
sfr     LDAT2_P1          = 0xf3;
sfr     LDAT3_P1          = 0xf4;
sfr     RDAT0_P1          = 0xf5;
sfr     RDAT1_P1          = 0xf6;
sfr     RDAT2_P1          = 0xf7;
sfr     ACCON1_P1         = 0xf8;
sfr     RDAT3_P1          = 0xf9;


//6'h7f public
                                      
/////////////////////////////////////////////////////////////////////////////////////////////
//                  page2
/////////////////////////////////////////////////////////////////////////////////////////////
sfr     NCEE_P2           = 0xa3;
sfr     NMCON0_P2         = 0xa4;
sfr     NMCON1_P2         = 0xa5;
sfr     NTCON0_P2         = 0xa6;
sfr     NTCON2_P2         = 0xa7; 
//7'h28 public
sfr     NPCON_P2          = 0xa9;   
sfr     NPGSZ0_P2         = 0xaa;
sfr     NPGSZ1_P2         = 0xab;
sfr16   NPGSZ_P2         = 0xaa;
sfr     NXADR0L_P2        = 0xac;
sfr     NXADR0H_P2        = 0xad;
sfr16   NXADR0_P2        = 0xac;
sfr     NXADR1L_P2        = 0xae;
sfr     NXADR1H_P2        = 0xaf;
sfr16   NXADR1_P2        = 0xae;
sfr     NTCON1_P2         = 0xb0;
sfr     NXCNT0L_P2        = 0xb1;
sfr     NXCNT0H_P2        = 0xb2;
sfr16   NXCNT0_P2        = 0xb1;

sfr     NACMD1_P2         = 0xb3;
sfr     NFIFO0_P2         = 0xb4;
sfr     NFIFO1_P2         = 0xb5;
sfr     NFIFO2_P2         = 0xb6;
sfr     NFIFO3_P2         = 0xb7;
sfr     NFIFO4_P2         = 0xb4;
sfr     NFIFO5_P2         = 0xb5;
sfr     NFIFO6_P2         = 0xb6;

sfr     BCON1_P2          = 0xb8;
sfr     BPSZL_P2          = 0xb9;
sfr     BPSZH_P2          = 0xba;
sfr16   BPSZ_P2          = 0xb9;
sfr     BTSEL_P2          = 0xbb;
sfr     BXADR0L_P2        = 0xbc;
sfr     BXADR0H_P2        = 0xbd;
sfr16   BXADR0_P2        = 0xbc;
sfr     BXADR1L_P2        = 0xbe;
sfr     BXADR1H_P2        = 0xbf;
sfr16   BXADR1_P2        = 0xbe;
sfr     BCON0_P2          = 0xc0;

sfr     CMPCON_P2         = 0xc1;
sfr     CMPADR0_P2        = 0xc2;
sfr     CMPADR1_P2        = 0xc3;
sfr16   CMPADR_P2        = 0xc2;
sfr     CPERCNT0_P2       = 0xc4;
sfr     CPERCNT1_P2       = 0xc5;
sfr16   CPERCNT_P2       = 0xc4;
sfr     HTABLEL_P2        = 0xc6;
sfr     HFRAME_P2         = 0xc7;
sfr     HCON_P2           = 0xc8;
sfr     HRAN320_P2        = 0xc9;
sfr     HRAN321_P2        = 0xca;
sfr     HRAN322_P2        = 0xcb;
sfr     HRAN323_P2        = 0xcc;
sfr     HDMAMT0_P2        = 0xcd;
sfr     HDMAMT1_P2        = 0xce;
sfr     HPAGE0_P2         = 0xcf;
//7'h50 public
sfr     HPAGE1_P2         = 0xd1;
sfr     HSEEDINIT0_P2     = 0xd2;
sfr     HSEEDINIT1_P2     = 0xd3;
sfr     HSEEDINIT2_P2     = 0xd4;
sfr     HSEEDINIT3_P2     = 0xd5;
sfr     BCMDAT_P2         = 0xd6;
sfr     BCMCON_P2         = 0xd7;
sfr     BCMADRL_P2        = 0xd8;
sfr     BCMADRH_P2        = 0xd9;
sfr16   BCMADR_P2        = 0xd8;

sfr     NFFENCNT_P2       = 0xdb;
sfr     NFFLEN_P2         = 0xdc;
sfr     NFFNFOUTCNT_P2    = 0xdd;
sfr     NFFBCHOUTCNT_P2   = 0xde;
//7'h60 public
sfr     NXADR2L_P2        = 0xe1;
sfr     NXADR2H_P2        = 0xe2;
sfr16   NXADR2_P2        = 0xe1;
sfr     NXCNT1L_P2        = 0xe3;
sfr     NXCNT1H_P2        = 0xe4;
sfr16   NXCNT1_P2        = 0xe3;
sfr     NDCTCNT0_P2       = 0xe5;
sfr     NDCTCNT1_P2       = 0xe6;
sfr     NDCTCNT2_P2       = 0xe7;
sfr     NDCTCNT3_P2       = 0xe8;

sfr     NFFCON_P2         = 0xea;
sfr     NFFAMT_P2         = 0xeb;
sfr     NFFSTCNT_P2       = 0xec;
sfr     NFFINBADR0_P2     = 0xed;
sfr     NFFINBADR1_P2     = 0xee;
sfr16   NFFINBADR_P2     = 0xed;
sfr     BECNT_P2          = 0xef;

//7'h70 public
sfr     NFFOUTBADR0_P2    = 0xf1;
sfr     NFFOUTBADR1_P2    = 0xf2;
sfr16   NFFOUTBADR_P2    = 0xf1;

sfr     BXADR2L_P2        = 0xf3;
sfr     BXADR2H_P2        = 0xf4;
sfr16   BXADR2_P2        = 0xf3;
sfr     BECADRL_P2        = 0xf5;
sfr     BECADRH_P2        = 0xf6;
sfr16   BECADR_P2        = 0xf5;
sfr     BPT0SZL_P2        = 0xf7;
sfr     BPT0SZH_P2        = 0xf8;
sfr16   BPT0SZ_P2        = 0xf7;
sfr     BPT1SZL_P2        = 0xf9;
sfr     BPT1SZH_P2        = 0xfa;
sfr16   BPT1SZ_P2        = 0xf9;
sfr     BPCNT_P2          = 0xfb;

sfr     S2T0_P2           = 0xfe;
//6'h7f public
/////////////////////////////////////////////////////////////////////////////////////////////
//                  page3
/////////////////////////////////////////////////////////////////////////////////////////////
sfr     BSCON_P3          = 0xa3;
sfr     BSADRL_P3         = 0xa4;
sfr     BSADRH_P3         = 0xa5;
sfr16   BSADR_P3         = 0xa4;
sfr     BSCNTL_P3         = 0xa6;
sfr     BSCNTH_P3         = 0xa7;
sfr16   BSCNT_P3          = 0xa6;
//7'h28 public
sfr     BSBTCNTL_P3       = 0xa9;
sfr     BSBTCNTH_P3       = 0xaa;
sfr16   BSBTCNT_P3       = 0xa9;
sfr     BSBTNUML_P3       = 0xab;
sfr     BSBTNUMH_P3       = 0xac;
sfr16   BSBTNUM_P3       = 0xab;

sfr     T3CNTL_P3         = 0xae;
sfr     T3CNTH_P3         = 0xaf;
sfr16   T3CNT_P3         = 0xae;
sfr     T3CON_P3          = 0xb0;
sfr     T3PRL_P3          = 0xb1;
sfr     T3PRH_P3          = 0xb2;
sfr16   T3PR_P3          = 0xb1;

sfr     BSBTIDXL_P3       = 0xb3;
sfr     BSBTIDXH_P3       = 0xb4;
sfr16   BSBTIDX_P3       = 0xb3;
sfr     BSBTOFSL_P3       = 0xb5;
sfr     BSBTOFSH_P3       = 0xb6;
sfr16   BSBTOFS_P3       = 0xb5;
sfr     BSCON1_P3         = 0xb7;
sfr     SSCON1_P3         = 0xb8;

sfr     SSCON_P3          = 0xc0;
sfr     SSMAXVALUEH1_P3   = 0xc1;
sfr     SSMAXVALUEH0_P3   = 0xc2;
sfr     SSMAXVALUEL1_P3   = 0xc3;
sfr     SSMAXVALUEL0_P3   = 0xc4;
sfr     SSMINVALUEH1_P3   = 0xc5; 
sfr     SSMINVALUEH0_P3   = 0xc6; 
sfr     SSMINVALUEL1_P3   = 0xc7; 
sfr     SSMINVALUEL0_P3   = 0xc8;
sfr     SSORIADRL_P3      = 0xc9; 
sfr     SSORIADRH_P3      = 0xca;
sfr16   SSORIADR_P3      = 0xc9; 

sfr     SSBSDADRL_P3      = 0xcb;  
sfr     SSBSDADRH_P3      = 0xcc;
sfr16   SSBSDADR_P3      = 0xcb;  

sfr     SSBSAADRL_P3      = 0xcd;
sfr     SSBSAADRH_P3      = 0xce;
sfr16   SSBSAADR_P3      = 0xcd;

  
//7'h50 public
sfr     SSDATALENL_P3     = 0xd1;
sfr     SSDATALENH_P3     = 0xd2;
sfr16   SSDATALEN_P3     = 0xd1;

sfr     RDSRAMADDRL_P3    = 0xd3;
sfr     RDSRAMADDRH_P3    = 0xd4;
sfr16   RDSRAMADDR_P3    = 0xd3;
sfr     WRSRAMADDRL_P3    = 0xd5;
sfr     WRSRAMADDRH_P3    = 0xd6;
sfr16   WRSRAMADDR_P3    = 0xd5;
sfr     BITEDCON_P3       = 0xd7;
sfr     TMRCON_P3         = 0xd8;
sfr     TMRCNT_P3         = 0xd9;
sfr     TMRPR_P3          = 0xda;
sfr     TMRSPBUF_P3       = 0xdb;

//7'h60 public
sfr     SSMAXNUML_P3      = 0xe2;
sfr     SSMAXNUMH_P3      = 0xe3;  
sfr16   SSMAXNUM_P3      = 0xe2;
sfr     SSDATANUML_P3     = 0xe4; 
sfr     SSDATANUMH_P3     = 0xe5; 
sfr16   SSDATANUM_P3     = 0xe4; 


//6'h70 public
sfr     S3T0_P3           = 0xfe;
//6'h7f public
/////////////////////////////////////////////////////////////////////////////////////////////
//                  page4
/////////////////////////////////////////////////////////////////////////////////////////////
sfr     HORDER0_P4        = 0xa3;
sfr     HORDER1_P4        = 0xa4;
sfr     HORDER2_P4        = 0xa5;
sfr     HORDER3_P4        = 0xa6;
sfr     HORDER4_P4        = 0xa7;
//7'h28 public
sfr     HORDER5_P4        = 0xa9;
sfr     HORDER6_P4        = 0xaa;
sfr     HORDER7_P4        = 0xab;
sfr     HPOLY00_P4        = 0xac;
sfr     HPOLY01_P4        = 0xad;
sfr     HPOLY02_P4        = 0xae;
sfr     HPOLY03_P4        = 0xaf;

sfr     HPOLY10_P4        = 0xb0;
sfr     HPOLY11_P4        = 0xb1;
sfr     HPOLY12_P4        = 0xb2;
sfr     HPOLY13_P4        = 0xb3;
sfr     HPOLY20_P4        = 0xb4;
sfr     HPOLY21_P4        = 0xb5;
sfr     HPOLY22_P4        = 0xb6;
sfr     HPOLY23_P4        = 0xb7; 
sfr     HPOLY30_P4        = 0xb8;
sfr     HPOLY31_P4        = 0xb9;
sfr     HPOLY32_P4        = 0xba;
sfr     HPOLY33_P4        = 0xbb;
sfr     HPOLY40_P4        = 0xbc;
sfr     HPOLY41_P4        = 0xbd;
sfr     HPOLY42_P4        = 0xbe;
sfr     HPOLY43_P4        = 0xbf;

sfr     HPOLY50_P4        = 0xc0;
sfr     HPOLY51_P4        = 0xc1;
sfr     HPOLY52_P4        = 0xc2;
sfr     HPOLY53_P4        = 0xc3;
sfr     HPOLY60_P4        = 0xc4;
sfr     HPOLY61_P4        = 0xc5;
sfr     HPOLY62_P4        = 0xc6;
sfr     HPOLY63_P4        = 0xc7;
sfr     HPOLY70_P4        = 0xc8;
sfr     HPOLY71_P4        = 0xc9;
sfr     HPOLY72_P4        = 0xca;
sfr     HPOLY73_P4        = 0xcb;
sfr     HBADR00_P4        = 0xcc;
sfr     HBADR01_P4        = 0xcd;
sfr     HBADR10_P4        = 0xce;
sfr     HBADR11_P4        = 0xcf;
//7'h50 public
sfr     HBADR20_P4        = 0xd1;
sfr     HBADR21_P4        = 0xd2;
sfr     HBADR30_P4        = 0xd3;
sfr     HBADR31_P4        = 0xd4;
sfr     HBADR40_P4        = 0xd5;
sfr     HBADR41_P4        = 0xd6;
sfr     HBADR50_P4        = 0xd7;
sfr     HBADR51_P4        = 0xd8;
sfr     HBADR60_P4        = 0xd9;
sfr     HBADR61_P4        = 0xda;
sfr     HBADR70_P4        = 0xdb;
sfr     HBADR71_P4        = 0xdc;
sfr     HSEED00_P4        = 0xdd;  
sfr     HSEED01_P4        = 0xde;
sfr     HSEED02_P4        = 0xdf;
//7'h60 public
sfr     HSEED03_P4        = 0xe1;
sfr     HSEED10_P4        = 0xe2;
sfr     HSEED11_P4        = 0xe3;
sfr     HSEED12_P4        = 0xe4;
sfr     HSEED13_P4        = 0xe5;
sfr     HSEED20_P4        = 0xe6;
sfr     HSEED21_P4        = 0xe7;
sfr     HSEED22_P4        = 0xe8;
sfr     HSEED23_P4        = 0xe9;
sfr     HSEED30_P4        = 0xea;
sfr     HSEED31_P4        = 0xeb;
sfr     HSEED32_P4        = 0xec;
sfr     HSEED33_P4        = 0xed;
sfr     HSEED40_P4        = 0xee;
sfr     HSEED41_P4        = 0xef;
//6'h70 public
sfr     HSEED42_P4        = 0xf1;
sfr     HSEED43_P4        = 0xf2;
sfr     HSEED50_P4        = 0xf3;
sfr     HSEED51_P4        = 0xf4;
sfr     HSEED52_P4        = 0xf5;
sfr     HSEED53_P4        = 0xf6;
sfr     HSEED60_P4        = 0xf7;
sfr     HSEED61_P4        = 0xf8;
sfr     HSEED62_P4        = 0xf9;
sfr     HSEED63_P4        = 0xfa;
sfr     HSEED70_P4        = 0xfb;
sfr     HSEED71_P4        = 0xfc;
sfr     HSEED72_P4        = 0xfd;
sfr     HSEED73_P4        = 0xfe;
//6'h7f public
/////////////////////////////////////////////////////////////////////////////////////////////
//                  page5
/////////////////////////////////////////////////////////////////////////////////////////////

//--------------------------------------------- Control BIT -----//
//----- DPCON -----//
sbit    DPID1   = DPCON^7; 
sbit    DPID0   = DPCON^6; 
sbit    DPAST   = DPCON^5;
sbit    DPAID   = DPCON^4; 
sbit    CHEND   = DPCON^3; 
sbit    ASHF    = DPCON^2; 
sbit    LSHF    = DPCON^1; 
sbit    DPSEL   = DPCON^0; 

//----- NTCON1 -----//
sbit    NTSKD   = NTCON1_P2^7; 
sbit    NWBDLY2 = NTCON1_P2^6; 
sbit    NWBDLY1 = NTCON1_P2^5; 
sbit    NWBDLY0 = NTCON1_P2^4; 
sbit    NPTDLY1 = NTCON1_P2^3; 
sbit    NPTDLY0 = NTCON1_P2^2; 
sbit    NSTP1   = NTCON1_P2^1; 
sbit    NSTP0   = NTCON1_P2^0; 

//----- PCTL -----//
sbit    POF     = PCON^7; 
sbit    SDCKE   = PCON^6; 
sbit    RCKE    = PCON^5;
sbit    NCKE    = PCON^4; 
sbit    TCKE    = PCON^3; 
sbit    INTBK   = PCON^2; 
sbit    PD      = PCON^1; 
sbit    IDLE    = PCON^0;

//----- IE same as AX215,a,b,c-----//
//sbit    EA      = IE^7; 
//sbit    TIE     = IE^3; 
//sbit    UIE     = IE^2; 
//sbit    NIE     = IE^1; 
//sbit    RIE     = IE^0; 
//-------same as ax215E IE----//
sbit    EA      = IE^7; 
sbit    BSIE    = IE^6;  
sbit    BIE     = IE^5;  
sbit    NFIE    = IE^4;  
sbit    SDOIE   = IE^3;  
sbit    SDIIE   = IE^2;
sbit    SDRIE   = IE^1;
sbit    SDCIE   = IE^0; 

//----- PSW -----//
sbit    CY      = PSW^7; 
sbit    AC      = PSW^6; 
sbit    EC      = PSW^5; 
sbit    RS1     = PSW^4; 
sbit    RS0     = PSW^3; 
sbit    OV      = PSW^2; 
sbit    EZ      = PSW^1; 
sbit    P       = PSW^0; 

//----- SFLAG Control BIT -----//
sbit    SBYST     = SFLAG_P1^7;     //Busy CMD receive                    1:receive
sbit    SDIST     = SFLAG_P1^6;     //SD DMA Data avail                1:invail
sbit    SSTAINV   = SFLAG_P1^5;    //SSTA Invaild                        1:invail
sbit    SCEND     = SFLAG_P1^4;    //CMD END                            1:end
sbit    SDCRC     = SFLAG_P1^3;    //SD DATA  CRC STATES                1:error
sbit    SRPSTS    = SFLAG_P1^2;  // 1: -- NO RESPONSE  --CMD CRC error Or State Machine invalid 
sbit    SRCAST    = SFLAG_P1^1;  //RCA Match                            1:match
sbit    SCCRC     = SFLAG_P1^0;    //CMD CRC correct                    1:error

//----- SPND Control BIT -----//
sbit    SPIMODE    = SPND_P1^7;
sbit    SAJPND     = SPND_P1^6;
sbit    SDOPND     = SPND_P1^3;
sbit    SDIPND     = SPND_P1^2;
sbit    SRPND      = SPND_P1^1;
sbit    SCPND      = SPND_P1^0;

//----- arg cal control bit -----//
sbit 	DIVEN	   = ARGSTA_P1^7;		//enable div 									//1:enable(default)	
sbit 	CFGEN	   = ARGSTA_P1^6;		//enable hardware execute SSTA_P1 |=(1<<4)		//1:enable(default)
sbit 	CDONE	   = ARGSTA_P1^5;		//div pending									//1:done
sbit 	ATCFG	   = ARGSTA_P1^4;      	//hardware execute SSTA_P1 |=(1<<4) pending	//1:done
sbit 	CMP3	   = ARGSTA_P1^3;		//arg is multiple of register data		//0:yes; 		1:no
sbit 	CMP2	   = ARGSTA_P1^2;		//arg is multiple of 512.				//1:yes; 		0:no
sbit 	CMP1_1	   = ARGSTA_P1^1;		//arg compare with 512. // (CMP1_1,CMP1_0): 00 (arg ==512); 10(arg < 512); 01(arg>512)
sbit 	CMP1_0	   = ARGSTA_P1^0;

//-------- timer0 control bit --------//
sbit    TOF     = TMRCON_P3^7; 
sbit    TPSR2   = TMRCON_P3^6; 
sbit    TPSR1   = TMRCON_P3^5; 
sbit    TPSR0   = TMRCON_P3^4; 
sbit    SPKS    = TMRCON_P3^3; 
sbit    SPTD    = TMRCON_P3^3;
sbit    TMREXEN = TMRCON_P3^2;
sbit    MODE1   = TMRCON_P3^1;
sbit    MODE0   = TMRCON_P3^0;

//======================================//
//tank                                  //
//----- NAND FLASH FLOW DEFINE     -----//
//======================================//
                                      
/////////////////////////////////////////////////////////////////////////////////////////////
//                  page2
/////////////////////////////////////////////////////////////////////////////////////////////
#define     NCEE_P2_NFF            0xa3
#define     NMCON0_P2_NFF          0xa4
#define     NMCON1_P2_NFF          0xa5
#define     NTCON0_P2_NFF          0xa6
#define     NXADR1H_P2_NFF         0xa7
#define     NTCON2_P2_NFF          0xa9
#define     NPCON_P2_NFF           0xaa
#define     NPGSZ0_P2_NFF          0xab
#define     NPGSZ1_P2_NFF          0xac
#define     NXADR0L_P2_NFF         0xad
#define     NXADR0H_P2_NFF         0xae
#define     NXADR1L_P2_NFF         0xaf
#define     NTCON1_P2_NFF          0xb0
#define     NXCNT0L_P2_NFF         0xb1
#define     NXCNT0H_P2_NFF         0xb2
#define     NACMD1_P2_NFF          0xb3
#define     NFIFO0_P2_NFF          0xb4
#define     NFIFO1_P2_NFF          0xb5
#define     NFIFO2_P2_NFF          0xb6
#define     NFIFO3_P2_NFF          0xb7
#define     NFIFO4_P2_NFF          0xb4
#define     NFIFO5_P2_NFF          0xb5
#define     NFIFO6_P2_NFF          0xb6
#define     BPSZH_P2_NFF           0xb8
#define     BPSZL_P2_NFF           0xb9
#define     BCON1_P2_NFF           0xba
#define     BTSEL_P2_NFF           0xbb
#define     BXADR0H_P2_NFF         0xbc
#define     BXADR0L_P2_NFF         0xbd
#define     BXADR1H_P2_NFF         0xbe
#define     BXADR1L_P2_NFF         0xbf
#define     BCON0_P2_NFF           0xc0
#define     CMPCON_P2_NFF          0xc1
#define     CMPADR0_P2_NFF         0xc2
#define     CMPADR1_P2_NFF         0xc3
#define     CPERCNT0_P2_NFF        0xc4
#define     CPERCNT1_P2_NFF        0xc5
#define     HTABLEL_P2_NFF         0xc6
#define     HFRAME_P2_NFF          0xc7
#define     HCON_P2_NFF            0xc8
#define     HRAN320_P2_NFF         0xc9
#define     HRAN321_P2_NFF         0xca
#define     HRAN322_P2_NFF         0xcb
#define     HRAN323_P2_NFF         0xcc
#define     HDMAMT0_P2_NFF         0xcd
#define     HDMAMT1_P2_NFF         0xce
#define     HPAGE0_P2_NFF          0xcf
#define     HPAGE1_P2_NFF          0xd1
#define     HSEEDINIT0_P2_NFF      0xd2
#define     HSEEDINIT1_P2_NFF      0xd3
#define     HSEEDINIT2_P2_NFF      0xd4
#define     HSEEDINIT3_P2_NFF      0xd5
#define     BCMDAT_P2_NFF          0xd6
#define     BCMCON_P2_NFF          0xd7
#define     BCMADRL_P2_NFF         0xd8
#define     BCMADRH_P2_NFF         0xd9
#define     NXADR2L_P2_NFF         0xe1
#define     NXADR2H_P2_NFF         0xe2
#define     NXCNT1L_P2_NFF         0xe3
#define     NXCNT1H_P2_NFF         0xe4
#define     NDCTCNT0_P2_NFF        0xe5
#define     NDCTCNT1_P2_NFF        0xe6
#define     NDCTCNT2_P2_NFF        0xe7
#define     NDCTCNT3_P2_NFF        0xe8
#define     BXADR2H_P2_NFF         0xf2
#define     BXADR2L_P2_NFF         0xf3
#define     BECADRH_P2_NFF         0xf4
#define     BECADRL_P2_NFF         0xf5
#define     BPT0SZH_P2_NFF         0xf6
#define     BPT0SZL_P2_NFF         0xf7
#define     BPT1SZH_P2_NFF         0xf8
#define     BPT1SZL_P2_NFF         0xf9
#define     BECNT_P2_NFF           0xfa
#define     BPCNT_P2_NFF           0xfb


/////////////////////////////////////////////////////////////////////////////////////////////
//                  page4
/////////////////////////////////////////////////////////////////////////////////////////////
#define     HORDER0_P4_NFF         0x23
#define     HORDER1_P4_NFF         0x24
#define     HORDER2_P4_NFF         0x25
#define     HORDER3_P4_NFF         0x26
#define     HORDER4_P4_NFF         0x27
#define     HORDER5_P4_NFF         0x29
#define     HORDER6_P4_NFF         0x2a
#define     HORDER7_P4_NFF         0x2b
#define     HPOLY00_P4_NFF         0x2c
#define     HPOLY01_P4_NFF         0x2d
#define     HPOLY02_P4_NFF         0x2e
#define     HPOLY03_P4_NFF         0x2f
#define     HPOLY10_P4_NFF         0x30
#define     HPOLY11_P4_NFF         0x31
#define     HPOLY12_P4_NFF         0x32
#define     HPOLY13_P4_NFF         0x33
#define     HPOLY20_P4_NFF         0x34
#define     HPOLY21_P4_NFF         0x35
#define     HPOLY22_P4_NFF         0x36
#define     HPOLY23_P4_NFF         0x37
#define     HPOLY30_P4_NFF         0x38 
#define     HPOLY31_P4_NFF         0x39
#define     HPOLY32_P4_NFF         0x3a
#define     HPOLY33_P4_NFF         0x3b
#define     HPOLY40_P4_NFF         0x3c
#define     HPOLY41_P4_NFF         0x3d
#define     HPOLY42_P4_NFF         0x3e
#define     HPOLY43_P4_NFF         0x3f
#define     HPOLY50_P4_NFF         0x40
#define     HPOLY51_P4_NFF         0x41
#define     HPOLY52_P4_NFF         0x42
#define     HPOLY53_P4_NFF         0x43
#define     HPOLY60_P4_NFF         0x44
#define     HPOLY61_P4_NFF         0x45
#define     HPOLY62_P4_NFF         0x46
#define     HPOLY63_P4_NFF         0x47
#define     HPOLY70_P4_NFF         0x48
#define     HPOLY71_P4_NFF         0x49
#define     HPOLY72_P4_NFF         0x4a
#define     HPOLY73_P4_NFF         0x4b
#define     HBADR00_P4_NFF         0x4c
#define     HBADR01_P4_NFF         0x4d
#define     HBADR10_P4_NFF         0x4e
#define     HBADR11_P4_NFF         0x4f
#define     HBADR20_P4_NFF         0x51
#define     HBADR21_P4_NFF         0x52
#define     HBADR30_P4_NFF         0x53
#define     HBADR31_P4_NFF         0x54
#define     HBADR40_P4_NFF         0x55
#define     HBADR41_P4_NFF         0x56
#define     HBADR50_P4_NFF         0x57
#define     HBADR51_P4_NFF         0x58
#define     HBADR60_P4_NFF         0x59
#define     HBADR61_P4_NFF         0x5a
#define     HBADR70_P4_NFF         0x5b
#define     HBADR71_P4_NFF         0x5c
#define     HSEED00_P4_NFF         0x5d  
#define     HSEED01_P4_NFF         0x5e 
#define     HSEED02_P4_NFF         0x5f
#define     HSEED03_P4_NFF         0x61
#define     HSEED10_P4_NFF         0x62
#define     HSEED11_P4_NFF         0x63
#define     HSEED12_P4_NFF         0x64
#define     HSEED13_P4_NFF         0x65
#define     HSEED20_P4_NFF         0x66
#define     HSEED21_P4_NFF         0x67
#define     HSEED22_P4_NFF         0x68
#define     HSEED23_P4_NFF         0x69
#define     HSEED30_P4_NFF         0x6a
#define     HSEED31_P4_NFF         0x6b
#define     HSEED32_P4_NFF         0x6c
#define     HSEED33_P4_NFF         0x6d
#define     HSEED40_P4_NFF         0x6e
#define     HSEED41_P4_NFF         0x6f
#define     HSEED42_P4_NFF         0x71
#define     HSEED43_P4_NFF         0x72
#define     HSEED50_P4_NFF         0x73
#define     HSEED51_P4_NFF         0x74
#define     HSEED52_P4_NFF         0x75
#define     HSEED53_P4_NFF         0x76
#define     HSEED60_P4_NFF         0x77
#define     HSEED61_P4_NFF         0x78
#define     HSEED62_P4_NFF         0x79
#define     HSEED63_P4_NFF         0x7a
#define     HSEED70_P4_NFF         0x7b
#define     HSEED71_P4_NFF         0x7c
#define     HSEED72_P4_NFF         0x7d
#define     HSEED73_P4_NFF         0x7e
//#define EXINST 0

#ifdef EXINST
//----- Extended Instruction Macro -----//
//
// Instruction Opcode Format:
// 0xA5 code0 / 0xD4 code0
//
// Assemble Code Format:
// OPeration Destination Source0 Source1
//
//--------------------------------------//

// Macro Parameter Definination

// Parameter Type
#define Tsfr    0x01
#define Treg32  0x02
#define Tptr    0x03
#define Timm    0x04

// DPTRi
#define EDP0    Tptr, 0x00 
#define EDP1    Tptr, 0x01

// SFR R8 
#define ER8     Tsfr, 0x40

// SFR ACC
#define EACC    Tsfr, 0x41

// 32-bit Reg ERn
#define ER0 Treg32, 0x00
#define ER1 Treg32, 0x01
#define ER2 Treg32, 0x02
#define ER3 Treg32, 0x03
#define ER4 Treg32, 0x04

// Immediate Data
#define EI(x)   Timm, x 

//----- Macro Define -----//
//
// Assemble Code
// Operation Description
// OPcode
// 
//------------------------//

MOV32 macro Tx,Vx,Ty,Vy 
db 0xA5 
 
//--------------------------------------//
// MOV32 ERn, EDPi 
// ERn <- @DPTRi 
// 1110_nn0i
    if Tx=Treg32 and Ty=Tptr 
        db 0xe0 | (LOW Vx SHL 2) | Vy
//--------------------------------------//

//--------------------------------------//
// MOV32 EDPi, ERn
// @DPTRi <- ERn
// 1110_nn1i
    elseif Tx=Tptr and Ty=Treg32
        db 0xe2 | (LOW Vy SHL 2) | Vx
//--------------------------------------//

//--------------------------------------//
// MOV32 ER4, ERn
// ER4 <- ERn
// 1001_nn00
    elseif Tx=Treg32 and Vx=0x04 and Ty=Treg32
        db 0x90 | (LOW Vy SHL 2)
//--------------------------------------//

//--------------------------------------//
// MOV32 ERn, ER4
// ERn <- ER4
// 1001_nn10
    elseif Tx=Treg32 and Ty=Treg32 and Vy=0x04
        db 0x92 | (LOW Vx SHL 2)
//--------------------------------------//

//--------------------------------------//
// MOV32 ERn, ERm
// ERn <- ERm
// 1111_nnmm
    elseif Tx=Treg32 and Ty=Treg32
        db 0xf0 | (LOW Vx SHL 2) | Vy
//--------------------------------------//
    else 
        __ERROR__ "syntax error in MOV32"
    endif
endm

NOT32 macro Tx,Vx
db 0xA5

//--------------------------------------//
// NOT32 ERn
// ERn <- !ERn
// 0001_nn00
    if Tx=Treg32
    db 0x10 | (LOW Vx SHL 2) 
//--------------------------------------//
    else 
        __ERROR__ "syntax error in NOT32"
    endif
endm

INC32 macro Tx Vx
db 0xa5
// INC32 ERn
// ERn <- ERn + 1
// 0001_nn10
    if Tx=Treg32
        db 0x12 | (LOW Vx SHL 2)
    else
        __ERROR__ "syntax error in INC32"
    endif
endm

DEC32 macro Tx Vx
db 0xa5
// DEC32 ERn
// ERn <- ERn - 1
// 0001_nn11
    if Tx=Treg32
        db 0x13 | (LOW Vx SHL 2)
    else 
        __ERROR__ "syntax error in DEC32"
    endif
endm

RAN32 macro Tx,Vx,Ty,Vy
db 0xa5
//-------------------------------------//
// RAN32 EDPi,ERn
// @DPTRi <- ERn
// ERn <- RANDOM
// 0000_nn1i
  if Tx=Tptr and Ty=Treg32 
      db 0x02 | (LOW Vy SHL 2) | Vx

  else
     __ERROR__"syntax error in RAN32"
  endif
endm

ANL32 macro Tx,Vx,Ty,Vy
db 0xA5

//--------------------------------------//
// ANL32 ERn, EDPi
// ERn <- @DPTRi & ERn
// 0010_nn0i
    if Tx=Treg32 and Ty=Tptr
        db 0x20 | (LOW Vx SHL 2) | Vy
//--------------------------------------//

//--------------------------------------//
// ANL32 EDPi, ERn
// @DPTRi <- ERn & @DPTRi
// 0010_nn1i
    elseif Tx=Tptr and Ty=Treg32
        db 0x22 | (LOW Vy SHL 2) | Vx 
//--------------------------------------//

//--------------------------------------//
// ANL32 ERn, ERm
// ERn <- ERn & ERm
// 0011_nnmm
    elseif Tx=Treg32 and Ty=Treg32
        db 0x30 | (LOW Vx SHL 2) | Vy
//--------------------------------------//

    else
        __ERROR__"syntax error in ANL32"
    endif
endm

ORL32 macro Tx,Vx,Ty,Vy
db 0xA5

//--------------------------------------//
// ORL32 ERn EDPi
// ERn<- @DPTRi | ERn
// 0100_nn0i
    if Tx=Treg32 and Ty=Tptr
        db 0x40 | (LOW Vx SHL 2) | Vy
//--------------------------------------//

//--------------------------------------//
// ORL32 EDPi, ERn
// @DPTRi <- ERn | @DPTRi
// 0100_nn1i
    elseif Tx=Tptr and Ty=Treg32
        db 0x42 | (LOW Vy SHL 2) | Vx
//--------------------------------------//

//--------------------------------------//
// ORL32 ERn, ERm
// ERn <- ERn | ERm
// 0101_nnmm
    elseif Tx=Treg32 and Ty=Treg32
        db 0x50 | (LOW Vx SHL 2) | Vy     
//--------------------------------------//

    else
        __ERROR__"syntax error in ORL32"
    endif
endm

XRL32 macro Tx,Vx,Ty,Vy
db 0xA5

//--------------------------------------//
// XRL32 ERn, EDPi
// ERn <- @DPTRi ^ ERn
// 0110_nn0i
    if Tx=Treg32 and Ty=Tptr
        db 0x60 | (LOW Vx SHL 2) | Vy
//--------------------------------------//

//--------------------------------------//
// XRL32 EDPi, ERn
// @DPTRi <- ERn ^ @DPTRi
// 0110_nn1i
    elseif Tx=Tptr and Ty=Treg32
        db 0x62 | (LOW Vy SHL 2) | Vx
//--------------------------------------//

//--------------------------------------//
// XRL32 ERn, ERm
// ERn <- ERn ^ ERm
// 0111_nnmm
    elseif Tx=Treg32 and Ty=Treg32
        db 0x70 | (LOW Vx SHL 2) | Vy
//--------------------------------------//

    else
        __ERROR__"syntax error in XRL32"
    endif
endm

ADD32 macro Tx,Vx,Ty,Vy,Tz,Vz
db 0xD4

//--------------------------------------//
// ADD32 ERp, EDPi, ERn
// ERp <- @DPTRi + ERn
// 00pp_nn0i
    if Tx=Treg32 and Ty=Tptr and Tz=Treg32
        db 0x00 | (LOW Vx SHL 4) | (LOW Vz SHL 2) | Vy
//--------------------------------------//

//--------------------------------------//
// ADD32 EDPi, ERn, ERp
// @DPTRi <- ERn + ERp
// 00pp_nn1i
    elseif Tx=Tptr and Ty=Treg32 and Tz=Treg32
        db 0x02 | (LOW Vz SHL 4) | (LOW Vy SHL 2) | Vx
//--------------------------------------//

//--------------------------------------//
// ADD32 ERp,ERn,ERm
// ERp <- ERn + ERm
// 01pp_nnmm
    elseif Tx=Treg32 and Ty=Treg32 and Tz=Treg32
        db 0x40 | (LOW Vx SHL 4) | (LOW Vy SHL 2) | Vz
//--------------------------------------//

    else
        __ERROR__"syntax error in ADD32"
    endif
endm

SUB32 macro Tx,Vx,Ty,Vy,Tz,Vz
db 0xD4

//--------------------------------------//
// SUB32 ERp, EDPi, ERn
// ERp <- @DPTRi - ERn
// 10pp_nn0i
    if Tx=Treg32 and Ty=Tptr and Tz=Treg32
        db 0x80 | (LOW Vx SHL 4) | (LOW Vz SHL 2) | Vy
//--------------------------------------//

//--------------------------------------//
// SUB32 EDPi, ERn, ERp
// @DPTRi <- ERn - ERp
// 10pp_nn1i
    elseif Tx=Tptr and Ty=Treg32 and Tz=Treg32
        db 0x82 | (LOW Vz SHL 4) | (LOW Vy SHL 2) | Vx
//--------------------------------------//

//--------------------------------------//
// SUB32 ERp, ERn, ERm
// ERp <- ERn - ERm
// 11pp_nnmm
    elseif Tx=Treg32 and Ty=Treg32 and Tz=Treg32
        db 0xc0 | (LOW Vx SHL 4) | (LOW Vy SHL 2) | Vz
//--------------------------------------//

    else
        __ERROR__"syntax error in SUB32"
    endif
endm

ROTR32 macro Tx,Vx,Ty,Vy
db 0xA5

//--------------------------------------//
// ROTR32 ERn, ER8
// ERn <- ERn >> rotate right (R8+1)-bit
// 1101_nn00
    if Tx=Treg32 and  Ty=Tsfr
        db 0xd0 | (LOW Vx SHL 2)
//--------------------------------------//

    else
        __ERROR__"syntax error in ROTR32"
    endif
endm


ROTL32 macro Tx,Vx,Ty,Vy
db 0xA5

//--------------------------------------//
// ROTL32 ERn, ER8
// ERn <- ERn >> rotate left (R8+1)-bit
// 1101_nn00
    if Tx=Treg32 and  Ty=Tsfr
        db 0xd1 | (LOW Vx SHL 2)
//--------------------------------------//

    else
        __ERROR__"syntax error in ROTL32"
    endif
endm


ROTR8 macro Tx,Vx,Ty,Vy
db 0xA5

//--------------------------------------//
// ROTR8 EACC, ER8
// ACC <- ACC[7:0] >> rotate right (R8+1)-bit
// 1101_0001
    if Tx=Tsfr and  Ty=Tsfr
        db 0x80
//--------------------------------------//

    else
        __ERROR__"syntax error in ROTR8"
    endif
endm

ROTL8 macro Tx,Vx,Ty,Vy
db 0xA5

//--------------------------------------//
// ROTL8 EACC, ER8
// ACC <- ACC[7:0] >> rotate left (R8+1)-bit
// 1101_0001
    if Tx=Tsfr and  Ty=Tsfr
        db 0x81
//--------------------------------------//

    else
        __ERROR__"syntax error in ROTL8"
    endif
endm


CLR32 macro Tx,Vx
db 0xA5

//--------------------------------------//
// CLR32 ERn
// ERn <- #0x00000000
// 0001_nn01
    if Tx=Treg32
        db 0x11 | (LOW Vx SHL 2)
//--------------------------------------//
    
    else 
        __ERROR__"syntax error in CLR32"
    endif
endm

ADDDP0 macro
db 0xA5

//--------------------------------------//
// ADDDP0
// DPTR0 <- DPTR0 + {B, R8}
// 0000_0100
    db 0x04
//--------------------------------------//
endm

ADDDP1 macro
db 0xA5

//--------------------------------------//
// ADDDP1
// DPTR1 <- DPTR1 + {B, R8}
// 0000_0101
    db 0x05
//--------------------------------------//
endm

SUBDP0 macro
db 0xA5

//--------------------------------------//
// SUBDP0
// DPTR0 <- DPTR0 - {B, R8}
// 0000_1100
    db 0x0c
//--------------------------------------//
endm

SUBDP1 macro
db 0xA5

//--------------------------------------//
// SUBDP1
// DPTR1 <- DPTR1 - {B, R8}
// 0000_1101
    db 0x0d
//--------------------------------------//
endm

INCDP0 macro 
db 0xA5

//--------------------------------------//
// INCP0
// DPTR0 <- DPTR0 + 1
// 0000_0000
    db 0x00
//--------------------------------------//
endm

INCDP1 macro 
db 0xA5

//--------------------------------------//
// INCP1
// DPTR1 <- DPTR1 + 1
// 0000_0001
    db 0x01
//--------------------------------------//
endm

INC4DP0 macro 
db 0xA5

//--------------------------------------//
// INCP0
// DPTR0 <- DPTR0 + 1
// 1101_0011
    db 0xd3
//--------------------------------------//
endm

INC4DP1 macro 
db 0xA5

//--------------------------------------//
// INCP1
// DPTR1 <- DPTR1 + 1
// 1101_0111
    db 0xd7
//--------------------------------------//
endm

DECDP0 macro 
db 0xA5

//--------------------------------------//
// DECP0
// DPTR0 <- DPTR0 - 1
// 0000_1000
    db 0x08
//--------------------------------------//
endm

DECDP1 macro 
db 0xA5

//--------------------------------------//
// DECP1
// DPTR1 <- DPTR1 - 1
// 0000_1001
    db 0x09
//--------------------------------------//
endm


DEC4DP0 macro 
db 0xA5

//--------------------------------------//
// DECP0
// DPTR0 <- DPTR0 - 1
// 1101_1011
    db 0xdb
//--------------------------------------//
endm

DEC4DP1 macro 
db 0xA5

//--------------------------------------//
// DECP1
// DPTR1 <- DPTR1 - 1
// 1101_1111
    db 0xdf
//--------------------------------------//
endm

MUL16 macro Tx,Vx
db 0xA5

//--------------------------------------//
// MUL16 ERm, ERn
// ERm <- ERn[31:16] * ERn[15:0]
// 1100_nnmm
    if Tx=Treg32
        db 0xc0 | (LOW Vx SHL 2)
//--------------------------------------//

    else
        __ERROR__"syntax error in MUL16"
    endif
endm

DIV16 macro Tx,Vx
db 0xA5

//--------------------------------------//
// DIV16 ERn
// ERn <- ERn / {B, R8}
// 1101_nn10
    if Tx=Treg32
        db 0xd2 | (LOW Vx SHL 2)
//--------------------------------------//

    else
        __ERROR__"syntax error in DIV16"
    endif
endm

#endif //asm

#endif



