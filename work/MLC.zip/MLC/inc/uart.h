#ifndef _uart_h_
#define _uart_h_


//UARTӲ������
//uart tx P01(NCE1)
//      rx P36(NRB1)

void uart_init_timer0(void);
char putchar (char c);
void uart_send_byte(char c);
void PrintHex(char dat);
void NewLine(void);
unsigned char chk_uart_pending(void);
void printf_buf(unsigned char xdata *ptr, unsigned short len);

extern void xrl_p3(unsigned char dat);

#endif