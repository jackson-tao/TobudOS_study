#ifndef _sd_isr_h_
#define _sd_isr_h_

extern unsigned char idata  rcv_data_state;
extern unsigned short idata u16RCA;	  
extern unsigned char idata u8_pwr_active_cnt;	  					
extern unsigned char idata  u8_extern_dma_in_task;		 //������dma in ���񡣣�pragram csd(u8_extern_dma_in_task & 0x80)��


extern void xrl_p1(u8 dat);
void xrl_p3(u8 dat);

extern void dma_data_in_pro(void);
extern void sd_kick_dma_out_data(void);
extern void cur_map_lba_inc(void);
extern void judge_cprm_data_dma_out_complete(void);
extern void clr_sd_read_data_flag(void);
extern void change_state_machine_in_data_state(void);
						
extern unsigned char code SD_STATE,TAB_R6_ACK,CSD,CSD_25M_CRC7,ERASE_PARAMETER,TAB_R1_ACK,TAB_R7_ACK,CID,ERASE_START_LBA,ERASE_END_LBA;
extern unsigned char code W_BUF_ADDR_H,W_BUF_ADDR_L,SOFT_RESET_ACMD41_CNT_TMP,SOFT_RESET_ACMD41_CNT,TAB_R3_ACK;

extern unsigned char code ERASE_START_LBA, ERASE_END_LBA;

unsigned char cmd_no_rps(void);
void cmd_r1_rps(void);
unsigned char isr_check_rca_match(void);
void rca_inc(void);
void kick_dma_cid(void);
void push_er0(void);
void pop_er0(void);
void get_addr(void);
void kick_rcv_data(void);
void check_addr_out_of_range(void);
void cmd_rps_with_check_range(void);
void ake_rev_data(void);
void isr_cmd0_process(void);
void read_r1_rps_and_dma_config(void);
											
bit chk_read_data_cmd(unsigned char yTast_Index_config);
bit chk_single_r_cmd(unsigned char yTast_Index_config);
void chk_erase_cmd_rps_and_save_par(void);
bit chk_cprm_send_data_cmd(unsigned char yTast_Index_config);
bit chk_cprm_rcv_data_cmd(unsigned char yTast_Index_config);
bit chk_stand_rcv_data(u8 task_index);

void pre_config_r1_rps(void);

u8 idata last_SSTA_P1;

#endif