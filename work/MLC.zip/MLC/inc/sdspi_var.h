#ifndef _SD_VAR_H_
#define _SD_VAR_H_
/**********************************************************************************************************************************************************
* repons R1
***********************************************************************************************************************************************************/
#define	 R1_REG  addr_0x20;
unsigned char bdata addr_0x20 _at_ 0x20;

sbit  RESERVED          = addr_0x20^7;  //31
sbit  PARAMETER_ERROR   = addr_0x20^6;  //30
sbit  ADDRESS_ERROR     = addr_0x20^5;  //29
sbit  ERASE_SEQ_ERROR   = addr_0x20^4;  //28
sbit  COM_CRC_ERROR     = addr_0x20^3;  //27
sbit  ILLEGAL_COMMAND   = addr_0x20^2;  //26
sbit  ERASE_RESET       = addr_0x20^1;  //25
sbit  IDLE_STATE        = addr_0x20^0;  //24  

/**********************************************************************************************************************************************************
* repons R2
***********************************************************************************************************************************************************/
#define R2_REG0   addr_0x20
#define R2_REG1   addr_0x21
unsigned char bdata addr_0x21 _at_ 0x21;  

sbit  OUT_OF_RANGE      = addr_0x21^7;  //23 
sbit  ERASE_PARAM       = addr_0x21^6;  //22
sbit  WP_VIOLATION      = addr_0x21^5;  //21
sbit  CARD_ECC_FAILED   = addr_0x21^4;  //20
sbit  CC_ERROR          = addr_0x21^3;  //19
sbit  ERROR             = addr_0x21^2;  //18
sbit  WP_ERASE_SKIP     = addr_0x21^1;  //17
sbit  CARD_IS_LOCKED    = addr_0x21^0;  //16

/**********************************************************************************************************************************************************
* ���±�����SD����SPIģʽ��λ����
* ʹ�õ�ַ0x24 - 0x27
**********************************************************************************************************************************************************/

#define  FlagReg0    addr_0x24
unsigned char bdata addr_0x24 _at_ 0x24;      

sbit  bAppo_CMD_Flag    = addr_0x24^0;  //�������־    
sbit  bCMDRec_Flag      = addr_0x24^1;  //CMD�жϱ�־ 
sbit  bCMDRps_Flag      = addr_0x24^2;  //CMDӦ���־ 
sbit  bDataIn_Flag      = addr_0x24^3;  //д�����жϱ�־
sbit  bDataOut_Flag     = addr_0x24^4;  //�������жϱ�־
sbit  bDataStop_Flag  	= addr_0x24^5;  //����ֹͣ��־
sbit  bStr_MulRead    	= addr_0x24^6;  //������ʼ��־
sbit  bStr_MulWrite   	= addr_0x24^7;  //���д��ʼ��־


#define FlagReg1   addr_0x25
unsigned char bdata addr_0x25 _at_ 0x25; 

sbit  bSpeedClass_Flag      = addr_0x25^0;  //25M SDCLK��־ ��ֻ��SDģʽ����Ч��
sbit  bSPI_CRC_Check_Flag   = addr_0x25^1;  //CRCУ�����   ��ֻ��SPIģʽ����Ч��
sbit  bSPICMDInR2Rps		= addr_0x25^2;	//1: CMD's rps type in R2.
sbit  bEnterReadDmaOut		= addr_0x25^3;	//1:����ִ��dma out���� 0: dma out ���������
sbit  bSpiMulReadAddrErr    = addr_0x25^4;	 //1:SPI mul read addr err.
sbit 	bEnIsrDmaOut		= addr_0x25^5; //1: Enable dma out isr dma data one by one.
sbit  bHwEnBusyCmd          = addr_0x25^6;  //
sbit  bEnCheckEraseSeq      = addr_0x25^7;  //1-->������CMD�������Ƿ񱻴��


#define FlagReg2 addr_0x26 
unsigned char bdata addr_0x26 _at_ 0x26; 
sbit  bCallWriteLBA         = addr_0x26^0;
sbit  bMulRFlag             = addr_0x26^1;  
sbit  bMulWriteTask         = addr_0x26^2;   //0:CMD8 not received; 1:CMD8 received  
sbit  bSingleWriteTask      = addr_0x26^3;   //1-->in single write task
sbit  bCMD8Rcv              = addr_0x26^4;   //1-->in mul write task   
sbit  bSwitch50M            = addr_0x26^5;   //25M->50M SD CLK b��־��0�����ܱ�50M SD CLK,1:���Ա��50M SD CLK
sbit  bInReadLba            = addr_0x26^6; 
sbit  bSDHC                 = addr_0x26^7;    //0:not SDHC ; 1: SDHC. 


#define FlagReg3  addr_0x27
unsigned char bdata addr_0x27 _at_ 0x27; 

sbit  bReadType                 = addr_0x27^0;
sbit  bWriteType                = addr_0x27^1;
sbit  bInWriteLbaFun		    = addr_0x27^2;	 //1: in write lba.
sbit  bStopMulWriteData         = addr_0x27^3; 
sbit  bNandPowerup              = addr_0x27^4;
sbit  bEnVirtualBuf2Nf			= addr_0x27^5;  //1: Enable Virtual buf data write to nf after flash power up.
sbit  bTmpWriteProtect          = addr_0x27^6;
sbit  bRomCard									= addr_0x27^7;	 //1: ROM card.

unsigned char bdata addr_0x2e _at_ 0x2e;
sbit bEnForceEraseVirtualBufBlk	= addr_0x2e^0; //0: Enable force erase virtual buf nf blk after power up(default); 1: disable.		
sbit bReadDataInHsBuf			= addr_0x2e^1; //0: LBA's data is not in HS_BUF; 1: LBA's data is in HS_BUF
sbit bBlockLenLess512Byte		= addr_0x2e^2; //1: In reading lba data.
sbit bForceDly					= addr_0x2e^3; //1��Force delay in receiving data.(default); 0: Do not force delay.
sbit  bInEraseTask          	= addr_0x2e^4;  //1-->����������
sbit bTimeout					= addr_0x2e^5; //1: Write data timeout.
sbit bReadDataInVirtualBuf		= addr_0x2e^6; //1: Read data is in virtual buf.

unsigned char bdata bCPRMFlag _at_ 0x2f;
  
sbit  bCPRM_E_D_Flag        = bCPRMFlag^0;    //0: C2_E/C2_ECBC;            1: C2_D/C2_DCBC
sbit  bAKERcvType           = bCPRMFlag^1;    //0: AKE Rcv challenge1;        1: AKE Rcv challenge2_rps
sbit  bScrtyMode            = bCPRMFlag^2;    //1: Security mode
sbit  bCprmDmaDataMode      = bCPRMFlag^3;    //0: Normal read mode             1: Read CPRM data mode.
sbit  bAKEVerifyErr         = bCPRMFlag^4;    //0: AKE Verify ok            1: AKE Verify err
sbit  bFirstEnDecodeData    = bCPRMFlag^5;    //0: Not first packet en/decode data.   1 :first packet en/decode data. 
sbit  bVisitCprmDataMode    = bCPRMFlag^6;    //0: Normal read(data do not en/decode) 1: Cprm read mode(data en/decode)
sbit  bStopRcvCprmData      = bCPRMFlag^7;    //0: Normal write mode or continue receive data in CPRM mode.  1: stop receive data in CPRM write mode.       

/**********************************************************************************************************************************************************
* ���±�����SD����SPIģʽ��REG����
* ʹ�õ�ַ0x30 - 0x35
***********************************************************************************************************************************************************/
  /* SD ģ���±������� */
unsigned char data yCMD_Index        _at_  0x30;   //CMD Index 
unsigned char data yTast_Index       _at_  0x31;   //����Index
unsigned char data yScrtyUnitCnt     _at_  0x32;  


unsigned char code sd_hs_cache_data_buf [SD_HS_CACHE_BUF_CNT * 512]	 _at_ (SD_HS_CACHE_BUF_START_ADDR);
unsigned char code sd_hs_cache_data_buf_lba [SD_HS_CACHE_BUF_CNT][4]	 _at_ (SD_HS_CACHE_BUF_START_ADDR + SD_HS_CACHE_BUF_CNT * 512); //LBA

	#if 1//(SD_VIRTUAL_BUF_CNT <= (VIRTUAL_BUF_MAX_NF_LG_PAGE_CNT * VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE))
	unsigned char code sd_virtual_data_buf_lba [SD_VIRTUAL_BUF_CNT][4]	 	 _at_ (SD_VIRTUAL_BUF_LBA_START_ADDR);
	unsigned char code sd_virtual_data_buf_cnt [SD_VIRTUAL_BUF_CNT]	 	 _at_ (SD_VIRTUAL_BUF_LBA_START_ADDR+SD_VIRTUAL_BUF_CNT*4);
	#elif (EN_VIRTUAL_BUF)
	 Error:  //SD_VIRTUAL_BUF_CNT ���� <= VIRTUAL_BUF_MAX_NF_LG_PAGE_CNT
	#elif ( ! EN_VIRTUAL_BUF)
	unsigned char code sd_virtual_data_buf_lba [SD_VIRTUAL_BUF_CNT][4]	 	 _at_ (SD_VIRTUAL_BUF_LBA_START_ADDR);
	unsigned char code sd_virtual_data_buf_cnt [SD_VIRTUAL_BUF_CNT]	 	 _at_ (SD_VIRTUAL_BUF_LBA_START_ADDR+SD_VIRTUAL_BUF_CNT*4);
	#endif

#if 0//EN_DEBUG_VIRTUAL_BUF
unsigned char code sd_virtual_data_buf [VIRTUAL_BUF_MAX_NF_LG_PAGE_CNT * 512]	     _at_ (SD_HS_CACHE_BUF_START_ADDR + SD_HS_CACHE_BUF_CNT * 512 + SD_HS_CACHE_BUF_CNT * 4 + SD_VIRTUAL_BUF_CNT * 4);
#endif

#endif