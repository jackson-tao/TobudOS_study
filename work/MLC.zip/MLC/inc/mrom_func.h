//#define	get_block_phaddr_maskrom                        0xF48C
//#define	set_block_phaddr_maskrom                        0xF261
#define	addr_block2bit_maskrom                          0xF8EA
#define	buf1_2_buf0_maskrom                             0xFA80
#define	dptr1_cpy_to_dptr0_maskrom                      0xFB36
#define	compare_wdata_maskrom                           0xFB9E
#define	dptr0_point_to_dptr0_maskrom                    0xFAB5

#define	nf_send_cmd_only_maskrom                        0xFBB5
#define	nf_wait_read_over_maskrom                       0xFB27
#define	wait_flash_ready_maskrom                        0xFC4A
#define	nf_send_cmd1_maskrom                            0xFBC0

#define	disable_timer_isr_maskrom                       0xFC87
#define	enable_timer_isr_maskrom                        0xFC8B
#define	timer3_clr_tof_maskrom                          0xFBCB
#define	mem_copy_hw_maskrom                             0xF766   //��ʱ�Ȳ���MROM�ģ�
#define	mem_copy_hw_clr_pending_maskrom                 0xFBD6
#define	inc_read_buf_cnt_maskrom                        0xFC02
#define	stop_read_acce_maskrom                          0xFC0D
#define	stop_write_acce_maskrom                         0xFC23
#define	dec_write_buf_cnt_maskrom                       0xFC18
#define	cal_cac16_maskrom                               0xF53A
#define	dptr_add_ab_maskrom                             0xFC38
#define	pop_reg_bank_0_maskrom                          0xF44B
#define	push_reg_bank_0_maskrom                         0xF40A
#define	pop_er0_to_er4_maskrom                          0xFA1B
#define	push_er0_to_er4_maskrom                         0xFA04
#define	sd_kick_dma_out_data_pop_er0_er1_maskrom        0xFBF7
#define	sd_kick_dma_out_data_push_er0_er1_maskrom       0xFBEC
#define	fetch_agm_addr_to_er3_maskrom                   0xF972
#define	config_dma_buf_addr_maskrom											0xFA92

#define	read_rec_lba_tab_maskrom                        0xF825
#define	write_rec_lba_tab_maskrom                       0xF715
#define	write_rec_lba_maskrom                           0xF2B6
#define	write_rec_lba_len_maskrom                       0xF98B
#define	read_rec_lba_len_maskrom                        0xFA5A
#define	read_rec_blk_size_maskrom                       0xF9A4
#define	read_rec_lba_maskrom                            0xFC67
#define	read_captab_maskrom                             0xFC41
#define	read_rescap_maskrom                             0xFC6D
#define	read_remapcap_maskrom                           0xFC73
#define	reset_write_buf_maskrom                         0xFC8F
#define	write_enlarge_data_delay_maskrom                0xFC79
#define	get_cur_rec_tab_index_maskrom                   0xFC5A
#define	update_rec_tab_index_copy_maskrom               0xFC95

#define	get_cur_map_lba_to_er1_maskrom                  0xFB52
#define	update_cur_lba_to_cur_map_lba_var_maskrom       0xF93E
#define	fill_cur_buf_data_maskrom                       0xF638
#define	judge_reach_per_record_tab_end_maskrom          0xF6C0
#define	cal_32bit_erx_remainder_maskrom                 0xF5A3
#define	cur_lba_dec_maskrom                             0xFAC6
#define	initial_enlarge_chk_var_maskrom                 0xF5D6
#define	clr_buf_at_rec_lba_tab_maskrom                  0xE2E2
#define	get_cur_lba_to_er1_maskrom                      0xFB79

#define	initial_valid_sector_cnt_maskrom                0xF694			
#define	fill_buf_data_and_randomsize_maskrom            0xF20B				
#define	delay_r_w_maskrom                               0xFB5F
#define	update_er3_to_cur_map_lba_var_maskrom           0xFB45
#define	in_360_mode_delay_maskrom                       0xF9BD
#define	get_arg_to_lba_tmp_maskrom                      0xFA6D
#define	init_sd_kict_rcv_maskrom                        0xF8AB
#define	update_start_lba_to_cur_lba_maskrom             0xFBE1

#define	data_in_clr_enlargetab_maskrom                  0xF666
#define	enable_force_sd_bus_rcv_data_in_dly_maskrom     0xFC92
#define	update_er3_to_cur_lba_var_maskrom               0xFB6C
#define	restrict_rec_index_loop_cnt_maskrom             0xF0F5
#define	search_rec_maskrom                   						0xEFAD


#define	check_h2testw_data_maskrom                      0xF023
#define	cal_exarea1_remap_maskrom                       0xF800
#define	change_lba_maskrom                              0xEE98
#define	chk_dbr_maskrom                                 0xF73E
#define	chk_mbr_maskrom                                 0xF8CC
#define	chk_w_process_enlarge_rec_lba_len_maskrom       0xF609
#define	update_exarea1_seq_maskrom                      0xF907
#define	read_lba_for_mapping_maskrom                    0xEF27
#define	chk_360_mode_step_maskrom                       0xEAB7
#define	v_30_chk_rec_len_maskrom												0xEE98


#define Cal_ExArea1_remap									(*((void (code *)(void))cal_exarea1_remap_maskrom))
#define Check_H2testw_data								(*((void (code *)(void))check_h2testw_data_maskrom))
#define Change_lba												(*((void (code *)(void))change_lba_maskrom))
#define V_30_chk_rec_len									(*((void (code *)(void))v_30_chk_rec_len_maskrom))
#define Chk_w_process_enlarge_rec_lba_len			(*((void (code *)(void))chk_w_process_enlarge_rec_lba_len_maskrom))	
#define Chk_DBR														(*((void (code *)(void))chk_dbr_maskrom))	
#define Update_ExArea1_Seq								(*((void (code *)(void))update_exarea1_seq_maskrom))	
//#define chk_MBR														(*((void (code *)(void))chk_mbr_maskrom))
#define Read_lba_for_mapping							(*((void (code *)(void))read_lba_for_mapping_maskrom))	
#define Chk_360_mode_step									(*((void (code *)(void))chk_360_mode_step_maskrom))

#define Data_in_clr_enlargeTab							(*((void (code *)(void))data_in_clr_enlargetab_maskrom))
#define Restrict_rec_index_loop_cnt					(*((void (code *)(void))restrict_rec_index_loop_cnt_maskrom))	
#define Search_rec													(*((void (code *)(void))search_rec_maskrom))	
#define Fill_buf_data_and_randomsize				(*((void (code *)(void))fill_buf_data_and_randomsize_maskrom))
#define Delay_r_w														(*((void (code *)(void))delay_r_w_maskrom))
#define Update_er3_to_cur_map_lba_var				(*((void (code *)(void))update_er3_to_cur_map_lba_var_maskrom))	
#define In_360_mode_delay										(*((void (code *)(void))in_360_mode_delay_maskrom))	
#define Update_start_lba_to_cur_lba					(*((void (code *)(void))update_start_lba_to_cur_lba_maskrom))	
#define Get_cur_map_lba_to_er1							(*((void (code *)(void))get_cur_map_lba_to_er1_maskrom))
#define Fill_cur_buf_data										(*((void (code *)(void))fill_cur_buf_data_maskrom))
#define Judge_reach_per_record_tab_end			(*((void (code *)(void))judge_reach_per_record_tab_end_maskrom))
#define Cal_32bit_erx_remainder							(*((void (code *)(void))cal_32bit_erx_remainder_maskrom))
#define INITIAL_ENLARGE_CHK_VAR							(*((void (code *)(void))initial_enlarge_chk_var_maskrom))
#define Clr_buf_at_rec_lba_tab							(*((void (code *)(void))clr_buf_at_rec_lba_tab_maskrom))
#define Read_rec_lba_tab										(*((void (code *)(void))read_rec_lba_tab_maskrom))
#define Write_rec_lba_tab										(*((void (code *)(void))write_rec_lba_tab_maskrom))
#define Write_rec_lba												(*((void (code *)(void))write_rec_lba_maskrom))	
#define Write_rec_lba_len										(*((void (code *)(void))write_rec_lba_len_maskrom))
#define Read_rec_lba_len										(*((void (code *)(void))read_rec_lba_len_maskrom))
#define Read_rec_blk_size										(*((void (code *)(void))read_rec_blk_size_maskrom))
#define Read_rec_lba												(*((void (code *)(void))read_rec_lba_maskrom))
#define Read_captab													(*((void (code *)(void))read_captab_maskrom))
#define Read_rescap													(*((void (code *)(void))read_rescap_maskrom))
#define Read_remapcap												(*((void (code *)(void))read_remapcap_maskrom))
#define Reset_write_buf											(*((void (code *)(void))reset_write_buf_maskrom))
#define Write_enlarge_data_delay						(*((void (code *)(void))write_enlarge_data_delay_maskrom))
#define Get_cur_rec_tab_index								(*((void (code *)(void))get_cur_rec_tab_index_maskrom))
#define Update_rec_tab_index_copy						(*((void (code *)(void))update_rec_tab_index_copy_maskrom))	



//#define Get_Block_PhAddr										(*((void (code *)(void))get_block_phaddr_maskrom))
//#define Set_Block_PhAddr										(*((void (code *)(void))set_block_phaddr_maskrom))	
#define	Addr_Block2Bit											(*((void (code *)(void))addr_block2bit_maskrom))			
#define	Buf1_2_Buf0													(*((void (code *)(void))buf1_2_buf0_maskrom))				
#define	Compare_wData												(*((void (code *)(void))compare_wdata_maskrom))			
#define Dptr0_Point_To_Dptr0								(*((void (code *)(void))dptr0_point_to_dptr0_maskrom))		
#define	NF_Send_CMD_Only										(*((void (code *)(void))nf_send_cmd_only_maskrom))		
#define	Wait_Flash_Ready										(*((void (code *)(void))wait_flash_ready_maskrom))			
#define	NF_Wait_Read_Over										(*((void (code *)(void))nf_wait_read_over_maskrom))	
#define NF_Send_CMD1												(*((void (code *)(void))nf_send_cmd1_maskrom))	
#define DPTR_Add_AB												 	(*((void (code *)(void))dptr_add_ab_maskrom))
#define disable_timer_isr										(*((void (code *)(void))disable_timer_isr_maskrom))
#define	enable_timer_isr										(*((void (code *)(void))enable_timer_isr_maskrom))
#define timer3_clr_tof											(*((void (code *)(void))timer3_clr_tof_maskrom))
#define	mem_copy_hw												 	(*((void (code *)(void))mem_copy_hw_maskrom))	
#define mem_copy_hw_clr_pending							(*((void (code *)(void))mem_copy_hw_clr_pending_maskrom))			
#define inc_read_buf_cnt										(*((void (code *)(void))inc_read_buf_cnt_maskrom))			
#define	dec_write_buf_cnt										(*((void (code *)(void))dec_write_buf_cnt_maskrom))		
#define stop_read_acce											(*((void (code *)(void))stop_read_acce_maskrom))				
#define stop_write_acce											(*((void (code *)(void))stop_write_acce_maskrom))				
#define cal_cac16														(*((void (code *)(void))cal_cac16_maskrom))				
#define pop_reg_bank_0											(*((void (code *)(void))pop_reg_bank_0_maskrom))				
#define push_reg_bank_0											(*((void (code *)(void))push_reg_bank_0_maskrom))		
#define pop_er0_to_er4											(*((void (code *)(void))pop_er0_to_er4_maskrom))				
#define push_er0_to_er4											(*((void (code *)(void))push_er0_to_er4_maskrom))		
#define sd_kick_dma_out_data_pop_er0_er1		(*((void (code *)(void))sd_kick_dma_out_data_pop_er0_er1_maskrom))				
#define sd_kick_dma_out_data_push_er0_er1		(*((void (code *)(void))sd_kick_dma_out_data_push_er0_er1_maskrom))		
#define update_er3_to_cur_lba_var						(*((void (code *)(void))update_er3_to_cur_lba_var_maskrom))	
#define get_arg_to_lba_tmp									(*((void (code *)(void))get_arg_to_lba_tmp_maskrom))
#define fetch_agm_addr_to_er3								(*((void (code *)(void))fetch_agm_addr_to_er3_maskrom))		
#define init_sd_kict_rcv										(*((void (code *)(void))init_sd_kict_rcv_maskrom))	
#define enable_force_sd_bus_rcv_data_in_dly		(*((void (code *)(void))enable_force_sd_bus_rcv_data_in_dly_maskrom))
#define cur_lba_dec													(*((void (code *)(void))cur_lba_dec_maskrom))
#define get_cur_lba_to_er1									(*((void (code *)(void))get_cur_lba_to_er1_maskrom))	
#define update_cur_lba_to_cur_map_lba_var		(*((void (code *)(void))update_cur_lba_to_cur_map_lba_var_maskrom))
#define	dptr1_cpy_to_dptr0									(*((void (code *)(void))dptr1_cpy_to_dptr0_maskrom))			
#define initial_valid_sector_cnt						(*((void (code *)(void))initial_valid_sector_cnt_maskrom))	
#define config_dma_buf_addr									(*((void (code *)(void))config_dma_buf_addr_maskrom))		