
#ifndef _mtd_c_h_
#define _mtd_c_h_
extern u8 code _PageLg2PhTable, _PageLg2PhTable_SLC_Plane1, _PageLg2PhTable_Plane1, BlockPageModeIndex_Infor, _PageLg2PhTable_ph;
extern u8 code BlockPageModeIndex_Buf, NF_DATA, BCH_MODE_DC_TAB, _SectorLg2PhTable, _SectorLg2PhTable_Plane1, Cur_ZoneLBA;
extern u8 code _FLASH_SECTORPERSMALLPAGE, _FLASH_SECTORPERSMLPAGEPLN2, _FLASH_SECTORPERSMLPAGEPLN4, _FLASH_SECTORPERSMLPAGEPLN6; 
extern u8 code ShiftCnt, BCH_MODE_EC_TAB, FirstValidZone, NF_SECTOR_SIZE_TAB, _FLASH_SECTORPERSMLPAGEPLN1;
extern u8 code _FLASH_BCMCfg_ADDR_Plane1_StartAddr, Retry_Register_Data_Table, CacheBlockMaxPageH, CacheBlockMaxPageL,Retry_Register_Addr_Table,Retry_Register_CMD/*,NFFINBuf,NFFOutBuf*/, Retry_Register_FLASH_RetryCnt;
extern u8 code _SectorLg2PhTable_Plane2,_SectorLg2PhTable_Plane4,_SectorLg2PhTable_Plane3;
extern u8 code PLANE_REFERENCE, _PLANE_MODE, _FLASH_SHIFTCNT;
extern bit bNandPowerup, bReadNeedChkBankBlk, bNfInReadLbaFun, bSendReadRandomCmd;
extern u8 code Retry_Register_Addr_Table, _Fill_Sec_Gap_P1, _Fill_Sec_Gap_P0;
extern unsigned char  data boundIndex;

extern void bit_search(void); 	
extern void get_bound_block(void);
extern void Sel_Buffer_Addr(void);
extern void Sel_DMA_Addr(void);
extern void timer_tick_clr(void);
extern void Set_Retry_Register_Data(void);
extern void Write_a_Block_Over(void);
extern void Find_A_Blank_Block(void);
extern void Get_Block_PhAddr(void);
extern void Set_Block_PhAddr(void);

extern void xrl_p3(u8 dat);
extern void wait_rbx_ready(u8 rb);

static void NF_Config_5ByteAddr(void);
static void BCM_KickStart(void);
static void Get_ColAddr(void);
static void Chk_Need_Retry(void);
static void Set_Retry_Register_Default_Data(void);
static void Set_Retry_Register_Offset_Data(void);
static void ECC_Step1_isr(void);
static void SDBuf_Block_Init_Addr(void);
static void NF_Config_Init(void);
static void NF_Send_Addr_Write_Data(void);
static void NF_Send_Addr_Read_Data(void);
void NF_Reset(void);
void SDBuf_Block_Init_Zone(void);

void NF_Read_Start(void);
void NF_Read_Data(void);
void NF_Prog_Data(void);
void NF_Prog_Stop(void);
void NF_Erase_Block(void);
void BCH_MODE_DC_Wait_Over(void);
void Get_CurPlaneCfg(void);
void Read_Sectors(void);
void Prog_A_Page_NewBlock(void);
void Prog_A_Page_CacheBlock(void);
void Buf_Data_CoDec(void);
void NF_Write_Addr(void);
void NF_Send_CMD0_5ByteAddr(void);
void Get_R1_Addr(void);
void NF_Get_Feature(u8 Feature_Addr);
void read_sdbuf_block(void);
void BCH_Config_Decode1time(void);
void erase_sdbuf_block(void);
void Chk_Blank_Block(void);
void SLC_ERASE(void);
void Get_PageLg2PhTable(void);
void NF_Read_Start_Copy(void);
void Get_Config_Data(void);
void NF_Prog_Data_Wait(void);
void program_sdbuf_block(void);
void reset_bch(void);
void select_ecc_bits(u8 config);
void select_ce(u8 ce);
u8 change_ax215e_to_tank_ecc_bits_config(u8 config);
unsigned char NF_Read_Status(unsigned char tmp);


#endif