#ifndef	_sd_spi_com_h_
#define _sd_spi_com_h_
 
#define			_50M							1
#define			POWER_DOWN_EN				1 
#define 		POWER_DOWN_CMD				0 //sd cmd����
#define			DIS_RC							0
#define			EN_CPRM							0
#define			EN_CPRM_CMD						1
#define			DYNAMIC_VIRTUAL_SECTOR    0  
#define			EN_MUL_RELEASE_VBUF		0
#define 		SYNC_CLRBUSY_SSTA   1
#define  		REDUCE_ERASE_NEW			1   //���ٲ���block�Ĵ���,ITM 8d2f��Ҫ�������ٲ�������
				
#define			EN_IDLE_RL_VBUF   0

#define			EN_DEBUG_SD						0
#define			EN_CAL_TIME						0       //��ȷ����ĳ��������ִ��ʱ�� (n*10ms)

#define			UART_SYN						1		// 1 -- ʹ��ͬ��; 0 -- ʹ���첽��ӡ

//#define			COB 			1				//fpga����trim��100M
  
#if 			0						
	#define 			EN_FPGA_SYS_CLK				100		//89 --89MHZ; 80--80MHZ; 100 -- 100MHZ
#else
	#define 			EN_FPGA_SYS_CLK				80		//89--89MHZ; 80--80MHZ; 100 -- 100MHZ  
#endif

#define			BAUDRATE						 3   // 0 -- no printf ;1 -- 115200 bps; 2 -- 256000 bps  

#define			EN_UART_IO_MAP_2_SD_D2			1   //Uartӳ�䵽SD D2  

#define 		PRINT_BOUND_BLOCK				0
  
#define			EN_VIRTUAL_BUF					1  //����SD buf�Ľӿ�  
 
#define			EN_POWERUP_SEARCH_VIRTUAL_BUF	  1  //�ϵ���������buf���ָ���ز��� 

#define			EN_AUTO_REDUCE_AND_FIX_25M_CLK	1		//�Զ��жϣ���ǿ�ƽ���25M SD CLKģʽ 
	
#define			HW_W_LBA_TAB_SMALL_ENDIAN		1

#define			EN_MUL_PAGES_MODE				1

#define			V20	

#define			EN_TEST_SD_BUS_R_W_SPEED		0		//����SD�ն���д

#define			DIS_NF_FUNCTION					0		//�Ժ��ٴ���
	
#define			EN_DEBUG_NF_R					0

#define			EN_DEBUG_NF_W					0

#define			EN_USE_SD_DMA_OUT_ONE_BUF		0		//sd dma out use one buf.	

#define			EN_HW_COPY_512BYTE				1		//control hw copy 

//#define			EN_FIX_FLASH_ONE_PLANE			0		//��oneplane

#define			EN_NF_RANDOM_WR_CMD				1		//0X85 cmd

#define			EN_NF_RANDOM_RD_CMD				1		//0X05 0xe0 cmd

#define			EN_RANDOMIZE_DATA				1

#define			RANDOMIZE_NF					1

#define			NFFUSING					0

//======================================================================================================
#define			CPRM_USING_RAMTABEL   0//0:sbox using solidified table,�Ѳ���Ҫ��Ŀǰ�����ѹ̶�ʹ�ù̻�SBOX

#define 		USE_HWBIT		0

#define 		EN_BCM			1  

#define 		EN_DEBUG_DMA				0			//debug dma out debug message

#define 		EN_DEBUG_DMA_KMU		0			//debug dma out Kmu	

#define 		EN_DEBUG_DMA_C1RSP		0			//debug dma out C1 respond with specified Kmu and C1

#define			EN_VERIFY_PROTECTED_DAT	0 	//debug use normal cmd read/write proteced area
/********************************************************************************************************************************************************** 
***********************************************************************************************************************************************************/

#define			_N_NOP_						_nop_(); _nop_(); _nop_();

/********************************************************************************************************************************************************** 
***********************************************************************************************************************************************************/

/********************************************************************************************************************************************************** 
SD TAB DMA ADDR
ע�⣺λ�ò�������޸ģ��ϲ��������д��Ӧ�Ĳ���
***********************************************************************************************************************************************************/
#define		SD_TAB						0x250
#define		CID_DMA_ADDR_L				((unsigned short)(SD_TAB + 8)/4/1)
#define		CID_DMA_ADDR_H				((unsigned short)(SD_TAB + 8)/4/256)

#define		MID_DMA_ADDR_L				((unsigned short)(SD_TAB + 8)/4/1)
#define		MID_DMA_ADDR_H				((unsigned short)(SD_TAB + 8)/4/256)

#define		TAB_R6_ACK_DMA_ADDR_L		((unsigned short)(SD_TAB + 44)/4/1)
#define		TAB_R6_ACK_DMA_ADDR_H		((unsigned short)(SD_TAB + 44)/4/256)

#define		TAB_R7_ACK_DMA_ADDR_L		((unsigned short)(SD_TAB + 48)/4/1)
#define		TAB_R7_ACK_DMA_ADDR_H		((unsigned short)(SD_TAB + 48)/4/256)

#define		CSD_DMA_ADDR_L				((unsigned short)(SD_TAB + 24)/4/1)
#define		CSD_DMA_ADDR_H				((unsigned short)(SD_TAB + 24)/4/256)

#define		TAB_R3_ACK_DMA_ADDR_L		((unsigned short)(SD_TAB + 40)/4/1)
#define		TAB_R3_ACK_DMA_ADDR_H		((unsigned short)(SD_TAB + 40)/4/256)

#define		SCR_DMA_ADDR_L				((unsigned short)(SD_TAB + 52)/4/1)
#define		SCR_DMA_ADDR_H				((unsigned short)(SD_TAB + 52)/4/256)

#define		SD_STATE_DMA_ADDR_L			((unsigned short)(SD_TAB + 60)/4/1)
#define		SD_STATE_DMA_ADDR_H			((unsigned short)(SD_TAB + 60)/4/256)

#define		FUNCTION_DMA_ADDR_L			((unsigned short)(SD_TAB + 60 + 64)/4/1)
#define		FUNCTION_DMA_ADDR_H			((unsigned short)(SD_TAB + 60 + 64)/4/256)

#define		WR_BLOCKS_TAB_DMA_ADDR_L	((unsigned short)(SD_TAB + 60 + 64 + 64)/4/1)
#define		WR_BLOCKS_TAB_DMA_ADDR_H	((unsigned short)(SD_TAB + 60 + 64 + 64)/4/256)

#define		WP_NUM_TAB_DMA_ADDR_L		((unsigned short)(SD_TAB + 60 + 64 + 64 + 16*3)/4/1)
#define		WP_NUM_TAB_DMA_ADDR_H		((unsigned short)(SD_TAB + 60 + 64 + 64 + 16*3)/4/256)

/***********************************************************************************************************************************************************
SD/SPI DMA ADDR
ע�⣺λ�ÿ��Ը���ʵ������޸ģ��ϲ�������������Ӧ����.
***********************************************************************************************************************************************************/
#define		TAB_R1_ACK_ADDR				(3*1024)						//0x017c //(10*1024)

#define		TAB_R1_ACK_DMA_ADDR_L		((unsigned short)TAB_R1_ACK_ADDR/4/1)
#define		TAB_R1_ACK_DMA_ADDR_H		((unsigned short)TAB_R1_ACK_ADDR/4/256)

#define		SPI_TAB_R1_ACK_DMA_ADDR_L	((unsigned short)TAB_R1_ACK_ADDR/4/1)
#define		SPI_TAB_R1_ACK_DMA_ADDR_H	((unsigned short)TAB_R1_ACK_ADDR/4/256)

#define		SPI_TAB_R2_ACK_DMA_ADDR_L	((unsigned short)(TAB_R1_ACK_ADDR + 4)/4/1)
#define		SPI_TAB_R2_ACK_DMA_ADDR_H	((unsigned short)(TAB_R1_ACK_ADDR + 4)/4/256)

#define		SPI_TAB_R3_ACK_DMA_ADDR_L	((unsigned short)(TAB_R1_ACK_ADDR + 4 + 4)/4/1)
#define		SPI_TAB_R3_ACK_DMA_ADDR_H	((unsigned short)(TAB_R1_ACK_ADDR + 4 + 4)/4/256)

#define		SPI_TAB_R7_ACK_DMA_ADDR_L	((unsigned short)(TAB_R1_ACK_ADDR + 4 + 4 + 8)/4/1)
#define		SPI_TAB_R7_ACK_DMA_ADDR_H	((unsigned short)(TAB_R1_ACK_ADDR + 4 + 4 + 8)/4/256)

/********************************************************************************************************************************************************** 
//SD/SPI  CPRM ������ز���
//CPRM kmu���ϲ�������Ҫ������Щ������ע���ַ��sort_sd�ļ�ͬ������
//SD/SPI  CPRM DMA ADDR
/**********************************************************************************************************************************************************/ 
#define		_CPRM_MAXUSERDATACAP					(0x01B0)
#define		_CPRM_MAXKEYCAPDATA	   					(0x0500) 
#define		_CPRM_MAXPROTECTEDCAP					(0x0580)
#define		_CPRM_MAXMKBCAP							(0x0584)
#define		_CPRM_MAXTOTALCAP						(0x0588)
#define		_CPRM_MAXKEYCAPDATADPTR					(0x058C)
#define		_CPRM_SIZE_OF_PROTECTED_AREA			(0x0590)	  //д�����SD_STATE����Ӧ�ĵط�

//ע�⣺���²������Ը���ʵ������޸ģ��ϲ�������������Ӧ������λ��.
#define		CPRM_AKE_BUF_ADDR_START	   			(0x0e00) //3.5*1024=0x0e00

#define		AKE_CHALLENGE_1_BUF_ADDR 			(CPRM_AKE_BUF_ADDR_START)
#define		AKE_CHALLENGE_1_BUF_DMA_ADDR_L		((unsigned short)(AKE_CHALLENGE_1_BUF_ADDR) / 4 / 1)
#define		AKE_CHALLENGE_1_BUF_DMA_ADDR_H		((unsigned short)(AKE_CHALLENGE_1_BUF_ADDR) / 4 / 256)	

#define		AKE_CHALLENGE_2_BUF_ADDR 			(CPRM_AKE_BUF_ADDR_START + 8)
#define		AKE_CHALLENGE_2_BUF_DMA_ADDR_L		((unsigned short)(AKE_CHALLENGE_2_BUF_ADDR) / 4 / 1)
#define		AKE_CHALLENGE_2_BUF_DMA_ADDR_H		((unsigned short)(AKE_CHALLENGE_2_BUF_ADDR) / 4 / 256)	

#define		AKE_CHALLENGE_1_RPS_BUF_ADDR 		(CPRM_AKE_BUF_ADDR_START + 8 + 8)
#define		AKE_CHALLENGE_1_RPS_BUF_DMA_ADDR_L	((unsigned short)(AKE_CHALLENGE_1_RPS_BUF_ADDR) / 4 / 1)
#define		AKE_CHALLENGE_1_RPS_BUF_DMA_ADDR_H	((unsigned short)(AKE_CHALLENGE_1_RPS_BUF_ADDR) / 4 / 256)	

#define		AKE_CHALLENGE_2_RPS_BUF_ADDR 		(CPRM_AKE_BUF_ADDR_START + 8 + 8 + 8)
#define		AKE_CHALLENGE_2_RPS_BUF_DMA_ADDR_L	((unsigned short)(AKE_CHALLENGE_2_RPS_BUF_ADDR) / 4 / 1)
#define		AKE_CHALLENGE_2_RPS_BUF_DMA_ADDR_H	((unsigned short)(AKE_CHALLENGE_2_RPS_BUF_ADDR) / 4 / 256)	

/********************************************************************************************************************************************************** 
* high speed buf �йصĺ궨��  
***********************************************************************************************************************************************************/
#define	EN_STOP_W_FLASH_DATA			0		   						//�򿪶����д��������flash�ڰ�Ǩ���ݹ����У�
//-----------------------------------------------------------------------------------------------------------------------------------------------------------
#define	RETRY_TIMEOUT_N_MS				128//64//30//64							//n * 1ms; 1msΪ��λ
#define	DELAY_10MS_TIMEOUT_CNT			0x03de		   				  	//10ms delay timeout

#if EN_MUL_RELEASE_VBUF
	#define SD_RCV_DATA_DLY_TIMEOUT_CNT			(15 * DELAY_10MS_TIMEOUT_CNT) //22  //��������copyʱƽ��timer����Լ10us // (1 ~ 65535)ÿ�����ݵ��delayʱ�䣨����С��250ms��  
	#define SD_CMD12_STOP_DLY_TIMEOUT_CNT		(15 * DELAY_10MS_TIMEOUT_CNT) //22	//������copyʱƽ��timer����ԼΪ8us,cmd12��ʱ�����ʵ��ӳ�
	#define SD_RCV_DATA_DLY_MID_HOLD_TIME		(15  * DELAY_10MS_TIMEOUT_CNT)  //18/4,����Ӳ��hold��ʱ����virtual page�ܴ洢��sector����
#else 
	#define SD_RCV_DATA_DLY_MID_HOLD_TIME		(20 * DELAY_10MS_TIMEOUT_CNT)
	#define SD_RCV_DATA_DLY_TIMEOUT_CNT			(20 * DELAY_10MS_TIMEOUT_CNT) //22  //��������copyʱƽ��timer����Լ10us // (1 ~ 65535)ÿ�����ݵ��delayʱ�䣨����С��250ms��  
	#define SD_CMD12_STOP_DLY_TIMEOUT_CNT		(20 * DELAY_10MS_TIMEOUT_CNT) //22	//������copyʱƽ��timer����ԼΪ8us,cmd12��ʱ�����ʵ��ӳ�
#endif
#define DEBUGTIME		(22 * DELAY_10MS_TIMEOUT_CNT)
#define	CMD12_STOP_EXTRN_DLY_TIMES_IN_TIMEOUT		0			 // n * SD_CMD12_STOP_DLY_TIMEOUT_CNT
//-----------------------------------------------------------------------------------------------------------------------------------------------------------

//sd high speed cache buf define  //ע��buf�ı߽��Լ�������,����buf��ʱ�򣬿ɶ����ڳ���������ַ�ķ�Χ֮��
#define	SD_HS_CACHE_BUF_START_ADDR	    (0x5000UL) //0x4108//(0x4748+0x1C0-1024*2)//0x4000//0x3500//20	//high speed cache buf start address
#define SD_HS_CACHE_BUF_USE_DLY_CNT   	1    //6//5	 //����n��buf��Ϊdly buf,��delay (n+1)*250ms( 0 < n < max_cache_buf_cnt) 

#if BAUDRATE
	#define SD_HS_CACHE_BUF_USE_CACHE_CNT 	2		//�����������ݻ���buf,��С��1
#else 
	#if EN_CPRM
	#define SD_HS_CACHE_BUF_USE_CACHE_CNT 	3		//�����������ݻ���buf,��С��1
	#else 
	#define SD_HS_CACHE_BUF_USE_CACHE_CNT 	6		//�����������ݻ���buf,��С��1
	#endif
#endif

#define	SD_HS_CACHE_BUF_CNT		   		(SD_HS_CACHE_BUF_USE_CACHE_CNT + SD_HS_CACHE_BUF_USE_DLY_CNT)				//high speed cache buf count		

//-----------------------------------------------------------------------------------------------------------------------------------------------------------
#define  SD_HS_CACHE_BUF_LBA_START_ADDR	(SD_HS_CACHE_BUF_START_ADDR + SD_HS_CACHE_BUF_CNT * 512)	//LBA
#define	 SD_HW_DMA_IN_BUF_LBA_TAB_START_ADDR	(SD_HS_CACHE_BUF_START_ADDR + SD_HS_CACHE_BUF_CNT * 512 + SD_HS_CACHE_BUF_CNT * 4) //VIRTUAL LBA
#define SD_HW_DMA_OUT_BUF_TAB_START_ADDR 	 (SD_HW_DMA_IN_BUF_LBA_TAB_START_ADDR + SD_HS_CACHE_BUF_CNT * 4)
#define	 SD_VIRTUAL_BUF_LBA_START_ADDR     (SD_HW_DMA_OUT_BUF_TAB_START_ADDR + READ_BUF_NUM * 4)   //��������λ��,��֪��Ϊʲô����ǰ�����5����4����������4Ҳ����

//-----------------------------------------------------------------------------------------------------------------------------------------------------------

#if EN_VIRTUAL_BUF
		#define	SD_VIRTUAL_BUF_CNT						(/*128*/NF_LG_WORD_LINE_NUMBER) //40  //(VIRTUAL_BUF_MAX_NF_LG_PAGE_CNT * 2 / 3) 	//�����ڴ��buf cnt	
#if DYNAMIC_VIRTUAL_SECTOR
		#define	VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE 		3 //SD_HS_CACHE_BUF_CNT												//timeout�Ժ�,ÿ��page�����Ч���ݵĵ�sector
#else
		#define	VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE 		1    //SD_HS_CACHE_BUF_CNT												//timeout�Ժ�,ÿ��page�����Ч���ݵĵ�sector
#endif
		//���defineֵ
		#if (VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE > SD_HS_CACHE_BUF_CNT)
			Error: Define parameter err, VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE <=  SD_HS_CACHE_BUF_CNT is ok.
		#endif
#else

	#define	SD_VIRTUAL_BUF_CNT							1
	#define	VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE 			1

#endif
//�˴�world line����sectors in page������Ҫ���ڣ����������������Ĳ���
#define	NF_LG_WORD_LINE_NUMBER							44 /*Ҫ��virtual cntY*/		 //���ֵΪNAND.H��WORD_LINE_NUMBER
#define	SAVE_IN_SAVE_VIRTUAL_BUF_DATA_2_NF_BUF_OFFSET		0		 //copy����buf��Ҫ��������ݵ���NF buf offset��ʼ��λ�ã��ܿ�buf0��buf1���л�ӳ�����ռ��2��buf��Ϊ���ݻ���,����������ݸ��ǵ����� ��
#define	SAVE_CTL_VIRTUAL_BUF_VAR_2_NF_BUF								VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE		 //����buf����Ӧ�Ŀ��Ʊ��������ڵ�n��nf buf�У����ڵ���ָ�	
#define	SAVE_VIRTUAL_BUF_MAP_LBA_TAB_2_NF_BUF						(VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE+1)		 //����buf�ж�Ӧ����LBA TAB �洢�ڵ�n��nf buf�� 
#define	VIRTUAL_BUF_READ_MAX_SECS_IN_PER_PAGE						(VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE+2)		 //����buf����DMA������sector����Ӧ��VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE����Ӧ��ͬ��VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE+2
//�ܵĸ���������,virtual cnt������char��
//-----------------------------------------------------------------------------------------------------------------------------------------------------------
	
//sd high speed cache buf ��Ӧ��DMA adrress
#if (SD_HS_CACHE_BUF_CNT == 1)	
	#define	SD_HS_CACHE_DMA_ADDR_BUF_0	((SD_HS_CACHE_BUF_START_ADDR + 512 * 0) / 4)

#elif (SD_HS_CACHE_BUF_CNT == 2)	
	#define	SD_HS_CACHE_DMA_ADDR_BUF_0	((SD_HS_CACHE_BUF_START_ADDR + 512 * 0) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_1	((SD_HS_CACHE_BUF_START_ADDR + 512 * 1) / 4)

#elif (SD_HS_CACHE_BUF_CNT == 3)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_0	((SD_HS_CACHE_BUF_START_ADDR + 512 * 0) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_1	((SD_HS_CACHE_BUF_START_ADDR + 512 * 1) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_2	((SD_HS_CACHE_BUF_START_ADDR + 512 * 2) / 4)

#elif (SD_HS_CACHE_BUF_CNT == 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_0	((SD_HS_CACHE_BUF_START_ADDR + 512 * 0) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_1	((SD_HS_CACHE_BUF_START_ADDR + 512 * 1) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_2	((SD_HS_CACHE_BUF_START_ADDR + 512 * 2) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_3	((SD_HS_CACHE_BUF_START_ADDR + 512 * 3) / 4)

#elif (SD_HS_CACHE_BUF_CNT == 5)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_0	((SD_HS_CACHE_BUF_START_ADDR + 512 * 0) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_1	((SD_HS_CACHE_BUF_START_ADDR + 512 * 1) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_2	((SD_HS_CACHE_BUF_START_ADDR + 512 * 2) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_3	((SD_HS_CACHE_BUF_START_ADDR + 512 * 3) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_4	((SD_HS_CACHE_BUF_START_ADDR + 512 * 4) / 4)

#elif (SD_HS_CACHE_BUF_CNT == 6)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_0	((SD_HS_CACHE_BUF_START_ADDR + 512 * 0) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_1	((SD_HS_CACHE_BUF_START_ADDR + 512 * 1) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_2	((SD_HS_CACHE_BUF_START_ADDR + 512 * 2) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_3	((SD_HS_CACHE_BUF_START_ADDR + 512 * 3) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_4	((SD_HS_CACHE_BUF_START_ADDR + 512 * 4) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_5	((SD_HS_CACHE_BUF_START_ADDR + 512 * 5) / 4)

#elif (SD_HS_CACHE_BUF_CNT == 7)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_0	((SD_HS_CACHE_BUF_START_ADDR + 512 * 0) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_1	((SD_HS_CACHE_BUF_START_ADDR + 512 * 1) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_2	((SD_HS_CACHE_BUF_START_ADDR + 512 * 2) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_3	((SD_HS_CACHE_BUF_START_ADDR + 512 * 3) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_4	((SD_HS_CACHE_BUF_START_ADDR + 512 * 4) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_5	((SD_HS_CACHE_BUF_START_ADDR + 512 * 5) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_6	((SD_HS_CACHE_BUF_START_ADDR + 512 * 6) / 4)

#elif (SD_HS_CACHE_BUF_CNT == 8)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_0	((SD_HS_CACHE_BUF_START_ADDR + 512 * 0) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_1	((SD_HS_CACHE_BUF_START_ADDR + 512 * 1) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_2	((SD_HS_CACHE_BUF_START_ADDR + 512 * 2) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_3	((SD_HS_CACHE_BUF_START_ADDR + 512 * 3) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_4	((SD_HS_CACHE_BUF_START_ADDR + 512 * 4) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_5	((SD_HS_CACHE_BUF_START_ADDR + 512 * 5) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_6	((SD_HS_CACHE_BUF_START_ADDR + 512 * 6) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_7	((SD_HS_CACHE_BUF_START_ADDR + 512 * 7) / 4)

#elif (SD_HS_CACHE_BUF_CNT == 9)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_0	((SD_HS_CACHE_BUF_START_ADDR + 512 * 0) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_1	((SD_HS_CACHE_BUF_START_ADDR + 512 * 1) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_2	((SD_HS_CACHE_BUF_START_ADDR + 512 * 2) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_3	((SD_HS_CACHE_BUF_START_ADDR + 512 * 3) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_4	((SD_HS_CACHE_BUF_START_ADDR + 512 * 4) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_5	((SD_HS_CACHE_BUF_START_ADDR + 512 * 5) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_6	((SD_HS_CACHE_BUF_START_ADDR + 512 * 6) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_7	((SD_HS_CACHE_BUF_START_ADDR + 512 * 7) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_8	((SD_HS_CACHE_BUF_START_ADDR + 512 * 8) / 4)

#elif (SD_HS_CACHE_BUF_CNT == 10)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_0	((SD_HS_CACHE_BUF_START_ADDR + 512 * 0) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_1	((SD_HS_CACHE_BUF_START_ADDR + 512 * 1) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_2	((SD_HS_CACHE_BUF_START_ADDR + 512 * 2) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_3	((SD_HS_CACHE_BUF_START_ADDR + 512 * 3) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_4	((SD_HS_CACHE_BUF_START_ADDR + 512 * 4) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_5	((SD_HS_CACHE_BUF_START_ADDR + 512 * 5) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_6	((SD_HS_CACHE_BUF_START_ADDR + 512 * 6) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_7	((SD_HS_CACHE_BUF_START_ADDR + 512 * 7) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_8	((SD_HS_CACHE_BUF_START_ADDR + 512 * 8) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_9	((SD_HS_CACHE_BUF_START_ADDR + 512 * 9) / 4)

#elif (SD_HS_CACHE_BUF_CNT == 11)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_0	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 0)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_1	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 1)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_2	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 2)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_3	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 3)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_4	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 4)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_5	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 5)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_6	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 6)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_7	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 7)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_8	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 8)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_9	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 9)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_10  ((SD_HS_CACHE_BUF_START_ADDR + 512 * 10) / 4)

#elif (SD_HS_CACHE_BUF_CNT == 12)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_0	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 0)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_1	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 1)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_2	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 2)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_3	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 3)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_4	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 4)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_5	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 5)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_6	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 6)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_7	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 7)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_8	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 8)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_9	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 9)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_10  ((SD_HS_CACHE_BUF_START_ADDR + 512 * 10) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_11  ((SD_HS_CACHE_BUF_START_ADDR + 512 * 11) / 4)

#elif (SD_HS_CACHE_BUF_CNT == 13)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_0	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 0)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_1	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 1)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_2	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 2)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_3	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 3)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_4	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 4)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_5	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 5)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_6	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 6)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_7	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 7)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_8	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 8)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_9	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 9)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_10  ((SD_HS_CACHE_BUF_START_ADDR + 512 * 10) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_11  ((SD_HS_CACHE_BUF_START_ADDR + 512 * 11) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_12  ((SD_HS_CACHE_BUF_START_ADDR + 512 * 12) / 4)

#elif (SD_HS_CACHE_BUF_CNT == 14)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_0	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 0)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_1	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 1)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_2	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 2)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_3	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 3)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_4	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 4)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_5	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 5)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_6	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 6)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_7	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 7)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_8	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 8)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_9	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 9)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_10  ((SD_HS_CACHE_BUF_START_ADDR + 512 * 10) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_11  ((SD_HS_CACHE_BUF_START_ADDR + 512 * 11) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_12  ((SD_HS_CACHE_BUF_START_ADDR + 512 * 12) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_13  ((SD_HS_CACHE_BUF_START_ADDR + 512 * 13) / 4)

#elif (SD_HS_CACHE_BUF_CNT == 15)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_0	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 0)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_1	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 1)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_2	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 2)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_3	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 3)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_4	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 4)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_5	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 5)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_6	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 6)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_7	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 7)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_8	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 8)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_9	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 9)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_10  ((SD_HS_CACHE_BUF_START_ADDR + 512 * 10) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_11  ((SD_HS_CACHE_BUF_START_ADDR + 512 * 11) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_12  ((SD_HS_CACHE_BUF_START_ADDR + 512 * 12) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_13  ((SD_HS_CACHE_BUF_START_ADDR + 512 * 13) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_14  ((SD_HS_CACHE_BUF_START_ADDR + 512 * 14) / 4)

#elif (SD_HS_CACHE_BUF_CNT == 16)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_0	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 0)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_1	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 1)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_2	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 2)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_3	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 3)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_4	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 4)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_5	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 5)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_6	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 6)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_7	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 7)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_8	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 8)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_9	 ((SD_HS_CACHE_BUF_START_ADDR + 512 * 9)  / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_10  ((SD_HS_CACHE_BUF_START_ADDR + 512 * 10) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_11  ((SD_HS_CACHE_BUF_START_ADDR + 512 * 11) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_12  ((SD_HS_CACHE_BUF_START_ADDR + 512 * 12) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_13  ((SD_HS_CACHE_BUF_START_ADDR + 512 * 13) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_14  ((SD_HS_CACHE_BUF_START_ADDR + 512 * 14) / 4)
	#define	SD_HS_CACHE_DMA_ADDR_BUF_15  ((SD_HS_CACHE_BUF_START_ADDR + 512 * 15) / 4)

#else
	... //���������������������ʾ�������Ӷ���
#endif

	 
//SD rcv data state machine
#define	HS_RCV_DATA_IN_IDLE							0
#define	HS_RCV_DATA_IN_ING							1
#define	HS_RCV_DATA_IN_STOP							2
#define	HS_RCV_DATA_IN_STOP_DLY						3
#define	HS_RCV_DATA_IN_END							4

//Hs buf data write to flash state machine
#define	W_HS_DATA_TO_FLASH_IDLE						0
#define	W_HS_DATA_TO_FLASH_WAIT_READY				1
#define	W_HS_DATA_TO_FLASH_ING						2
#define	W_HS_DATA_TO_FLASH_END						3

//Hs buf data write to virtual sd buf state machine
#define W_VIRTUAL_SD_BUF_DATA_TO_NF_IDLE			0
#define W_VIRTUAL_SD_BUF_DATA_TO_NF_ING				1
#define W_VIRTUAL_SD_BUF_DATA_TO_NF_NEXT  		2
#define W_VIRTUAL_SD_BUF_DATA_TO_NF_NEXT2			3  
#define W_VIRTUAL_SD_BUF_DATA_TO_NF_END				4
/**********************************************************************************************************************************************************
* 
* 
*
**********************************************************************************************************************************************************/
  #define     Idle_Task			                    0    												
  #define     READ_SCR_Task                         1
  #define     Single_Read_Task                      2
  #define     Security_Mul_Read_Task                3
  #define     Mul_Read_Task                         4
  #define     SD_State_Task                         5
  #define     SD_Fun_Task                           6
  #define     Get_WellWR_Task                       7
  #define     WP_STATE_Task                         8  
  #define     GEN_CMD_Read_Task                     9
  #define     MID_Task                              10
  #define     MKB_Task                              11
  #define     RCV_AKE_CHLG_1_Task                   12
  #define     RCV_AKE_CHLG_2_RPS_Task               13
  #define     SEND_AKE_CHLG_2_Task                  14
  #define     SEND_AKE_CHLG_1_RPS_Task              15
  #define     Change_Pro_Area_Task                  16
  #define     Update_MKB_Task                       17
  #define     Single_Write_Task                     18
  #define     Mul_Write_Task                        19
  #define     Security_Erase_Task                   20
  #define     Erase_Task                            21
  #define     Pro_CSD_Task                          22
  #define     GEN_CMD_Write_Task                    23
  #define     Secutity_Mul_Write_Task               24

//SPI TASK
  #define	  READ_CID_Task							25
  #define	  READ_CSD_Task							26

/**********************************************************************************************************************************************************
* 
* SD ״̬��
***********************************************************************************************************************************************************/
  #define	  SD_STATE_IN_IDLE						0
  #define	  SD_STATE_IN_READY						1
  #define	  SD_STATE_IN_IDENT						2
  #define	  SD_STATE_IN_STBY						3
  #define	  SD_STATE_IN_TRAN						4
  #define	  SD_STATE_IN_DATA						5
  #define	  SD_STATE_IN_RCV					    6
  #define	  SD_STATE_IN_PRG						7
  #define	  SD_STATE_IN_DIS						8
  #define	  SD_STATE_IN_INA						9

/**********************************************************************************************************************************************************
* 
* ����singl/mul write������dma in����
***********************************************************************************************************************************************************/
 #define	  EXTERN_NO_DMA_IN_TASK					0
 #define	  EXTERN_DMA_IN_PRG_CSD					1
 #define	  EXTERN_DMA_IN_ERASE_DATA				2

/**********************************************************************************************************************************************************
* 
* �Զ���ĺ�
***********************************************************************************************************************************************************/

#define disable_dma_in_isr()	(SDIIE = 0)
#define enable_dma_in_isr()		(SDIIE = 1)	

#define PUSH_R8_ER2_ER3		(IE2 |= (1 << 6))
#define POP_R8_ER2_ER3		(IE2 |= (1 << 7))

#define MIN(dat0, dat1)		(dat0 < dat1 ? dat0 : dat1)

#endif