#ifndef _extern_data_h_
#define _extern_data_h_

extern unsigned char data LargePagePerBlockH        ; 
extern unsigned short data WordLineNumberTLC	        ;
extern unsigned char data SectorPerSmallPage        ;

extern unsigned char idata SDBufBlockAddrH           ;
extern unsigned char idata SDBufBlockAddrL           ;
extern unsigned char idata SDBufPageAddr             ;
extern unsigned char data SdDmaReadLBACnt           ;                      
extern unsigned char data CurLg2PhTableAddrH        ;
extern unsigned char data CurLg2PhTableAddrL        ;
extern unsigned char data LargePagePerBlockL        ;
extern unsigned char data PlaneNum                  ;                          	                             
extern unsigned char data RdCurZone                 ;
extern unsigned char data BlockAddrTmpH             ;
extern unsigned char data BlockAddrTmpL             ;
extern unsigned char data BlankBlockIndexH          ;
extern unsigned char data BlankBlockIndexL          ;
extern unsigned char data KeepSWAPIndex             ;
extern unsigned char data SpareAreaH                ;
extern unsigned char data SpareAreaL                ;
extern unsigned char data ReadLBACnt                ;
extern unsigned char data HalfSectorPerSmallPage    ;

extern unsigned char data ProgramCMD1               ;
extern unsigned char data BBTIndex                  ;
extern unsigned char data CacheBlockLgPageNumL      ;
extern unsigned	short data WORD_LINE_NUMBER					;                                                    
extern unsigned char data ZoneLBA                   ;             
extern unsigned char data DataCoDecKeyIndex1        ;
extern unsigned char data DataCoDecKeyIndex         ;
extern unsigned char data BBTBlockIndex             ;                                              
extern unsigned char data PageLBAH                  ;                                                   
extern unsigned int  idata RetryCnt                 ;

extern volatile unsigned char data NfEmptyBufCnt             ;
extern unsigned char data SectorPerSmallPageTotal   ;                                                    
extern unsigned short data WordLineNumber           ;                                                 
//extern unsigned char data BankSwitchUsed          ;                                                    
extern unsigned char data PlanRcvSDDataCnt          ;

extern unsigned char data ActualRcvSDDataCnt        ;	
extern unsigned char data PageGroupNumber     	    ;
extern unsigned char data CopyWLNumber     	        ;
extern unsigned char data OrderAddr                 ; 
extern unsigned int idata OrderTotal                ; 
extern unsigned char data SpareArea2                ;
extern unsigned char data SectorNum                 ;
extern unsigned char data FlashType                 ;
extern unsigned char data FlashReTryType            ;
extern unsigned char data yBuffer_Index_Start       ;
extern unsigned char data ReadLBAIndex              ;
extern unsigned char data WriteLBAIndex	  	        ;
extern unsigned char data FlashIndex                ;
extern unsigned char data SWAPIndex	  	            ;
extern unsigned char data SWAPIndexTmp	  	        ;
extern unsigned char data yBuffer_Index             ;
                                                    
extern volatile unsigned char data NfEmptyBufCntTmp          ;
extern unsigned char data Lg2PhTableAddrL           ;

                                                    
extern unsigned char data PageLBAL                  ;
extern unsigned char data ProgramCMD0               ;
extern unsigned char data SectorInLargePage	        ;                                                    
extern unsigned char data R8Tmp                     ;
extern unsigned char data ProgramCMD2               ;
extern unsigned char data BECNTTmp                 ;
extern unsigned char data CacheBlockNextPagePhAddrH ;
extern unsigned char data CacheBlockLgPageNumH      ;
extern unsigned char data BlockLBAH                 ;
extern unsigned char data BlockLBAL                 ;
extern unsigned char data OldBlockPhAddrH           ;
extern unsigned char data OldBlockPhAddrL           ;
extern unsigned char data BlockLgAddrH              ;
extern unsigned char data BlockLgAddrL              ;
extern unsigned char data NewBlockPhAddrH           ;
extern unsigned char data NewBlockPhAddrL           ;
extern unsigned char data RandomIndex               ;
extern unsigned char data SWAPIndexTmp1             ;
extern unsigned char data CacheBlockNextPagePhAddrL ;
extern unsigned char data BitData                   ;
extern unsigned char data FunctionCfg               ;
extern bit bSLC2TLCProg        		    ;
extern bit bTerribleError      		    ;
extern bit bRcvSDDataKickStart 		    ;
extern bit b2PlaneTrue         		    ;
extern bit bNoNeedGetLgAddr    		    ;
extern bit bLg2PhVerifyError   		    ;
extern bit bNeedChkBlockPageModeIndex	;
extern bit bWriteLastLgPage    		    ;	
extern bit bProgCacheBlockPageTrue ;
extern bit bOldBlockNotTrue        ;
extern bit bStr_MulRead_SD         		;
extern bit bReadBlankBlock_0       		;
extern bit bRwDataBlockSpareArea   		;
extern bit bCopyBackNotOver        		;
extern bit bEraseCacheBlock        		;
extern bit bPageGroupSLC           		;
extern bit  bEnReadLBACnt          		;
extern bit  bWriteLastButOneLgPage 		;
extern bit  bBlockMode             		;
extern bit  btmp                   		;
extern bit  bCopyStart          			;
extern bit  bCopyNeedStop       			;
extern bit  bWriteLastCachePage 			;
extern bit  bSDStop            				;
extern bit  bDataEncodeTure     			;
extern bit  bNeedRetryTrue      			;
extern bit  bReadingCacheBlock  			;
extern bit  bRetryBlockMode     			;
extern bit  bPlaneMag              		;
extern bit  bNeedSend5DCMDTLC      		;
extern bit  bEnReleaseNfBufRcvData 		;
extern bit  bReadBlankBlock        		;
extern bit  bFlashRetryTimeOut     		;
extern bit  bCacheCmd            			;
extern bit  bNeedSend5DCMDSLC    			;
extern bit  bToggleTrue          			;
extern bit  bCopyBackNeedReWrite ;
extern bit  bNeedRandomizer      ;
extern bit  lastCmdProgPage				;
extern unsigned char idata R3_BlockAddrH;
extern unsigned char idata R2_BlockAddrL;
extern unsigned char idata R3_BlockAddrH_P1;
extern unsigned char idata R2_BlockAddrL_P1;

extern unsigned char idata R4_PageAddrH;
extern unsigned char idata R0_PageAddrL;
extern unsigned char idata R1_Sector,R1_SectorTmp,DelayCopyCnt;
	 							  									
extern unsigned char idata host_to_sd_buf_ptr       ;
extern unsigned char idata sd_to_nf_buf_ptr         ;
extern unsigned char idata sd_ready_for_nf_buf_cnt  ;

extern unsigned char idata virtual_sd_data_buf_cnt  ;				
extern unsigned char idata hs_to_virtual_buf_ptr    ;
extern unsigned char idata virtual_to_nf_buf_ptr    ; 
extern unsigned char idata virtual_to_nf_buf_in_per_page_sector_ptr ;		 

extern unsigned char idata virtual_sd_buf_map_w_nf_page_ptr;
extern unsigned char idata virtual_sd_buf_map_r_nf_page_ptr;

extern unsigned char idata dma_out_r_cur_virtual_buf_map_r_nf_page_ptr;	  		
extern unsigned char idata dma_out_r_cur_virtual_buf_map_r_nf_sec_in_page_ptr;	  	
extern unsigned char code _DEFAULT_TOGGLE;

#endif