#ifndef	_sd_bank_1_h_
#define _sd_bank_1_h_




extern unsigned char code SD_KICK_DMA_OUT_ER0_COPY,  SD_KICK_DMA_OUT_ER1_COPY;
extern unsigned char code _PagePhAddr_Buf;
extern unsigned char code sd_hs_cache_data_buf_lba[SD_HS_CACHE_BUF_CNT][4];
extern unsigned char code COPYLBA_M_TMP;
extern unsigned char code NF_SECTOR_SIZE_TAB;

extern unsigned char data yCMD_Index;

extern bit bSDHC,bCMD8Rcv,READY_FOR_DATA,bFirstActive,bNandPowerup,bCMDRps_Flag,bCMD0Rcv,bDataStop_Flag,bRcvCMD7InDataOrDisState,bVisitCprmDataMode;
extern bit bSingleReadTask,bReadType,bMulRFlag,bStopEn,bCprmDmaDataMode,bWriteType,bDataIn_Flag,bSingleWriteTask,bInEraseTask,bStopMulWriteData;
extern bit bMulWriteTask,bStopRcvCprmData,bSwitch50M,bTmpWriteProtect,WP_ERASE_SKIP,bStr_MulRead,bStr_MulRead_SD,bBlockLenLess512Byte;
extern bit bStr_MulWrite,bCallWriteLBA, bInWriteLbaFun;
extern bit bAKERcvType,bAKEVerifyErr;
extern bit bDataOut_Flag;
extern bit bLbaSeq, bReadDataInHsBuf, bForceDly, bReadDataInVirtualBuf;
extern bit bCopyBackNotOver, bCopyNeedStop, bLastReadDataInHsBuf; 
extern bit bRcvSDDataKickStart;
extern bit bSDStop, bEnReadLBACnt;
extern bit bEnVirtualBuf2Nf;
extern bit bReadNeedChkBankBlk, bNfInReadLbaFun, bSendReadRandomCmd;
extern bit bReadNewBlockTrue;
extern bit bSDStop;
extern bit bInReadLba;
extern u8 data ReadLBACnt;
extern u8 data NfEmptyBufCnt;
extern unsigned char bdata bCPRMFlag;
extern u8 data yBlockLen1,yBlockLen0,yTast_Index,LBATmp0,LBATmp1,LBATmp2,LBATmp3,yBufIndexCopyTmp,yBuffer_Index,yScrtyUnitCnt;
extern u8 data RdCurZone;
extern u16 idata u16RCA;


extern unsigned char idata last_lba[4];
extern unsigned char data PlanRcvSDDataCnt, ActualRcvSDDataCnt, yBuffer_Index_Start;
extern unsigned char idata virtual_sd_data_buf_cnt, hs_to_virtual_buf_ptr, virtual_to_nf_buf_ptr, write_virtual_sd_buf_data_to_nf_state;
extern unsigned char idata virtual_sd_buf_map_w_nf_page_ptr, virtual_sd_buf_map_r_nf_page_ptr;
extern unsigned char idata u8_pwr_active_cnt, SDBufPageAddr;
extern unsigned char idata virtual_to_nf_buf_in_per_page_sector_ptr;
extern unsigned char data yBuffer_Index_Start, ActualRcvSDDataCnt, PlanRcvSDDataCnt;
extern unsigned char idata copy_last_virtual_sd_data_buf_cnt;
extern unsigned char idata write_hs_data_to_flash_state;
extern unsigned char idata dma_out_r_cur_virtual_buf_map_r_nf_page_ptr, dma_out_r_cur_virtual_buf_map_r_nf_sec_in_page_ptr;


extern unsigned char code sd_virtual_data_buf_lba[][4];
extern unsigned char code sd_virtual_data_buf_cnt[];
extern bit bSdDmaOutUseAllBuf;
extern unsigned char idata  yBufIndexStartCopy;
extern unsigned char idata host_to_sd_buf_ptr, sd_ready_for_nf_buf_cnt , sd_to_nf_buf_ptr;
extern unsigned char idata R3_BlockAddrH;
extern unsigned char idata R2_BlockAddrL;
extern unsigned char idata R4_PageAddrH;
extern unsigned char idata R0_PageAddrL;
extern unsigned char idata R1_Sector,R1_SectorTmp;

unsigned char idata SdReadDmaAddrH, SdReadDmaAddrL;

extern void get_lba(void);

extern void read_sdbuf_block(void);
extern void Sel_Buffer_Addr(void);
extern void check_addr_out_of_range(void);
extern void wait_cmd_rps_ready(void);
extern void get_bound_block(void);

extern void copy_512byte_data(unsigned char src_buf_index, unsigned char target_buf_index);
extern void sel_dma_addr(void);
extern void cur_map_lba_inc(void);
extern void change_state_machine_in_data_state(void);
extern void cprm_en_de_code_buf_point_to_cur_buf(void);

extern void Get_RdCurZone_Lg2PhTable(void);
extern void Get_OldBlockPhAddr(void);
extern void Get_WritingBlockBuf_BlockLgAddrH_INDEX(void);
extern void Read_WritingBlockBuf(void);
extern void Get_Block_WL_Stage_Addr(void);
extern void timer_tick_clr(void);
extern void NF_Read_Start(void);
extern void NF_Read_Data(void);
extern void Chk_Blank_Block(void);
extern void Get_LgAddr(void);
extern void BCH_MODE_DC_Wait_Over(void);
extern void Buf_Data_CoDec(void);
extern void Chk_Data(void);
extern void Set_Retry_Register_Data(void);
extern void sd_pre_read_config(u8 buf_start_index);
extern void reset_bch(void);
extern void wait_dma_out_read_buf_empty(void);
extern void xrl_p3(u8 dat);
extern void Copy_Back_Prepare(void);
static void Set_Retry_Register_Offset_Data(void);
static void get_readaddr(void);
static void Set_Retry_Register_Default_Data(void); 
static void	cprm_encode_data(void);
static void	Write_WritingBlockBuf(void);
void read_lba(void);
extern void NF_Reset(void);
extern void clear_writting_buf_cache_block(void);
extern void NF_Erase_Block(void);
void Chk_Need_Retry(void);



#endif