//shaya add
#ifndef _PRINTF_H
#define _PRINTF_H

#include "inc\sd_spi_com_define.h" 	

#if 0//BAUDRATE

	#define	printf	min_printf  
	void printf(char * fmt, ...);
	
	#define	printf_buf printf_buf_fun
	void printf_buf(unsigned char xdata *ptr, unsigned short len);
	
#else

	#define	printf
	#define	printf_buf printf_buf_fun
#endif

#endif

