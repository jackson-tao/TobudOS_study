#ifndef _power_up_c_h_
#define _power_up_c_h_



extern unsigned char code _FLASH_CHIPNUM, _FLASH_RWCYCLE, _FLASH_BITDATA, _FLASH_FUNCTIONEXT, _FLASH_TWOPLANEMODE, NF_SECTOR_SIZE_TAB ,_FLASH_RetryTypes ,_FLASH_SYSCLKRE,_FLASH_SHIFTCNT,_FLASH_WLNUMH,_FLASH_WLNUML,_FLASH_TYPE; 
extern unsigned char code _FLASH_SECTORPERSMLPAGEPLN5;
extern unsigned char code FirstValidZone, SdVirtualBuf2NfUseMaxPage, SdVirtualBuf2NfUseMaxSector, _ZoneLgBlockNumBuf, _PageLg2PhTable;
extern unsigned char code _PageLg2PhTable_SLC_Plane1, _BadBlockAddrTable, _FLASH_BCMCfg_ADDR_Plane1_StartAddr, Reserved_Blocks_Buf;
extern unsigned char code PLANE_REFERENCE,_Fill_Sec_Gap_P0,_Fill_Sec_Gap_P1,_Fill_Sec_Gap_P2,_Fill_Sec_Gap_P3;
extern unsigned char code _PageLg2PhTable,_PageLg2PhTable_SLC_Plane3;
extern unsigned char code _PageLg2PhTable_Plane2, _PageLg2PhTable_Plane3, _PLANE_MODE;
extern unsigned char idata bin_level;
extern unsigned char idata ecc_encode_bits,BlockLBAHTmp,BlockLBALTmp;
extern unsigned int idata Order,PlanCopyBackNum;
extern unsigned int idata CacheLgPage;
extern unsigned char idata specialBit;
extern unsigned char code MAP_BOUNDARY;
extern void BCH_Config_Decode1time(void);
extern void Get_CurPlaneCfg(void);
extern void Read_WritingBlockBuf(void);
extern void Get_ZoneLBA(void);
extern void Get_OldBlockPhAddr(void);
extern void Write_WritingBlockBuf(void);
extern void Get_CacheBlock_Addr(void);
extern void Get_PagePh2LgTable_StartAddr(void);
extern void Set_Page_PhAddr(void);
extern void NF_Read_Start(void);
extern void NF_Read_Data(void);
extern void Chk_Blank_Block(void);
extern void BCH_MODE_DC_Wait_Over(void);
extern void Set_Retry_Register_Data(void);
extern void Mark_A_Blank_Block(void);
extern void NF_Erase_Block(void);
extern void Write_a_Block_Over(void);
extern void Updata_WrLg2phTable(void);
extern void chk_slcMode_switch(void);
extern void get_bound_block(void);
extern void Get_Page_PhAddr(void);
static void NF_Reset_CE(void);
static void NF_Reset(void);
static void PowerUp_NF_Get_Feature(void);
static void PowerUp_NF_Set_Feature(void);
static void NF_Read_ID(void);
static void NF_Init(void);
static void Chk_PageLg2PhTable(void);
static void Get_BCM_Table(void);
static void Init_WrLg2phTable(void);
static void Get_BBTBlock(void);
static void Update_BBT(void);
static void Find_Reserved_Blocks(void);
static void Fix_WritingBlockBuf(void);
static void Fix_TimingBuf(void);
static void Fix_Lg2PhTable(void);
static void INTIAL_SD_BUF_2_NF_USE_MAX_PAGE(void);
static void Fix_OldBlock_NewBlock_CacheBlock(void);
static void Update_CacheBlockNextPagePhAddr(void);
static void Update_NewBlockNextPagePhAddr(void);
static void PowerUp_Read_Sector(void);
static void Chk_Need_Retry(void);
static void NF_Read_BadBlockTable(void);
static void Find_DATA_BLOCK(void);
static void Find_DATA_CACHE_BLOCK(void);
static void Chk_WritingBlockBuf_BlockLgAddr(void);
static void Update_PageLg2PhTable(void);
static void bch_initial(void);
extern void get_bound_block(void);
void nf_power_up(void);



#endif