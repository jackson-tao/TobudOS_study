#ifndef _lg2ph_c_h_
#define _lg2ph_c_h_



extern void NF_Erase_Block(void);
extern void get_bound_block(void);

void Get_Lg2phIndex_Addr(void);
void Read_Lg2ph_ZoneLBA(void);
void Write_Lg2ph_ZoneLBA(void);
void Erase_Old_Lg2ph_ZoneLBA(void);
void Find_A_Blank_Block(void);
void Mark_A_Blank_Block(void);
extern void Get_Block_PhAddr(void);
extern void Set_Block_PhAddr(void);



#endif