#ifndef	_sd_bank_2_h_
#define _sd_bank_2_h_

extern bit bInEraseTask, bEnVirtualBuf2Nf, bSendReadRandomCmd;

extern bit bRcvSDDataKickStart, bInWriteLbaFun, bStr_MulWrite, bCallWriteLBA, bTmpWriteProtect, WP_ERASE_SKIP;
extern bit bSdDmaOutUseAllBuf, bBlockLenLess512Byte, bReadDataInHsBuf, bLbaSeqInHsBuf, bTimeout, bReadDataInVirtualBuf;
extern unsigned char idata host_to_sd_buf_ptr, sd_ready_for_nf_buf_cnt , sd_to_nf_buf_ptr;
extern unsigned char idata virtual_sd_buf_map_w_nf_page_ptr, virtual_sd_buf_map_r_nf_page_ptr;
extern unsigned char idata R3_BlockAddrH;
extern unsigned char idata R2_BlockAddrL;
extern unsigned char idata R4_PageAddrH;
extern unsigned char idata R0_PageAddrL,R1_Sector, R1_SectorTmp;
extern unsigned char idata BlockLBAHTmp,BlockLBALTmp;
extern unsigned int idata /*Order,*/PlanCopyBackNum;
extern unsigned int idata CacheLgPage;
extern unsigned char idata specialBit;

extern u8 data RdCurZone;
extern unsigned char  data boundIndex;
extern u8 data yBlockLen1,yBlockLen0,yTast_Index,LBATmp0,LBATmp1,LBATmp2,LBATmp3,yBufIndexCopyTmp,yBuffer_Index,yScrtyUnitCnt;
extern unsigned char idata virtual_sd_data_buf_cnt, hs_to_virtual_buf_ptr, virtual_to_nf_buf_ptr, write_virtual_sd_buf_data_to_nf_state;
extern unsigned char data PlanRcvSDDataCnt, ActualRcvSDDataCnt, yBuffer_Index_Start;
extern volatile u8 data NfEmptyBufCnt;
extern u8 code CacheBlockMaxPageH,CacheBlockMaxPageL;

extern void bit_cal(void);
extern void bit_search(void); 
extern unsigned char code BCH_MODE_EC_TAB;
extern unsigned char code NF_DATA;
extern unsigned char code SdVirtualBuf2NfUseMaxPage, SdVirtualBuf2NfUseMaxSector;
extern unsigned char code sd_hs_cache_data_buf_lba[][4];
extern unsigned char code sd_virtual_data_buf_lba[][4];
extern unsigned char code sd_virtual_data_buf_cnt[];

extern unsigned char code CUR_MAP_LBA;

extern unsigned char idata copy_last_virtual_sd_data_buf_cnt;
extern unsigned char idata status_for_writing_lba_virtual_buf_lba;

extern void set_p1(u8 dat);
extern void clr_p1(u8 dat);
extern void xrl_p1(u8 dat);
extern void xrl_p3(u8 dat);
extern void reset_bch(void);
extern void rcv_one_packet_case_in_pro_state_process(void);
extern void wait_cmd_rps_ready(void);
extern void Sel_Buffer_Addr(void);
extern void get_cur_lba_to_er1(void);
extern void uart_send_byte(unsigned char val);
extern void Get_ZoneLBA(void);
extern void get_bound_block(void);
extern void Change_CE(void);

extern void NF_Prog_Stop(void);
extern void Get_R1_Addr(void);
extern void Prog_CacheBlock_Page(void);
extern void Prog_NewBlock_Page(void);
extern void Write_WritingBlockBuf(void);
extern void Copy_A_Page(void);
extern void Get_LgAddr(void);
extern void Get_WritingBlockBuf_BlockLgAddrH_INDEX(void);
extern void Read_WritingBlockBuf(void);
extern void Get_OldBlockPhAddr(void);
extern void Get_CurPlaneCfg(void);
extern void Get_PagePh2LgTable_StartAddr(void);
extern void Write_a_Block_Over(void);
extern void Updata_WrLg2phTable(void);
extern void SLC_ERASE(void);
extern void Get_Page_PhAddr(void);
extern void Get_Block_WL_Stage_Addr(void);
extern void Read_Sectors(void);
extern void Find_A_Blank_Block(void);
extern void Get_PageLg2PhTable(void);
extern void NF_Read_Start_Copy(void);
extern void NF_Read_Data(void);
extern void BCH_MODE_DC_Wait_Over(void);
extern void Buf_Data_CoDec(void);
extern void Prog_A_Page_CacheBlock(void);
extern void NF_Write_Addr(void);
extern void Get_Config_Data(void);
extern void NF_Prog_Data(void);
extern void NF_Prog_Data_Wait(void);
extern void BCH_Config_Decode1time(void);
extern void NF_Send_CMD0_5ByteAddr(void);
extern unsigned char NF_Read_Status(unsigned char tmp);
extern void NF_Reset(void);
extern void Get_CacheBlock_Addr(void);
extern void NF_Erase_Block(void);
extern void Copy_Back_Prepare(void);
extern void Get_Block_PhAddr(void);
void erase_data_process(void);
void sd_lg_write_data(void);
void chk_writing_lba_and_sd_virtual_buf_lba(void);
void write_lba(void);
static void prepare_write_lba(void);
static void write_lba_cacheblock(void);
static void write_lba_over(void);
static void get_oldest_swapindex(void);
static void chk_need_copyback(void);
static void update_timingbuf(void);
static void get_new_cacheblockphaddr(void);
static void buf_8_to_sectorinlargepage(void);
static void rcv_sd_data_kickstart(void);
static void chk_cacheblock_full(void);
static unsigned char oldblock_newblock_cacheblock_2_newblock(void);
static void Erase_CacheBlockPhAddr(void);
static unsigned char copy_back_0(void);
static void copy_back_2(void);
static void copy_back_1(void);
void clear_writting_buf_cache_block(void);
void wait_rbx_ready(u8 rb);

void Copy_Back_ReWrite_Data(void);
void Copy_Back_Prepare(void);
bit erase_task_parameter_analysis(void);


void write_data_from_hs_buf_to_flash(void);
void mem_set(unsigned char fill_data);
void Copyback_One_Order(void);
#endif