#ifndef _ENLARGE_VAR_H_
#define	_ENLARGE_VAR_H_

#ifdef	 EN_ENLARGE_VERSION

unsigned char bdata addr_0x20_page1 		_at_ 0x20;

sbit bWriteREC_LBA_TAB       	 			= addr_0x20_page1^0;
sbit bResetBuf       	 					= addr_0x20_page1^1;
sbit bRead_0_Sector      					= addr_0x20_page1^2;	 
sbit bH2testwCheckEn       	 				= addr_0x20_page1^3;
sbit bSmartLinkRandomizerDataMode       	= addr_0x20_page1^4;
sbit bOverCapRandomizerDataModeEn       	= addr_0x20_page1^5;
sbit bEnlargeVersion     					= addr_0x20_page1^6;
sbit bEnlargeVerFirstReadLBASearchRecTab	= addr_0x20_page1^7;

//====================================================================================
unsigned char bdata addr_0x21_page1 		_at_ 0x21;

sbit bReadOverCap							= addr_0x21_page1^0; //1: ���ѳ�����ʵ����
sbit bReadInH2testMode						= addr_0x21_page1^1; //1: �Ѿ���⵽h2test������
sbit bWriteBufReset							= addr_0x21_page1^2; //1: �����Ѿ�������reset buf��������
sbit bOverResCap            				= addr_0x21_page1^3;
sbit bRecIndexIncDec        				= addr_0x21_page1^4;
sbit bH2testwDataMode       				= addr_0x21_page1^5;
sbit bH2testwDataEquCmpSec  				= addr_0x21_page1^6;
sbit bForceOverCapResetReadBuf  			= addr_0x21_page1^7; //1: ���ݶ������У�ǿ��reset read buf


//====================================================================================
unsigned char data RecLBATableIndexL  	_at_ 0x30;  
unsigned char data RecLBATableIndexH		_at_ 0x31;
unsigned char data enlarge_temp0	  		_at_ 0x32;
unsigned char data enlarge_temp1				_at_ 0x33; 

#endif
#endif