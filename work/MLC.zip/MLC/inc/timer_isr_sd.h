#ifndef _timer_isr_sd_h_
#define _timer_isr_sd_h_

extern bit bDataIn_Flag,READY_FOR_DATA, bMulWriteTask, bSingleWriteTask, bStopMulWriteData, bCMD0Rcv;
extern bit bCallWriteLBA, bInWriteLbaFun;
extern bit bForceDly;
extern bit bRcvSDDataKickStart;
extern bit bCopyBackNotOver;
extern bit bCopyNeedStop;
extern bit bStr_MulRead_SD;
extern bit bDataOut_Flag;
extern bit bDataStop_Flag, bMulRFlag;
extern bit bSDStop, bEnReadLBACnt;
extern bit bReadType;
extern bit bSdDmaOutUseAllBuf, bBlockLenLess512Byte, bReadDataInHsBuf, bLbaSeqInHsBuf, bTimeout, bReadDataInVirtualBuf;
extern bit bSwitch50M;
extern bit bInReadLba, bInFlashCopyBackState;
extern bit bStopRcvCprmData;
extern bit bVisitCprmDataMode, bCprmDmaDataMode;
extern bit bRomCard;
extern bit bEnVirtualBuf2Nf, bEnForceEraseVirtualBufBlk;
extern bit bFlashRetryTimeOut;
				   
extern unsigned char data yTast_Index;
extern unsigned char data yBlockLen0, yBlockLen1;
extern unsigned char data yBuffer_Index_Start, ActualRcvSDDataCnt, PlanRcvSDDataCnt ;
extern unsigned char idata host_to_sd_buf_ptr, sd_ready_for_nf_buf_cnt , sd_to_nf_buf_ptr;
extern unsigned char idata virtual_sd_data_buf_cnt, hs_to_virtual_buf_ptr, virtual_to_nf_buf_ptr;
extern unsigned char idata virtual_sd_buf_map_w_nf_page_ptr, virtual_sd_buf_map_r_nf_page_ptr;
extern unsigned char idata dma_out_r_cur_virtual_buf_map_r_nf_page_ptr, dma_out_r_cur_virtual_buf_map_r_nf_sec_in_page_ptr;	
extern unsigned char idata virtual_to_nf_buf_in_per_page_sector_ptr;			
extern unsigned char data ReadLBACnt;
extern unsigned char data yBuffer_Index;
extern unsigned char data SdReadDmaAddrH, SdReadDmaAddrL;
extern unsigned char idata SDBufBlockAddrH, SDBufBlockAddrL, SDBufPageAddr;
extern unsigned char code sd_hs_cache_data_buf [];
extern unsigned char code sd_hs_cache_data_buf_lba[][4];
extern unsigned char code sd_virtual_data_buf_lba[][4];
extern unsigned char code sd_virtual_data_buf_cnt[];
extern unsigned char code sd_virtual_data_buf [];
extern unsigned char code W_BUF_ADDR_H,W_BUF_ADDR_L;
extern unsigned char code TIMER_UART_IN_OUT_WORKING;
extern unsigned char code SdVirtualBuf2NfUseMaxPage, SdVirtualBuf2NfUseMaxSector;
extern volatile unsigned char data NfEmptyBufCnt;		   
 
extern void stop_single_write_fun(void);
extern void stop_mul_write_fun(void);
extern void config_hs_cache_buf_dma_addr(unsigned char buf_ptr);
extern void get_lba(void);
extern void clr_d0_busy_in_rcv_ing(void);
extern void write_block_tab(void);
extern void rcv_one_packet_case_in_pro_state_process(void);
extern void change_state_machine_in_pro_dis_state(void);
extern void clr_d0_busy_in_rcv_end(void);
extern void cprm_mul_write_end(void);
extern void copy_512byte_data(unsigned char src_buf_index, unsigned char target_buf_index);
extern void cprm_en_de_code_buf_point_to_cur_buf(void);
extern void	cprm_encode_data(void);
extern void cprm_decode_data(void);
extern void judge_cprm_data_dma_out_complete(void);
extern void judge_cprm_data_dma_in_complete(void);
extern void config_cur_buf_data_lba(unsigned char buf_ptr);
extern void sel_dma_addr(void);
extern void get_er1_to_cur_lba();
extern void Sel_Buffer_Addr(void);

extern void read_sdbuf_block(void);
extern void program_sdbuf_block(void);
extern void erase_sdbuf_block(void);
extern void NF_BUF1_2_BUF2_AND_RANDOMIZE(void);
extern void cur_map_lba_inc(void);
extern void uart_rcv_data(void);
extern void uart_out_one_byte(void);
extern void set_p1(u8 dat);
extern void clr_p1(u8 dat);
extern void xrl_p1(u8 dat);
extern void xrl_p3(u8 dat);
extern u8 get_mem_copy_hw_status(void);
				  
void cal_sd_dma_buf_addr(unsigned char buf_index);
void sd_kick_dma_out_data(void);
void cal_sd_dma_out_addr(void);
void cal_next_dma_in_addr(unsigned char cur_buf_ptr);
void disable_force_sd_bus_rcv_data_in_dly(void);
void timer_tick_inc(void);
void timer_tick_clr(void);
void printf_timer_n_10ms(void);
void printf_sd_buf_cnt(void);
void printf_n_1ms_cnt(void);
void delay_2n_sd_clk(unsigned char n_sd_clk);
void wait_dma_out_read_buf_empty(void);
void save_virtual_sd_buf_data_to_nf(void);
void updata_cur_virtual_sd_buf_data_to_nf(unsigned char r_virtual_buf_ptr, unsigned char r_virtual_buf_sec_in_page_ptr, unsigned char w_nf_buf);
void cpy_virtual_buf_var_2_nf_buf(void);
void sd_buf_2_nf_buf_cnt_dec(void);
void virtual_buf_2_nf_buf_cnt_dec(void);
void release_interrupt_reti(void);
void erase_virtual_buf_map_blk(void);
void initial_vitrual_buf_parameter_in_powerup(void);
void chk_writing_lba_and_sd_virtual_buf_lba(void);
void hs_write_to_virtual_sd_buf_map_nf(unsigned char hs_buf_ptr, unsigned char  w_nf_page_index, unsigned char savecnt);
void timer_timeout_cnt_dec(void);	
void save_hs_sd_buf_data_to_nf(void);
void ctl_sd_bus_data_from_host_to_hs_sd_buf(void);
void initial_sd_buf_in_out_ptr(void);


unsigned char idata  rcv_data_state;			   //Ĭ�ϳ�ʼ��Ϊ0��HS_RCV_DATA_IN_IDLE��
unsigned char idata  write_hs_data_to_flash_state; //Ĭ�ϳ�ʼ��Ϊ0 (W_HS_DATA_TO_FLASH_IDLE)	
unsigned short idata timer_dly_timeout;			   //timeout ������
unsigned char idata  yBufIndexStartCopy;
unsigned char idata copy_last_virtual_sd_data_buf_cnt;
unsigned char idata status_for_writing_lba_virtual_buf_lba;
unsigned short idata timer_tick, n_1ms;					  
unsigned char idata  write_virtual_sd_buf_data_to_nf_state; 	//Ĭ�ϳ�ʼ��Ϊ0 (W_VIRTUAL_SD_BUF_DATA_TO_NF_IDLE)
unsigned char idata  u8_extern_dma_in_task;						//������dma in ���񡣣�pragram csd(u8_extern_dma_in_task & 0x80)��									
unsigned char idata  cmd12_stop_dly_times;						//����cmd12 stop timeout��ѭ������ 
static unsigned char idata next_dma_in_addr_h, next_dma_in_addr_l;





#endif