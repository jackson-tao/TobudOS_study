#ifndef __SD_FUNC_TEST_H__
#define __SD_FUNC_TEST_H__


void SD_func_test(long l_data, long r_data);
void SD_isr_func_test(void);
void SD_init(void);		   
void set_SD_cmd_IP(byte SDNum, byte Priority);
			  
#endif
