#ifndef _read_write_c_h_
#define _read_write_c_h_

extern bit  bStr_MulRead  ;
extern bit  bStr_MulWrite ;
extern bit  bNandPowerup ;
extern bit bReadNewBlockTrue;
extern unsigned char code COPYLBA_M_TMP;
extern unsigned char code WholePageTabAB;
extern u8 code PLANE_REFERENCE, _PLANE_MODE;
extern u8 code FirstValidZone;
extern u8 code PLANE_REFERENCE, _PLANE_MODE;
extern unsigned char code MAP_BOUNDARY;
extern unsigned char  data boundIndex;
extern unsigned char code _ZoneLgBlockNumBuf;
extern unsigned char code CUR_MAP_LBA;
extern unsigned int idata Order;
extern unsigned int idata CacheLgPage;
extern void bit_cal(void);
extern void Get_CurPlaneCfg(void);
extern void NF_Set_Feature(u8 FeatureAddr);
extern void NF_Get_Feature(u8 Feature_Addr);
extern void Read_Sectors(void);
extern void NF_Erase_Block(void);
extern void Mark_A_Blank_Block(void);
extern void Find_A_Blank_Block(void);
extern void Prog_A_Page_CacheBlock(void);
extern void NF_Reset(void);
static void Get_Block_PhAddr(void);
static void Set_Block_PhAddr(void);
extern void Get_PageLg2PhTable(void);
extern void bit_search(void); 

void Sel_Buffer_Addr(void);
void Sel_DMA_Addr(void);
void Get_Block_WL_Stage_Addr(void);
void Read_WritingBlockBuf(void);
void Get_WritingBlockBuf_BlockLgAddrH_INDEX(void);
void Get_OldBlockPhAddr(void);
void Get_RdCurZone_Lg2PhTable(void);
void Get_LgAddr(void);
void Set_Retry_Register_Data(void);
void Chk_Data(void);
void Updata_WrLg2phTable(void);
void Write_WritingBlockBuf(void);
void Write_a_Block_Over(void);
void Get_WrCurZone_Lg2PhTable(void);
void Get_Page_PhAddr(void);
void Get_PagePh2LgTable_StartAddr(void);
void Copy_A_Page(void);
void Prog_CacheBlock_Page(void);
void Prog_NewBlock_Page(void);
void Get_ZoneLBA(void);
void Set_Page_PhAddr(void);
void Get_CacheBlock_Addr(void);
void Get_WrLg2phTableL(void);
extern unsigned char NF_Read_Status(unsigned char tmp);
extern unsigned char code _PagePhAddr_Buf;






#endif