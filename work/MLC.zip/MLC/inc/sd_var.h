#ifndef _sdsd_h_
#define _sdsd_h_

/**********************************************************************************************************************************************************
* CARD_STATUS Bit����
* ʹ�õ�ַ0x20 - 0x23
**********************************************************************************************************************************************************/
#define  CARD_STATUS_0   addr_0x20
#define  CARD_STATUS_1   addr_0x21
#define  CARD_STATUS_2   addr_0x22
#define  CARD_STATUS_3   addr_0x23

unsigned char bdata addr_0x20 _at_ 0x20;

sbit  OUT_OF_RANGE          = addr_0x20^7;  //31
sbit  ADDRESS_ERROR         = addr_0x20^6;  //30
sbit  BLOCK_LEN_ERROR       = addr_0x20^5;  //29
sbit  ERASE_SEQ_ERROR       = addr_0x20^4;  //28
sbit  ERASE_PARAM           = addr_0x20^3;  //27
sbit  WP_VIOLATION          = addr_0x20^2;  //26
sbit  CARD_IS_LOCKED        = addr_0x20^1;  //25
sbit  LOCK_UNLOCK_FAILED    = addr_0x20^0;  //24  

unsigned char bdata addr_0x21 _at_ 0x21;  

sbit  COM_CRC_ERROR         = addr_0x21^7;  //23 
sbit  ILLEGAL_COMMAND       = addr_0x21^6;  //22
sbit  CARD_ECC_FAILED       = addr_0x21^5;  //21
sbit  CC_ERROR              = addr_0x21^4;  //20
sbit  ERROR                 = addr_0x21^3;  //19
sbit  Reserved0             = addr_0x21^2;  //18
sbit  Reserved1             = addr_0x21^1;  //17
sbit  CSD_OVERWRITE         = addr_0x21^0;  //16

unsigned char bdata addr_0x22 _at_ 0x22;
                         
sbit  WP_ERASE_SKIP         = addr_0x22^7;  //15  
sbit  CARD_ECC_DISABLED     = addr_0x22^6;  //14
sbit  ERASE_RESET           = addr_0x22^5;  //13     
sbit  CURRENT_STATE_0       = addr_0x22^4;  //12
sbit  CURRENT_STATE_1       = addr_0x22^3;  //12
sbit  CURRENT_STATE_2       = addr_0x22^2;  //12
sbit  CURRENT_STATE_3       = addr_0x22^1;  //12
sbit  READY_FOR_DATA        = addr_0x22^0;  //8

unsigned char bdata addr_0x23 _at_ 0x23;                    

sbit  Reserved2             = addr_0x23^7;  //7
sbit  Reserved3             = addr_0x23^6;  //6
sbit  APP_CMD               = addr_0x23^5;  //5
sbit  Reserved4             = addr_0x23^4;  //4 
sbit  AKE_SEQ_ERROR         = addr_0x23^3;  //3
sbit  Reserved5             = addr_0x23^2;  //2
sbit  Reserved6             = addr_0x23^1;  //1
sbit  Reserved7             = addr_0x23^0;  //0
                          
/**********************************************************************************************************************************************************
* ���±�����SD����SDģʽ��λ����
* ʹ�õ�ַ0x24 - 0x27
**********************************************************************************************************************************************************/

unsigned char bdata addr_0x24 _at_ 0x24;      

sbit  bAppo_CMD_Flag    = addr_0x24^0;  //�������־    
sbit  bCMDRec_Flag      = addr_0x24^1;  //CMD�жϱ�־ 
sbit  bCMDRps_Flag      = addr_0x24^2;  //CMDӦ���־ 
sbit  bDataIn_Flag      = addr_0x24^3;  //д�����жϱ�־
sbit  bDataOut_Flag     = addr_0x24^4;  //�������жϱ�־
sbit  bDataStop_Flag  	= addr_0x24^5;  //����ֹͣ��־
sbit  bStr_MulRead    	= addr_0x24^6;  //������ʼ��־
sbit  bStr_MulWrite   	= addr_0x24^7;  //���д��ʼ��־

unsigned char bdata addr_0x25 _at_ 0x25; 

sbit  bDecteInvalidCmdBySw  	= addr_0x25^0;  //��Ӳ��״̬�������õ�ʱ�����������CMD�ĺϷ���
sbit  bRcvCMD7InDataOrDisState  = addr_0x25^1;
sbit  bSdDmaOutUseAllBuf        = addr_0x25^2;  //1-->����������  
sbit  bCMD0Rcv      			= addr_0x25^3;  //1-->������CMD�������Ƿ񱻴��
sbit  bActiveOk					= addr_0x25^5;  //1: Enable Virtual buf data write to nf after flash power up.
sbit  bStopEn               	= addr_0x25^6;  //����æ
sbit  bEnCheckEraseSeq          = addr_0x25^7;  //1--> CMD0 Received in single/mul write task.  

unsigned char bdata addr_0x26 _at_ 0x26; 

sbit  bCallWriteLBA         = addr_0x26^0;
sbit  bMulRFlag             = addr_0x26^1;  
sbit  bMulWriteTask         = addr_0x26^2;   //0:CMD8 not received; 1:CMD8 received  
sbit  bSingleWriteTask      = addr_0x26^3;   //1-->in single write task
sbit  bCMD8Rcv              = addr_0x26^4;   //1-->in mul write task   
sbit  bSwitch50M            = addr_0x26^5;   //25M->50M SD CLK b��־��0�����ܱ�50M SD CLK,1:���Ա��50M SD CLK
sbit  bInReadLba            = addr_0x26^6; 
sbit  bSDHC                 = addr_0x26^7;    //0:not SDHC ; 1: SDHC. 


unsigned char bdata addr_0x27 _at_ 0x27; 

sbit  bReadType                 = addr_0x27^0;
sbit  bWriteType                = addr_0x27^1;
sbit  bInWriteLbaFun		    = addr_0x27^2;	 //1: in write lba.
sbit  bEnVirtualBuf2Nf			= addr_0x27^3;  //1: Enable Virtual buf data write to nf after flash power up.
sbit  bNandPowerup              = addr_0x27^4;
sbit  bInEraseTask          	= addr_0x27^5;  //1-->����������  
sbit  bTmpWriteProtect          = addr_0x27^6;
sbit  bRomCard					= addr_0x27^7;	 //1: ROM card.
 
unsigned char bdata addr_0x2e _at_ 0x2e;
sbit bEnForceEraseVirtualBufBlk	= addr_0x2e^0; //0: Enable force erase virtual buf nf blk after power up(default); 1: disable.	
sbit bReadDataInHsBuf			= addr_0x2e^1; //0: LBA's data is not in HS_BUF; 1: LBA's data is in HS_BUF
sbit bBlockLenLess512Byte		= addr_0x2e^2; 
sbit bForceDly					= addr_0x2e^3; //1��Force delay in receiving data.(default); 0: Do not force delay.
sbit  bStopMulWriteData     	= addr_0x2e^4;
sbit bTimeout					= addr_0x2e^5; //1: Write data timeout.
sbit bReadDataInVirtualBuf		= addr_0x2e^6; //1: Read data is in virtual buf.
sbit bStopClearBusyIng			= addr_0x2e^7;

unsigned char bdata bCPRMFlag _at_ 0x2f;
  
sbit  bCPRM_E_D_Flag        = bCPRMFlag^0;    //0: C2_E/C2_ECBC;            1: C2_D/C2_DCBC
sbit  bAKERcvType           = bCPRMFlag^1;    //0: AKE Rcv challenge1;        1: AKE Rcv challenge2_rps
sbit  bScrtyMode            = bCPRMFlag^2;    //1: Security mode
sbit  bCprmDmaDataMode      = bCPRMFlag^3;    //0: Normal read mode             1: Read CPRM data mode.
sbit  bAKEVerifyErr         = bCPRMFlag^4;    //0: AKE Verify ok            1: AKE Verify err
sbit  bFirstEnDecodeData    = bCPRMFlag^5;    //0: Not first packet en/decode data.   1 :first packet en/decode data. 
sbit  bVisitCprmDataMode    = bCPRMFlag^6;    //0: Normal read(data do not en/decode) 1: Cprm read mode(data en/decode)
sbit  bStopRcvCprmData      = bCPRMFlag^7;    //0: Normal write mode or continue receive data in CPRM mode.  1: stop receive data in CPRM write mode.       

/**********************************************************************************************************************************************************
* ���±�����SD����SDģʽ��REG����
* ʹ�õ�ַ0x30 - 0x35
***********************************************************************************************************************************************************/
  /* SD ģ���±������� */  /*�⼸byte������data bank1��ͬʹ��*/ 
unsigned char data yCMD_Index        _at_  0x30;   //CMD Index 
unsigned char data yTast_Index       _at_  0x31;   //����Index
unsigned char data yScrtyUnitCnt     _at_  0x32;  
  /**********************************************************************************************************************************************************
***********************************************************************************************************************************************************/
#endif
