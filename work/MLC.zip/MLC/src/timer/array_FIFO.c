#include "inc\common.h"
#include "inc\sd_spi_com_define.h"
#include "inc\array_FIFO.h"		

#if BAUDRATE
//byte xdata ArrayFIFO[0];   //FIFO_LENGTH];
//struct array_struct{
//	int begin;
//	int end;
//	int length;
//	u16 add_tail_err_cnt;       //buf�������err
//}ArrayStruct;
#endif


//void uart_array_init(void)
//{
//#if BAUDRATE
//	_push_(DPCON);
//	DPCON = 0x00;
//	ArrayStruct.begin = 0;
//	ArrayStruct.end = 0;
//	ArrayStruct.length = 0;
//	ArrayStruct.add_tail_err_cnt = 0;
//	_pop_(DPCON);
//#endif
//}


//int array_get_length(void)
//{
//#if BAUDRATE
//	int ret;

//	_push_(DPCON);
//	DPCON = 0x00;
//	ret =  ArrayStruct.length;
//	_pop_(DPCON);

//	return ret;
//#else
//	return 0;
//#endif
//}


//int array_add_tail(byte dat)
//{
//#if BAUDRATE
//	int ret;

//	_push_(DPCON);
//	DPCON = 0x00;
//	
//	if(ArrayStruct.length >= FIFO_LENGTH){			//���buffer���ˣ��Ͳ��ټ�������
//		if(ArrayStruct.add_tail_err_cnt < 0xffff)
//			ArrayStruct.add_tail_err_cnt++;
//		
//		_pop_(DPCON);
//		return -1;		
//	}

//	ArrayFIFO[ArrayStruct.end] = dat;
//	ArrayStruct.length ++;
//	if(FIFO_LENGTH == ++ArrayStruct.end){
//		ArrayStruct.end = 0;	
//	}
//	
//	ret = ArrayStruct.end;

//	_pop_(DPCON);
//	
//	return ret;
//#else
//	return 0;
//#endif
//}


//int array_get_head(void)
//{
//#if BAUDRATE
//	
//	byte dat;

//	_push_(DPCON);
//	DPCON = 0x00;
//	
//	if(ArrayStruct.length == 0){
//		_pop_(DPCON);
//		return -1;
//	}
//	
//	ArrayStruct.length--;	
//	
//	dat = ArrayFIFO[ArrayStruct.begin];
//	if(FIFO_LENGTH == ++ArrayStruct.begin){
//		ArrayStruct.begin = 0;
//	}

//	_pop_(DPCON);
//	
//	return dat;	
//#else 
//	return 0;
//#endif
//}					

