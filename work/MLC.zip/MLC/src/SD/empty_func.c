				
#include "inc\common.h"		  				 		 
#include "inc\ax215_exinst.h"		
#include "inc\nand_flash.h"		   
#include "inc\nand_flash_var_extern.h"			  
#include "src\timer\array_FIFO.h"			   
#include "inc\extern_data.h"

extern void set_p1(u8 dat);
extern void clr_p1(u8 dat);
extern void xrl_p1(u8 dat);

extern void mem_set(unsigned char fill_data);
/*****************************************************************************/
//	MTD.ASM
/*****************************************************************************/                                  
//void	NF_Read_Start        (void){}
//void	NF_Read_Data         (void){}
//void	NF_Prog_Page         (void){}
//void	NF_Prog_Data         (void){}
//void	NF_Prog_Stop         (void){}
//void	NF_Erase_Block       (void){}
//void	Change_CE            (void){}
//void	NF_Wait_Read_Over    (void){}
//void	Get_CurPlaneCfg      (void){}
//void	Wait_Flash_Ready     (void){}
//void	BCH_MODE_DC_Wait_Over(void){}
//void	Get_True_BlockAddr   (void){}
//void	Read_SDBuf_Block	 (void){}
//void	program_sdbuf_block  (void){}
//void	erase_sdbuf_block    (void){}



///*****************************************************************************/
////	READ_WRITE.ASM
///*****************************************************************************/ 
//void Write_LBA_Over                   (void){}
//void Write_a_Block_Over               (void){}
//void Read_WritingBlockBuf             (void){}
//void Write_WritingBlockBuf            (void){}
//void Updata_WrLg2phTable              (void){}
//void Get_OldBlockPhAddr               (void){}
//void Get_PagePh2LgTable_StartAddr     (void){}
//void Sel_DMA_Addr                     (void){}
//void Set_Page_PhAddr                  (void){}
//void Get_WrCurZone_Lg2PhTable         (void){}
//void Set_Block_PhAddr                 (void){}
//void Get_Block_PhAddr                 (void){}
//void Chk_SpareArea_Data               (void){}
//void Chk_Need_Retry                   (void){} 
  		                                             
//void Read_LBA                   (void);

//void Write_LBA                        (void){}
//void Sel_Buffer_Addr                  (void){}
//void Buf1_2_Buf0	                  (void){}
//void Copy_LBA                         (void){}	
//void Get_LgAddr                       (void){}                                         
//void Erase_LBA            		      (void){}
//void NF_POWER_UP   				      (void){}
//void READ_BANK_CODES   		  	      (void){}
//void CONFIG_FIRST_RCV_BUF             (void){}
//void AKE_CHALLENGE_2_BUF              (void){}
//void AKE_CHALLENGE_1_BUF              (void){}


	/*============================================================
* �Ρ�����:R02
* ��������:
============================================================*/
//void Sel_Buffer_Addr(void)
//{
//	ER11 = (u8)(BUFFER_START_ADDR >> 8);
//	ER10 = (u8)(BUFFER_START_ADDR >> 0);

//	ER01 = (u8)(512 >> 8);
//	ER00 = (u8)(512 >> 0);

//	ER03 = 0;
//	#pragma asm
//	MUL16_ER0
//	ADD32_ER0_ER0_ER1
//	#pragma endasm
//}

/*============================================================
* �Ρ�����:R02
* ��������:
============================================================*/
//void Sel_DMA_Addr(void)
//{
//	ER11 = (u8)((BUFFER_START_ADDR / 4) >> 8);
//	ER10 = (u8)((BUFFER_START_ADDR / 4) >> 0);

//	ER01 = (u8)((512 / 4) >> 8);
//	ER00 = (u8)((512 / 4) >> 0);	

// 	ER03 = 0;
//	#pragma asm
//	MUL16_ER0
//	ADD32_ER0_ER0_ER1
//	#pragma endasm	
//}



/************************************************************************************************************************
* ��������void read_lba (void)

************************************************************************************************************************/
#if 0
void read_lba (void)
{	

    unsigned char idata i;

//	for(i = 0; i < READ_BUF_NUM; ++i){
//		ER02 = i;
//		Sel_Buffer_Addr();
//		DP0H = ER01;
//		DP0L = ER00;
//		mem_set(i);//memset 512byte buffer 
//	}

	i  = 0;
	
	yBuffer_Index = 0;
	bEnReadLBACnt = 0;

	while(! bSDStop){
								
		ReadLBACnt++;
	 	bEnReadLBACnt = 1;	

		while(ReadLBACnt >= READ_BUF_NUM){
			if(bSDStop)	
				break;
		}						  			
	}

}
#endif

extern bit bStopMulWriteData;  
#if 0
void write_lba (void)
{		
	while(1){
		while(bRcvSDDataKickStart){}
			
		if(ActualRcvSDDataCnt != PlanRcvSDDataCnt){
			break;
		}
			
		PlanRcvSDDataCnt = 16;    	
		ActualRcvSDDataCnt = 0;
		yBuffer_Index_Start = 0;
		NfEmptyBufCnt =  PlanRcvSDDataCnt;	
		
		bRcvSDDataKickStart = 1; 

		xrl_p1(1 << 7);
		
	}
			  						
}
#endif
