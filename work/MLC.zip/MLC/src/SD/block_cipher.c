#include "src\sd\block_cipher.h"

xdata char SourceData[SOURCE_LENGTH]   _at_ SOURCE_BUFFER;
xdata char EncodedData[ENCODED_LENGTH] _at_ ENCODED_BUFFER;
xdata char KeyTable[KEY_TAB_LENGTH]    _at_ CONST_KEY_TAB;		
xdata char EncodedData_3[ENCODED_LENGTH_3] _at_ ENCODED_BUFFER_3;
void block_cipher_main(void)
{	
	unsigned int i;	
	bit ErrorFlag = false;	
	sfrpage(1);
	printf("Here is block cipher test!\r\n");
	init_block_cipher();   	 		   
	NewLine();	 
	printf("Key data is:\r\n");		  
	for(i=0;i<7;i++){
		PrintHex(EncryptionKey[i]);	
	}		
	NewLine();	 				
	printf("Source data is:\r\n");
	for(i=0;i<SOURCE_LENGTH;i++){	
		if(i%512 == 0)	NewLine(); 
		PrintHex(SourceData[i]);	
	}	
#if	CBC_ENCODE				
	ECB_encode();			
#else						
	CBC_encode();				
#endif			
	NewLine();	 		 
	printf("Encode data is:\r\n");
#if	TO_ENCODED_BUFFER		
	for(i=0;i<ENCODED_LENGTH;i++){ 	 
		if(i%512 == 0)	NewLine(); 
		PrintHex(EncodedData[i]);
		if(EncodedData[i] != CipherText[i])
			ErrorFlag = true;
	}							 
#else						   
	for(i=0;i<SOURCE_LENGTH;i++){ 
		PrintHex(SourceData[i]); 
		if(i%512 == 0)	NewLine(); 
		if(SourceData[i] != CipherText[i])
			ErrorFlag = true;
	}
#endif	
	if(ErrorFlag){
		printf("\r\nEncode error!!\r\n");
	}else{						
		printf("\r\nEncode OK!!\r\n");		
	}
	CBC_encode_times();
	ErrorFlag = false;
	for(i=0;i<ENCODED_LENGTH;i++){  
		if(i%512 == 0)	NewLine(); 
		PrintHex(EncodedData_3[i]); 
		if(EncodedData[i] != EncodedData_3[i])
			ErrorFlag = true;
	}
	if(ErrorFlag){
		printf("\r\nEncode different!!\r\n");
	}else{						
		printf("\r\nEncode same!!\r\n");		
	}
//	ErrorFlag = false;	
//#if	CBC_ENCODE				
//	ECB_decode();			
//#else						
//	CBC_decode();				
//#endif		
//	NewLine();	 		 
//	printf("Decode data is:\r\n");
//	for(i=0;i<SOURCE_LENGTH;i++){
//		PrintHex(SourceData[i]);
//		if(SourceData[i] != PlainText[i])
//			ErrorFlag = true;	
//	}	 
//	if(ErrorFlag){
//		printf("\r\nDecode error!!\r\n");
//	}else{						
//		printf("\r\nDecode OK!!\r\n");		
//	}

		
}

void init_block_cipher(void)
{		
	unsigned int i;	 

#if BIG_ENDIUM				 
	BCCON_P1  |= BIT(6);//���	
#else						   
	BCCON_P1  &= ~BIT(6);//С��
#endif

#if	TO_ENCODED_BUFFER
	BCCON_P1 |=	BIT(1);
#endif

#if	SRAM_KEY_TAB
	BCCON_P1 &=	~BIT(2);
#else				 	
	BCCON_P1 |=	BIT(2);
#endif
		
	for(i=0;i<SOURCE_LENGTH;i++){
		SourceData[i] = PlainText[i];//i;//	
	}
	for(i=0;i<KEY_TAB_LENGTH;i++){
		KeyTable[i] = SecretConstant[i];
	}

#if	ENABLE_INTERRUPT
/************************************* 
	block cipher�ж�			
*************************************/ 
	PCON &= ~BIT(2);	// interrupt vecter set to 0x0000
//	PCON |= BIT(2);		// interrupt vecter set to 0xE000
	IE1 |= BIT(7);	
	BCCON_P1 |=	BIT(3);
	EA = 1;
#endif
}

void write_info(bit en_decode)//0:encode	1:decode
{					   	   
	int SourceAddr = SOURCE_BUFFER >> 2;	//Դ��ַ  
	int EncodeAddr = ENCODED_BUFFER >> 2;	//Ŀ�ĵ�ַ
	int EncodeCNT  = (SOURCE_LENGTH >> 3) - 1;  	//����
	int KeyTabAddr = CONST_KEY_TAB >> 2;

	if(!en_decode){		 
		BCRADR0_P1 = SourceAddr & 0x00FF;
		BCRADR1_P1 = (SourceAddr>>8) & 0x00FF;	 
	#if	TO_ENCODED_BUFFER		 
		BCWADR0_P1 = EncodeAddr & 0x00FF;	
		BCWADR1_P1 = (EncodeAddr>>8) & 0x00FF;	 	 
	#endif	
	}else{	  		   	 
	#if	TO_ENCODED_BUFFER		 		   
		BCRADR0_P1 = EncodeAddr & 0x00FF;
		BCRADR1_P1 = (EncodeAddr>>8) & 0x00FF; 
		BCWADR0_P1 = SourceAddr & 0x00FF;	
		BCWADR1_P1 = (SourceAddr>>8) & 0x00FF;	
	#else		  
		BCRADR0_P1 = SourceAddr & 0x00FF;
		BCRADR1_P1 = (SourceAddr>>8) & 0x00FF; 		 
	#endif		
	}									  
	#if	SRAM_KEY_TAB		 
		BCRCADR0_P1 = KeyTabAddr & 0x00FF;		//constant key table
		BCRCADR1_P1 = (KeyTabAddr>>8) & 0x00FF;	 	 
	#endif	
	BCBCNT0_P1 = EncodeCNT & 0x00FF;
	BCBCNT1_P1 = (EncodeCNT>>8) & 0x00FF;

	BCKEY0_P1  = EncryptionKey[0];
	BCKEY1_P1  = EncryptionKey[1];
	BCKEY2_P1  = EncryptionKey[2];
	BCKEY3_P1  = EncryptionKey[3];
	BCKEY4_P1  = EncryptionKey[4];
	BCKEY5_P1  = EncryptionKey[5];
	BCKEY6_P1  = EncryptionKey[6];	  
	BCCON1_P1 |= 0X01;//��һ����Ҫ��Ϊ1������ͬ����key��������
}
void ECB_encode(void)
{	
	write_info(0);				 		 			   
	BCCON_P1  &= 0xCF;//ECB encryption 
	printf("\r\nBCCON_P1 is 0x%x\r\n", (int)BCCON_P1);
	BCCON_P1  |= 0x01;//kickstart
	while(!(BCCON_P1 & 0x80)); 

#if	!ENABLE_INTERRUPT
	BCCON_P1  &= ~BIT(7);
#endif	
}	

void ECB_decode(void)
{				
	write_info(1);								   
	BCCON_P1  &= 0xCF;			   
	BCCON_P1  |= 0x10;//ECB decryption 
	printf("\r\nBCCON_P1 is 0x%x\r\n", (int)BCCON_P1);
	BCCON_P1  |= 0x01;//kickstart
	while(!(BCCON_P1 & 0x80)); 

#if	!ENABLE_INTERRUPT
	BCCON_P1  &= ~BIT(7);
#endif		
}			

void CBC_encode(void)
{					  
	write_info(0);				   
	BCCON_P1  &= 0xCF;			   
	BCCON_P1  |= 0x20;//CBC encryption 
	printf("\r\nBCCON_P1 is 0x%x\r\n", (int)BCCON_P1);
	BCCON_P1  |= 0x01;//kickstart
	while(!(BCCON_P1 & 0x80)); 

#if	!ENABLE_INTERRUPT
	BCCON_P1  &= ~BIT(7);
#endif		
}	

void CBC_decode(void)
{						
	write_info(1);					   
	BCCON_P1  &= 0xCF;			   
	BCCON_P1  |= 0x30;//CBC decryption 
	printf("\r\nBCCON_P1 is 0x%x\r\n", (int)BCCON_P1);
	BCCON_P1  |= 0x01;//kickstart
	while(!(BCCON_P1 & 0x80)); 

#if	!ENABLE_INTERRUPT
	BCCON_P1  &= ~BIT(7);
#endif		
}					 	

/*******************************************************************************/
//����CBC������encode 3*512byte�����Ƿ���һ��encode 1536byte���ݽ����ͬ
/*******************************************************************************/
void CBC_encode_times(void)
{
	int i;		  			   	   
	int SourceAddr = SOURCE_BUFFER >> 2;	//Դ��ַ  
	int EncodeAddr = ENCODED_BUFFER_3 >> 2;	//Ŀ�ĵ�ַ
	int EncodeCNT  = ((ENCODED_LENGTH_3 /3) >> 3) - 1;  	//����	  * 512 / 4	  
	int addr;
		
	BCKEY0_P1  = EncryptionKey[0];
	BCKEY1_P1  = EncryptionKey[1];
	BCKEY2_P1  = EncryptionKey[2];
	BCKEY3_P1  = EncryptionKey[3];
	BCKEY4_P1  = EncryptionKey[4];
	BCKEY5_P1  = EncryptionKey[5];
	BCKEY6_P1  = EncryptionKey[6];
	BCCON1_P1 |= 0X01;//��һ����Ҫ��Ϊ1������ͬ����key��������
	for(i=0;i<3;i++){ 
		addr = (SourceAddr + i*ENCODED_LENGTH_3/3/4);
  		printf("Source Address is��%x\n" , addr);				   
		BCRADR0_P1 =  addr& 0x00FF;
		BCRADR1_P1 = (addr>>8) & 0x00FF;	 
		addr = (EncodeAddr + i*ENCODED_LENGTH_3/3/4);
  		printf("Encode Address is��%x\n" , addr);
		BCWADR0_P1 = addr & 0x00FF;	
		BCWADR1_P1 = (addr>>8) & 0x00FF;	
		BCBCNT0_P1 = EncodeCNT & 0x00FF;
		BCBCNT1_P1 = (EncodeCNT>>8) & 0x00FF; 	   
		BCCON_P1  &= 0xCF;			   
		BCCON_P1  |= 0x20;//CBC encryption 
		BCCON_P1  |= 0x01;//kickstart
		while(!(BCCON_P1 & 0x80)); 
		BCCON_P1  &= ~BIT(7);
	}
}



#if ENABLE_INTERRUPT
void block_cipher_isr(void)	interrupt	14	
{		  	
	printf("\r\nHere is block cipher interrupt test!\r\n");
	BCCON_P1  &= ~BIT(7);
}
#endif













