#include "absacc.h"
#include "intrins.h"
#include "inc\ax215_exinst.h"	
#include "inc\common.h"		 		 
#include "inc\nand_flash.h"			 		 
#include "inc\sd_spi_com_define.h"
#include "inc\nand_flash_var.h"
#include "inc\system_initial.h"
#include "inc\mrom_func.h"

void system_initial(void)
{	
			
	_push_(PAGEMAP);
	
	sfrpage(0);  

	CLKCON2_P0 = _FLASH_SYSCLKRE|0x80;

#if BAUDRATE
#if (EN_FPGA_SYS_CLK==100)
	CLKCON2_P0 = 0x2F|0x80;
#else
	CLKCON2_P0 = 0x1C|0x80;
#endif
#endif	

	PCON = 0x7c;
	PCON0_P0 |= 0xf0;
	CLKCON0_P0 &= ~(0xD8);//�ϵ粻��reset sdc,�������cmd8��־
	CLKCON1_P0 &= ~((0x80)|(1<<2));
	
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();	
	_nop_();
	_nop_();
	_nop_();
	
	CLKCON0_P0 |= 0xD8;
	CLKCON1_P0 |= (0x80);
//#if POWER_DOWN_EN
		PCON0_P0 |= (1<<1);//|(1<<0);//FALLING EDGE(default SDCLK)
#if POWER_DOWN_CMD
		PCON0_P0 |= (1<<0);   //sd trigger
#endif 
		PCON0_P0 |= (1<<2);//wake up enable
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();//wait power down 
 
	_pop_(PAGEMAP);
//#endif
	
  ax215_system_intial();
	
 	sd_spi_init(); 
	
 	config_first_rcv_buf(); 
	
	config_multiple_pages_mode_table();
}

//void initial_card_type(void)
//{
//	if ((*((unsigned char xdata *)(&_FLASH_CARD_TYPE)) & 0x01) == 0x01) {	
//		bRomCard = 1;						   //CardType^0 == 1,ֻ����
//		*(char xdata *)((&SD_STATE) + 3) = 1;	//0: r/w card; 1: rom card.
//	}
//}


void ax215_system_intial(void)
{	
	EA = 0;
	DPCON = 0;		
	PSW = 0;

	ClearDataArea();

	uart_init_timer0();
//	uart_array_init();

	timer3_init();	
	
	PAGEMAP = 0x01;			//Ĭ��SD���ڵ�sfr page	
//	set_p1(0xff);			//debug	

}

extern u8 xdata sd_hw_dma_in_addr_lba_buf[];
void init_write_acce_buf_config(void)
{	
	u8 i;
	u16 buf_addr, lba_addr;
	_push_(DPCON);
	_push_(PAGEMAP);
	PAGEMAP = 0x01;	  	
	DPCON = 0;
	buf_addr = SD_HS_CACHE_BUF_START_ADDR;
	lba_addr = SD_HS_CACHE_BUF_LBA_START_ADDR;
	for(i = 0; i < SD_HS_CACHE_BUF_CNT; i++){
		sd_hw_dma_in_addr_lba_buf[i * 4 + 0] = (u8)((buf_addr >> 8) & 0x00FF);		//sd_data_buf_ptr
		sd_hw_dma_in_addr_lba_buf[i * 4 + 1] = (u8)((buf_addr >> 0) & 0x00FF);  
		sd_hw_dma_in_addr_lba_buf[i * 4 + 2] = (u8)((lba_addr >> 8) & 0x00FF);		//lba_buf_ptr
		sd_hw_dma_in_addr_lba_buf[i * 4 + 3] = (u8)((lba_addr >> 0) & 0x00FF);
		buf_addr += 512;		
		lba_addr += 4;			
	}			 
	_pop_(PAGEMAP);
	_pop_(DPCON);
}

void sd_spi_init(void)
{
	_push_(PAGEMAP);
	
	sfrpage(1);
   	SRPND = 0;
	EA = 0;
	INTBK = 0;

	u8_pwr_active_cnt = 0;
	bSDHC = (bit)((*(char xdata *)(&TAB_R3_ACK)) & (1<<6));
	bCMD8Rcv = (bit)(SCCON_P1 & (1<<3));

	*(((char xdata*) &CSD) + 3) = 0x5a;
	*((char xdata*) &CSD_50M_CRC7) = cal_crc7((char xdata *)&CSD);

	*(((char xdata*) &CSD) + 3) = 0x32;	
	R8 = cal_crc7((char xdata *)&CSD);
	*((char xdata*) & CSD_25M_CRC7) = R8;
	*(((char xdata*) & CSD) + 15) = R8;
		
//	ext_int_init();

	if( ! SPIMODE)					 //SD mode
	{
//		uart_send_byte(0x5a);	
		SCCON_P1 &= ~(1<<5);		  	//	;SD CLK Falling Edge
		
		SRDL1_P1 = 0;				  	//	;initial CMD response len_h.
		SRCA0_P1 = 0;
		SRCA1_P1 = 0;
		u16RCA = 0;				  	// RCA = 0
		SDODLY_P1 = 0xfe;			   	//;Data start_BIT delay n*8 CLK behind CMD response
		SDRPSDLY_P1 = 0x82;			   	//;R2 response delay 5 CLK
	
		SDICON_P1 &= ~(1<<7);			//;default 1 line data mode.
		
		init_write_acce_buf_config();	
		
	}
	else	  	//SPI mode
	{
		SCCON_P1 &= ~(1<<5);		  //	;SD CLK Falling Edge;
	
		SDODLY_P1 = 0x0c;			   //;Data start_BIT delay n*8 CLK behind CMD response
			
	}
	_pop_(PAGEMAP);
}

unsigned char cal_crc7 (unsigned char xdata *datas)
{	
	R8 = 0;	
		
	for (ER00 = 0; ER00 < 15; ER00++)						
	{
	    for (ER01 = 0; ER01 < 8; ER01++)
	    {
			R8 <<= 1;
			R8 ^= ((((datas[ER00] << ER01) ^ R8) & 0x80) ? 0x9 : 0);
	    }
	}	
	return ((R8 << 1) + 0x01) ;				/* ��������CRC7����һλ,�������λ��1 */
}


//void ext_int_init(void)
//{
//	RCCTL |= (1<<6);	   		//;215D RCCTL[5:5] must be set before enable RC when sleep
//
//#if DIS_RC
//	RCCTL |= (1<<5);
//#else
//	RCCTL &= ~(1<<5);
//#endif	
//	EXINTR &= ~(1<<0);
//	EXINTR |= (1<<1);
//	_nop_();
//	_nop_();
//	EXINTR &= ~(1<<3);
//	EXINTR |= (1<<2);
//	
//	power_down();
//
//}


/************************************************************************************************************************
* ��������void config_first_rcv_buf(void)
* ���룺
* ���ܣ���ʼ����ر���
*�ϵ��ʼ��Ԥ����rcv buf
************************************************************************************************************************/
void config_first_rcv_buf(void)
{
//	*(char xdata *)(&W_BUF_ADDR_H) = _DATA_BUF_DMA_ADDR_H;		  //��һ��ʹ�ù̶���buf������
//	*(char xdata *)(&W_BUF_ADDR_L) = _DATA_BUF_DMA_ADDR_L;

	initial_sd_buf_in_out_ptr();
	sd_ready_for_nf_buf_cnt = 0;
	
	rcv_data_state = HS_RCV_DATA_IN_IDLE;
//	sd_dma_in_cnt = 0;
	
	config_hs_cache_buf_dma_addr(host_to_sd_buf_ptr);
	
	*(char xdata *)(&W_BUF_ADDR_H) = R8;
	*(char xdata *)(&W_BUF_ADDR_L) = B;

	write_hs_data_to_flash_state = W_HS_DATA_TO_FLASH_IDLE;

	PlanRcvSDDataCnt = 1;
	ActualRcvSDDataCnt = 0;
	yBuffer_Index_Start = _DATA_BUF_INDEX;

	NfEmptyBufCnt =  PlanRcvSDDataCnt;

	bRcvSDDataKickStart = 1;

	bEnReadLBACnt = 0;			//	//1: ReadLBACnt������Ч��0 < ReadLBACnt < 255��
	bSDStop = 1;					////1:SD host stop cmd ֹͣ������

	bInReadLba = 0;
	bCopyNeedStop = 0;

#if (! EN_POWERUP_SEARCH_VIRTUAL_BUF)
    virtual_sd_buf_map_w_nf_page_ptr = 0;
	virtual_sd_buf_map_r_nf_page_ptr = 0;
	hs_to_virtual_buf_ptr = 0;
	virtual_to_nf_buf_ptr = 0;
	virtual_lbabuf_emptycnt = SD_VIRTUAL_BUF_CNT;
	virtual_sd_data_buf_cnt = 0;    //��ʼ��
	virtual_to_nf_buf_in_per_page_sector_ptr = 0;
#endif	
	
	write_virtual_sd_buf_data_to_nf_state = W_VIRTUAL_SD_BUF_DATA_TO_NF_IDLE;

	u8_extern_dma_in_task = EXTERN_NO_DMA_IN_TASK;

#if(EN_CAL_TIME)	  				 //for debug
	virtual_buf_w_to_nf_thread_tick = 0;  
	before_cpy_max_sd_ready_for_nf_buf_cnt = 0;
	max_sd_ready_for_nf_buf_cnt = 0;
	use_debug_lba_cnt = 0;
	max_n_10ms = 0;	 
	cal_erase_virtual_sd_buf_map_blk_cnt = 0;
	cal_map_blk_max_page_number = 0;
	cal_max_virtual_buf_cnt = 0;
#endif

	sd_pre_write_config();

}

void cmd_entrance_tab_init(void)
{
//	int i;

	_push_(PAGEMAP);
	
	sfrpage(1);
	TABA0_P1 = (u8)((u16)(& AUTO_CMD_TAB_ADDR) >> 0);
	TABA1_P1 = (u8)((u16)(& AUTO_CMD_TAB_ADDR) >> 8);
	WCMDA0_P1 = *(u8 xdata*)(& AUTO_CMD_JMP_ADDR + 1);
	WCMDA1_P1 = *(u8 xdata*)(& AUTO_CMD_JMP_ADDR + 0);
	
//	printf("Here is the cmd table:\r\n");
//	for(i=0;i<128;i++){
//		PrintHex(AUTO_CMD_TAB_ADDR[i]);
//	}
	
	_pop_(PAGEMAP);		
}

//����sd�жϵȼ�	SDNum:	0:SDCmd		1:SDRps		2:SDDataIn		3.SDDataOut
void set_SD_cmd_IP(byte SDNum, byte Priority)
{
	Priority &= 0x03;						
	IPH0 |= (((Priority & BIT(1))>>1)<<(SDNum));
	IP   |= ((Priority & BIT(0))<<(SDNum));
}	


void SD_init(void)
{
	_push_(PAGEMAP);
	
	sfrpage(0);																			
	PCON |= BIT(6);	 // enable sd clk
	PCON &= ~BIT(2);  // interrupt vecter set to 0x0003

	IE |= BIT(0)|BIT(1)|BIT(2)|BIT(3); //SDCMD �ж�	
	set_SD_cmd_IP(0,3); //sd cmd
	set_SD_cmd_IP(1,3); //sd cmd rps
	set_SD_cmd_IP(2,2); //sd dma in
	set_SD_cmd_IP(3,2);	//sd dma out		
	
//	printf("SD init!\r\nIPH0: 0x%x   IP: 0x%x\n", (int)IPH0, (int)IP);

	CLKCON0_P0 |= BIT(5);	//relese sdc soft reset	 	
	
	sfrpage(1);
	
//	ARGSTA_P1 &= ~BIT(6);   //disable hardware execute  SSTA_P1 |= (1 << 4)
	last_SSTA_P1 = 0;
	  
//	ARGSTA_P1 &= ~BIT(7);  //�ر�ARGS��16bit����
	DIVR0_P1 = 0x00;	 //16bit������byte
	DIVR1_P1 = 0x02;	 //16bit������byte
//	printf("IE is :0x%x\r\n", (int)IE);	
//	printf("PCON is :0x%x\r\n", (int)PCON);	 	

	cmd_entrance_tab_init();

	SDOCON_P1 |= (1<<3);
	_nop_();
	_nop_();
	_nop_();
	SDOCON_P1 &= ~(1<<3);	//ת�ֶ�ģʽ
	
	EA = 1; 
	
	_pop_(PAGEMAP);	
} 


void ClearDataArea(void)
{
	_push_(PAGEMAP);
	
	for(B = 0; B < 5; B++){  		  		
		datapage(B);
		for(R8 = 0x7f; R8 >= 0x20; R8--){
			*(char idata *)R8 = 0;
		} 	
	}
	
	_pop_(PAGEMAP);
}

void timer3_init(void)
{	
	_push_(PAGEMAP);
	
	sfrpage(3);
	T3CNTL_P3  = 0;
	T3CNTH_P3  = 0;
#if (EN_FPGA_SYS_CLK==100)
	T3PRL_P3   = 110;  	//100: 8.23us; 70: 5.23us @80MHz   100:7.5us  110:8.2us   @100MHz
#else 
	T3PRL_P3  = 100;
#endif
	T3PRH_P3   = 0;			//200:80ms	    200
	T3CON_P3   = 0x36;	//8 pre-scalar,	enable timer3 interrupt, enable timer3		
	IE1 &= ~ BIT(3);		//disable timer3 interrupt(default) 	.//timer3��2bit����interrupt

	_pop_(PAGEMAP);
}


/*****************************************
��ʼ����pageģ��

*****************************************/
static void config_multiple_pages_mode_table(void)
{
#if 0//EN_MUL_PAGES_MODE
	
	_push_(DPCON);
	
	DPCON = 0x10;						//DPTR0 ����	

	DPTR0 = _FLASH_BCMBuf_ADDR;

	//-------------------------------------------------------------------------------
	//��ʼ��table����
	ER03 = 0;
	ER02 = 0;
	ER01 = (u8)((_FLASH_BCM_TABLE_SIZE + _FLASH_BLOCK_PAGE_MODE_TABLE_SIZE) >> 8);
	ER00 = (u8)((_FLASH_BCM_TABLE_SIZE + _FLASH_BLOCK_PAGE_MODE_TABLE_SIZE) >> 0);
	#pragma asm	
		
//	MOV		DPTR, # _FLASH_BCMBuf_ADDR	
	CLR_BCM_MUL_PAGE_TAB_LOOP:			
	CLR		A
	MOVX	@DPTR, A
	DEC32_ER0
	JNB		EZ, CLR_BCM_MUL_PAGE_TAB_LOOP
	//-------------------------------------------------------------------------------

	MOV		DPTR, # (_FLASH_BLOCK_PAGE_MODE_TABLE + 2)
	MOVX	A, @DPTR
	MOV		ER43, A						//tab_len = (R43 << 8) + R42;
	MOVX	A, @DPTR
	MOV		ER42, A	
	//-------------------------------------------------------------------------------
	//����bcm����
	CLR32_ER0						  	//���bcm����
//	MOV		B, # BCM_MAX_SECTOR
//	MOV		DPTR, # _FLASH_BCMCfg_ADDR_Tmp		
//	CAL_BCM_CNT_LOOP:
//	CLR32_ER1
//	MOVX	A, @DPTR
//	MOV		ER10, A
//	ADD32_ER0_ER0_ER1				  	//ER0 = ���bcm����;
//	DJNZ	B, CAL_BCM_CNT_LOOP
	
	MOV		R8, # 1
	ROTL32_ER0_ER8	 					//ER0(BCM��ַ��) = bcm���� * 2;

	MOV		R8, ER01
	MOV		B, ER00
	#pragma endasm

	DPTR0 = _FLASH_BCMBuf_ADDR;		   //buf �׵�ַ
	#pragma asm
	ADDDP0								//DPTR0(DPTR + {R8,B}) =  _FLASH_BCMBuf_ADDR + ER0(BCM��ַ��)	; ָ���pageģ�Ϳ�ʼ���XRAM
	#pragma endasm
	ER41 = DP0H;							//���ݣ�������Ŷ�pageģ��table��bufָ��
	ER40 = DP0L;
	
	DPTR1 = _FLASH_BLOCK_PAGE_MODE_TABLE + 8;

	ER03 = 0;
	ER02 = 0;
	ER01 = ER43;
	ER00 = ER42;
	if(ER03 || ER02 || ER01 || ER00){
		Dptr1_cpy_to_dptr0();			   //input: DPTR1/DPTR0/ER0  	//@dptr1 -> @dptr0
	}   //if _FLASH_BLOCK_PAGE_MODE_TABLE + 8����,copy��������page model ��ַ
	//-------------------------------------------------------------------------------
	DPCON = 0x00;						//DPTR0 �ر�����
	#pragma asm
	MOV		DPTR, # (_FLASH_BLOCK_PAGE_MODE_TABLE)
	MOVX	A, @DPTR
	MOV		B, A
	MOV		DPTR, # (_FLASH_BLOCK_PAGE_MODE_TABLE + 1)
	MOVX	A, @DPTR
	MOV		DP0L,      A					
	MOV		DP0H, B					//�ϲ�д��ָ���pageģ�͵�dptr����
	#pragma endasm	
//	MOV		R8, # HIGH (_FLASH_BLOCK_PAGE_MODE_TABLE + 8)
//	MOV		B, #  LOW (_FLASH_BLOCK_PAGE_MODE_TABLE + 8)
	R8 = (u8)((_FLASH_BLOCK_PAGE_MODE_TABLE + 8) >> 8);
	B  = (u8)((_FLASH_BLOCK_PAGE_MODE_TABLE + 8) >> 0);
	#pragma asm	
	SUBDP0							  //�����pageģ��table��0��pageģ�͵�ƫ��

	MOV		R8, ER41					  
	MOV		B, ER40
	ADDDP0							 //�����pageģ��table��0��pageģ�͵�������ַ
	MOV		R8, DP0H				 //����
	MOV		B, DP0L
	#pragma endasm
	//_FLASH_BLOCK_PAGE_MODE_TABLE[0\1] - _FLASH_BLOCK_PAGE_MODE_TABLE[8] + 
	*(((char xdata*) & BlockPageModeIndex_Infor) + 0) = R8;    			//������ַ
	*(((char xdata*) & BlockPageModeIndex_Infor) + 1) = B;					//

	*(((char xdata*) & MulBlockPageModeTabDptr) + 0) = ER41;			  //����ָ�� //������Ŷ�pageģ��table��bufָ��(��byte)
	*(((char xdata*) & MulBlockPageModeTabDptr) + 1) = ER40;			   //������Ŷ�pageģ��table��bufָ��(��byte)


	#pragma asm
	CLR32_ER1
	MOV	 	DPTR, # (_FLASH_BLOCK_PAGE_MODE_TABLE + 4)
	MOVX	A, @DPTR
	MOV		ER11, A
	MOV	 	DPTR, # (_FLASH_BLOCK_PAGE_MODE_TABLE + 5)
	MOVX	A, @DPTR
	MOV		ER10, A

	CLR32_ER0
	MOV	 	DPTR, # (_FLASH_BLOCK_PAGE_MODE_TABLE + 0)
	MOVX	A, @DPTR
	MOV		ER01, A
	MOV	 	DPTR, # (_FLASH_BLOCK_PAGE_MODE_TABLE + 1)
	MOVX	A, @DPTR
	MOV		ER00, A
	#pragma endasm
	
	if((ER11 == 0xff) && (ER10 == 0xff)) {  //���û�еڶ���
		ER01 = 0xff;
		ER00 = 0xff;
	}else{																	//����,�ڶ�������һ��
		#pragma asm
		SUB32_ER0_ER1_ER0

		CLR32_ER1
		MOV		ER11, R8
		MOV		ER10, B
		ADD32_ER0_ER0_ER1											//����ڶ��������ĵ�ַ
		#pragma endasm	
	}
	
	*(((char xdata*) & BlockPageModeIndex_Infor) + 2) = ER01;
	*(((char xdata*) & BlockPageModeIndex_Infor) + 3) = ER00;
	
	_pop_(DPCON);
	
#endif
	
}





/************************************************************************************************************************
* ��������void initial_vitrual_buf_parameter_in_powerup(void)
* ���룺 nf buf index (SAVE_CTL_VIRTUAL_BUF_VAR_2_NF_BUF)
* ���ܣ����ַ��������µ�����buf��Ӧ����Чpage,���ָ���ز���
* tmp: ER3
//byte
// 1  0x5a											//flag	
// 1  virtual_sd_buf_map_w_nf_page_ptr = 0;		   	//Cur write page for saving sd buf data.
// 1  virtual_sd_buf_map_r_nf_page_ptr = 0;		   	//Cur read page for saving virtual buf data. 
// 1  hs_to_virtual_buf_ptr = 0;					//lba tab ptr for wrting	

// 1  virtual_to_nf_buf_ptr = 0;					//lba tab ptr for reading.
// 1  virtual_sd_data_buf_cnt = 0;    			   	//virtual buf sectors for wating for saving. 
// 1  virtual_to_nf_buf_in_per_page_sector_ptr = 0; //offset sector in page read. 
// 1  chksum_1.									   	//chksum

// 2  crc16(sd_virtual_data_buf_lba[][4])			//crc16
// 2  0x00, 0x00

// 4*n virutal_buf_blk_map_lg_nf_blk[n]

// 1   0x00
// 1   virutal_buf_blk_map_lg_nf_blk_r_ptr
// 1   virutal_buf_blk_map_lg_nf_blk_w_ptr
// 1   chksum_2.									//chksum
************************************************************************************************************************/
/*********************************************************
1:�ͷ���sd bufǰ
����д���µ�sd data
����cache�д�����sd bufͬһpage������,�޷�ͨ���Ƿ�����ӳ����ж�sd buf�������Ƿ���Ч
--->��Ҫ�������Ϣ����,�ж���Ч�������,�Ϳ�λ�����
1)��λ�����:virtual_sd_buf_map_w_nf_page_ptrλ���,�����һ����Чsd buf page
2)��Ч�������:��λ�����ָ����
*********************************************************/
extern unsigned char idata copy_last_virtual_sd_data_buf_cnt;
extern unsigned char code SdVirtualBuf2NfUseMaxPage, SdVirtualBuf2NfUseMaxSector;
void initial_vitrual_buf_parameter_in_powerup(void)
{
//	copy_last_virtual_to_nf_buf_ptr = 0;
	copy_last_virtual_sd_data_buf_cnt = 0;

#if (! EN_POWERUP_SEARCH_VIRTUAL_BUF)

	if (SDBufBlockAddrH != 0xff){
	   	erase_virtual_buf_map_blk();				 //����blk
	}
//	sectors_in_virtual_page_toal = 0;		//����Ҫ,ÿ�λ�ȡLBAֱ�ӻ�ȡ
//	sectors_in_virtual_page_w = 0;	
	virtual_sd_buf_map_w_nf_page_ptr = 0;
	virtual_sd_buf_map_r_nf_page_ptr = 0;
	hs_to_virtual_buf_ptr = 0;
	virtual_to_nf_buf_ptr = 0;		
	virtual_lbabuf_emptycnt = SD_VIRTUAL_BUF_CNT;
	virtual_sd_data_buf_cnt = 0; 
	virtual_to_nf_buf_in_per_page_sector_ptr = 0;
#else

	if ((SDBufBlockAddrH == 0xff) && (SDBufBlockAddrL == 0xff)){
		R8 = 0;
	}else{
		R8 = 1;
	}

	if (R8 == 0){		 // no data in virtual sd buf	
		virtual_sd_buf_map_w_nf_page_ptr = 0;
		virtual_sd_buf_map_r_nf_page_ptr = 0;
		hs_to_virtual_buf_ptr = 0;
		virtual_to_nf_buf_ptr = 0;
		virtual_lbabuf_emptycnt = SD_VIRTUAL_BUF_CNT;
		virtual_sd_data_buf_cnt = 0; 
		virtual_to_nf_buf_in_per_page_sector_ptr = 0;
//		sectors_in_virtual_page_w = 0;
//		sectors_in_virtual_page_total = 0;
		
		return;
	}

	_push_(DPCON);	
	DPCON = 0;
//����blk�����д��page		
//����[R30�� R31)��page	

//#if 1
//uart_send_byte(0x88);
//uart_send_byte(virutal_buf_blk_map_lg_nf_blk[0]>>8);
//uart_send_byte(virutal_buf_blk_map_lg_nf_blk[0]>>0);
//uart_send_byte(virutal_buf_blk_map_lg_nf_blk[1]>>8);
//uart_send_byte(virutal_buf_blk_map_lg_nf_blk[1]>>0);
//#endif

	ER30 = 0;									 		//��Ч���ݵ�page index
	ER31 = *(unsigned char xdata *)(& SdVirtualBuf2NfUseMaxPage);//NF_LG_WORD_LINE_NUMBER;			 			//ûЧ���ݵ�page index
//	ER32	 //��ǰ�����ݵ�page index 
	while((ER31 - ER30) != 1){  //ֱ��ʣ�����ڵ�����

		ER32 = (ER30 + ER31) / 2 ;							//������������Ӧ��page index
		SDBufPageAddr = ER32;
		DPCON = 0x10;									//DPTR0 ����
		read_sdbuf_block();	
	
		//�ж������Ƿ���Ч
		ER02 =  SAVE_CTL_VIRTUAL_BUF_VAR_2_NF_BUF; 		//nf buf (SAVE_CTL_VIRTUAL_BUF_VAR_2_NF_BUF)				
		Sel_Buffer_Addr();
		DP0H = ER01;
		DP0L = ER00;

		DPCON = 0x18;									//DPTR0 ����,���

		#pragma asm
		MOV32_ER0_EDP0
		MOV32_ER1_EDP0
		#pragma endasm
	
		B = ER03 + ER02 + ER01 + ER00 + ER13 + ER12 + ER11;   	//check sum.
		if ((B != ER10) || (ER03 != 0x5a)){				
		 	ER31 = ER32;						//������Ч,������Ч���ݵ�page index
		}else {										  	
			ER30 = ER32;						//������Ч,������Ч���ݵ�page index
		}				
	}
//--------------------------------------------------------------------------------------------------------
//R30 �����µ���Чpage index

	SDBufPageAddr = ER30;
	DPCON = 0x10;									//DPTR0 ����
	read_sdbuf_block();	
//--------------------------------------------------------------------------------------------------------
//��ʼ������buf��Ӧ��LBA TAB
// nf buf(SAVE_VIRTUAL_BUF_MAP_LBA_TAB_2_NF_BUF) -> virtual buf lba tab
	//src

	ER02 =  SAVE_VIRTUAL_BUF_MAP_LBA_TAB_2_NF_BUF; //2,����1K,ֻҪread��program virtual bufʱsector num��2���伴��	//nf buf (SAVE_VIRTUAL_BUF_MAP_LBA_TAB_2_NF_BUF)				

	Sel_Buffer_Addr();
	DP1H = ER01;
	DP1L = ER00;	

	//target
	DPTR0 = (u16)(&sd_virtual_data_buf_lba);				//sd virtual buf lba tab

	//len
	#pragma asm
	CLR32_ER0
//	MOV		ER01, # HIGH(SD_VIRTUAL_BUF_CNT * 4)
//	MOV		ER00, # LOW (SD_VIRTUAL_BUF_CNT * 4)
	#pragma endasm						  

	ER01 = (SD_VIRTUAL_BUF_CNT * 5)>>8;
	ER00 = (SD_VIRTUAL_BUF_CNT * 5);

	//copy
	dptr1_cpy_to_dptr0();  //�ظ�lba��sectors_in_page_cnt
 //--------------------------------------------------------------------------------------------------------

	#pragma asm									   //len
	CLR32_ER0
//	MOV		ER01, # HIGH(SD_VIRTUAL_BUF_CNT * 4)
//	MOV		ER00, # LOW (SD_VIRTUAL_BUF_CNT * 4)
	#pragma endasm							   

	ER01 = (SD_VIRTUAL_BUF_CNT * 5)>>8;
	ER00 = (SD_VIRTUAL_BUF_CNT * 5);

	DPTR0 = (u16)(&sd_virtual_data_buf_lba);
	cal_cac16();	// {R8,B} = crc16
 //--------------------------------------------------------------------------------------------------------

//��ʼ������buf��ر���
	ER02 =  SAVE_CTL_VIRTUAL_BUF_VAR_2_NF_BUF; 		//nf buf (SAVE_CTL_VIRTUAL_BUF_VAR_2_NF_BUF)				
	Sel_Buffer_Addr();
	DP0H = ER01;
	DP0L = ER00;

	DPCON = 0x18;									//DPTR0 ����,���
	#pragma asm
	MOV32_ER0_EDP0
	MOV32_ER1_EDP0
	MOV32_ER2_EDP0									//crc16_h, crc16_l, 0x00, 0x00

	#pragma endasm

//#if 0
//uart_send_byte(0xcc);
//uart_send_byte(R30);	 
//
//uart_send_byte(R03);
//uart_send_byte(R02);
//uart_send_byte(R01);
//uart_send_byte(R00);
//
//uart_send_byte(R13);
//uart_send_byte(R12);
//uart_send_byte(R11);
//uart_send_byte(R10);
//
//uart_send_byte(R23);
//uart_send_byte(R22);
//uart_send_byte(R21);
//uart_send_byte(R20);
//
//uart_send_byte(SDBufBlockAddrH);
//uart_send_byte(SDBufBlockAddrL);
//#endif

	ACC = ER03 + ER02 + ER01 + ER00 + ER13 + ER12 + ER11;   	//check sum.
	if ((ACC == ER10) &&  (ER03 == 0x5a) 
		&& (R8 == ER23) && (B == ER22)){					//chk crc16
	
		virtual_sd_buf_map_w_nf_page_ptr = ER02;			//����ָ�ʱ������һ��page����д����
		virtual_sd_buf_map_r_nf_page_ptr = ER01;
		hs_to_virtual_buf_ptr = ER00;
		
		virtual_to_nf_buf_ptr = ER13;
		virtual_sd_data_buf_cnt = ER12; 
		virtual_to_nf_buf_in_per_page_sector_ptr = ER11;

//		sectors_in_virtual_page_total = 0;//����Ϊ0��������ʱ��⵽��ȥ���¼��غͼ���lba
			

//		virtual_lbabuf_emptycnt =  virtual_sd_buf_map_r_nf_page_ptr;//������ʱ����,�������⻺������Ҫȫ�̹�timer
//		if (virtual_sd_buf_map_w_nf_page_ptr >= virtual_sd_buf_map_r_nf_page_ptr) {
//			virtual_lbabuf_emptycnt += SD_VIRTUAL_BUF_CNT;
//		}	
//		virtual_lbabuf_emptycnt -= virtual_sd_buf_map_w_nf_page_ptr;//������
		virtual_lbabuf_emptycnt =  virtual_to_nf_buf_ptr;//������ʱ����,�������⻺������Ҫȫ�̹�timer
		if (hs_to_virtual_buf_ptr >= virtual_to_nf_buf_ptr) {
			virtual_lbabuf_emptycnt += SD_VIRTUAL_BUF_CNT;
		}	
		virtual_lbabuf_emptycnt -= hs_to_virtual_buf_ptr;//������
			
//		prints("p up cnt");
//		printHexSync(virtual_to_nf_buf_ptr);
//		printHexSync(hs_to_virtual_buf_ptr);			
////		printHexSync(SD_VIRTUAL_BUF_CNT);
//		printHexSync(virtual_lbabuf_emptycnt);
////prints("pw sc vv");
//printHexSync(virtual_sd_buf_map_w_nf_page_ptr);
//printHexSync(virtual_sd_buf_map_r_nf_page_ptr);
//printHexSync(virtual_to_nf_buf_in_per_page_sector_ptr);
////printHexSync(hs_to_virtual_buf_ptr);	
////printHexSync(virtual_to_nf_buf_ptr);
//printHexSync(virtual_sd_data_buf_cnt);	
			
//		copy_last_virtual_sd_data_buf_cnt = virtual_sd_data_buf_cnt;

	}else{		  									//У�����
		
		erase_virtual_buf_map_blk();				 //����blk
		virtual_sd_buf_map_w_nf_page_ptr = 0;
		virtual_sd_buf_map_r_nf_page_ptr = 0;
		hs_to_virtual_buf_ptr = 0;
		virtual_to_nf_buf_ptr = 0;
		virtual_lbabuf_emptycnt = SD_VIRTUAL_BUF_CNT;
		virtual_sd_data_buf_cnt = 0; 
		virtual_to_nf_buf_in_per_page_sector_ptr = 0;
	}
//------------------------------------------------------------------------------------------------------------------------

//uart_send_byte(0xbb);
//uart_send_byte(virtual_sd_buf_map_w_nf_page_ptr);	 
//uart_send_byte(virtual_sd_buf_map_r_nf_page_ptr);
//uart_send_byte(hs_to_virtual_buf_ptr);
//
//uart_send_byte(virtual_to_nf_buf_ptr);
//uart_send_byte(virtual_sd_data_buf_cnt);
//uart_send_byte(virtual_to_nf_buf_in_per_page_sector_ptr);

 	_pop_(DPCON);

#endif
}