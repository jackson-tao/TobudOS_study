#include "inc\common.h"				
#include "inc\ax215_exinst.h"		 
#include "inc\nand_flash.h"							 
#include "inc\sd_spi_com_define.h"				 				  
#include "inc\array_FIFO.h"
#include "inc\extern_data.h"
#include "inc\sdsd.h"
#include "inc\mrom_func.h"



#ifdef _MLC_
extern bit bReadNewBlockTrue;
#endif

#pragma asm
EXTRN CODE (CUR_LBA,ERASE_START_LBA, ERASE_END_LBA)
EXTRN CODE (AKE_CHALLENGE_2_BUF,SecurityArgm) 
EXTRN CODE (Get_LgAddr)
EXTRN CODE (Kmu_x,Kmu_array,C2_GKeyTmp,KmuTmp,Ks)
EXTRN CODE (CPRM_MKB_OFFSET,AKE_CHALLENGE_1_RPS_BUF,AKE_CHALLENGE_2_RPS_BUF)
EXTRN CODE (SD_MaxUserDataCap,SectorPerBlock)
EXTRN BIT (bCPRM_E_D_Flag)
EXTRN BIT (bFirstEnDecodeData)
#pragma endasm
extern u8 code LBA_TMP,AKE_CHALLENGE_1_BUF;
extern unsigned char code _PagePhAddr_Buf; 
extern char putchar(char);
extern u8 idata last_SSTA_P1;
void cprm_encode_data(void);
extern void Find_Reserved_Blocks_test(void);
void xrl_p0(u8 dat);
extern void cmd_entrance_tab_init(void);

extern void set_SD_cmd_IP(byte SDNum, byte Priority);
extern void Uart_Send_Byte(u8 dat);
extern void printHexSync(u8 dat);
extern void prints(u8 *p);
extern unsigned char code SdVirtualBuf2NfUseMaxPage;
extern bit bStopClearBusyIng;
extern unsigned short idata timer_dly_timeout,timer_dly;			   //timeout ������

void main(void)							   
{		
	
	DPCON = 0;
	
	system_initial();		
	bNandPowerup = 0;
	bStopClearBusyIng = 0;
#if 0
	_push_(PAGEMAP);
	sfrpage(3);  
	ER01 = 0x70;
	while(ER01 < 0xff) {
		TMRPR_P3 = ER01;
		ER00 = 20;	
		while (ER00--)	 
			Uart_Send_Byte(0x55);
		
		Uart_Send_Byte(ER01);
		ER01++;
	}
	_pop_(PAGEMAP);
#endif
	bAKERcvType = 0;
	nf_power_up_pro();
#if EN_CPRM	
	initial_cprm_pamameter();  //�ŵ��ϵ��,�ϵ�buf��BBT,�����ı�BBT buf
#endif	
	SD_init();		
	bNandPowerup = 1;
		
	bInReadLba = 0;	
	READY_FOR_DATA = 1;	

prints("print test\n");					

	while(1)
	{
		enable_timer_isr();		 			//�ϵ���ϣ����ߣ���stop�󣬴�timer isr.	
		R8 = yTast_Index;		
		if ((R8 != Single_Write_Task) && 
			(R8 != Mul_Write_Task) && 
			(R8 != Secutity_Mul_Write_Task) && 
			(R8 != Erase_Task) && 
			(R8 != Security_Erase_Task) &&
			(R8 != Idle_Task) 
			){
		
			EA = 0;
	if (R8 == yTast_Index) {			
			R8 = yTast_Index;	  //R8�ٸ�ֵ,if�ڲ���cmd�жϿ��ܻ�����⡣Ҳ���԰�EA�ŵ�ifǰ
				
			yTast_Index = Idle_Task;			
			bCallWriteLBA = 0;			  	//���read cmd ��timer copy data ���� write_data_from_hs_buf_to_flash֮��
	}
			EA = 1;
		}
			
//putchar('a');	
//PrintHex(R8);		 				
		switch(R8)
		{

		 case Idle_Task:
			  if ((sd_ready_for_nf_buf_cnt == 0) &&   	//û�����ݵȴ�д��flash������£��Ž���power down
				(virtual_sd_data_buf_cnt == 0) &&
				(rcv_data_state == HS_RCV_DATA_IN_IDLE) &&					//���˳�singe write	 //���˳�mul write
				(write_hs_data_to_flash_state == W_HS_DATA_TO_FLASH_IDLE) &&
				(write_virtual_sd_buf_data_to_nf_state == W_VIRTUAL_SD_BUF_DATA_TO_NF_IDLE)) {				 		 	 
	//			  	 bNandPowerup = 1;						//Re-power up start
//xrl_p3(1 << 6);	
#if POWER_DOWN_EN		
		if (!bMulWriteTask && !bSingleWriteTask) {										
					wait_for_enter_sleep_mode();				 
		}
#endif 					
//xrl_p3(1 << 6);	
//xrl_p3(1 << 6);	
//xrl_p3(1 << 6);	
//xrl_p3(1 << 6);
//xrl_p3(1 << 6);
//xrl_p3(1 << 6);
			   }	
			break;

#if EN_CPRM			
		 case Security_Erase_Task:
			  //Auto jmp to Erase_Task
#endif			  	  			                         
		 case Erase_Task:
#if (!EN_DEBUG_SD)
			  if ((sd_ready_for_nf_buf_cnt == 0) && (virtual_sd_data_buf_cnt == 0)) {	  //��֤����buf��û�����ݣ��������ݲ����󣬾������ָ��µ�����LBA��
								
//				  wait_cmd_rps_ready();													  //����Ҫ�ȴ�cmd  rpsͬ��

				  if ( ! bTmpWriteProtect)
				  {
//				 	if ( ! Read_Bank_Codes()){
					if (1){									  //�����ٶ�
						erase_lba_change_sector_mode();
						if ( ! erase_task_parameter_analysis())
						{
							erase_data_process();
						}				
					}
				  }
				  else
				  {
					WP_ERASE_SKIP = 1;
				  }
				  yTast_Index = Idle_Task;													 //��������ִ����ϣ��Ž���idle״̬
//���� blk				 
				  rcv_one_packet_case_in_pro_state_process();				  				  
				  bInEraseTask = 0;
				  bEnVirtualBuf2Nf = 0;
			  }else{
				 bEnVirtualBuf2Nf = 1;		//���ϵ�󣬼�ʹbEnVirtualBuf�����ݣ��ȴ�����д���ݺ󣬲Ÿ��µ�flash
			  }
#endif
			  break; 
									   
		 case Pro_CSD_Task:
#if (!EN_DEBUG_SD)
			  wait_cmd_rps_ready();
			  wait_dma_in_ready();
			  bDataIn_Flag = 0;
			  
			  bTmpWriteProtect = (bit)((*((char xdata *)(_DATA_BUF)+14))& (1<<4));

			  rcv_one_packet_case_in_pro_state_process();
#endif
			  break; 

		 case GEN_CMD_Write_Task: 
#if (!EN_DEBUG_SD)
			  wait_cmd_rps_ready();
			  wait_dma_in_ready();
			  SDICON_P1 &= ~(1<<0);
			  bDataIn_Flag = 0;
			  rcv_one_packet_case_in_pro_state_process();
			  bSingleWriteTask = 0;
#endif
			  break; 


		 default:     
			read_only_tasks(R8);
			break;
		}

		if (bCallWriteLBA) {	
//prints("w\n");			
			write_data_from_hs_buf_to_flash();	
		}
		
		clr_sd_read_data_flag();
		
	}
}

void erase_lba_change_sector_mode(void)
{
	#pragma asm	
	PUSH	DPCON
	MOV		DPCON, # 0x08 | (1<<1)					//���, �ر�����, dptr0, ����λ���bit��0		
	MOV		DPTR, # ERASE_START_LBA
	MOV32_ER3_EDP0			
	MOV		DPTR, #	ERASE_END_LBA
	MOV32_ER2_EDP0	
	
	JB		bSDHC, ERASE_SDHC_CARD
	MOV		R8, # 9
	ROTR32_ER2_ER8
	ROTR32_ER3_ER8
	MOV		DPTR, # ERASE_START_LBA		  
	MOV32_EDP0_ER3
	MOV		DPTR, # ERASE_END_LBA	 
	MOV32_EDP0_ER2
	ERASE_SDHC_CARD:								
	POP	  DPCON
	#pragma endasm

}

void read_only_tasks(unsigned char task_index)
{
	switch (task_index){
		 case Idle_Task:

			  break;
														 
		 case READ_SCR_Task:			 		 
			  bReadType = 1;  			  
			  wait_cmd_rps_ready_and_en_sdodly();
			  SDXADR0_P1 = SCR_DMA_ADDR_L;
			  SDXADR1_P1 = SCR_DMA_ADDR_H;
			  SDDL0_P1 = 7;
			  SDDL1_P1	= 0;
			  dma_data_out_kict_and_wait_ready(0xfe); 	 
			  break; 
								  
		 case Single_Read_Task:	
			  get_lba();  
			  bReadType = 1;		  
			  wait_cmd_rps_ready_and_en_sdodly();
			  check_addr_out_of_range();
			  bDataOut_Flag = 0;
			  read_lba_data();

				bInReadLba = 0;
			  bCMD0Rcv = 0;
			  SDODLY_P1 = 0xfe;		               
			  break;
	
	#if EN_CPRM	
		 case Security_Mul_Read_Task:  
			  bVisitCprmDataMode = 1;
			  bCprmDmaDataMode = 1;
			  //Auto jmp to Mul_Read_Task
	#endif
		 case Mul_Read_Task:			
			  get_lba();  
			  #pragma asm
				CLR32_ER2
			  #pragma endasm			  			 
			  initial_valid_sector_cnt();			  
			  mul_read_process();			//bReadType = 0; 
			  break;  
								  
										
		 case SD_State_Task:
			  bReadType = 1; 			 
			  wait_cmd_rps_ready_and_en_sdodly();
			  SDXADR0_P1 = SD_STATE_DMA_ADDR_L;
			  SDXADR1_P1 = SD_STATE_DMA_ADDR_H;
			  SDDL0_P1 = 63;
			  SDDL1_P1	= 0;
			  dma_data_out_kict_and_wait_ready(0xfe);		 	 
			  break;  
								   
		 case SD_Fun_Task:
			  bReadType = 1; 
			  switch_clk_frq();
			  break;  
	
									 
		 case Get_WellWR_Task:
	#if (!EN_DEBUG_SD)
			  bReadType = 1;   
			  wait_cmd_rps_ready_and_en_sdodly();
			  SDXADR0_P1 = WR_BLOCKS_TAB_DMA_ADDR_L;
			  SDXADR1_P1 = WR_BLOCKS_TAB_DMA_ADDR_H;
			  SDDL0_P1 = 3;
			  SDDL1_P1 = 0;
			  dma_data_out_kict_and_wait_ready(0xfe);
	#endif
			  break; 
								
		 case WP_STATE_Task: 
	#if (!EN_DEBUG_SD)
			  bReadType = 1; 
			  wait_cmd_rps_ready_and_en_sdodly();
			  SDXADR0_P1 = WP_NUM_TAB_DMA_ADDR_L;
			  SDXADR1_P1 = WP_NUM_TAB_DMA_ADDR_H;
			  SDDL0_P1 = 3;
			  SDDL1_P1 = 0;
			  dma_data_out_kict_and_wait_ready(0xfe);
	#endif
			  break;  
								  
		 case GEN_CMD_Read_Task:
	#if (!EN_DEBUG_SD)
			  bReadType = 1; 
			  wait_cmd_rps_ready_and_en_sdodly();
//			  SDXADR1_P1 = LBATmp1;
//			  SDXADR0_P1 = LBATmp0;
		 #pragma asm
				MOV 	DPTR,#(LBA_TMP+2)
				MOVX	A,@DPTR
				MOV 	SDXADR1_P1,A
			
		 		MOV 	DPTR,#(LBA_TMP+3)
				MOVX	A,@DPTR
				MOV 	SDXADR0_P1,A
		 #pragma endasm
			  SDDL0_P1 = 0xff;
			  SDDL1_P1 = 0x01;
			  dma_data_out_kict_and_wait_ready(0xfe);
	#endif
			  break;  
							   
	
	#if EN_CPRM			                  
		 case MID_Task: 
			  bReadType = 1; 
			  wait_cmd_rps_ready_and_en_sdodly(); 
			  SDXADR0_P1 = MID_DMA_ADDR_L;
			  SDXADR1_P1 = MID_DMA_ADDR_H;
			  SDDL0_P1 = 7;
			  SDDL1_P1 = 0;
			  dma_data_out_kict_and_wait_ready(0xfe);   
			  SDDL0_P1 = 0xff;
			  SDDL1_P1 = 0x01;
			  break; 
									
		 case MKB_Task:							  //ǿ���˳�flashд���ݺ�������������ѭ����Ӧ������
			  dma_mkb_pro();						//����CPRMģʽ��־�����encode/decode��־����ȡָ����ȡMKB LBA��ER3	
			  if (B == 0)
			  {
				mul_read_process();	   //bReadType = 0;  
			  }else {//if (last_SSTA_P1 == 5) {
					SSTA_P1 = 4;
					last_SSTA_P1 = 4;
				}
			  break;   
						
		 case RCV_AKE_CHLG_1_Task: 				   //ǿ���˳�flashд���ݺ�������������ѭ����Ӧ������
			  while ((write_hs_data_to_flash_state != W_HS_DATA_TO_FLASH_IDLE) || 
					(write_virtual_sd_buf_data_to_nf_state != W_VIRTUAL_SD_BUF_DATA_TO_NF_IDLE)){};	//ͬ��timerд����������idle״̬�¶�����.
	
			  bAKERcvType = 0;
			  ake_rev_data_process();		
			  break; 
							 
		 case RCV_AKE_CHLG_2_RPS_Task: 			  //ǿ���˳�flashд���ݺ�������������ѭ����Ӧ������
			  while ((write_hs_data_to_flash_state != W_HS_DATA_TO_FLASH_IDLE) || 
					(write_virtual_sd_buf_data_to_nf_state != W_VIRTUAL_SD_BUF_DATA_TO_NF_IDLE)){};	//ͬ��timerд����������idle״̬�¶�����.
	
			  bAKERcvType = 1;
			  ake_rev_data_process();	   	
			  break;  
						
		 case SEND_AKE_CHLG_2_Task:  
			  while ((write_hs_data_to_flash_state != W_HS_DATA_TO_FLASH_IDLE) || 
					(write_virtual_sd_buf_data_to_nf_state != W_VIRTUAL_SD_BUF_DATA_TO_NF_IDLE)){};	//ͬ��timerд����������idle״̬�¶�����.
	
				DPTR0 =  AKE_CHALLENGE_2_BUF_ADDR;
				DPTR1 =  AKE_CHALLENGE_1_BUF_ADDR;
				copy_dptr1_8_byte_data_to_dptr0();
	#if 1	//;CHALL_2 come from CHALL_1			
				ER03 = 'Z';
				ER02 = 'G';
				ER01 = 'Z';
				ER00 = 215;	  	 		
				#pragma asm
				XRL32_ER0_ER1									   		//;ER0��Ϊ�����
				MOV		DPTR,	#AKE_CHALLENGE_2_BUF_ADDR
				XRL32_EDP0_ER0	
				MOV		DPTR,	#(AKE_CHALLENGE_2_BUF_ADDR + 4)
				XRL32_EDP0_ER0
				#pragma endasm
	#endif
				SDXADR1_P1 = AKE_CHALLENGE_2_BUF_DMA_ADDR_H;
				SDXADR0_P1 = AKE_CHALLENGE_2_BUF_DMA_ADDR_L;
				ake_send_data_process();
			  break;  
						  
		 case SEND_AKE_CHLG_1_RPS_Task: 
			  while ((write_hs_data_to_flash_state != W_HS_DATA_TO_FLASH_IDLE) || 
					(write_virtual_sd_buf_data_to_nf_state != W_VIRTUAL_SD_BUF_DATA_TO_NF_IDLE)){};	//ͬ��timerд����������idle״̬�¶�����.
			  if (bAKEVerifyErr)
			  {
				bAKEVerifyErr = 0;
					SSTA_P1 = 4;
					last_SSTA_P1 = 4;
			  }
			  else
			  {
				SDXADR1_P1 = AKE_CHALLENGE_1_RPS_BUF_DMA_ADDR_H;
				SDXADR0_P1 = AKE_CHALLENGE_1_RPS_BUF_DMA_ADDR_L;
				ake_send_data_process();
			  }
			  break;   
			
		 case Change_Pro_Area_Task:	//�Ժ���������		 				
			  SDICON_P1 |= (1<<1);    	//	;CLR D0 busy.
			  SSTA_P1 = 4;			   	//	;go to transfer state
				last_SSTA_P1 = 4;
			  break;   
						  
		 case Update_MKB_Task:  	//�Ժ���������	
			  SDICON_P1 |= (1<<1);    	//	;CLR D0 busy.
			  SSTA_P1 = 4;	
				last_SSTA_P1 = 4;
			  break;
	#endif
	
		default:
			  break;
	}
}

void nf_power_up_pro(void)
{
	nf_power_up();
	initial_vitrual_buf_parameter_in_powerup();	//����7THL flash��Ƭ���ú����ܳ�ʱ
}

/************************************************************************************************************************
* ��������void config_hs_cache_buf_dma_addr(unsigned char buf_ptr)	 using 3
* ���룺unsigned char buf_ptr ��buf������
* output: R8 B
* ���ܣ�buf_ptrת����SD DMA ��ַ�����ݴ���XDATA�У�W_BUF_ADDR_H��W_BUF_ADDR_L�������㹫ʽΪDMA addr = buf_ptr * 512 / 4 
* �õ�����ʱ�Ĵ���Ϊ��A,B,DPTR0
************************************************************************************************************************/
void config_hs_cache_buf_dma_addr(unsigned char buf_ptr) 
{
	_push_(DPCON);	

	DPCON = (1<<4);						  //DPTR0 & AUTO_INC 
	DPTR0 = sd_hs_cache_buf_dma_addr;		  //DPTR0 = sd_hs_cache_buf_dma_addr

	ACC =  buf_ptr;
	
	#pragma asm
	RL		A							//A = buf_ptr * 2
	MOV		R8, # 0
	MOV		B, 	A
	ADDDP0								//DPTR0 = sd_hs_cache_buf_dma_addr + buf_ptr * 2
				
	MOVX	A, @DPTR				   	//A = DMA_ADDR_H
	MOV		R8, A						//R8 = DMA_ADDR_H
	MOVX	A, @DPTR					//A = DMA_ADDR_L
	MOV		B, A						//B =  DMA_ADDR_L
	#pragma endasm

	_pop_(DPCON);					  //���Ż�

}

extern void sleep_main(void);
void power_down(void)
{
	
	disable_timer_isr();
	sleep_main();	
}


void wait_cmd_rps_ready(void)
{
	while(1)
	{
		if (bCMD0Rcv)
		{
			break;
		}
		if (bCMDRps_Flag)
		{
			bCMDRps_Flag = 0;
			break;	
		}
	}
}

void wait_cmd_rps_ready_and_en_sdodly(void)
{
	SDODLY_P1 |=  0x01;
	wait_cmd_rps_ready();
}

void wait_dma_out_ready(void)
{
	while(1)
	{
		if (bDataStop_Flag || bDataOut_Flag )
		{
			break;
		}
	}
	bDataOut_Flag = 0;
	SDODLY_P1 &= ~0x01;
}

void dma_data_out_kict_and_wait_ready(unsigned char dly)
{
	_push_(SDODLY_P1);

//	SDODLY_P1 = (4<<1) | (1<<0);		//delay  32 SD CLK.
	SDODLY_P1 = (dly <<1 ) | (1<<0);		//delay  32 SD CLK.
	
	EA = 0;
	if ((SSTA_P1 & 0x0F) == SD_STATE_IN_DATA)
	{
		bDataStop_Flag = 0;			//����
		EA = 1;

		SDOCON_P1 |= (1<<0);
		wait_dma_out_ready();
	}
	EA = 1;

	_pop_(SDODLY_P1);

}

/************************************************************************************************************************
* ��������void change_state_machine_in_data_state(void)
* ���룺
* ���ܣ���DMA out��Ϻ󣬸ı�SD״̬��
* �����
*ע�⣺��DMA out �ж��е��ã��Ķ��ú���Ҫ����䷴��������жϵ�Ӱ��
************************************************************************************************************************/
void change_state_machine_in_data_state(void)
{
	if ((SSTA_P1 & 0x0F) != 4) {   //SSTA_P1 != 4, δ�յ�CMD12
		if ( ! bCMD0Rcv)
		{
			if ( ! bRcvCMD7InDataOrDisState)
			{
				SSTA_P1 = 4;
				last_SSTA_P1 = 4;
				SDICON_P1 &= ~(1<<2);				//;disable cmd12_en
				SDICON_P1 |= (1<<3);				//;enable busycmd_en
			}				
		}
		bMulRFlag = 0;
	//	bStopEn = 0;
		bRcvCMD7InDataOrDisState = 0;	
	} 

}

void get_lba(void)
{
	_push_(PAGEMAP);

	PAGEMAP = 0x01;
	
	ER33 = *(char xdata *)((&LBA_TMP) + 0);
	ER32 = *(char xdata *)((&LBA_TMP) + 1);
	ER31 = *(char xdata *)((&LBA_TMP) + 2);
	ER30 = *(char xdata *)((&LBA_TMP) + 3);
	
	if ( ! bSDHC)
	{
		ER30	&= 0;
		ER31 &= 0xfe;
		R8 = 9;						
		#pragma asm
		ROTR32_ER3_ER8 
		#pragma endasm	
	}
#if EN_CPRM	
	if (bVisitCprmDataMode)
	{
		get_scrty_lba();
	}
#endif
	_pop_(PAGEMAP);
} 

//void check_erase_lba_range(void)
//{
//
//}
/************************************************************************************************************************
* ��������	READ_OFFSET_IN_CURRENT_BUF
* ��ڲ�����	yBlockLen0/yBlockLen1/yBuffer_Index/R0(Bank1)/R1(Bank1) 
* ��Ҫ����Դ��ER0 ER2	DPTR0 DPRT1
* ���ڲ�����	��	
* ����˵����	�ѵ�ǰSECTOR����offset��ʼ������copy���Ե�ǰsectorΪ�׵�ַ�ĵط������DMA OUT����512byte������
************************************************************************************************************************/
//void read_offset_in_current_buf()
//{
//#if 0
//	_push_(DPCON);
//
//	ER02 = yBuffer_Index;
//	Sel_Buffer_Addr();
//	DP0L = ER00;
//	DP0H = ER01;
//	
//	#pragma asm
//	CLR32_ER2
//	#pragma endasm
//	R20 = *((char idata *)(&u16_offset_in_buf) + 1);
//	R21 = *((char idata *)(&u16_offset_in_buf) + 0)& 0x01;
//
//	R02 = yBufIndexCopyTmp;
//	Sel_Buffer_Addr();
//	#pragma asm
//	ADD32_ER0_ER2_ER0
//	#pragma endasm
//
//	DP1L = R00;
//	DP1H = R01;
//
//	#pragma asm
//	CLR32_ER0
//	#pragma endasm
//	R00 = yBlockLen0;
//	R01 = yBlockLen1;
//
//	#pragma asm
//	ADD32_ER0_ER0_ER2
//	INC32_ER0	
//	#pragma endasm
//	*((char idata *)(&u16_offset_in_buf) + 1) = R00;
//	*((char idata *)(&u16_offset_in_buf) + 0) = R01;
//
//	#pragma asm
//	MOV		R2,	yBlockLen0	  				//DMA OUT ����
//	MOV		R3,	yBlockLen1
//	MOV	    DPCON,#31H						//Enable DPTR0/DPTR1 Auto INC ,select toggle enable,select DPTR1	
//	INC		R2
//
//CONTINUE_MEMORY_COPY:
//
//	MOVX	A,@DPTR
//	MOVX	@DPTR,A	
//	DJNZ	R2,CONTINUE_MEMORY_COPY
//	MOV		A,R3
//	JZ		EXIT_MEMORY_COPY
//	DEC		R3
//	MOV		R2,#00H
//	JMP		CONTINUE_MEMORY_COPY
//	
//EXIT_MEMORY_COPY:
//
// 	#pragma endasm
//
//	_pop_(DPCON);
//
//#endif
//}


void judge_cprm_data_dma_out_complete(void)
{
#if EN_CPRM
	if (bCprmDmaDataMode)
	{
		yScrtyUnitCnt--;
		if (yScrtyUnitCnt == 0)
		{
			while( ! bDataOut_Flag)
			{}
			SDICON_P1 &= ~(1<<2);
			SDICON_P1 |= (1<<3);
			bDataStop_Flag = 1;
			bSDStop = 1;			//nfc read stop
			cprm_mul_read_end();
		}	
	}
#endif
}


/************************************************************************************************************************
* ��������void update_er3_to_r_random_lba_var(void)
* ���룺ER3
* �����RANDOMIZE_LBA_TMP[4],��Ϊflash�Ķ����ݵ� ����� LBA��������˶���
************************************************************************************************************************/
void update_er3_to_r_random_lba_var(void)
{
//	#pragma asm
//	PUSH	DPCON
//	MOV		DPCON,# 0x08					//���, �ر�����, dptr0	
//	MOV		DPTR, # CUR_LBA
//	MOV32_ER0_EDP0
//	MOV		DPTR, # RANDOMIZE_LBA_TMP	 	//LBA��Ϊ����
//	MOV32_EDP0_ER0
//	POP		DPCON
//	#pragma endasm
}

void read_lba_data(void)
{	
	
	while (	(write_hs_data_to_flash_state != W_HS_DATA_TO_FLASH_IDLE) || 
			(write_virtual_sd_buf_data_to_nf_state != W_VIRTUAL_SD_BUF_DATA_TO_NF_IDLE)){};	//ͬ��timerд����������idle״̬�¶�����.
	
	_push_(PAGEMAP);   
	PAGEMAP = 0X01;			
				
	EA = 0;
	if ((SSTA_P1 & 0x0F) == SD_STATE_IN_DATA)
	{
		bDataStop_Flag = 0;								 //����
		ReadLBACnt = 0;
		SdDmaReadLBACnt = 0;
		bEnReadLBACnt = 0;
		bSDStop = 0;
		EA = 1;
	
		update_er3_to_cur_lba_var();

#ifdef _MLC_
		bReadNewBlockTrue=0;
#endif	
	
		while( ! bDataStop_Flag) {		
#ifdef _MLC_
				copy_lba();		
				bReadNewBlockTrue=0;
#endif				
			
				bStr_MulRead_SD = 1;							 //timer ��ѯ����bit��ʼ׼��dma out����	
				
				update_cur_lba_to_cur_map_lba_var();
			
				read_lba();	 
				reset_bch();
				
				bEnReadLBACnt = 0;		
				ReadLBACnt = 0;
				SdDmaReadLBACnt = 0;
	
				EA = 0;
				if ( ! bDataStop_Flag) {
					bSDStop = 0;
				}
				EA = 1;
		#ifdef _MLC_			
				if (bReadDataInVirtualBuf) {
					bReadNewBlockTrue = 0;
				}
				while ((!bDataStop_Flag) && (bReadNewBlockTrue && RBLKCNT_P1)) {}; 
		#endif		
				//��dma�꣬�Ի�ȡ��ȷ��lba
				
				if (bReadDataInVirtualBuf) {	
//?????�˴�������bug������û��dma��sd�Ѿ�׼���õ����ݾͳ�ȥ��
					bStr_MulRead_SD = 1;							 //timer ��ѯ����bit��ʼ׼��dma out����	
					yBuffer_Index = 0;
					updata_cur_virtual_sd_buf_data_to_nf(dma_out_r_cur_virtual_buf_map_r_nf_page_ptr, dma_out_r_cur_virtual_buf_map_r_nf_sec_in_page_ptr, yBuffer_Index);
		#ifdef _MLC_		
					bReadNewBlockTrue = 0;
		#endif					
					bDataOut_Flag = 0;
					ReadLBACnt = 1;
					SdDmaReadLBACnt = 1;
					bEnReadLBACnt = 1; 
				}
			
				while( ( ! bDataStop_Flag) && (bReadDataInHsBuf || bReadDataInVirtualBuf) && ( ! bDataOut_Flag)) {}  //data in hs buf������stop��Ϻ���Ҫͬ���ȴ����һ��data dma out�󣬱���(single read && in hs buf)�ٴν��������	  
				bDataOut_Flag = 0;				  //dma out finished.
				bReadDataInHsBuf = 0;			  //0:Data is not in hs buf.
				bReadDataInVirtualBuf = 0;		  //0:Data is not is virtual buf.

		}  //end while( ! bDataStop_Flag)
	}//	end ((SSTA_P1 & 0x0F) == SD_STATE_IN_DATA)	
	EA = 1;
	bSDStop = 1;		

	_pop_(PAGEMAP);
}


void cprm_mul_read_end(void)
{
#if EN_CPRM
	if (bCprmDmaDataMode)
	{
		EA = 0;
		if ( ! bCMD0Rcv)
		{
			change_state_machine_in_data_state();
		}
		EA = 1;
//;\	bDataOut_Flag = 0;
		bCprmDmaDataMode = 0;
		bVisitCprmDataMode = 0;

//		bMulRFlag = 0;
//	   	bStopEn = 0;
	}
#endif
}

void mul_read_end_pro(void)
{
//-----------------------------------------------------------------------------------------------------
////��״̬����صĿ���bit�������һʱ�䴦��������Ӱ����һ��CMD��״̬
	bCMD0Rcv = 0;
//	bMulRFlag = 0;
//	bStopEn = 0;
//-----------------------------------------------------------------------------------------------------
	bDataOut_Flag = 0;		
}

void mul_read_process(void)
{				 	
	bReadType = 0;
	wait_cmd_rps_ready_and_en_sdodly();	//��һ��������Ҫ�����ϴ��DELAY����ֹ������̫�죬host����������
	bDataOut_Flag = 0;
	read_lba_data();
	mul_read_end_pro();
	SDODLY_P1 = 0xfe;
	bInReadLba = 0;
}

void init_write_task_var(void)
{
	bStr_MulWrite = 1;
//	bCallWriteLBA = 0;
	RdCurZone = 0xff;
	yBuffer_Index = _DATA_BUF_INDEX;
}  

void clr_d0_busy_in_rcv_ing(void)
{
	EA = 0;
	READY_FOR_DATA = 1;	
	if ( (bInEraseTask) || ( ! SDCRC)) 
	{
		EA = 1;
		
		do{
			SDICON_P1 |= (1<<1);		//CLR busy, һ������£�sd d0��8��sd clk �ڻ����
		}while( ! chk_sd_d0_busy(12));	//12 sd clk ��busy ��û���������ִ����busy���̣�ֱ��sd d0 ready���˳�		
	
	}
	EA = 1;
	
}

void  sd_stop_single_write_pro(void)
{
	EA = 0;
	if ( ! bCMD0Rcv)
	{
		SSTA_P1 = 7;	
	}
//	bStopEn = 0;
	READY_FOR_DATA = 0;
	EA = 1;

	SDICON_P1 &= ~(1<<0);	//;Disable receive data on SD bus.	
}

void sd_stop_mul_write_pro(void)
{
#if EN_CPRM	
	if ( ! bStopRcvCprmData)
#endif
	{
		wait_cmd_rps_ready();
	}
//	bStopEn = 0;
	READY_FOR_DATA = 0;
	SDICON_P1 &= ~(1<<2);
	SDICON_P1 &= ~(1<<0);	
}

void stop_single_write_fun(void)
{
	sd_stop_single_write_pro();
}
void stop_mul_write_fun(void)
{
	sd_stop_mul_write_pro();
}

#if EN_CPRM
void judge_cprm_data_dma_in_complete(void)
{
	if (bCprmDmaDataMode)
	{
		yScrtyUnitCnt--;
		if (yScrtyUnitCnt == 0)
		{
			bStopRcvCprmData = 1;
			SSTA_P1 = 7;
			last_SSTA_P1 = 7;
		}
	}
}
#endif

//input: delay n sd clk
//return: 1 -- sd d0 ready;  0 -- timeout, and sd do busy still in busy state. 
u8 chk_sd_d0_busy(u8  dly_n_sd_clk)
{
	SDSPICNT_P1 = dly_n_sd_clk > 1 ?  (dly_n_sd_clk  / 2) : 1;			//timeout config.
	do{
		if( ! (SHCON_P1 & BIT(3))){			/// 1 means in busy state.; 0--sd_d0 ready
			return 1;
		}	
		//sd d0 is in busy state
	}while( !(SDSPICNT_P1 & 0x80)); //����SD CLKʱ�ӣ��ȴ���BUSY
	
	//delay dly_n_sd_clk, timeout
	return 0;
}

extern bit bStopClearBusyIng;
void clr_d0_busy_in_rcv_end(void)
{
	bDataIn_Flag = 0;
	bStopMulWriteData = 0;  //���������ӦΪ��stop clear�����з��ֻ����ν����жϣ���bStopMulWriteData=0ʱ��״̬���ֻ�ת��ing״̬,����release hold,�´ξͲ���holdס��
	
	EA = 0;
	if ( ! bRcvCMD7InDataOrDisState)
	{
		EA = 1;
		bStopClearBusyIng = 1;
		do{
			SDICON_P1 |= (1<<1);		//CLR busy, һ������£�sd d0��8��sd clk �ڻ����
		}while( ! chk_sd_d0_busy(12));	//12 sd clk ��busy ��û���������ִ����busy���̣�ֱ��sd d0 ready���˳�		

	}else{
		bStopClearBusyIng = 1;
		bRcvCMD7InDataOrDisState = 0;
		EA = 1;
	}		 
//  bStopMulWriteData = 0;
}

/*************************************************
���øú���������жϣ���ΪӲ��bug,�жϹرյ����ŵ�����
**************************************************/
void change_state_machine_in_pro_dis_state(void)
{
//	EA = 0;
	
	if ( ! bCMD0Rcv)
	{
		if ((SSTA_P1 & 0x0F) == 7)
		{			
			SSTA_P1 = 4;
			last_SSTA_P1 = 4;
		}
		else
		{
			SSTA_P1 = 3;
			last_SSTA_P1 = 3;
			rca_inc();
		}
	}
	else
	{
		bCMD0Rcv = 0;
//prints("bcmd0");		
	}
//	EA = 1;
}

void rcv_one_packet_case_in_pro_state_process(void)
{
EA = 0;	
	change_state_machine_in_pro_dis_state();
EA = 1;	
	if ( ! bRcvCMD7InDataOrDisState)
	{
		clr_d0_busy_in_rcv_ing();
	}
}

void cprm_mul_write_end(void)
{
#if EN_CPRM
	if (bCprmDmaDataMode)
	{
		bCprmDmaDataMode = 0;
		bStopRcvCprmData = 0;			
	}

#endif
}

extern void test_Read(void);
void wait_for_enter_sleep_mode(void)
{	
	_push_(IE1);
	_push_(PAGEMAP);
	PAGEMAP = 3;
	_push_(T3CON_P3);


	#pragma asm
	CLR32_ER0
	#pragma endasm
	
	PAGEMAP = 0;
EA = 0;	
	ER40 = yCMD_Index;
EA = 1;	
	while(1)
	{		
		if ((PCON0_P0 & (1<<3)) || (yTast_Index != Idle_Task) || (yCMD_Index != ER40))	//�����û������,����cmd trigger���ڵȴ�power down̫��
		{
				PCON0_P0 &= ~(1<<3); //clear wake up pending 
				break;
		}
		
		
		#pragma asm
			INC32_ER0
		#pragma endasm

		if (ER02 & (1<<4)) 	//5*16ms	
		{
	
			power_down();			
	
			break;						
		}


	} 

	PAGEMAP = 3;
	_pop_(T3CON_P3);
	_pop_(PAGEMAP);	
	_pop_(IE1);
}


void switch_clk_frq(void)
{
	wait_cmd_rps_ready_and_en_sdodly();
	#pragma asm
	CLR32_ER2
	#pragma endasm	
	ER40 = 0x64;
	bSwitch50M = 0;	
	for (ER00=6; ER00>0; ER00--)	
	{
		R8 = 4;
		#pragma asm
		ROTR32_ER2_ER8	
		#pragma endasm		
		if (((ER30 & 0x0f) != 0) && ((ER30 & 0x0f) != 0x0f) ) 
		{
#if _50M
			if ((u8_pwr_active_cnt < 0x03) && 		 		// >= 3 ǿ��25M SD CLKģʽ	//vaso ¼���ʣ�������SD�����л���50Mģʽ�����Ƕ�ȡ���ݻ������3�κ�����SD��
				(ER00 == 6) && ((ER30 & 0x0f) == 0x01) )			 
//			if ((ER00 == 6) && (ER30 & 0x0f) == 0x01 )
			{
				ER23 = 0x10;
				if (ER33 & (1<<7))
				{
					bSwitch50M = 1;
				}
			}
			else
#endif
			{
				ER23 |= 0xf0; 
				ER40 = 0;
				bSwitch50M = 0;
			}			  
	}
	R8 = 4;
	#pragma asm
	ROTR32_ER3_ER8	
	#pragma endasm							  
	}		  	
	*((char xdata *)(&FUNCTION) + 1)  = ER40;			 
	*((char xdata *)(&FUNCTION) + 14) = ER23;
	*((char xdata *)(&FUNCTION) + 15) = ER22;
	*((char xdata *)(&FUNCTION) + 16) = ER21;	
	SDXADR0_P1 = FUNCTION_DMA_ADDR_L;
	SDXADR1_P1 = FUNCTION_DMA_ADDR_H;	
	SDDL0_P1 = 63;
	SDDL1_P1 = 0;	
	if (ER40 != 0)
	{
		*((char xdata *)(&CSD)+3) = 0x5a;
		*((char xdata *)(&CSD)+15) = *(char xdata *)(&CSD_50M_CRC7);
	}
	else
	{
		*((char xdata *)(&CSD)+3) = 0x32;
		*((char xdata *)(&CSD)+15) = *(char xdata *)(&CSD_25M_CRC7);
	
	}
	dma_data_out_kict_and_wait_ready(0x04);									  //sandisk sd ����32 sd clk ������//@һ����Ӵʵ�
#if _50M

	if ((ER40 != 0) && (bSwitch50M == 1))
	{
		SCCON_P1 |= (1<<5);
	}

#endif
//	change_state_machine_in_data_state();	 //��ISR�ж����洦��״̬��	 	 
}
/************************************************************************************************************************
* ��������void mem_set(unsigned char fill_data)
* ���룺 DPTR0, ER0, fill_data
* DPTR0: buf�׵�ַ
* �̶�512byte
* fill_data: ��Ҫ���������
* ����:	
* �����
* TPM: ER1
************************************************************************************************************************/
void mem_set(unsigned char fill_data)
{
	_push_(DPCON);

	DPCON = 0x18;						//DPTR0 ����,���

	ER10 = fill_data;
	ER11 = fill_data;
	ER12 = fill_data;
	ER13 = fill_data;

	B = 512/4;

	#pragma asm
	MEM_SET_FILL_BUF_LOOP:
	MOV32_EDP0_ER1
	DJNZ	B,	MEM_SET_FILL_BUF_LOOP
	#pragma endasm

	_pop_(DPCON);
}
/************************************************************************************************************************
* ��������sd_lg_write_data
* ���룺ER2(len) 
* ����:	 
* �����
* tmp: 
************************************************************************************************************************/
void sd_lg_write_data(void)
{
	_push_(DPCON);
	DPCON = 0;

	 if (bInEraseTask && (sd_ready_for_nf_buf_cnt == 0) && (virtual_sd_data_buf_cnt == 0)){	
	
	
		 specialBit |= 0x01;
		 
		#pragma asm
		MOV32_ER0_ER2						//�ж�ER2�Ƿ�Ϊ0
		#pragma endasm		
		
		while((EZ == 0) && (PlanRcvSDDataCnt != 0)){
			ER02 =  yBuffer_Index_Start;
			Sel_Buffer_Addr();
			DP0H = ER01;
			DP0L = ER00;
			mem_set(0xff);					//fill 0xff to cur buf 

			#pragma asm
			DEC32_ER2
			#pragma endasm

			NfEmptyBufCnt--;			
			yBuffer_Index_Start++;
			ActualRcvSDDataCnt++;	 
			if (ActualRcvSDDataCnt == PlanRcvSDDataCnt) {
//				bRcvSDDataKickStart = 0;
				break;
			}
		}  //end while()
		bRcvSDDataKickStart = 0;

	 }
	 _pop_(DPCON);
}

void get_SectorPerBlock(void)
{
	#pragma asm
	PUSH	DPCON
	MOV		DPCON, #0x10//INC
	
	//����BlockLBA
	SETB	bStr_MulWrite
	MOV 	B,#2
	CALL	Get_LgAddr//bStr_MulWrite=1ʱ����Ҫ�ò����������Ҫ��Ҳ�ض�Ϊ1
	CLR		bStr_MulWrite
	
//	MOV		R8, SectorPerBlockH
//	MOV		B, 	SectorPerBlockL
	
	POP		DPCON
	#pragma endasm
} 


/************************************************************************************************************************
* ��������void erase_data_process(void)
* ���룺 ERASE_START_LBA[4], ERASE_END_LBA[4]
* ����:	 [ERASE_START_LBA�� ERASE_END_LBA] ������LBA��ַ��д��0xff
* �����
* tmp: 	ER2
************************************************************************************************************************/
extern unsigned char code _FLASH_TWOPLANEMODE;
void erase_data_process(void)
{
	bInWriteLbaFun = 1;		
	
	
	_push_(DPCON);
	
	DPCON = 0x08;				  		//���, �ر�����, dptr0	
//printf("0erasing....");

	#pragma asm			  	
//------����blk�ڵ����,��blk //writing lba
	CALL	update_start_lba_to_cur_lba_maskrom
	CALL	update_cur_lba_to_cur_map_lba_var_maskrom

	MOV		DPTR, # ERASE_START_LBA	
	MOV32_ER0_EDP0
	MOV		DPTR, # ERASE_END_LBA	
	SUB32_ER0_EDP0_ER0	  					 	

	CLR32_ER1
	MOV ER11,#0x20
	SUB32_ER1_ER1_ER0	
  #pragma endasm
	
   if(EC){  
		goto 	erase_data_end;
   }
	



//	 if ((_FLASH_TWOPLANEMODE != 0) && (b2PlaneTrue == 0))  //2 planeǿ����1p�����
//	 {  
//			 #pragma asm
//			 MOV		DPTR, # ERASE_START_LBA	
//			 MOV32_ER2_EDP0
//			 MOV		DPTR, # ERASE_END_LBA	
//			 SUB32_ER2_EDP0_ER2	  					 //ER2 =  ERASE_END_LBA -  ERASE_START_LBA
//			 #pragma endasm	
//			 if ( ! EC) {							//��ַû���			
//				 
////printHexSync(ER23);
////printHexSync(ER22);
////printHexSync(ER21);
////printHexSync(ER20);		 
////prints("\n");		 
//				 
//				 
//				#pragma asm
//				INC32_ER2
//				#pragma endasm		

//				DPCON = 0;
//				init_write_task_var();		
//				write_lba();	
//			} 
//			goto erase_data_end;
//	 }
//   #pragma asm
//	CALL	get_SectorPerBlock
//	CALL	get_cur_lba_to_er1 
//	#pragma endasm

//	 
//	R8 = 0;		
//	B =  SectorPerSmallPageTotal + 1;
//	#pragma asm
//	DIV16_ER1						   //start/SectorPerBlock
//	MOV		ER23,R8
//	MOV		ER22,B
//	#pragma endasm
//	R8 = LargePagePerBlockH;		
//	B =  LargePagePerBlockL;
//	#pragma asm
//	DIV16_ER1						   //start/SectorPerBlock
//	MOV		ER21,R8
//	MOV		ER20,B
//	#pragma endasm  //�ж��Ƿ�block����
//	
////	 printf("2erasing....");
////------write data(0xff) to LBA, len -> ER2----------------------------------------------------------------------	
//	//�ж��Ƿ���ڿ�ǰ��blk�����(blk�������Ƿ�Ϊ0) 
////	if ((R8 != 0) || (B != 0) ){	
//	if (ER23|| ER22||ER21||ER20){		
////prints("wr1:");
////printHexSync(SectorPerBlockH);
////printHexSync(SectorPerBlockL);	
//		
//		#pragma asm	
////		CLR32_ER2
////		MOV		ER20, SectorPerBlockL
////		MOV		ER21, SectorPerBlockH
//		
//		MOV		DPTR, # SectorPerBlock
//		MOV32_ER2_EDP0
//		
//		CLR32_ER0
//		MOV		ER00, B
//		MOV		ER01, R8
//		SUB32_ER2_ER2_ER0			//������block��erase����		   //д���ݳ���ER2(blk_len - start_lba % blk_len,lba��blk���һ����ַ�ķ�Χ )
//	
//		MOV		DPTR, # ERASE_START_LBA	
//		MOV32_ER0_EDP0
//		MOV		DPTR, # ERASE_END_LBA
//		SUB32_ER0_EDP0_ER0
//		INC32_ER0		
//		SUB32_ER1_ER0_ER2			//�ܲ�������,������Χ����end lba
//		#pragma endasm
//		
//		if(EC){								   // ERASE_END_LBA <  (blk_len - start_lba % blk_len)
//		#pragma asm
//		MOV32_ER2_ER0						   //ȡ��Сֵ,������ֶ�д0xff�����
//		#pragma endasm
//		}
////printHexSync(ER23);
////printHexSync(ER22);
////printHexSync(ER21);
////printHexSync(ER20);		 
////prints("\n");
//		
//		#pragma asm	
//		MOV		DPTR, # ERASE_START_LBA		   //������һ��start LBA.
//		ADD32_ER0_EDP0_ER2
//		MOV32_EDP0_ER0
//		#pragma endasm

//		//��������� CUR_LBA, ER2
//		_push_(DPCON);							//write_lba() intial DPCON 
//		DPCON = 0;			
//		init_write_task_var();		
//		write_lba();
//		_pop_(DPCON);
////	printf("3erasing....");
//		//����start LBA to CUR_LBA
//		update_start_lba_to_cur_lba();
//		Update_cur_lba_to_cur_map_lba_var();

//	}
//	
////#pragma asm
////		MOV		DPTR, # ERASE_START_LBA
////		MOV32_ER0_EDP0
////#pragma endasm	
////prints("erase lba2;");
////printHexSync(ER03);
////printHexSync(ER02);
////printHexSync(ER01);
////printHexSync(ER00);
////prints("\n");
//	
////-----------------erase-------------------------------------------------------------------------
//	 #pragma asm
//	 MOV		DPTR, # ERASE_START_LBA	
//	 MOV32_ER2_EDP0
//	 MOV		DPTR, # ERASE_END_LBA	
//	 SUB32_ER2_EDP0_ER2	  					 	//ER2 =  ERASE_END_LBA -  ERASE_START_LBA
//	 #pragma endasm	

//	 if ( ! EC) {								//��ַû���	 
//		#pragma asm
//		INC32_ER2								//ER2 (len)=  ERASE_END_LBA -  ERASE_START_LBA + 1
//		CALL	get_SectorPerBlock
//		#pragma endasm
//		
//		R8 = 0;		
//		B =  SectorPerSmallPageTotal + 1;
//		#pragma asm
//		DIV16_ER2						   //start/SectorPerBlock
//		#pragma endasm
//		R8 = LargePagePerBlockH;		
//		B =  LargePagePerBlockL;
//		#pragma asm
//		DIV16_ER2						   //start/SectorPerBlock
//		MOV32_ER0_ER2		  //��ȡ������block��  				   //�жϽ���Ƿ�Ϊ0
//		#pragma endasm
//		
//		while(EZ == 0){
////prints("erase cnt:");
////printHexSync(ER21);
////printHexSync(ER20);
////prints("\n");					
//				erase_lba();
//									 
//			 #pragma asm			 			//���¼�����һ��START_LBA��ַ
////				CLR32_ER0
////				MOV		ER01, SectorPerBlockH
////				MOV		ER00, SectorPerBlockL

//			 	MOV		DPTR, # SectorPerBlock
//				MOV32_ER0_EDP0
//			 
//				MOV		DPTR, # ERASE_START_LBA
//				ADD32_ER0_EDP0_ER0
//				MOV32_EDP0_ER0	
//					
//				CALL	update_start_lba_to_cur_lba
//				CALL	update_cur_lba_to_cur_map_lba_var_maskrom
//				DEC32_ER2					  //����ER2(erase blk cnt)
//			 #pragma endasm	
//		}  //end of while	 
//	 } //end of if()

//-------write end blk data	----------------------------------------------------------------------
	 #pragma asm
	 MOV		DPTR, # ERASE_START_LBA	
	 MOV32_ER2_EDP0
	 MOV		DPTR, # ERASE_END_LBA	
	 SUB32_ER2_EDP0_ER2	  					 //ER2 =  ERASE_END_LBA -  ERASE_START_LBA
	 #pragma endasm	


	 if ( ! EC) {							//��ַû��
		#pragma asm
		INC32_ER2
		#pragma endasm		
		
#pragma asm
CLR32_ER0 	//ֱ��д���ֻ��д1M
MOV 	ER01,#0x08
MOV 	ER00,#0x04  
SUB32_ER0_ER0_ER2
#pragma endasm
if (EC) {
	#pragma asm
	CLR32_ER2 	//ֱ��д���ֻ��д1M
	MOV 	ER21,#0x08
	#pragma endasm	
}
	
		
		DPCON = 0;
		init_write_task_var();		
		write_lba();	
	}
//-------------------------------------------------------------------------------------------------
	erase_data_end:

	init_write_task_var();
	
	initial_rcv_data_par();
							
	bInWriteLbaFun = 0;					   //write lba in idle.
	
	_pop_(DPCON);
}

void wait_dma_in_ready(void)
{
	while(1)
	{
		if (bCMD0Rcv)
		{
			break;
		}
		if (bDataIn_Flag)
		{
			bDataIn_Flag = 0;
			READY_FOR_DATA = 0;
			break;
		}	
	}
}

extern void disable_force_sd_bus_rcv_data_in_dly(void);
extern unsigned short idata timer_dly_timeout;			   //timeout ������
void write_data_from_hs_buf_to_flash(void)
{  	
 //uart_send_byte(0xd9);
			
		while(bRcvSDDataKickStart) {}
		
		bInWriteLbaFun = 1;					   //writing lba
		init_write_task_var();	
//BlockLBAH = 0;
//BlockLBAL = 0x03;

//uart_send_byte(0xde);	  
		write_lba();
		
		save_hs_buf_data_to_virtual_sd_buf();

		bCallWriteLBA = 0;						 //time_isr�õ���bit��Ϣ,�����ж�stop���Ƿ�������ݵĴ���
		while((write_hs_data_to_flash_state == W_HS_DATA_TO_FLASH_END) || 
			  (write_virtual_sd_buf_data_to_nf_state == W_VIRTUAL_SD_BUF_DATA_TO_NF_END )
			 ){}			  					//�ȴ�timer���˳�д����	
		
		bInWriteLbaFun = 0;					   //write lba in idle.
//uart_send_byte(0xdf);		
}

/************************************************************************************************************************
* ��������void cur_map_lba_inc(void)
* ���룺
* ���ܣ�@CUR_LBA++
* �����@CUR_LBA = @CUR_LBA + 1
*tmp�� DPTR0
************************************************************************************************************************/
void cur_map_lba_inc(void)
{
	_push_(ER03);
	_push_(ER02);
	_push_(ER01);
	_push_(ER00);
	_push_(DPCON);
	
	DPCON = 0x08;				//���, �ر�����, dptr0

	#pragma asm
	MOV	 DPTR, # CUR_LBA  
	MOV32_ER0_EDP0
	INC32_ER0
	MOV32_EDP0_ER0
	#pragma endasm

	_pop_(DPCON);
	_pop_(ER00);
	_pop_(ER01);
	_pop_(ER02);
	_pop_(ER03);
}

/************************************************************************************************************************
* ��������void copy_512byte_data(unsigned char src_buf_index, unsigned char target_buf_index)
* ���룺
* unsigned char src_buf_index	 : hs_cache_buf ��������
* unsigned char target_buf_index ��flash����buf��������
* �����target_buf_indexָ���buf���ݡ�
* ���ܣ��� src_buf_indexָ��buf������copy��target_buf_indexָ���buf�С�
************************************************************************************************************************/
void copy_512byte_data(unsigned char src_buf_index, unsigned char target_buf_index)
{ 

#if EN_HW_COPY_512BYTE
	R8 = src_buf_index;	
	ER02 = target_buf_index;		
	Sel_Buffer_Addr();					 			//(target) ER01, ER00

	DPTR0 = sd_hs_cache_data_buf;					//hs_cache_data_buf

	#pragma asm
	CLR32_ER1
	MOV		ER10, R8
	MOV		ER13, # 0x02 		  						
	MUL16_ER1									   //ER1 = src_buf_index * 0x0200
	MOV		R8, ER11									
	MOV		B,  ER10									
	ADDDP0										  //(src)DPTR0= hs_cache_data_buf + buf_ptr * 0x0200
	#pragma endasm
	
	ER11 = DP0H;
	ER10 = DP0L;

	mem_copy_hw(); //mask���ù̶�512 byte
	
#else

	_push_(DP1H);
	_push_(DP1L);

	_push_(DPCON);
	
	DPCON = 0;
	R8 = src_buf_index;	
	ER02 = target_buf_index;	
	DPTR1 = sd_hs_cache_data_buf;					  //hs_cache_data_buf

	Sel_Buffer_Addr();
	#pragma asm
	MOV		DP0H, ER01
	MOV		DP0L, ER00
	CLR32_ER0
	MOV		ER00, R8
	MOV		ER03, #0x02 		  						
	MUL16_ER0									   //ER0 = src_buf_index * 0x0200
	MOV		R8, ER01									
	MOV		B,  ER00									
	ADDDP1											//DPTR1 = hs_cache_data_buf + buf_ptr * 0x0200

	MOV		DPCON, # 0x31							//Enable DPTR0/DPTR1 Auto INC ,select toggle enable,select DPTR1	
	MOV		B, # 512 / (4 * 8)
	
	COPY_512_BYTE_LOOP:	
		 
	MOV32_ER0_EDP1
	MOV32_EDP0_ER0								   //copy 4 byte
	
	MOV32_ER0_EDP1
	MOV32_EDP0_ER0								   //copy 4 byte
	
	MOV32_ER0_EDP1
	MOV32_EDP0_ER0								   //copy 4 byte
	
	MOV32_ER0_EDP1
	MOV32_EDP0_ER0								   //copy 4 byte

	MOV32_ER0_EDP1
	MOV32_EDP0_ER0								   //copy 4 byte
	
	MOV32_ER0_EDP1
	MOV32_EDP0_ER0								   //copy 4 byte
	
	MOV32_ER0_EDP1
	MOV32_EDP0_ER0								   //copy 4 byte
	
	MOV32_ER0_EDP1
	MOV32_EDP0_ER0								   //copy 4 byte
	
	DJNZ	B, COPY_512_BYTE_LOOP

	#pragma endasm
	
	_pop_(DPCON);
	
	_pop_(DP1L);
	_pop_(DP1H);
#endif

}  


/************************************************************************************************************************
* ��������u8 get_mem_copy_hw_status(void)
* ���룺0: copying;  !=0: copy complete.
* ����:
* �����
************************************************************************************************************************/
u8 get_mem_copy_hw_status(void)
{

#if EN_HW_COPY_512BYTE

	_push_(PAGEMAP);

	PAGEMAP = 0x00;
	B = DMACON_P0 & 0x80;
	
	_pop_(PAGEMAP);
	
	return B;
	
#else

	return 1;

#endif

}

/************************************************************************************************************************
* ��������void config_cur_buf_data_lba(unsigned char buf_ptr)
* ���룺unsigned char buf_ptr ��buf������
* ���ܣ���sd_hs_cache_data_buf_lba[buf_ptr][4]��ȡ��LBA����ŵ�CUR_LBA[4]�У���Ϊflash����ڲ���
* �����CUR_LBA[4],ER0.  ER0 = CUR_LBA[4] = LBA.
************************************************************************************************************************/
void config_cur_buf_data_lba(unsigned char buf_ptr)
{
	_push_(DPCON);
	
	DPCON = 0x08;				//���, �ر�����, dptr0
	
	//���»���buf��Ӧ��LBA TABLE, sd_hs_cache_data_buf_lba[buf_ptr][4] = ER3	
	DPTR0 =  sd_hs_cache_data_buf_lba;	
	R8 = 0;
	B = buf_ptr << 2;		  

#if HW_W_LBA_TAB_SMALL_ENDIAN
	DPCON = 0x00;				//С��, �ر�����, dptr0
#endif
	
	#pragma asm
	ADDDP0					//DPTR0 + (R8 B)	
	MOV32_ER0_EDP0
	#pragma endasm

#if HW_W_LBA_TAB_SMALL_ENDIAN
	DPCON = 0x08;				//���, �ر�����, dptr0
#endif
	
	#pragma asm
	MOV	 DPTR, # CUR_LBA
	MOV32_EDP0_ER0			 //��˴��LBA
	#pragma endasm
			
	_pop_(DPCON);
}

/************************************************************************************************************************
* ��������void clr_sd_read_data_flag(void)
* ���룺
* ����:
* �����
************************************************************************************************************************/
void clr_sd_read_data_flag(void)
{
	EA = 0;
	if ((SSTA_P1 & 0x0F) != SD_STATE_IN_DATA) {
		bInReadLba = 0;
		bCopyNeedStop = 0;
		bSDStop = 0;
	}	
	EA = 1;
}


/*********************************MKB deal**********************************************/
/************************************************************************************************************************
AKE_SEND_DATA_PROCESS:
;input: DMA address(SDXADR1/SDXADR0).
;output:DMA 8byte data to host.
************************************************************************************************************************/
static void ake_send_data_process(void)
{
#if EN_CPRM
	_push_(PAGEMAP);
	PAGEMAP = 1;
	
	bReadType = 1;
	SDDL0_P1 = 7;
	SDDL1_P1 = 0;
	wait_cmd_rps_ready_and_en_sdodly();
	dma_data_out_kict_and_wait_ready(0xfe);
	SDDL0_P1 = 0xff;
	SDDL1_P1 = 1;
	
	_pop_(PAGEMAP);
#endif				
}

