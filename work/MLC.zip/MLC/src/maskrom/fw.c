#include "inc\common.h"
#include "inc\ax215_exinst.h"
#include "inc\fw_sd_spi_var.h"


#pragma asm
	EXTRN CODE (CUR_LBA,CUR_MAP_LBA,ERASE_START_LBA,SD_KICK_DMA_OUT_ER0_COPY,SD_KICK_DMA_OUT_ER1_COPY,PRE_CHK_360_MODE_RESULT) 
	EXTRN CODE (REC_LEN_VALUE,ENABLE_REC_TAB_CLR,clr_buf_at_rec_lba_tab)
#pragma endasm
extern u8 code LBA_TMP[];
extern code W_BUF_ADDR_H,W_BUF_ADDR_L;

/*============================================================
* �Ρ�����:ER01 ER00 = LgAddr ER11 ER10 = PhAddr
* ��������: 
============================================================*/
void Get_Block_PhAddr(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����	
	
	#pragma asm
	//*3
	MOV		ER03,#0
	MOV		ER02,#3
	MUL16_ER0
	//2
	MOV		R8,#0
	MOV		B,#2
	DIV16_ER0
	PUSH	B		//����
	MOV		R8,ER01
	MOV		B ,ER00
	ADDDP0			
	MOVX	A,@DPTR
	MOV		ER00,A
	MOVX	A,@DPTR
	MOV		ER01,A
	POP		ACC	
	#pragma endasm

	if(ACC & (1 << 0)){
		R8 = 4;
		#pragma asm
		ROTR32_ER0_ER8
		#pragma endasm		
	}
	ER01 &= 0x0f;
	ER10 = ER00;
	ER11 = ER01;

	_pop_(DPCON);
}


void Set_Block_PhAddr(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����	

	#pragma asm
	//*3
	MOV		ER03,#0
	MOV		ER02,#3
	MUL16_ER0
	//2
	MOV		R8,#0
	MOV		B,#2
	DIV16_ER0
	PUSH	B		//����	
	MOV		R8,ER01
	MOV		B ,ER00
	ADDDP0
	MOVX	A,@DPTR//��ԭ��������ȡ����������R01 ER00
	MOV		ER00,A
	MOVX	A,@DPTR
	MOV		ER01,A
	DECDP0
	DECDP0
	POP		ACC
	#pragma endasm
	
	if(ACC & (1 << 0)){
		ER13 = 0;
		#pragma asm
		MOV		R8,#4
		ROTL32_ER1_ER8	//�˴���Ҫ�ⲿ���???
		MOV		ER01,#0
		ANL		ER00,#0x0F
		ANL		ER10,#0xF0
		#pragma endasm	
	}else{
		#pragma asm	
		ANL		ER01,#0xF0
		MOV		ER00,#0
		ANL		ER11,#0x0F
		#pragma endasm		
	}

	#pragma asm
	ORL32_ER1_ER0
	MOV		A,ER10
	MOVX	@DPTR,A
	MOV		A,ER11
	MOVX	@DPTR,A
	#pragma endasm

	_pop_(DPCON);
}

void Addr_Block2Bit(void)  //�ŵ�mask rom 
{
	#pragma asm
//	;bit addr
	MOV		R8,ER00								
	XRL		R8,#0x07						
	ANL		R8,#0x07
	MOV		A,#0x80
	ROTR8_EACC_ER8
	MOV		ER10,A

//	;byte addr
	MOV		R8,#3
	ROTR32_ER0_ER8									
	MOV		R8,ER01								
	MOV		B ,ER00							
	ADDDP0	
	#pragma endasm

}

void Buf1_2_Buf0(void)
{
	_push_(DPCON);
	DPCON = 0x10;	
  
	B = (512 / 4);
	do{
		#pragma asm
		MOV32_ER0_EDP1			
		MOV32_EDP0_ER0
		#pragma endasm	
		--B;	
	}while(B);
   
  _pop_(DPCON);
}


void Dptr0_Point_To_Dptr0(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����

	#pragma asm
	MOVX	A, @DPTR   
	MOV		B, A
	MOVX  A, @DPTR
	MOV		DPL, A
	MOV		DPH, B
  #pragma endasm
	 
 	_pop_(DPCON);
}



void Compare_wData(void)   
{
	ER03 = 0;
	ER02 = 0;
	ER13 = 0;
	ER12 = 0;
	#pragma asm
	SUB32_ER0_ER0_ER1	  
	#pragma endasm		
}


void Wait_Flash_Ready(void)
{
	while( ! NTSKD) {}
	_N_NOP_
	NTSKD = 0;
}


void NF_Send_CMD_Only(void)
{
	if(ACC){
		NFIFO0_P2 = ACC;
		NPCON_P2 = 0x01;
		Wait_Flash_Ready();	
	}	
}


void NF_Send_CMD1(void)		
{
	if(ACC){
		NACMD1_P2 = ACC;
		NPCON_P2 = 0x80;
		Wait_Flash_Ready();	
	}
}

void NF_Wait_Read_Over(void)  
{
	Wait_Flash_Ready();
	while( !(BCON1_P2 & (1 << 7))){};
	BCON1_P2 &= ~(1<<7);
	BCMCON_P2 = 0;

}


/*****************************************************
�ú���ûʹ��,�����иĶ��ر�LDO1.8
*****************************************************/
void sleep_main(void)
{
//	unsigned char i;
		_push_(PAGEMAP);		
		_push_(IE);
		_push_(IE1);
		 PAGEMAP &= 0xf8;
		PAGEMAP |= 0;
		_push_(PCON2_P0);
		_push_(PCON1_P0); 
		_push_(CLKCON1_P0);
	
		
	 if (PCON0_P0 & (1<<3) || (yTast_Index != Idle_Task))
		{
				PCON0_P0 &= ~(1<<3); //clear wake up pending 
				goto wake_up_end;
		}
	
		ER10 = P4DIR_P0;
		ER11 = P4PLP_P0;
		ER12 = P0DIR_P0;
		ER13 = P0PLP_P0;
		ER20 = P1DIR_P0;
		ER21 = P1PLP_P0;
		ER22 = P3DIR_P0;
		ER23 = P3PLP_P0;
	
// =========================================
// io setting: input & pullup
// =========================================
// SDCLK_IO
// high voltage, low drive, have noise limit  
/*****P40~P45 SD IO*****/
		EA = 0;  //�ȹ��ж���ȥ��ʼ��IO,�����жϻ�ı�ER�Ĵ���	
/*****P40~P45 SD IO all input & pull up register 30K & defaul driver & defaul noise tolerant*****/	
		P4DIR_P0 = 0xff;//all SD io input 0x3f
		P4PLP_P0 |= (1<<5);
//		P4PLP_P0 = 0x00;
//		P4PLP_P0 = 0xff;//all SD io pull up 30k register choise   30K������  0x3f  //261uA
//		P4PLP_P0 &= ~(1<<1);	//cmd������
//		P4PLP_P0 &= ~(1<<0);	//clk������
//		P4PD_P0	|= (1<<0);		//clk����
//		P4PLP_P0 &= ~(1<<2)|(1<<3)|(1<<4)|(1<<5);	//data������

//		P4PLP1_P0 = 0xff;		//10Kǿ����  400uA
		//30k 10k��������Ϊ7.5K����
		
//all input & pull up   
/*****P00~P01 NCE0/1*****/
/*****P1 NF data0~7*****/
/****
 *P30	NWP
 *P31 NCLE
 *P32 NALE
 *P33	NWE
 *P34	NRE
 *P35	NRB0
 *P36	NRB1
 *P37	NDQS
******/
		P0DIR_P0 = 0xff;//0x03;
		P0PLP_P0 = 0xff;//0x03;
		
		P1DIR_P0 = 0xff;
		P1PLP_P0 = 0xff;
		
		P3DIR_P0 = 0xff;
		P3PLP_P0 = 0xff;
		
/****power down******/
		PCON0_P0 |= (1<<1)|(1<<0);//FALLING EDGE(default SDCLK)
		PCON0_P0 |= (1<<2);//wake up enable
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();//wait power down 
		
		PCON2_P0 |= 0x01;		  //low power enable
		PCON2_P0 &= ~(1<<1);	  //disable LDO18
		PCON1_P0 &= ~0x02;		  //lvd disable  
	////	PCON2_P0 &= ~(0xf0);	  //ldo12 = 0.8V
	////	PCON2_P0 &= ~(0x0c);	  //ldo18 = V
		CLKCON1_P0 |= BIT(3);     // disable RC when power down		
			
		PD = 1;
		_nop_(); 
		_nop_(); 
		_nop_(); 
		_nop_(); 
		_nop_(); 
		_nop_(); 
		_nop_(); 

		PCON0_P0 &= ~(1<<3);//clear wake up pending 
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	
		
		P4DIR_P0 = ER10;
		P4PLP_P0 = ER11;
		P0DIR_P0 = ER12;
		P0PLP_P0 = ER13;
		P1DIR_P0 = ER20;
		P1PLP_P0 = ER21;
		P3DIR_P0 = ER22;
		P3PLP_P0 = ER23;
wake_up_end:
		PAGEMAP = 0;
		_pop_(CLKCON1_P0);
		_pop_(PCON1_P0);
		_pop_(PCON2_P0);
		_pop_(IE1);  //�ж���Ӧλ��
		_pop_(IE);
		_pop_(PAGEMAP); 
}

void disable_timer_isr(void)
{
	IE1 &= ~ BIT(3);
}


void enable_timer_isr(void)
{	 
	IE1 |= BIT(3);
}


void timer3_clr_tof(void)
{
	_push_(PAGEMAP);
	PAGEMAP = 3;					
	T3CON_P3  &= ~BIT(7); 	
	_pop_(PAGEMAP);
}



void power_down(void)
{
	_push_(PAGEMAP);
	PAGEMAP = 3;
	_push_(T3CON_P3);
	disable_timer_isr();
	sleep_main();	
	enable_timer_isr();
	PAGEMAP = 3;
	_pop_(T3CON_P3);
	_pop_(PAGEMAP);
}





void wait_for_enter_sleep_mode(void)
{
	_push_(PAGEMAP);
	PAGEMAP = 0;
	#pragma asm
	CLR32_ER0
	#pragma endasm

	while(1)
	{
		if (PCON0_P0 & (1<<3) || (yTast_Index != Idle_Task))	
		{
				PCON0_P0 &= ~(1<<3);
				break;
		}
			
		#pragma asm
			INC32_ER0
		#pragma endasm
		if (ER02 & (1<<4)) 
		{
			power_down();			
			break;						
		}
	} 
	_pop_(PAGEMAP);
}


void dptr1_cpy_to_dptr0(void)
{
#pragma asm
	    
		PUSH	DPCON	
		MOV	    DPCON,#0x31						
	
	COPY_N_BYTE_GO_ON:
		MOVX	A,@DPTR
		MOVX	@DPTR,A
		DEC32_ER0
		JNB	EZ, COPY_N_BYTE_GO_ON
		POP		DPCON

#pragma endasm
}



void cur_lba_dec(void)
{
	_push_(DPCON);
	
	DPCON = 0x08;				

	#pragma asm
	MOV	 DPTR, # CUR_LBA  
	MOV32_ER0_EDP0
	DEC32_ER0
	MOV32_EDP0_ER0
	#pragma endasm

	_pop_(DPCON);
}


void update_er3_to_cur_lba_var(void)
{
	#pragma asm
	PUSH	DPCON
	MOV		DPCON, # 0x08		
	MOV	 	DPTR, # CUR_LBA
	MOV32_EDP0_ER3					
	POP		DPCON
	#pragma endasm

}


void update_cur_lba_to_cur_map_lba_var(void)
{
	#pragma asm
	PUSH	ER03
	PUSH	ER02
	PUSH	ER01
	PUSH	ER00

	MOV		DPTR, # CUR_LBA
	MOV32_ER0_EDP0
	MOV	 	DPTR, # CUR_MAP_LBA
	MOV32_EDP0_ER0				

	POP		ER00
	POP		ER01
	POP		ER02
	POP		ER03
	#pragma endasm

}



void mem_copy_hw(void)
{	
	_push_(PAGEMAP);

	PAGEMAP = 0x00;

	DMARADRH_P0 = ER11;	
	DMARADRL_P0 = ER10;

	DMAWADRH_P0 = ER01;	
	DMAWADRL_P0 = ER00;

	DMACNTH_P0  = (u8)((511 >> 8) & 0xff);	
	DMACNTL_P0  = (u8)((511 >> 0) & 0xff) ;

	DMACON_P0 |=0x40;	
	
	DMACON_P0   = 0x05; 
			  
	while((DMACON_P0 & 0x80) == 0);	
	
	DMACON_P0 |=0x40;	
	
	_pop_(PAGEMAP);
}


void mem_copy_hw_clr_pending(void)
{
	_push_(PAGEMAP);

	PAGEMAP = 0x00;
	
	DMACON_P0 |=0x40;	//clear pending	
	
	_pop_(PAGEMAP);
}



void cal_cac16(void)
{	

#if 1
	_push_(PAGEMAP);	   
	
	 PAGEMAP &= 0xf8;
	 PAGEMAP |= 3;

	_push_(TMRCON_P3);   
	_push_(TMRCNT_P3);
	_push_(TMRPR_P3);	
 	
	_push_(DPCON);

	DPCON = 0x10;								
	TMRCON_P3 = 0x03;
	TMRCNT_P3 = 0;
	TMRPR_P3 = 0;


	do{
		#pragma asm				
		MOVX	A, @DPTR
		MOV		TMRSPBUF_P3, A
		NOP			
		DEC32_ER0
		#pragma endasm
	}while( ! EZ);

	R8 = TMRPR_P3;									
	B = TMRCNT_P3;										   

	_pop_(DPCON);	 
	_pop_(TMRPR_P3);
	_pop_(TMRCNT_P3);
	_pop_(TMRCON_P3);     
	
	_pop_(PAGEMAP);	
#endif

}

void get_cur_lba_to_er1(void)
{
	_push_(DPCON);
	
	DPCON = 0x08;				

	#pragma asm
	MOV	 DPTR, # CUR_LBA  
	MOV32_ER1_EDP0
	#pragma endasm

	_pop_(DPCON);
}


void update_start_lba_to_cur_lba(void)
{
	#pragma asm
	MOV		DPTR, # ERASE_START_LBA
	MOV32_ER0_EDP0
	MOV		DPTR, #	CUR_LBA
	MOV32_EDP0_ER0
	#pragma endasm	
}



void sd_kick_dma_out_data_push_er0_er1(void)
{
	#pragma asm
	MOV	DPTR, # SD_KICK_DMA_OUT_ER0_COPY
	MOV32_EDP0_ER0
	MOV	DPTR, # SD_KICK_DMA_OUT_ER1_COPY
	MOV32_EDP0_ER1
	#pragma endasm
}

void sd_kick_dma_out_data_pop_er0_er1(void)
{
	#pragma asm
	MOV	DPTR, # SD_KICK_DMA_OUT_ER1_COPY
	MOV32_ER1_EDP0
	MOV	DPTR, # SD_KICK_DMA_OUT_ER0_COPY
	MOV32_ER0_EDP0
	#pragma endasm
}



void get_arg_to_lba_tmp(void)
{
		*(char xdata *)((&LBA_TMP) + 0) = SARG7_P1;
		*(char xdata *)((&LBA_TMP) + 1) = SARG6_P1;
		*(char xdata *)((&LBA_TMP) + 2) = SARG5_P1;
		*(char xdata *)((&LBA_TMP) + 3) = SARG4_P1;
}



void init_sd_kict_rcv(void)
{
#if 1
	
	SDDL0_P1 = 0xff;  //��֧�ֱ䳤
	SDDL1_P1 = 0x01;

	ACCON0_P1 |= BIT(0);	//enable	//ע�⻹û�г�ʼ��LBA3_P1/LBA2_P1/LBA1_P1/LBA0_P1, intial in dma in isr.
	
	SDICON_P1 |= (1 << 3) | (1 << 2) | (1 << 0);
	
	bDataIn_Flag = 0;

	*(char xdata *)((&LBA_TMP) + 0) = SARG7_P1;
	*(char xdata *)((&LBA_TMP) + 1) = SARG6_P1;
	*(char xdata *)((&LBA_TMP) + 2) = SARG5_P1;
	*(char xdata *)((&LBA_TMP) + 3) = SARG4_P1;
	

#else
	PUSH_R8_ER2_ER3;
	
	SDDL0_P1 = 0xff;  //��֧�ֱ䳤
	SDDL1_P1 = 0x01;

	ER33 = SARG7_P1;	
	ER32 = SARG6_P1;
	ER31 = SARG5_P1;	
	ER30 = SARG4_P1;

	if ( ! bSDHC)
	{
		ER30 &= 0;
		ER31 &= 0xfe;
		R8 = 9;						
		#pragma asm
		ROTR32_ER3_ER8 
		#pragma endasm	
	}
							
	LBA3_P1 = ER33;
	LBA2_P1 = ER32;
	LBA1_P1 = ER31;
	LBA0_P1 = ER30;
	
	ACCON0_P1 |= BIT(0);	//enable	
	
	SDICON_P1 |= (1 << 3) | (1 << 2) | (1 << 0);
	
	bDataIn_Flag = 0;

	POP_R8_ER2_ER3;
#endif
}


void inc_read_buf_cnt(void)
{
	_push_(PAGEMAP);
	PAGEMAP = 0x01;
	ACCON1_P1 |= BIT(2);
	_pop_(PAGEMAP);
}

void stop_read_acce(void)
{			 	
	_push_(PAGEMAP);
	PAGEMAP = 0x01;
	ACCON1_P1 &= ~BIT(0);
	_pop_(PAGEMAP);
}


void dec_write_buf_cnt(void)
{
	_push_(PAGEMAP);
	PAGEMAP = 0x01;
	ACCON0_P1 |= BIT(3);
	_pop_(PAGEMAP);
}

void stop_write_acce(void)
{			 	
	_push_(PAGEMAP);
	PAGEMAP = 0x01;
	ACCON0_P1 &= ~ BIT(0);
	_pop_(PAGEMAP);
}


void config_dma_buf_addr(void)
{

	SDXADR1_P1 = *(char xdata *)(&W_BUF_ADDR_H);
	SDXADR0_P1 = *(char xdata *)(&W_BUF_ADDR_L);						
	SDICON_P1 |= (1<<0);
	bDataIn_Flag = 0;

}

