#include "inc\common.h"				
#include "inc\ax215_exinst.h"		 
//#include "inc\nand_flash.h"							 
#include "inc\sd_spi_com_define.h"				 				  
//#include "inc\array_FIFO.h"
//#include "inc\extern_data.h"
//#include "inc\sdsd.h"
#include "inc\mrom_func.h"


extern u8 data yScrtyUnitCnt;
extern bit bCPRM_E_D_Flag,bFirstEnDecodeData,bScrtyMode,bVisitCprmDataMode;
extern u8 code _SK_TMP,_Key,_Inkey,C2_GKeyTmp,Ks,Kmu_x,KmuTmp;
extern u8 code SD_Km_DPTR,Kmu_array[],MID[],SBOX_EN_DECODE_KEY,Kmux_DPTR_tmp,CPRM_User_Cap,SecurityArgm,AKE_CHALLENGE_2_BUF;
extern u8 code AKE_CHALLENGE_1_BUF,AKE_CHALLENGE_1_RPS_BUF,LBA_TMP[];
extern void copy_dptr1_8_byte_data_to_dptr0(void);
extern void C2_G(void);
extern void prints(u8 *p);
extern void printHexSync(u8 dat);
extern unsigned char code sd_hs_cache_data_buf [];

extern u8 code SD_STATE;
void initial_cprm_pamameter(void)
{

#if EN_CPRM
		u8 xdata *p;
	
		_push_(DPCON);
		
	
		DPCON = 0x1A;  //dptr1 auto inc,big endian
		DPTR0 = &Kmu_array;
		DPTR1 = SD_HS_CACHE_BUF_START_ADDR;
		for (yScrtyUnitCnt = 0; yScrtyUnitCnt < 16; yScrtyUnitCnt++) { 
			#pragma asm
			MOV32_ER0_EDP0
			MOV32_EDP1_ER0
			MOV32_ER0_EDP0
			MOV32_EDP1_ER0
			#pragma endasm
		}
		
		DPTR1 = &Kmu_array;
		for (yScrtyUnitCnt = 0; yScrtyUnitCnt < 16; yScrtyUnitCnt++) { 
			DPTR0 = &MID;
			#pragma asm
			MOV32_ER0_EDP0
			MOV32_EDP1_ER0
			MOV32_ER0_EDP0
			MOV32_EDP1_ER0
			#pragma endasm
		}
		
		//DPTR0 KEY
		//DPTR1 result=tmp=mid
		//�������ΪKm,����Kmu		
		DPTR0 = SD_HS_CACHE_BUF_START_ADDR;
		DPTR1 = &Kmu_array;;
		for (yScrtyUnitCnt = 0; yScrtyUnitCnt < 16; yScrtyUnitCnt++) { 
			
			_push_(DP1H);
			_push_(DP1L);
			_push_(DP0H);
			_push_(DP0L);
			
			bFirstEnDecodeData = 1;
			C2_G();	
			
			_pop_(DP0L);
			_pop_(DP0H);
			_pop_(DP1L);
			_pop_(DP1H);
			
			DPTR0 += 8;
			DPTR1 += 8;
		}	
		
		DPCON = 0;
		for (yScrtyUnitCnt = 0; yScrtyUnitCnt < 16*8; yScrtyUnitCnt += 8) { 
			*(u8 xdata *)(&Kmu_array+yScrtyUnitCnt) = 0;
		}

//		DPCON = 0;
//		for (yScrtyUnitCnt = 0; yScrtyUnitCnt < 16*8; ) { 
//			printHexSync(Kmu_array[yScrtyUnitCnt]);
//			yScrtyUnitCnt++;
//			if ((yScrtyUnitCnt%8) == 0)
//			{
//				prints("\n");
//			}
//		}
		

		_pop_(DPCON);
#endif
}
