#include "inc\common.h"				
#include "inc\ax215_exinst.h"		 
//#include "inc\nand_flash.h"							 
#include "inc\sd_spi_com_define.h"				 				  
//#include "inc\array_FIFO.h"
//#include "inc\extern_data.h"
//#include "inc\sdsd.h"
#include "inc\mrom_func.h"

	
extern u8 data yScrtyUnitCnt;
extern bit bCPRM_E_D_Flag,bFirstEnDecodeData,bScrtyMode,bVisitCprmDataMode,bAKERcvType,bAKEVerifyErr,bCprmDmaDataMode;
extern bit bCMD0Rcv,bSingleWriteTask, READY_FOR_DATA, bReadType;

extern u8 code SD_STATE,SecurityArgm, LBA_TMP[];
extern u8 code AKE_CHALLENGE_2_BUF,AKE_CHALLENGE_1_RPS_BUF,AKE_CHALLENGE_1_BUF;
extern u8 code Ks,Kmu_x,KmuTmp,Kmu_array,CPRM_MKB_OFFSET;
void Sel_Buffer_Addr(void);
void wait_cmd_rps_ready(void);
void wait_dma_in_ready(void);
void copy_dptr1_8_byte_data_to_dptr0(void);
void C2_G(void);
void cprm_en_de_code_buf_fetch_cur_buf_dptr(void);
void C2_ECBC_DCBC(void);
void C2_E_D(void);
void read_lba_in_tab(void);
#pragma asm
EXTRN CODE(CPRM_User_Cap,AKE_CHALLENGE_2_RPS_BUF)	
#pragma endasm
extern void prints(u8 *p);
extern void printHexSync(u8 dat);

/************************************************************************************************************************
GetScrtyLBA:
;input:  none
;output: ER3 = LBA[22:0],yScrtyUnitCnt,bScrtyMode,bFirstEnDecodeData
;		// ER1 = SecurityArgm[3:0] 
;����user area 
************************************************************************************************************************/
void get_scrty_lba(void)
{
#if EN_CPRM
	
		_push_(DPCON);

		DPCON = 0x18;		//���;Ĭ��ѭ����λ,DPTR �Լ�,Ĭ��DPTR0
		
		bFirstEnDecodeData = 1;
		DPTR0 = (u16)(&SecurityArgm);
		#pragma asm 
		MOV32_ER3_EDP0 				
		#pragma endasm 			
		yScrtyUnitCnt = ER33;
		
		if (ER32 & 0x80) {
			bScrtyMode = 1;
		} else {
			bScrtyMode = 0;	
		}
		ER33 = 0x00;
		ER32 &= ~(1<<7);
		
		if (!bScrtyMode) {
			*(u8 xdata *)(&SD_STATE) &= ~(1<<5);
		} else {
			*(u8 xdata *)(&SD_STATE) |= (1<<5);
		}

		#pragma asm
		MOV		DPTR, # CPRM_User_Cap		//protect area cal real lba
		ADD32_ER3_EDP0_ER3
		#pragma endasm

		_pop_(DPCON);

#endif
}
				
				
				
/*********************************MKB deal**********************************************/
/************************************************************************************************************************
; DMA_MKB_Task
; ;input:	LBATmp0,LBATmp1,LBATmp2,LBATmp3
; ;output: MKB_LBA, bCprmDmaDataMode, A
; ;A , B : 0:Normal DMA; 1: err, do not DMA
; ;MKB_LBA  = 64 * 2(Sector) * MKB_ID + Unit_offset + @CPRM_MKB_OFFSET
; ;����system area
************************************************************************************************************************/
void dma_mkb_pro(void)
{			
#if 1//EN_CPRM	
		_push_(DP0H);
		_push_(DP0L);
		
		if (!(LBA_TMP[2]&0xf0))
		{
			DPTR0 = (u16)(&CPRM_MKB_OFFSET); 		//SD LBA OFFSET
			read_lba_in_tab();
						
			DPTR1 = ((u16)(&Kmu_array)) + (LBA_TMP[1]<<3);		
			DPTR0 = (u16)(&Kmu_x);
			copy_dptr1_8_byte_data_to_dptr0();			//GET Kmu 2 Kmu_x

			*(u8 xdata *)(&Kmu_x) = 0;			//HIGHEST BYTE CLEAR(BIG ENDIAN),WE JUST NEED LAST 7 BYTE
			yScrtyUnitCnt = ((LBA_TMP[0]-1)&(128-1)) + 1;

		#pragma asm
			CLR32_ER0
			CLR32_ER1
		#pragma endasm
			ER01 = LBA_TMP[2];	
			ER00 = LBA_TMP[3];
			ER10 = (64 * 2);			//64KB = 64 * 2 Sector;
			ER12 = LBA_TMP[1];
			
		#pragma asm
			MUL16_ER1							//ER1 = 64 * 2 * MKB_ID
			ADD32_ER0_ER0_ER1				//ER2 = 64 * 2 * MKB_ID + Unit_offset
		#pragma endasm
		
			DPTR0 = (u16)(&CPRM_MKB_OFFSET); 		//SD LBA OFFSET
			read_lba_in_tab();

		#pragma asm
			ADD32_ER3_ER0_ER3				//ER3 = 64 * 2(Sector) * MKB_ID + Unit_offset + @CPRM_MKB_OFFSET
		#pragma endasm
			bCprmDmaDataMode = 1;			//Read MKB data
			bVisitCprmDataMode = 0;

			B = 0;							//Normal DMA
	
		} else {

			B = 1;				//err
			SSTA_P1 = 4;			//Turn to transfer state
		}

		_pop_(DP0L);
		_pop_(DP0H);
#endif
}				
				
				
/***********************************************************************************************************************
;AKE_REV_DATA_PROCESS:
;input:	 bAKERcvType
;0: AKE Rcv challenge1; 1: AKE Rcv challenge2_rps 
;output:
/***********************************************************************************************************************/
void ake_rev_data_process(void)
{
#if EN_CPRM
				_push_(DPCON);
				_push_(DP0H);
				_push_(DP0L);
				_push_(PAGEMAP);
				
				PAGEMAP = 0x01;
				DPCON = ((1<<4)|(1<<3));		//??;??????,DPTR ??,??DPTR0

				wait_cmd_rps_ready(); //Wait_CMD_Rps_Only
//-----------------------------------------------------------------------------------------------------------------------

//WAIT_AKE_REV_DATA:

				if (bCMD0Rcv) { 
					goto WAIT_AKE_REV_DATA_END;
				}
				while (!SDIPND);
					
				SDIPND = 0;
				READY_FOR_DATA = 0;
				
WAIT_AKE_REV_DATA_END:
				bSingleWriteTask = 0;
				SDIIE = 1;						  	//Enable sd dma in isr.							 
//-----------------------------------------------------------------------------------------------------------------------
																						
				SDICON_P1 &= ~(1 << 0);	   			//Disable receive data on SD bus.

				if (SCCRC) {
					goto RCV_AKE_DATA_STOP;				//;Data CRC err,data should not be programed.
				}

//AKE_DATA_CRC_OK:
									
				SSTA_P1 = 0x07;	   					//DMA IN complete,then go to "program" state.

				if (!bAKERcvType) {
					goto AKE_RCV_DATA_RPOCESS_END;
				}
//-----------------------------------------------------------------------------------------------------------------------						
//AKE_CHALLENGE2_RPS_PROCESS:
				//Verify challenge2 & Rps.--> C2_G(Kmu,challenge2) =? challenge2_rps
				DPTR1 = (u16)(&AKE_CHALLENGE_2_BUF);
				DPTR0 = (u16)(&AKE_CHALLENGE_1_RPS_BUF);
				copy_dptr1_8_byte_data_to_dptr0();


				bFirstEnDecodeData = 1;
				DPTR1 = (u16)(&AKE_CHALLENGE_1_RPS_BUF);
				DPTR0 = (u16)(&Kmu_x);
				C2_G();
		
				#pragma asm
				MOV		DPTR, # AKE_CHALLENGE_2_RPS_BUF
				MOV32_ER0_EDP0
				MOV32_ER1_EDP0
							
				MOV		DPTR, # AKE_CHALLENGE_1_RPS_BUF				 	//AKE_CHALLENGE_1_RPS_BUF as tmp. 
				MOV32_ER2_EDP0
				MOV32_ER3_EDP0
				#pragma endasm
			
				//challenge2 =? challenge2_rps
				#pragma asm
				MOV		B,#0
				XRL32_ER0_ER2
				JNB		EZ, SET_B__1								//EZ=0 -> ER0 != ER2 -> AKE Verify Err
				XRL32_ER1_ER3
				JB		EZ, SET_B__0								//EZ=0 -> ER1 != ER3 -> AKE Verify Err
				
			SET_B__1:		
				MOV		B,#1
			SET_B__0:
				#pragma endasm
				if (B) {
					prints("C2 RSP ERROR\n");
					goto C2G_VERIFY_ERR;
				}
				//challenge2 == challenge2_rps...

				//Cal. challenge_1_rps
				DPTR1 = (u16)(&AKE_CHALLENGE_1_BUF);
				DPTR0 = (u16)(&AKE_CHALLENGE_1_RPS_BUF);
				copy_dptr1_8_byte_data_to_dptr0();
				
				DPTR1 = (u16)(&AKE_CHALLENGE_1_RPS_BUF);
				DPTR0 = (u16)(&Kmu_x);
				C2_G();

				
prints("ake:");

			
				//KmuTmp = ~Kmu
				#pragma asm
				MOV		DPTR, # Kmu_x
				MOV32_ER0_EDP0
				MOV32_ER1_EDP0

				NOT32_ER0
				NOT32_ER1

				MOV		DPTR, # KmuTmp
				MOV32_EDP0_ER0
				MOV32_EDP0_ER1
			
				//Initial Ks;   Ks = Challenge1 ? Challenge2 

				MOV		DPTR, # AKE_CHALLENGE_1_BUF
				MOV32_ER0_EDP0
				MOV32_ER1_EDP0
				MOV		DPTR, # Ks
				MOV32_EDP0_ER0
				MOV32_EDP0_ER1
				
				MOV		DPTR, # AKE_CHALLENGE_2_BUF
				MOV32_ER2_EDP0
				MOV32_ER3_EDP0
			
				MOV		DPTR, # Ks
				XRL32_EDP0_ER2
				XRL32_EDP0_ER3
				#pragma endasm

						    
				//Ks = C2_G(~Kmu,challenge1?challenge2)				
				bFirstEnDecodeData = 1;
				DPTR0 = (u16)(&KmuTmp);
				DPTR1 = (u16)(&Ks);
				C2_G();
	
//--------------------------------------------------------------------------------------------
				//Pick up the argument in challenge1, then save...
				DPTR0 = (u16)(&Kmu_x);
				DPTR1 = (u16)(&AKE_CHALLENGE_1_BUF);

				bCPRM_E_D_Flag = 1;
				bFirstEnDecodeData = 1;
				C2_E_D();
			
				#pragma asm
				MOV		DPTR, # AKE_CHALLENGE_1_BUF
				MOV32_ER0_EDP0
				MOV		DPTR, # SecurityArgm
				MOV32_EDP0_ER0	
				#pragma endasm				
				
				#pragma asm
				MOV		DPTR, # Ks
				MOV32_ER0_EDP0
				#pragma endasm										
				
				goto	AKE_RCV_DATA_RPOCESS_END;
				
																																		
	C2G_VERIFY_ERR:
				bAKEVerifyErr = 1;
prints("ake err:");

//-----------------------------------------------------------------------------------------------------------------------
	AKE_RCV_DATA_RPOCESS_END:

				SDICON_P1 |= (1<<1);				//D0 CLR busy 
											
	RCV_AKE_DATA_STOP:
				EA = 0;
				if (!bCMD0Rcv)
				{
					SSTA_P1 = 0x04;        					//	Go to transfer state
				}
	
RCV_AKE_DATA_END:
				SDDL0_P1 = 0xff;
				SDDL1_P1 = 0x01;
				
				EA = 1;
			
				bCMD0Rcv = 0;
				READY_FOR_DATA = 1;
				
				_pop_(PAGEMAP);
				_pop_(DP0L);
				_pop_(DP0H);
				_pop_(DPCON);
#endif
}
				

				
	