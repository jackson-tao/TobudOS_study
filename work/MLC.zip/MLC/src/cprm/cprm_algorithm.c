#include "inc\common.h"				
#include "inc\ax215_exinst.h"		 
//#include "inc\nand_flash.h"							 
#include "inc\sd_spi_com_define.h"				 				  
//#include "inc\array_FIFO.h"
//#include "inc\extern_data.h"
//#include "inc\sdsd.h"
#include "inc\mrom_func.h"


extern bit bCPRM_E_D_Flag,bFirstEnDecodeData,bScrtyMode,bVisitCprmDataMode;
extern u8 data yBuffer_Index;
extern u8 code _SK_TMP,_Key,_Inkey,C2_GKeyTmp[],Ks,Kmu_x,KmuTmp;
extern u8 code CPRM_EN_DE_CODE_BUF_DPTR_H,CPRM_EN_DE_CODE_BUF_DPTR_L;
extern void Sel_Buffer_Addr(void);
extern void printHexSync(u8 dat);
extern void prints(u8 *p);

/***************************************************************************************************************************/
//;C2_ECBC_DCBC:
//;input:DPTR0/DPTR1/R3
//;DPTR0: Key pointer		  ;input key[6:0]
//;DPTR1: Data pointer	  ;input data[7:0]
//;R3:data_len/8  (R3==1 --> 1 * 8 byte)
//;bCPRM_E_D_Flag: ;0: C2_E/C2_ECBC   1: C2_D/C2_DCBC.
//;bFirstEnDecodeData 	;1:reload key 	0:keep  key and not reload
/***************************************************************************************************************************/
void C2_ECBC_DCBC(void)
{
#if EN_CPRM
		_push_(DPCON);
		_push_(PAGEMAP);
		
		PAGEMAP = 0x01;
		DPCON = 0x02;   //�߼���λ	
		
		DPTR1 >>= 2;
	
		BCRADR1_P1 = DP1H;
		BCRADR0_P1 = DP1L;
		
		BCBCNT0_P1 = 512/8-1;
		BCBCNT1_P1 = 0;
		
		DPCON = 0x1A;		//dptr0 auto inc,logic rot,big endian
		if (bFirstEnDecodeData) 
		{
		#pragma asm
			MOV32_ER0_EDP0
			MOV		BCKEY2_P1,ER00
			MOV		BCKEY1_P1,ER01
			MOV		BCKEY0_P1,ER02
			MOV32_ER0_EDP0
			MOV		BCKEY6_P1,ER00
			MOV		BCKEY5_P1,ER01
			MOV		BCKEY4_P1,ER02
			MOV		BCKEY3_P1,ER03
			MOV		BCCON1_P1,#0x01		//load new keys
		#pragma endasm	
		}

		if (!bCPRM_E_D_Flag) 
		{	
			BCCON_P1 = 0x65; 			//EEBC 
		} else {
			BCCON_P1 = 0x75;			//DEBC 
		}

		while (!(BCCON_P1&0x80));
		BCCON_P1 |= 0x40;

		
		_pop_(PAGEMAP);
		_pop_(DPCON);

#endif
}
		
		
/***************************************************************************************************************************
;C2_D:
;input:DPTR0/DPTR1
;DPTR0: Key pointer		 ;input key[6:0]
;DPTR1: Data pointer	 ;input data[7:0]
;bCPRM_E_D_Flag: ;0: C2_E/C2_ECBC   1: C2_D/C2_DCBC.
;bFirstEnDecodeData 	;1:reload key 	0:keep  key and not reload
/***************************************************************************************************************************/
void C2_E_D(void)
{
#if EN_CPRM
 		_push_(DPCON);
		_push_(PAGEMAP);

		PAGEMAP = 0x01;
		DPCON = 0x02;   //�߼���λ	
		
		DPTR1 >>= 2;

		BCRADR1_P1 = DP1H;		//MID
		BCRADR0_P1 = DP1L;
		
		BCBCNT1_P1 = 0;
		BCBCNT0_P1 = 0;
		 
		DPCON = 0x1A;		//dptr0 auto inc,logic rot,big endian
		if (bFirstEnDecodeData) 
		{
		#pragma asm
			MOV32_ER0_EDP0    //KEY Km
			MOV		BCKEY2_P1,ER00
			MOV		BCKEY1_P1,ER01
			MOV		BCKEY0_P1,ER02
			MOV32_ER0_EDP0
			MOV		BCKEY6_P1,ER00
			MOV		BCKEY5_P1,ER01
			MOV		BCKEY4_P1,ER02
			MOV		BCKEY3_P1,ER03
			MOV		BCCON1_P1,#0x01		//load new keys
		#pragma endasm	

			bFirstEnDecodeData = 0;
		}
	
		if (!bCPRM_E_D_Flag) 
		{	
			BCCON_P1 = 0x45;		//EEBC #0x01
		} else {
			BCCON_P1 = 0x55;			//DEBC 
		}

		while (!(BCCON_P1&0x80));
		BCCON_P1 |= 0x40;

		_pop_(PAGEMAP);
		_pop_(DPCON);
#endif
}	
		
extern u8 data yScrtyUnitCnt;
/***************************************************************************************************************************
;C2_G(d1, d2) = C2_E(d1, d2) ? d2. 
;input:DPTR0/DPTR1
;DPTR0: Key pointer	 	;input key[6:0],for cal Kmu,that is Km
;DPTR1: Data pointer	;input data[7:0],for cal Kmu,that is MID
;TMP:C2_GKeyTmp
;bFirstEnDecodeData 	;1:reload key 	0:keep  key and not reload
/***************************************************************************************************************************/
void C2_G(void)
{
#if EN_CPRM
	
		_push_(DPCON);
		_push_(DP1H);
		_push_(DP1L);

		DPCON = 0x19;  //dptr1 auto inc,big endian
	#pragma asm
		MOV32_ER1_EDP1
		MOV32_ER0_EDP1
		MOV		DP1H,#HIGH C2_GKeyTmp
		MOV		DP1L,#LOW  C2_GKeyTmp
		MOV32_EDP1_ER1
		MOV32_EDP1_ER0
	#pragma endasm	
	
		DPTR1 = (u16)(&C2_GKeyTmp);
		bCPRM_E_D_Flag = 0;
		C2_E_D();

	#pragma asm
		MOV		DP1H,#HIGH C2_GKeyTmp
		MOV		DP1L,#LOW  C2_GKeyTmp
		
		MOV32_ER0_EDP1
		MOV32_ER1_EDP1
		
		POP	DP1L
		POP DP1H

		XRL32_EDP1_ER0					//	;C2_G result
		XRL32_EDP1_ER1     
	#pragma endasm
	
		_pop_(DPCON);
#endif
}



/************************************************************************************************************************
READ_LBA_IN_TAB
;input: DPTR0
;Function: ER3 = @DPTR0 ;��˶���
************************************************************************************************************************/
void read_lba_in_tab(void)
{				
		_push_(DPCON);

		DPCON = 0x18;		//���;Ĭ��ѭ����λ,DPTR �Լ�,Ĭ��DPTR0
	#pragma asm	
		MOV32_ER3_EDP0
	#pragma endasm
		_pop_(DPCON);
}

/**********************************************             -54567'9887/9 *****************************************************************************/
//;input: DPTR0,DPTR1
//;function: DPTR1[7:0] --> DPTR0[7:0]
//;TMP: ER2,ER3
/***************************************************************************************************************************/
void copy_dptr1_8_byte_data_to_dptr0(void)
{
#if EN_CPRM

		_push_(DPCON);

		DPCON = 0x18;		//���;Ĭ��ѭ����λ,DPTR �Լ�,Ĭ��DPTR0
	#pragma asm		
		MOV32_ER2_EDP1
		MOV32_ER3_EDP1
		MOV32_EDP0_ER2
		MOV32_EDP0_ER3
	#pragma endasm
	
		_pop_(DPCON);

#endif
}


/*************************************************************************************************************************
CPRM_EN_DE_CODE_BUF_POINT_TO_CUR_BUF
;input: B
B: buf index
***************************************************************************************************************************/
void cprm_en_de_code_buf_point_to_cur_buf(void)
{
#if EN_CPRM	
	push_er0_to_er4();

	ER02 = yBuffer_Index;
	Sel_Buffer_Addr();
	
	*(u8 xdata *)(&CPRM_EN_DE_CODE_BUF_DPTR_H) = ER01;
	*(u8 xdata *)(&CPRM_EN_DE_CODE_BUF_DPTR_L) = ER00;

	pop_er0_to_er4();		
#endif
}

/*************************************************************************************************************************
CPRM_EN_DE_CODE_BUF_FETCH_CUR_BUF_DPTR
***************************************************************************************************************************/
void cprm_en_de_code_buf_fetch_cur_buf_dptr(void)
{
#if EN_CPRM
	ER01 = *(u8 xdata *)(&CPRM_EN_DE_CODE_BUF_DPTR_H);
	ER00 = *(u8 xdata *)(&CPRM_EN_DE_CODE_BUF_DPTR_L);	
	DP1H = ER01;
	DP1L = ER00;
#endif
}

/*************************************************************************************************************************
CPRM_DECODE_DATA
;input: CPRM_EN_DE_CODE_BUF_DPTR_H/CPRM_EN_DE_CODE_BUF_DPTR_L
Decode time 990us @80MHz
***************************************************************************************************************************/
void cprm_en_de_code_data(void)
{
#if EN_CPRM
	if  (bVisitCprmDataMode)
	{

		_push_(DPCON);
		_push_(DP1H);
		_push_(DP1L);

		push_er0_to_er4();
													
		cprm_en_de_code_buf_fetch_cur_buf_dptr();			
			
		DPTR0 = (u16)(&Ks);
		C2_ECBC_DCBC();

		bFirstEnDecodeData = 0;
	
		pop_er0_to_er4();

		_pop_(DP1L);
		_pop_(DP1H);
		_pop_(DPCON);
	}
#endif
}



