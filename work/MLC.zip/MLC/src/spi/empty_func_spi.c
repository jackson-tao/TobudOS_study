				
#include "inc\common.h"		  				 		 
#include "inc\ax215_exinst.h"		
#include "inc\nand_flash.h"		   
#include "inc\nand_flash_var_extern.h"			  
#include "inc\array_FIFO.h"			   
#include "inc\SD_accelerate.h"
		  
extern void mem_set(unsigned char fill_data);

void	Read_SDBuf_Block	 (void){}
void	program_sdbuf_block  (void){}
void	erase_sdbuf_block    (void){}


void Buf1_2_Buf0	                  (void){}
void Copy_LBA                         (void){}	
void Get_LgAddr                       (void){}                                         
void Erase_LBA            		      (void){}
void NF_POWER_UP   				      (void){}
void READ_BANK_CODES   		  	      (void){}
//void CONFIG_FIRST_RCV_BUF             (void){}
void AKE_CHALLENGE_2_BUF              (void){}
void AKE_CHALLENGE_1_BUF              (void){}


/*============================================================
* �Ρ�����:R02
* ��������:
============================================================*/

void Sel_DMA_Addr(void)
{
		ER11 = (BUFFER_START_ADDR / 4)>>8;
		ER10 = (BUFFER_START_ADDR / 4);
 	#pragma asm

//		MOV		ER11,#HIGH (BUFFER_START_ADDR / 4)
//		MOV		ER10,#LOW  (BUFFER_START_ADDR / 4)

		MOV		ER00,#LOW  (512 / 4)
		MOV		ER01,#HIGH (512 / 4)
	
		MOV		ER03,#0
		MUL16_ER0

		ADD32_ER0_ER0_ER1

		RET
	#pragma endasm
}
/*============================================================
* �Ρ�����:R02
* ��������:
============================================================*/

void Sel_Buffer_Addr(void)
{
	#pragma asm
		
		MOV		ER11,#HIGH BUFFER_START_ADDR
		MOV		ER10,#LOW  BUFFER_START_ADDR

		MOV		ER00,#LOW  512
		MOV		ER01,#HIGH 512

		MOV		ER03,#0
		MUL16_ER0

		ADD32_ER0_ER0_ER1

	    RET
	#pragma endasm
}

void Read_LBA (void)
{			
    unsigned char idata i;

	yBuffer_Index = 0;

	i  = 0;
			 
	while(! bSDStop){
	
		ER02 = i;
		Sel_Buffer_Addr();
		DP0H = ER01;
		DP0L = ER00;
		mem_set(i);//	 		0x5A
	
		ReadLBACnt++;
	 	bEnReadLBACnt = 1;

		while(ReadLBACnt >= READ_BUF_NUM ? 1 : 0){
			if(bSDStop)	  break;
		}

		i++;
		if(i == READ_BUF_NUM){
			i = 0;
		}		  			
	}
	//SPIЭ��û��Ӳ�����͹���
}
extern bit bStopMulWriteData;  
extern xdata u8 sd_hs_buf   [SD_HS_BUF_LEN];
void write_lba (void)
{			   
	while(PlanRcvSDDataCnt == ActualRcvSDDataCnt){
		
 		PlanRcvSDDataCnt = 31;
    	ActualRcvSDDataCnt = 0;
		yBuffer_Index_Start = 0;
		NfEmptyBufCnt =  PlanRcvSDDataCnt;
		bRcvSDDataKickStart = 1; 
	
		while(bRcvSDDataKickStart){}
	}

	//SPIЭ��û��Ӳ�����չ���
}