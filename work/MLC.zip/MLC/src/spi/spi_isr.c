#include "inc\common.h"		
#include "inc\sd_spi_com_define.h" 			
#include "inc\ax215_exinst.h"				 
#include "inc\array_FIFO.h"			 
#include "inc\nand_flash.h"			 
#include "inc\extern_data.h"
#include "inc\mrom_func.h"
#include "inc\sdspi_var.h"

extern unsigned char idata u8_extern_dma_in_task;

extern void uart_send_byte(u8 val);
extern void clr_sd_read_data_flag(void);
extern void push_er0(void);
extern void pop_er0(void);

extern unsigned char code SD_STATE,TAB_R6_ACK,CSD,CSD_25M_CRC7,ERASE_PARAMETER,TAB_R1_ACK,TAB_R7_ACK,ERASE_START_LBA,ERASE_END_LBA;
extern unsigned char code W_BUF_ADDR_H,W_BUF_ADDR_L,SOFT_RESET_ACMD41_CNT_TMP,SOFT_RESET_ACMD41_CNT,TAB_R3_ACK;

extern unsigned char code SPI_TAB_R7_ACK,SPI_TAB_R3_ACK,SPI_TAB_R1_ACK,SPI_TAB_R2_ACK;	   //SPI
extern unsigned char code VALID_SECTOR_CNT;
void chk_single_r_cmd(unsigned char task_info);
extern u8 code LBA_TMP;
#pragma asm
EXTRN CODE (ISR_ERX_TMP, ERASE_START_LBA, ERASE_END_LBA)
#pragma endasm


void cmd_r1_rps(void);
static bit isr_check_rca_match(void);
void rca_inc(void);
void get_addr(void);
void kick_rcv_data(void);
void ake_rev_data(void);
void isr_cmd0_process(void);
void cmd_r7_rps(void);
void cmd_r2_rps(void);
void cmd_r3_rps(void);   
void set_SD_cmd_IP(byte SDNum, byte Priority);
		  
#pragma asm
PUBLIC	AUTO_CMD_TAB_ADDR, AUTO_CMD_JMP_ADDR
CSEG	AT 	0x2800
AUTO_CMD_JMP_ADDR:
DW	AUTO_CMD_JMP_ADDR_CODE
AUTO_CMD_TAB_ADDR:
DW	SD_STAN_CMD0 , SD_STAN_CMD1 , SD_STAN_CMD2 , SD_STAN_CMD3 , SD_STAN_CMD6
DW	SD_STAN_CMD7 , SD_STAN_CMD8 , SD_STAN_CMD9 , SD_STAN_CMD10, SD_STAN_CMD12
DW	SD_STAN_CMD13, SD_STAN_CMD15, SD_STAN_CMD16, SD_STAN_CMD17, SD_STAN_CMD18
DW	SD_STAN_CMD19, SD_STAN_CMD24, SD_STAN_CMD25, SD_STAN_CMD27, SD_STAN_CMD28
DW	SD_STAN_CMD29, SD_STAN_CMD30, SD_STAN_CMD32, SD_STAN_CMD33, SD_STAN_CMD38 
DW	SD_STAN_CMD41, SD_STAN_CMD42, SD_STAN_CMD55, SD_STAN_CMD56, SD_STAN_CMD58
DW	SD_STAN_CMD59	
DW	SD_APPO_CMD6 , SD_APPO_CMD13, SD_APPO_CMD18, SD_APPO_CMD22, SD_APPO_CMD23  
DW	SD_APPO_CMD25, SD_APPO_CMD26, SD_APPO_CMD38, SD_APPO_CMD41, SD_APPO_CMD42
DW	SD_APPO_CMD43, SD_APPO_CMD44, SD_APPO_CMD45, SD_APPO_CMD46, SD_APPO_CMD47
DW	SD_APPO_CMD48, SD_APPO_CMD49, SD_APPO_CMD51, SD_APPO_CMD55, DEFAULT_CMD//SD_APPO_CMD63��invalid CMD����ת��ַ
						 		 
#pragma endasm


#pragma ot(7,SPEED)
	u8 idata last_SSTA_P1;
	
void cmd_isr(void) interrupt 0  using 1
{
//	printf("isr\r\n");
//	PrintHex(SINDEX_P1);

		_push_(R8);
 		_push_(DPCON);
		_push_(PAGEMAP);
	 PAGEMAP = 0x01;	
//xrl_p3(1 << 6);	
	SDRONE_P1 &= ~(0x13);				//	;CLR (APP_CMD_Flag & R6_En & R1_En).
	if(bAppo_CMD_Flag){
		bAppo_CMD_Flag = 0;
		SDRONE_P1 |= (1<<4);		  	//;SET APP_CMD_Flag in R1 Rps.
		ACCON1_P1 |= (1<<6) ;           //Select app_cmd_tab in hardware calculation cmd entrance address automatic.
	}
	ACCON1_P1 |= (1<<5) ;				 //kick start auto cal cmd entrance address
yCMD_Index = SINDEX_P1;				//copy cmd index
//	array_add_tail('v');
	DPCON = 0x08;		   				//���, �ر�����, DPTR0		   
	SCPND = 0;							//CLR CMD pending			
	SCCON_P1 |= ( 1 << 0);				//;Ready for next CMD(Don't care CMD response whether or not)	  		
//	bCMDRps_Flag = 0;       			//CLR RPS pending	  	
	SDRPSDLY_P1 = 0x00;							 

	while(! SAJPND) { }				//waiting for hardware checked cmd entrance address.
	SAJPND = 0;
		
//	while(!SCEND) {}
#pragma asm														 
	DB 0x02								//LJMP
	AUTO_CMD_JMP_ADDR_CODE:
	DB	0x00, 0x00	
#pragma endasm	

		do
		{			
#pragma asm	
	SD_STAN_CMD0:
#pragma endasm				
					isr_cmd0_process();
					break;

//#pragma asm	
//	SD_STAN_CMD1:	   //jmp to  SD_APPO_CMD41
//#pragma endasm
//					break;
	
#pragma asm	
	SD_STAN_CMD6:
#pragma endasm

						
						chk_single_r_cmd(SD_Fun_Task);					
						ER33 = SARG3_P1;
						ER32 = SARG2_P1;
						ER31 = SARG1_P1;
						ER30 = SARG0_P1;

					cmd_r1_rps();
					break;

#pragma asm	
	SD_STAN_CMD8:
#pragma endasm
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
//						IDLE_STATE = 1;
						*((char xdata *)(&SPI_TAB_R7_ACK) + 0) = R1_REG;
 						*((char xdata *)(&SPI_TAB_R7_ACK) + 4) = SARG0_P1;
					}
					cmd_r7_rps();
					break;
#pragma asm	
	SD_STAN_CMD9:
#pragma endasm
					chk_single_r_cmd(READ_CSD_Task);

					cmd_r1_rps();
					break;
#pragma asm	
	SD_STAN_CMD10:
#pragma endasm
					chk_single_r_cmd(READ_CID_Task);
				
					cmd_r1_rps();
					break;
#pragma asm	
	SD_STAN_CMD12:
#pragma endasm
	//				xrl_p3(1 << 7);	
					while(!SCEND) 
					{}
					push_er0();
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
						if (bMulRFlag)  //::��û������ֹͣ����
						{
							bMulRFlag = 0;
							bDataStop_Flag = 1;						
							SDICON_P1 &= ~(1<<2);		//;disable cmd12_en
							bSDStop = 1;			//nfc read stop
							bEnterReadDmaOut = 0;

							DPTR0 = (char xdata *)(&VALID_SECTOR_CNT);
							#pragma asm
				 			SUB32_ER0_EDP0_ER2
							#pragma endasm
							if (EC)
							{
								OUT_OF_RANGE = 1;
							}
							if (bSpiMulReadAddrErr) {
								bSpiMulReadAddrErr = 0;
								ADDRESS_ERROR = 1;			   // mul read addr err.
							}
						}
					}
					cmd_r1_rps();
					pop_er0();
					break;
#pragma asm	
	SD_STAN_CMD13:
#pragma endasm
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{

					}
					cmd_r2_rps();
					break;
#pragma asm	
	SD_STAN_CMD16:
#pragma endasm	
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
//						#pragma asm
//			   			MOV		DPTR, # ISR_ERX_TMP
//							MOV32_EDP0_ER2			
//							MOV		ER23, SARG3_P1
//							MOV		ER22, SARG2_P1
//							MOV		ER21, SARG1_P1
//							MOV		ER20, SARG0_P1
//							DEC32_ER2
//							MOV		DPTR, #CMP_BLOCK_LEN
//							SUB32_ER2_EDP0_ER2
//						#pragma endasm				
//						if (EC)
						if((ARGSTA_P1 & 0x03) == 0x01)
						{
							PARAMETER_ERROR = 1;   //;> 512
						}					
						
						if (bEnCheckEraseSeq)
						{
							ERASE_RESET = 1;
						}	
						cmd_r1_rps();
					
						bBlockLenLess512Byte = 0;
//						if (! bSDHC && ! EZ )
						if (! bSDHC && ((ARGSTA_P1 & 0x03) == 0x02))
						{
							bBlockLenLess512Byte = 1;
						}
//						#pragma asm
//		   					MOV		DPTR, # CMP_BLOCK_LEN
//							ADD32_ER2_EDP0_ER2
//						#pragma endasm

						if ( ! bSDHC && ! PARAMETER_ERROR )
						{
//							yBlockLen0 = ER20;
//							yBlockLen1 = ER21;
//							
//							#pragma asm
//						  MOV		DPTR, # REAL_BLOCK_LEN			//���浱ǰ��block len
//							MOV32_EDP0_ER2							
//							#pragma endasm	
								DP0L = SARG4_P1;
								DP0H = SARG5_P1;
								#pragma asm
								DECDP0
								#pragma endasm
							
//								yBlockLen0 = DP0L;
//								yBlockLen1 = DP0H;  //�ص�����ȥ֧��
//								
//								DIVR0_P1 = SARG4_P1;	 //16bit������byte
//								DIVR1_P1 = SARG5_P1;	 //16bit������byte	
						}

//						#pragma asm
//			 			   	MOV		DPTR, # ISR_ERX_TMP 
//							MOV32_ER2_EDP0
//						#pragma endasm					
						
						break;
					}
					cmd_r1_rps();
					break;								
#pragma asm	
	SD_STAN_CMD17:
#pragma endasm

					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
						while( !CDONE );
						get_addr();
		//				if ( ! ADDRESS_ERROR)					  //SDЭ������ǲ����У�SPIģʽ����ʹADDRESS_ERROR���������ǻ�����ݵ�DMA
						{
 							yTast_Index = Single_Read_Task;	
							bDataStop_Flag = 0;
							bInReadLba = 1;
							bEnterReadDmaOut = 1;
							bReadType = 1;
#if EN_STOP_W_FLASH_DATA
							bCopyNeedStop = 1;					//ǿ���˳�flashд���ݺ�������������ѭ����Ӧ������													
#endif						
						}
					}
					cmd_r1_rps();
					break;
#pragma asm	
	SD_STAN_CMD18:
#pragma endasm
	//				xrl_p3(1 << 7);	
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
						while( !CDONE );
 						get_addr();
		//				if ( ! ADDRESS_ERROR)				   //SDЭ������ǲ����У�SPIģʽ����ʹADDRESS_ERROR���������ǻ�����ݵ�DMA
						{			
							SDICON_P1 |= (1<<2);		//	;enable cmd12_en
							yTast_Index = Mul_Read_Task;
							bDataStop_Flag = 0;
							bInReadLba = 1;
							bEnterReadDmaOut = 1;
							bReadType = 0;
#if EN_STOP_W_FLASH_DATA
							bCopyNeedStop = 1;					//ǿ���˳�flashд���ݺ�������������ѭ����Ӧ������													
#endif							
						}
					   	bSpiMulReadAddrErr = ADDRESS_ERROR;
							ADDRESS_ERROR = 0;
					}
					cmd_r1_rps();
					
					break;
#pragma asm	
	SD_STAN_CMD19:
#pragma endasm
					SDRPSDLY_P1 = ((30 << 0) | ( 1 << 7 ));  	//SDRPSDLY_P1[7]--Enable bit	
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
						ILLEGAL_COMMAND = 1;
					}
					cmd_r1_rps();
					break;

#pragma asm	
	SD_STAN_CMD24:
#pragma endasm
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
						while( !CDONE );
						get_addr();
						if ( (! bBlockLenLess512Byte) && (! ADDRESS_ERROR))
					   	{									
							cmd_r1_rps();
							kick_rcv_data();
							yTast_Index = Single_Write_Task;
							bSingleWriteTask = 1;		
							break;					   
					   	}
					}
					cmd_r1_rps();
					break;

#pragma asm	
	SD_STAN_CMD25:
#pragma endasm
//					xrl_p3(1 << 6);	
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
						while( !CDONE );
						get_addr();
						if ( (! bBlockLenLess512Byte) && (! ADDRESS_ERROR))
						{
							SDICON_P1 &= ~(1<<2);		 //	;disable CMD12.
							cmd_r1_rps();
							kick_rcv_data();
							yTast_Index = Mul_Write_Task;
							bMulWriteTask = 1;
							break;						
						}
					}
					cmd_r1_rps();
					break;								
#pragma asm	
	SD_STAN_CMD27:
#pragma endasm
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
						yTast_Index = Pro_CSD_Task;
						SDOCON_P1 |= 0x40;
						SDDL0_P1 = 15;
						SDDL1_P1 = 0;
//						config_dma_buf_addr();
#if 1
						SDXADR1_P1 = DATA_BUF_DMA_ADDR_H;			  //����DATA BUF��
						SDXADR0_P1 = DATA_BUF_DMA_ADDR_L;						
						SDICON_P1 |= (1<<0);
						bDataIn_Flag = 0;

						u8_extern_dma_in_task = EXTERN_DMA_IN_PRG_CSD; 
#endif
					}
					cmd_r1_rps();
					break;
#pragma asm	
	SD_STAN_CMD28:
	SD_STAN_CMD29:
#pragma endasm
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
					 	fetch_agm_addr_to_er3();
					}
					cmd_r1_rps();
					break;
#pragma asm	
	SD_STAN_CMD30:
#pragma endasm
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{

					}
					cmd_r1_rps();
					break;
#pragma asm	
	SD_STAN_CMD32:
#pragma endasm
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
//						LBATmp0 = SARG0_P1;
//						LBATmp1 = SARG1_P1;
//						LBATmp2 = SARG2_P1;
//						LBATmp3 = SARG3_P1;  
						*(char xdata *)((&LBA_TMP) + 0) = SARG3_P1;
						*(char xdata *)((&LBA_TMP) + 1) = SARG2_P1;
						*(char xdata *)((&LBA_TMP) + 2) = SARG1_P1;
						*(char xdata *)((&LBA_TMP) + 3) = SARG0_P1;
						
						bEnCheckEraseSeq = 1;
						
						ACC = *(char xdata *)(&ERASE_PARAMETER);
					
						if ((ACC & 0x03) == 0)
						{
							 ACC |= (1<<0);
 							*(char xdata *)(&ERASE_PARAMETER) = ACC;					
						}
						else
						{
						  	if (ACC == (1<<0))
							{
							 	ERASE_RESET = 1;
							}
							else if (ACC == (1<<1))
								{
								 	ERASE_SEQ_ERROR = 1;
								}
							bEnCheckEraseSeq = 0;
							*(char xdata *)(&ERASE_PARAMETER) = 0;							
						}
					}
					cmd_r1_rps();
					
					#pragma asm
								MOV 	DPTR,#LBA_TMP
								MOV32_ER3_EDP0
								MOV		DPTR,#ERASE_START_LBA
								MOV32_EDP0_ER3
					#pragma endasm
//					*(char xdata *)((&ERASE_START_LBA) + 0) = LBATmp3;
//					*(char xdata *)((&ERASE_START_LBA) + 1) = LBATmp2;
//					*(char xdata *)((&ERASE_START_LBA) + 2) = LBATmp1;
//					*(char xdata *)((&ERASE_START_LBA) + 3) = LBATmp0;
					break;
#pragma asm	
	SD_STAN_CMD33:
#pragma endasm
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
						ACC = *(char xdata *)(&ERASE_PARAMETER);
						if ((ACC & 0x03) == 0x01)
						{
							ACC |= (1<<1);
 						 	*(char xdata *)(&ERASE_PARAMETER) = ACC;
//							LBATmp0 = SARG0_P1;
//							LBATmp1 = SARG1_P1;
//							LBATmp2 = SARG2_P1;
//							LBATmp3 = SARG3_P1;
								*(char xdata *)((&LBA_TMP) + 0) = SARG3_P1;
								*(char xdata *)((&LBA_TMP) + 1) = SARG2_P1;
								*(char xdata *)((&LBA_TMP) + 2) = SARG1_P1;
								*(char xdata *)((&LBA_TMP) + 3) = SARG0_P1;
						}
						else
						{
							ERASE_SEQ_ERROR = 1;
							bEnCheckEraseSeq = 0;
							*(char xdata *)(&ERASE_PARAMETER) = 0;
						}
					}
					cmd_r1_rps();
					#pragma asm
							MOV 	DPTR,#LBA_TMP
							MOV32_ER3_EDP0
							MOV		DPTR,#ERASE_END_LBA
							MOV32_EDP0_ER3
					#pragma endasm
//					*(char xdata *)((&ERASE_END_LBA) + 0) = LBATmp3;
//					*(char xdata *)((&ERASE_END_LBA) + 1) = LBATmp2;
//					*(char xdata *)((&ERASE_END_LBA) + 2) = LBATmp1;
//					*(char xdata *)((&ERASE_END_LBA) + 3) = LBATmp0;

#if 1
					SDICON_P1 |= (1<<3);		  //	;enable busycmd_en
					bHwEnBusyCmd = 1;
#endif

					break;
#pragma asm	
	SD_STAN_CMD38:
#pragma endasm
//P2 ^= (1<<0);
					while(!SCEND) 
					{}
					u8_extern_dma_in_task = EXTERN_DMA_IN_ERASE_DATA;
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
						bEnCheckEraseSeq = 0;
 						ACC = *(char xdata *)(&ERASE_PARAMETER);
						if ((ACC & 0x03) == 0x03)
						{							
							cmd_r1_rps();						 	//��busy,����Ӧ��
						  yTast_Index = Erase_Task;
							bInEraseTask = 1;
							bHwEnBusyCmd = 0;
						}
						else
						{
							ERASE_SEQ_ERROR = 1;
							if ( ! bHwEnBusyCmd){		
								cmd_r1_rps();
							}else{
								SDICON_P1 |= (1<<1);						//��busy,����Ӧ��
								SDICON_P1 &= ~(1<<3);		  				//;disable busycmd_en
								bHwEnBusyCmd = 0;
							}

						}
					   	*(char xdata *)(&ERASE_PARAMETER) = 0;
						break;
					}else {
						if ( ! bHwEnBusyCmd){
								cmd_r1_rps();
							}else{
								SDICON_P1 |= (1<<1);						//��busy,����Ӧ��
								SDICON_P1 &= ~(1<<3);		  				//;disable busycmd_en
								bHwEnBusyCmd = 0;
							}

						break;
					}
//#pragma asm	
//	SD_STAN_CMD41:	//Jmp to ACMD41
//#pragma endasm

					
#pragma asm	
	SD_STAN_CMD42:
#pragma endasm
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{

					}
					cmd_r1_rps();
					break;
#pragma asm	
	SD_STAN_CMD55:
	SD_APPO_CMD55:
#pragma endasm
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
						bAppo_CMD_Flag = 1;
					}
					cmd_r1_rps();
					break;
#pragma asm	
	SD_STAN_CMD56:
#pragma endasm
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
					 	if ((SARG0_P1 & 0x01) == 0)
						{
							yTast_Index = GEN_CMD_Write_Task;
							cmd_r1_rps();
							kick_rcv_data();
							break;
						}
						else
						{
//							LBATmp0 = SARG0_P1;
//							LBATmp1 = SARG1_P1;
								*(char xdata *)((&LBA_TMP) + 3) = SARG0_P1;
								*(char xdata *)((&LBA_TMP) + 2) = SARG1_P1;
//							LBATmp2 = SARG2_P1;
//							LBATmp3 = SARG3_P1;

						 	yTast_Index = GEN_CMD_Read_Task;
						
							bInReadLba = 1;
							bEnterReadDmaOut = 1;
							bReadType = 1;
#if EN_STOP_W_FLASH_DATA
							bCopyNeedStop = 1;		//ǿ���˳�flashд���ݺ�������������ѭ����Ӧ������													
#endif						 
						}
					}
					cmd_r1_rps();
					break;
#pragma asm	
	SD_STAN_CMD58:
#pragma endasm
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
						*((char xdata *)(&SPI_TAB_R3_ACK) + 0) = R1_REG;
						*((char xdata *)(&SPI_TAB_R3_ACK) + 1) = *((char xdata *)(&TAB_R3_ACK) + 0);
					}
					cmd_r3_rps();
					break;
#pragma asm	
	SD_STAN_CMD59:
#pragma endasm
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
						if ((SARG0_P1 & 0x01) == 0x00)  //0ff
						{
							SCCON_P1 |= (1<<7);
							SDOCON_P1 |= (1<<2);
							SDOCON_P1 &= ~(1<<1);
							bSPI_CRC_Check_Flag = 0;
						}
						else
						{
							SCCON_P1 &= ~(1<<7);		
							SDOCON_P1 &= ~(1<<2);
							SDOCON_P1 &= ~(1<<1);
//							SDOCON_P1 |= (1<<1);  //�ݲ����Ϊʲô���������
							bSPI_CRC_Check_Flag = 1;						
						}
					}
					cmd_r1_rps();
					break;

#pragma asm	
	SD_APPO_CMD13:
#pragma endasm
					chk_single_r_cmd(SD_State_Task);

					cmd_r2_rps();
					break;
#pragma asm	
	SD_APPO_CMD18:
#pragma endasm
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
						SDICON_P1 |= (1<<2);
						yTast_Index = Security_Mul_Read_Task;								
						bDataStop_Flag = 0;	
					
						bInReadLba = 1;
						bEnterReadDmaOut = 1;
						bReadType = 0;
#if EN_STOP_W_FLASH_DATA
						bCopyNeedStop = 1;		//ǿ���˳�flashд���ݺ�������������ѭ����Ӧ������													
#endif								
					}
					cmd_r1_rps();
					break;
#pragma asm	
	SD_APPO_CMD22:
#pragma endasm
					chk_single_r_cmd(Get_WellWR_Task);

					cmd_r1_rps();
					break;
#pragma asm	
	SD_APPO_CMD23:
#pragma endasm
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{

					}
					cmd_r1_rps();
					break;
#pragma asm	
	SD_APPO_CMD25:
#pragma endasm
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
//						get_addr();
						SDICON_P1 &= ~(1<<2);		 //	;disable CMD12.
						yTast_Index = Secutity_Mul_Write_Task;
						cmd_r1_rps();
						kick_rcv_data();
						break;
					}
					cmd_r1_rps();
					break;
//#pragma asm	
//	SD_APPO_CMD26:
//#pragma endasm
//					while(!SCEND) 
//					{}
//					if ( ! SCCRC)
//					{
//					 	if (SSTA == 4)
//						{
//						   	SSTA = 6;
//						   	yTast_Index = Update_MKB_Task;
//						  	cmd_r1_rps();
//							bMulWriteTask = 1;
//							SDICON_P1 |= (1<<2); 										
//							kick_rcv_data();
//							break;
//						}
//						else
//						{
//							bDecteInvalidCmdBySw = 1;
//						}
//					}
//					continue;
//#pragma asm	
//	SD_APPO_CMD38:
//#pragma endasm
//					while(!SCEND) 
//					{}
//				 	SSTA |= (1<<4);
//					if ( ! SRPSTS)
//					{
//						SSTA = 7;
//						READY_FOR_DATA = 0;
//						yTast_Index = Security_Erase_Task;
//					 	cmd_r1_rps();
//						break;
//					}
//					SDICON_P1 |= (1<<1);
//					continue;
	
#pragma asm	
	SD_STAN_CMD1:
	SD_STAN_CMD41:
	SD_APPO_CMD41:
#pragma endasm
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
						if (! bNandPowerup)
						{
							IDLE_STATE = 1;
						}
						else
						{
							 ACC = *(char xdata *)(&SOFT_RESET_ACMD41_CNT_TMP);								 
							 if (ACC != 0)
							 {
								*(char xdata *)(&SOFT_RESET_ACMD41_CNT_TMP) -= 1;
							  	IDLE_STATE = 1;
							 }
							 else
							 {
							 	IDLE_STATE = 0;
							 }						
						}
					}
					cmd_r1_rps();
					break;						
#pragma asm	
	SD_APPO_CMD42:
#pragma endasm
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{

					}
					cmd_r1_rps();
					break;
#pragma asm	
	SD_APPO_CMD43:
#pragma endasm
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
						while( !CDONE );
						get_addr();
						yTast_Index = MKB_Task;
						bInReadLba = 1;
						bEnterReadDmaOut = 1;
						bReadType = 1;
#if EN_STOP_W_FLASH_DATA
						bCopyNeedStop = 1;		//ǿ���˳�flashд���ݺ�������������ѭ����Ӧ������													
#endif	
					}
					cmd_r1_rps();
					break;
#pragma asm	
	SD_APPO_CMD44:
#pragma endasm
					chk_single_r_cmd(MID_Task);

					cmd_r1_rps();
					break;

#pragma asm	
	SD_APPO_CMD45:
#pragma endasm
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
						yTast_Index = RCV_AKE_CHLG_1_Task;							
						SDXADR1_P1 = AKE_CHALLENGE_1_BUF_DMA_ADDR_H;
						SDXADR0_P1 = AKE_CHALLENGE_1_BUF_DMA_ADDR_L;
						ake_rev_data();
						break;
					}
					cmd_r1_rps();
					break;
	
#pragma asm	
	SD_APPO_CMD46:
#pragma endasm
					chk_single_r_cmd(SEND_AKE_CHLG_2_Task);

					cmd_r1_rps();
					break;

#pragma asm	
	SD_APPO_CMD47:
#pragma endasm
					while(!SCEND) 
					{}
					if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
					{
						yTast_Index = RCV_AKE_CHLG_2_RPS_Task;
						SDXADR1_P1 = AKE_CHALLENGE_2_RPS_BUF_DMA_ADDR_H;
						SDXADR0_P1 = AKE_CHALLENGE_2_RPS_BUF_DMA_ADDR_L;
						ake_rev_data();
						break;
					}
					cmd_r1_rps();
					break;

#pragma asm	
	SD_APPO_CMD48:
#pragma endasm
					chk_single_r_cmd(SEND_AKE_CHLG_1_RPS_Task);

					cmd_r1_rps();
					break;

//#pragma asm	
//	SD_APPO_CMD49:
//#pragma endasm
// 					while(!SCEND) 
//					{}
//					if ( ! SCCRC)
//					{
//						if ((SSTA == 4) && (! bSDHC))
//						{
//						 	SSTA = 7;
//							READY_FOR_DATA = 0;
//							yTast_Index = Change_Pro_Area_Task;
//						   	cmd_r1_rps(); 							
//							break;
//						}
//						else
//						{
//							bDecteInvalidCmdBySw = 1;
//						}
//					}
//					continue;
#pragma asm	
	SD_APPO_CMD51:
#pragma endasm
					chk_single_r_cmd(READ_SCR_Task);

					cmd_r1_rps();
					break;
					
#pragma asm	
/* ���������� command reserved*/
SD_STAN_CMD2:
SD_STAN_CMD3:
SD_STAN_CMD4:
SD_STAN_CMD5:
SD_STAN_CMD7:
SD_STAN_CMD11:
SD_STAN_CMD14:
SD_STAN_CMD15:
SD_STAN_CMD20:
SD_STAN_CMD21:
SD_STAN_CMD22:
SD_STAN_CMD23:
SD_STAN_CMD26:
SD_STAN_CMD31:	
SD_STAN_CMD34:
SD_STAN_CMD35:
SD_STAN_CMD36:
SD_STAN_CMD37:
SD_STAN_CMD39:
SD_STAN_CMD40:
SD_STAN_CMD43:
SD_STAN_CMD44:
SD_STAN_CMD45:
SD_STAN_CMD46:
SD_STAN_CMD47:
SD_STAN_CMD48:
SD_STAN_CMD49:
SD_STAN_CMD50:
SD_STAN_CMD51:
SD_STAN_CMD52:
SD_STAN_CMD53:
SD_STAN_CMD54:
SD_STAN_CMD57:
SD_STAN_CMD60:
SD_STAN_CMD61:	
SD_STAN_CMD62:
SD_STAN_CMD63:
SD_APPO_CMD0:	
SD_APPO_CMD1: 
SD_APPO_CMD2: 
SD_APPO_CMD3: 
SD_APPO_CMD4: 
SD_APPO_CMD5:
SD_APPO_CMD6:
SD_APPO_CMD7: 
SD_APPO_CMD8: 
SD_APPO_CMD9:               
SD_APPO_CMD10:
SD_APPO_CMD11:
SD_APPO_CMD12:
SD_APPO_CMD14:
SD_APPO_CMD15:
SD_APPO_CMD16:
SD_APPO_CMD17:
SD_APPO_CMD19:              
SD_APPO_CMD20:
SD_APPO_CMD21:
SD_APPO_CMD24:
SD_APPO_CMD26:
SD_APPO_CMD27:
SD_APPO_CMD28:
SD_APPO_CMD29:             
SD_APPO_CMD30:
SD_APPO_CMD31:
SD_APPO_CMD32:
SD_APPO_CMD33:
SD_APPO_CMD34:
SD_APPO_CMD35:
SD_APPO_CMD36:
SD_APPO_CMD37:
SD_APPO_CMD38:
SD_APPO_CMD39:              
SD_APPO_CMD40:
SD_APPO_CMD49:              
SD_APPO_CMD50:
SD_APPO_CMD52:
SD_APPO_CMD53:
SD_APPO_CMD54:
SD_APPO_CMD56:
SD_APPO_CMD57:
SD_APPO_CMD58:
SD_APPO_CMD59:
SD_APPO_CMD60:
SD_APPO_CMD61:
SD_APPO_CMD62:
DEFAULT_CMD:
				SETB	ILLEGAL_COMMAND
				CALL	cmd_r1_rps
				JMP		CMD_ISR_END					
#pragma endasm		
				break;
		} while(1);

#pragma asm
	CMD_ISR_END:
#pragma endasm							   
		ACCON1_P1 &= ~BIT(6);	 //���ACCON1_P1�Ĵ�����APP_CMD��־
		if (bEnCheckEraseSeq)
		{
			if ((yCMD_Index != 13) && (yCMD_Index != 32)&&(yCMD_Index != 33))
			{
				*(char xdata *)(&ERASE_PARAMETER) = 0;
			}				
		}		   	 	 
//		array_add_tail(yCMD_Index);

		_pop_(PAGEMAP);
		_pop_(DPCON);	
		_pop_(R8);
}

void chk_single_r_cmd(unsigned char task_info)
{
	while(!SCEND) 
	{}
if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC)) {				
	yTast_Index = task_info;
					
	bInReadLba = 1;
	bEnterReadDmaOut = 1;
	bReadType = 1;
#if EN_STOP_W_FLASH_DATA
	bCopyNeedStop = 1;		//ǿ���˳�flashд���ݺ�������������ѭ����Ӧ������													
#endif						
}	
}

void cmd_r1_rps(void) using 1
{
	if (bSPI_CRC_Check_Flag && SCCRC)
	{
		COM_CRC_ERROR = 1;
	}
	*(char xdata *)(&SPI_TAB_R1_ACK) = R1_REG;
	SPND_P1 &= ~(1<<1);
	SRXADR0_P1 = 	SPI_TAB_R1_ACK_DMA_ADDR_L;
	SRXADR1_P1 = 	SPI_TAB_R1_ACK_DMA_ADDR_H;
	SRDL0_P1 = 0;
	SRDL1_P1 = 0;
	SRCON_P1 = (1<<7)|(1<<6)|(1<<5)|(1<<4)|(1<<0);
	bCMDRps_Flag = 0;			//::responding
}

void cmd_r2_rps(void) using 1
{
	if (bSPI_CRC_Check_Flag && SCCRC)
	{
		COM_CRC_ERROR = 1;
	}
	*((char xdata *)(&SPI_TAB_R2_ACK) + 0) = R2_REG0;		//::the first byte same as R1 RSP
	*((char xdata *)(&SPI_TAB_R2_ACK) + 1) = R2_REG1;
	
	SPND_P1 &= ~(1<<1);
	SRXADR0_P1 = 	SPI_TAB_R2_ACK_DMA_ADDR_L;
	SRXADR1_P1 = 	SPI_TAB_R2_ACK_DMA_ADDR_H;
	SRDL0_P1 = 1;
	SRDL1_P1 = 0;
	SRCON_P1 = (1<<7)|(1<<6)|(1<<5)|(1<<4)|(1<<0);
	bCMDRps_Flag = 0;

	bSPICMDInR2Rps = 1;

}
void cmd_r3_rps(void) using 1
{
	if (bSPI_CRC_Check_Flag && SCCRC)
	{
		COM_CRC_ERROR = 1;
	}
	SPND_P1 &= ~(1<<1);
	SRXADR0_P1 = 	SPI_TAB_R3_ACK_DMA_ADDR_L;
	SRXADR1_P1 = 	SPI_TAB_R3_ACK_DMA_ADDR_H;
	SRDL0_P1 = 4;
	SRDL1_P1 = 0;
	SRCON_P1 = (1<<7)|(1<<6)|(1<<5)|(1<<4)|(1<<0);
	bCMDRps_Flag = 0;

}

void cmd_r7_rps(void) using 1
{
	if (bSPI_CRC_Check_Flag && SCCRC)
	{
		COM_CRC_ERROR = 1;
	}
	SPND_P1 &= ~(1<<1);
	SRXADR0_P1 = 	SPI_TAB_R7_ACK_DMA_ADDR_L;
	SRXADR1_P1 = 	SPI_TAB_R7_ACK_DMA_ADDR_H;
	SRDL0_P1 = 4;
	SRDL1_P1 = 0;
	SRCON_P1 = (1<<7)|(1<<6)|(1<<5)|(1<<4)|(1<<0);
	bCMDRps_Flag = 0;
}


void get_addr(void) using 1
{
//	LBATmp0 = SARG0_P1;
//	LBATmp1 = SARG1_P1;
//	LBATmp2 = SARG2_P1;
//	LBATmp3 = SARG3_P1;

	*(char xdata *)((&LBA_TMP) + 0) = SARG3_P1;
	*(char xdata *)((&LBA_TMP) + 1) = SARG2_P1;
	*(char xdata *)((&LBA_TMP) + 2) = SARG1_P1;
	*(char xdata *)((&LBA_TMP) + 3) = SARG0_P1;
	
	if ( ! bSDHC)
	{
//		_push_(R8);
//		_push_(B);

//		#pragma asm

//		MOV		DPTR, # ISR_ERX_TMP			  //push ER2
//		MOV32_EDP0_ER2

//		MOV		DPTR, # REAL_BLOCK_LEN	
//		MOV32_ER2_EDP0	
//		INC32_ER2
//		MOV		R8, ER21
//		MOV		B,  ER20
//		
//		MOV		ER20, SARG0_P1
//		MOV		ER21, SARG1_P1
//		ANL		ER21, # 0x01

//		DIV16_ER2							 //lba % blk_len
//		MOV		A, R8
//		ORL		A, B
//		JZ		ADDR_JUDGE_END				 //û����������blk len �Ĵ�С����
		if ( CMP3 )
		{
				ADDRESS_ERROR	= 1;
		}
			//		ADDR_JUDGE_END:

//		MOV		DPTR, # ISR_ERX_TMP			 //pop ER2
//		MOV32_ER2_EDP0

//		#pragma endasm
//		
//		_pop_(B);
//		_pop_(R8);		
	}
}

void kick_rcv_data(void) using 1
{
//	SDICON_P1 |= (1<<3);		  //	;enable busycmd_en
	SDOCON_P1 |= 0x40;			  //;disable command rcv				
//			SDDL0_P1 = yBlockLen0;
//			SDDL1_P1 = yBlockLen1;
			SDDL0_P1 = 0xff;  //��֧�ֱ䳤
			SDDL1_P1 = 0x01;
	config_dma_buf_addr();
}


void ake_rev_data(void) using 1
{		
	cmd_r1_rps();
	SDOCON_P1 |= 0x40;
	SDDL0_P1 = 7;
	SDDL1_P1 = 0;
	SDICON_P1 |= (1<<0);
	bDataIn_Flag = 0;
}

void isr_cmd0_process(void) using 1
{
	while(!SCEND) 
	{}
	if (SCCRC)
	{
		return;
	}
	if ( (! bSPI_CRC_Check_Flag) ||(! SCCRC))
	{
		if (bMulRFlag)
		{
			bMulRFlag = 0;
			bDataStop_Flag = 1;	
			bSDStop = 1;		  //nfc read stop
			bEnterReadDmaOut = 0;
			SDICON_P1 &= ~(1<<2);
		}
		IDLE_STATE = 1;
		bBlockLenLess512Byte = 0;
		*((char xdata *)(&CSD) + 3) = 0x32;							
		*((char xdata *)(&CSD) + 15) = *(char xdata *)(&CSD_25M_CRC7);	
		*(char xdata *)(&SOFT_RESET_ACMD41_CNT_TMP) = *(char xdata *)(&SOFT_RESET_ACMD41_CNT);
	}
	cmd_r1_rps();			
}


void cmd_rps_isr_pro(void) using 1  //::r1��r2 rsp��Ҫ����
{		  
	_push_(PAGEMAP);    				  
	sfrpage(1);	
	SRPND = 0;
	bCMDRps_Flag = 1;

	ERASE_RESET = 0;
	ILLEGAL_COMMAND = 0;
	COM_CRC_ERROR = 0;
	ERASE_SEQ_ERROR = 0;
	ADDRESS_ERROR = 0;
	PARAMETER_ERROR = 0;

	if (bSPICMDInR2Rps)
	{
		bSPICMDInR2Rps = 0;	
	
		WP_ERASE_SKIP = 0;
		WP_VIOLATION = 0;
		ERASE_PARAM = 0;
		OUT_OF_RANGE = 0;
	}						 
	_pop_(PAGEMAP);
}


void cmd_rps_isr(void) interrupt 1 using 1
{
 	cmd_rps_isr_pro();
}

//void dma_data_in_isr(void) interrupt 2 using 1
//{
//	SDIPND = 0;
//	bDataIn_Flag = 1;
//}

void dma_data_out_isr(void) interrupt 3 using 1
{		  
	_push_(ACC);
	_push_(PSW);
	_push_(PAGEMAP); 
	PAGEMAP = 0x01;

	SDOPND = 0;
	bDataOut_Flag = 1;
	if (bReadType) {
		bDataStop_Flag = 1;
		bSDStop = 1;			//nfc read stop
		bEnterReadDmaOut = 0;
	}	
	 
	_pop_(PAGEMAP);
	_pop_(PSW);
	_pop_(ACC);
}

void not_use_1(void) interrupt 15 using 2		//֪ͨ��������ռ�õ�2��Ĵ������Ż���ʱ���ܵ�dataʹ��
{

}









