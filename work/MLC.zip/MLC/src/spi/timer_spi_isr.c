
#include "intrins.h"		  
#include "inc\common.h"						
#include "inc\ax215_exinst.h"							
#include "inc\sd_spi_com_define.h" 				 
#include "inc\nand_flash.h"		
#include "inc\timer.h"  
#include "inc\array_FIFO.h"						  		   
#include "inc\SD_accelerate.h"
#include "inc\extern_data.h"
#include "inc\timer_isr_spi.h"
#include "inc\mrom_func.h"

extern volatile unsigned char idata sectors_in_virtual_page_total;
extern volatile unsigned char idata sectors_in_virtual_page_w;
#pragma asm
EXTRN CODE (CUR_LBA, LBA_TMP)
EXTRN CODE (TIMER_ER0_COPY, TIMER_ER1_COPY, SD_KICK_DMA_OUT_ER0_COPY, SD_KICK_DMA_OUT_ER1_COPY)
EXTRN CODE (CPRM_EN_DE_CODE_BUF_DPTR_H, CPRM_EN_DE_CODE_BUF_DPTR_L)
#pragma endasm

extern bit bDataIn_Flag,READY_FOR_DATA, bMulWriteTask, bSingleWriteTask, bStopMulWriteData;
extern bit bCallWriteLBA, bInWriteLbaFun;
extern bit bForceDly;
extern bit bRcvSDDataKickStart;
extern bit bCopyBackNotOver;
extern bit bCopyNeedStop;
extern bit bStr_MulRead_SD;
extern bit bDataOut_Flag;
extern bit bDataStop_Flag, bMulRFlag;
extern bit bSDStop, bEnReadLBACnt;
extern bit bSPI_CRC_Check_Flag;
extern bit bEnIsrDmaOut, bBlockLenLess512Byte, bReadDataInHsBuf, bLbaSeqInHsBuf, bTimeout, bReadDataInVirtualBuf;
extern bit bSwitch50M;
extern bit bInReadLba, bReadType;
extern bit bStopRcvCprmData;
extern bit bVisitCprmDataMode, bCprmDmaDataMode;
extern bit bRomCard;
extern bit bEnVirtualBuf2Nf, bEnForceEraseVirtualBufBlk;
extern bit bFlashRetryTimeOut,bCPRM_E_D_Flag;

extern unsigned char data yTast_Index;
extern unsigned char data yBlockLen0, yBlockLen1;
extern unsigned char data yBuffer_Index_Start, ActualRcvSDDataCnt, PlanRcvSDDataCnt;
extern unsigned char idata host_to_sd_buf_ptr, sd_ready_for_nf_buf_cnt , sd_to_nf_buf_ptr;
extern unsigned char idata virtual_sd_data_buf_cnt, hs_to_virtual_buf_ptr, virtual_to_nf_buf_ptr;
extern unsigned char idata virtual_sd_buf_map_w_nf_page_ptr, virtual_sd_buf_map_r_nf_page_ptr;
extern unsigned char idata dma_out_r_cur_virtual_buf_map_r_nf_page_ptr, dma_out_r_cur_virtual_buf_map_r_nf_sec_in_page_ptr;	
extern unsigned char idata virtual_to_nf_buf_in_per_page_sector_ptr;			
extern unsigned char data ReadLBACnt;
extern unsigned char data yBuffer_Index;
extern unsigned char idata SdReadDmaAddrH, SdReadDmaAddrL,SDBufPageAddr;
extern unsigned char idata SDBufBlockAddrH, SDBufBlockAddrL;
extern unsigned char idata host_to_sd_buf_ptr, sd_ready_for_nf_buf_cnt;
extern unsigned char code sd_hs_cache_data_buf_lba[][4];
extern unsigned char code sd_hs_cache_data_buf[];
extern unsigned char code sd_virtual_data_buf_lba[][4];
extern unsigned char code sd_virtual_data_buf [];
extern unsigned char code W_BUF_ADDR_H,W_BUF_ADDR_L;
extern unsigned char code SdVirtualBuf2NfUseMaxPage, SdVirtualBuf2NfUseMaxSector;
//extern unsigned char data LBATmp0, LBATmp1;
extern unsigned char data NfEmptyBufCnt;
 
extern void stop_single_write_fun(void);
extern void stop_mul_write_fun(void);

extern void config_hs_cache_buf_dma_addr(unsigned char buf_ptr);
extern void get_lba(void);
extern void clr_d0_busy_in_rcv_ing(void);
extern void write_block_tab(void);
extern void rcv_one_packet_case_in_pro_state_process(void);
extern void change_state_machine_in_pro_dis_state(void);
extern void clr_d0_busy_in_rcv_end(void);
extern void cprm_mul_write_end(void);
extern void uart_send_byte(unsigned char val);
extern void copy_512byte_data(unsigned char src_buf_index, unsigned char target_buf_index);

extern void cprm_en_de_code_buf_point_to_cur_buf(void);
extern void	cprm_encode_data(void);
extern void cprm_decode_data(void);
extern void judge_cprm_data_dma_out_complete(void);
extern void judge_cprm_data_dma_in_complete(void);
extern void cprm_en_de_code_data(void);
extern void clr_d0_busy_in_rcv_ing(void);
extern void w_data_end_process(void);

extern void config_cur_buf_data_lba(unsigned char buf_ptr);
extern void sel_dma_addr(void);
extern void Sel_Buffer_Addr(void);

extern void read_sdbuf_block(void);
extern void program_sdbuf_block(void);
extern void erase_sdbuf_block(void);
extern void NF_BUF1_2_BUF2_AND_RANDOMIZE(void);
extern void cur_map_lba_inc(void);
extern void update_er3_to_r_random_lba_var(void);

void cal_sd_dma_out_addr(void);
void reset_timer_cnt(void);
void force_timer_enter_isr(void);
void cal_next_dma_in_addr(unsigned char cur_buf_ptr);
void timer_tick_inc(void);
void timer_tick_clr(void);
void printf_timer_n_10ms(void);
void printf_sd_buf_cnt(void);
void printf_n_1ms_cnt(void);
void save_virtual_sd_buf_data_to_nf(void);
void updata_cur_virtual_sd_buf_data_to_nf(unsigned char r_virtual_buf_ptr, unsigned char r_virtual_buf_sec_in_page_ptr, unsigned char w_nf_buf);
void cpy_virtual_buf_var_2_nf_buf(void);
void sd_buf_2_nf_buf_cnt_dec(void);
void virtual_buf_2_nf_buf_cnt_dec(void);
void release_interrupt_reti(void);
void erase_virtual_buf_map_blk(void);
void initial_vitrual_buf_parameter_in_powerup(void);
void chk_writing_lba_and_sd_virtual_buf_lba(void);
void hs_write_to_virtual_sd_buf_map_nf(unsigned char hs_buf_ptr, unsigned char  w_nf_page_index, unsigned char savecnt);
void timer_timeout_cnt_dec(void);
void disable_force_sd_bus_rcv_data_in_dly(void);

unsigned char idata  rcv_data_state;			   //Ĭ�ϳ�ʼ��Ϊ0��HS_RCV_DATA_IN_IDLE��
unsigned char idata  write_hs_data_to_flash_state; //Ĭ�ϳ�ʼ��Ϊ0 (W_HS_DATA_TO_FLASH_IDLE)	
unsigned short idata timer_dly_timeout;			   //timeout ������

unsigned char idata  sd_dma_in_cnt;
unsigned char idata  yBufIndexStartCopy;

//unsigned char idata copy_last_virtual_to_nf_buf_ptr; 	   //sd virtual buf�� ������page��Ӧ��LBA tab ptr.
unsigned char idata copy_last_virtual_sd_data_buf_cnt;
unsigned char idata status_for_writing_lba_virtual_buf_lba;

unsigned short idata timer_tick, n_1ms;							//timer��ʱ��


unsigned char idata  write_virtual_sd_buf_data_to_nf_state; 	//Ĭ�ϳ�ʼ��Ϊ0 (W_VIRTUAL_SD_BUF_DATA_TO_NF_IDLE)

unsigned char idata  u8_extern_dma_in_task;						//������dma in ���񡣣�pragram csd(u8_extern_dma_in_task & 0x80)��									

unsigned char idata  cmd12_stop_dly_times;						//����cmd12 stop timeout��ѭ������ 

static unsigned char idata next_dma_in_addr_h, next_dma_in_addr_l;		

void initial_rcv_data_par(void)
{
	PlanRcvSDDataCnt = 1;
	ActualRcvSDDataCnt = 0;
	yBuffer_Index_Start = _DATA_BUF_INDEX;
	NfEmptyBufCnt =  PlanRcvSDDataCnt;
	bRcvSDDataKickStart = 1;	
	
}

/************************************************************************************************************************
* ��������void dma_data_in_isr(void)
* ���룺
* ���ܣ�����dma in ����
* �����
************************************************************************************************************************/
void dma_data_in_isr(void)  interrupt 2
{
	_push_(PAGEMAP);
	_push_(DPCON);
	_push_(R8);	
	
	PAGEMAP = 0x01;
//-------------------------------------------------------------------------------			
	SDIPND = 0;					//�жϱ�־����
	bDataIn_Flag = 1;
//	READY_FOR_DATA = 0;
//-------------------------------------------------------------------------------

	DPCON = 0x08;				//���, �ر�����, dptr0	

	if (u8_extern_dma_in_task != EXTERN_NO_DMA_IN_TASK) {
		if (u8_extern_dma_in_task == EXTERN_DMA_IN_PRG_CSD) {			
			stop_single_write_fun();			
		}else if(u8_extern_dma_in_task == EXTERN_DMA_IN_ERASE_DATA){
		}
		u8_extern_dma_in_task = EXTERN_NO_DMA_IN_TASK;
		goto  dma_data_in_isr_exit;
	}
//-------------------------------------------------------------------------------

	if ((rcv_data_state == HS_RCV_DATA_IN_ING) || (rcv_data_state == HS_RCV_DATA_IN_IDLE) ) {	// >= HS_RCV_DATA_IN_STOP����ס״̬��	
		if (yTast_Index != 0) {	//���HS_RCV_DATA_IN_IDLE		  
			if ((yTast_Index == Single_Write_Task) || 
				(yTast_Index == Mul_Write_Task) || 
				(yTast_Index == Secutity_Mul_Write_Task)) {
#if EN_CPRM			
				if (yTast_Index == Secutity_Mul_Write_Task) {
						bVisitCprmDataMode  = 1;
				  	bCprmDmaDataMode = 1 ;
				}
#endif
	//-------------------------------------------------------------------------------	
				get_lba();			 				//ER3 = LBA							
	//-------------------------------------------------------------------------------
				yTast_Index = 0;
//				initial_valid_sector_cnt();			
				#pragma asm
				CLR32_ER2			//Ĭ��ER2 = 0
				#pragma endasm									
				
			   cal_next_dma_in_addr(host_to_sd_buf_ptr);			   
			   enable_force_sd_bus_rcv_data_in_dly();			
			   bEnVirtualBuf2Nf = 1;		//���ϵ�󣬼�ʹbEnVirtualBuf�����ݣ��ȴ�����д���ݺ󣬲Ÿ��µ�flash
			}
		}		
		
		if (( (!bMulWriteTask) && (!bSingleWriteTask)) || 
			(bMulWriteTask && (SDOTK_P1 == 0xfd)) || 
			(bSPI_CRC_Check_Flag && SDCRC)) {
				
		}
		else {						//crc ���ͨ��
	//-------------------------------------------------------------------------------
#if EN_CPRM	
	//cprm decode data	
			if (bVisitCprmDataMode) {
				config_hs_cache_buf_dma_addr(host_to_sd_buf_ptr);	 //cur_buf_dma_addr = {R8 B}
				DP0H = R8;
				DP0L = B;
				#pragma asm
				ADDDP0					   							//cur_buf =  cur_buf_dma_addr * 4
				ADDDP0
				ADDDP0
				MOV	  	A, DP0H
				MOV	  	B, DP0L
				MOV		DPTR, # CPRM_EN_DE_CODE_BUF_DPTR_H		    //input cur buf ptr.
				MOVX	@DPTR, A
				MOV		A, B
				MOV		DPTR, # CPRM_EN_DE_CODE_BUF_DPTR_L	
				MOVX	@DPTR, A
				#pragma endasm
	
				bCPRM_E_D_Flag = 1;	
				cprm_en_de_code_data();
			}
#endif
	//-------------------------------------------------------------------------------
	//���»���buf��Ӧ��LBA TABLE, hs_cache_data_buf_lba[host_to_sd_buf_ptr][4] = ER3	
			DPTR0 = sd_hs_cache_data_buf_lba;	
			R8 = 0;
			B = host_to_sd_buf_ptr << 2;		  
			#pragma asm
			ADDDP0					//DPTR0 + (R8 B)	
			MOV32_EDP0_ER3
			#pragma endasm												
	//-------------------------------------------------------------------------------			
			#pragma asm
			INC32_ER2				//ER2++	 //��¼����single/mul write ���յ����ݰ���
			INC32_ER3				//ER3++	 //��¼��ǰ��LBA��ַ	   
			#pragma endasm

			host_to_sd_buf_ptr++;
			if (host_to_sd_buf_ptr == SD_HS_CACHE_BUF_CNT) {
				host_to_sd_buf_ptr = 0;	
			}

	  	//-------------------------------------------------------------------------------

			if ( ! bRomCard){
				sd_ready_for_nf_buf_cnt++;							//��д��flash����Ч����cnt	
			}

  
			
			SDXADR1_P1 = next_dma_in_addr_h;
			SDXADR0_P1 = next_dma_in_addr_l;
#if 1
			_push_(IE);	

		   	EA = 0;	
			if ( (bMulWriteTask && (!bStopMulWriteData))
#if EN_CPRM 
				&& ( ! bVisitCprmDataMode)									  //Not in cprm mode.
#endif
//				&& (sd_ready_for_nf_buf_cnt < SD_HS_CACHE_BUF_USE_CACHE_CNT)
//				&& (sd_ready_for_nf_buf_cnt < SD_HS_CACHE_BUF_CNT / 2)
				&& (sd_ready_for_nf_buf_cnt < SD_HS_CACHE_BUF_CNT)
//				&& ((bRcvSDDataKickStart) && ((ActualRcvSDDataCnt + 1) < (PlanRcvSDDataCnt)))
				&& ((bRcvSDDataKickStart) && (sd_ready_for_nf_buf_cnt < PlanRcvSDDataCnt))
#if 0
//				&& (bLbaSeqInHsBuf)								//Hs buf lba ����
#endif
				&& (virtual_sd_data_buf_cnt == 0)

				&& ( ! bForceDly)) {			  				//�ر�force dly							   		

				SDICON_P1 |= (1<<1);								//Kict next packet,mul write,�˴���Ȼ SDCRC == 0																	
//P2 ^= (1<<6);					
//				READY_FOR_DATA = 1;
				
				EA = 1;
			
				bDataIn_Flag = 0;
				sd_dma_in_cnt--;

				*(char xdata *)(&W_BUF_ADDR_H) =  next_dma_in_addr_h;
				*(char xdata *)(&W_BUF_ADDR_L) =  next_dma_in_addr_l;

//				B = host_to_sd_buf_ptr + 1;
//				if (B == SD_HS_CACHE_BUF_CNT) {
//					B = 0;	
//				}
//				cal_next_dma_in_addr(B);
				cal_next_dma_in_addr(host_to_sd_buf_ptr);
														
			}else {
				*(char xdata *)(&W_BUF_ADDR_H) =  next_dma_in_addr_h;
				*(char xdata *)(&W_BUF_ADDR_L) =  next_dma_in_addr_l;				
			} 
			EA = 1;	
_pop_(IE);	
#else
			*(char xdata *)(&W_BUF_ADDR_H) =  next_dma_in_addr_h;
			*(char xdata *)(&W_BUF_ADDR_L) =  next_dma_in_addr_l;	
		
#endif
		} //������1������

		if (bSingleWriteTask) {
			stop_single_write_fun();		   //single write �ı�SD״̬��
		}

#if EN_CPRM
		judge_cprm_data_dma_in_complete();
		if (bStopRcvCprmData){
			bStopMulWriteData = 1;
			cprm_mul_write_end();
		}	
#endif
		//����timer_isr��״̬��
		if (bSingleWriteTask || (bMulWriteTask && (SDOTK_P1 == 0xfd)) || bStopMulWriteData) {
			SDICON_P1 &= ~(1<<0);	//;Disable receive data on SD bus.		
			rcv_data_state = HS_RCV_DATA_IN_STOP;				//single write || mul write stop��������			
			timer_dly_timeout = SD_RCV_DATA_DLY_TIMEOUT_CNT;	//timeout config.
		
		}else {
			
			rcv_data_state = HS_RCV_DATA_IN_ING;				//mul write���ڽ�������
			timer_dly_timeout = SD_RCV_DATA_DLY_TIMEOUT_CNT;	//����ÿ�����ݿ�����Ҫ��dlyֵ

		}
	}
	
	sd_dma_in_cnt++;

dma_data_in_isr_exit:
											
	_pop_(R8);
	_pop_(DPCON);
	_pop_(PAGEMAP);
	
}


void cal_next_dma_in_addr(unsigned char cur_buf_ptr)
{
#if 1
	   B = cur_buf_ptr + 1;				//Cal next buf dma addr.
	   if (B == SD_HS_CACHE_BUF_CNT) {
	   		B = 0;
	   }
	   config_hs_cache_buf_dma_addr(B);
	   next_dma_in_addr_h = R8;
	   next_dma_in_addr_l = B;

#endif	
}

/************************************************************************************************************************
* ��������void cal_sd_dma_out_addr(void)
* ���룺yBuffer_Index
* ���ܣ�����SD DMA ADDR
* �����SdReadDmaAddrH, SdReadDmaAddrL
* TMP:  DPTR0, ER0, ER1
************************************************************************************************************************/
void cal_sd_dma_out_addr(void)
{
	sd_kick_dma_out_data_push_er0_er1();

	ER02 = yBuffer_Index;
	sel_dma_addr();						
	SdReadDmaAddrH = ER01;					
	SdReadDmaAddrL = ER00;

	sd_kick_dma_out_data_pop_er0_er1();

}
/************************************************************************************************************************
* ��������void wait_dma_out_read_buf_empty(void)
* ���룺
* ���ܣ��ȴ�sd ��bufΪ�գ����Ѿ�dma out �������� 
* �����
************************************************************************************************************************/
void wait_dma_out_read_buf_empty(void)
{
	if ((! bSDStop) && ((bStr_MulRead_SD && bEnReadLBACnt) || ( ! bStr_MulRead_SD)) ) {  //::bEnReadLBACnt�ȼ���DMA���ǵ�һ�������һ������DMA����bEnReadLBACnt=0�����
		while( ( ! bDataStop_Flag) && ( ! bSDStop) && bEnReadLBACnt ){}		 //�ȴ����һ������kict start�󣬴�������ִ��
		while(( ! bDataOut_Flag)) {}										 //�ȴ����һ������dam���
	}	
}
/************************************************************************************************************************
* ��������void sd_kick_dma_out_data(void)
* ���룺yBuffer_Index(ָ���data)
* ���ܣ�
* �����
* tmp: ER0, ER1
************************************************************************************************************************/
extern bit bReadNewBlockTrue;
void sd_kick_dma_out_data(void)   //��timer������һ������DMA OUT
{
	if (( ! bDataStop_Flag) && (! bSDStop) && bEnReadLBACnt) {		// SD not stop && flash not stop && buf data ok
		if (bMulRFlag && (bDataOut_Flag || bStr_MulRead_SD )){		//bMulRFlag == 0 -> stop mul read		
			if (bStr_MulRead_SD) {
				cal_sd_dma_out_addr();					
				yBufIndexStartCopy = yBuffer_Index;	   //dma len < 512
#if  EN_CPRM
				if (bReadType || bBlockLenLess512Byte || (!bSwitch50M) /*|| bCopyBackNotOver*/ || (bReadDataInVirtualBuf) || bCprmDmaDataMode /*|| bVisitCprmDataMode*/) {
#else  											
				if (bReadType || bBlockLenLess512Byte || (!bSwitch50M) /*|| bCopyBackNotOver*/ || (bReadDataInVirtualBuf)) {
#endif	   
					bEnIsrDmaOut = 0; 		 			   		//single read || dma len < 512 || sd clk in 25m hz || cprm data mode
				}else {
#if 1
					bEnIsrDmaOut = 0; 							//1: Enable dma out isr dma data one by one in dma_out_isr.
#endif
				}
				bStr_MulRead_SD = 0;						  		//dma ��һ������
			} //end if (bStr_MulRead_SD)
							
	
#if DYNAMIC_VIRTUAL_SECTOR  //DEBUG VBUF
//		   	bReadDataInVirtualBuf = 0;			  							//Ĭ��data ���� virtual buf��,Ĭ����Ϊ0
			if ( (! bReadDataInHsBuf) 
				&& (virtual_sd_data_buf_cnt != 0)
				&& (! bReadDataInVirtualBuf))									//2013-02-03����
				 {	//LBA's data is not in hs_buf && virtual buf is not empty && not in virtual buf.			 	
//prints("fled");
//printHexSync(virtual_sd_buf_map_w_nf_page_ptr);						 
//printHexSync(virtual_sd_data_buf_cnt);	
////debug LBA��Χ  //Сok
//ER33 =	0x00;
//ER32 =	0x25;
//ER31 =	0x20;
//ER30 =	0x08;					 
//					 
//printHexSync(ER33);
//printHexSync(ER32);
//printHexSync(ER31);
//printHexSync(ER30); 
				bEnIsrDmaOut = 0; 	 
				//R00: virtual_sd_data_buf_cnt (offset)
				//R01: hs_to_virtual_buf_ptr
					//read pageָ��Ӻ���ǰ��ʼ��,�յݼ�				 
				for (ER00 = 0, ER01 = hs_to_virtual_buf_ptr, dma_out_r_cur_virtual_buf_map_r_nf_page_ptr = virtual_sd_buf_map_w_nf_page_ptr;	
						ER00 < virtual_sd_data_buf_cnt; ER00 += sectors_in_virtual_page_total) {  //����(����)������������				
					if (ER01 == 0) {		 						//hs_to_virtual_buf_ptr--
						ER01 = SD_VIRTUAL_BUF_CNT - 1; 			//[0,SD_VIRTUAL_BUF_CNT-1]
					}else {
						ER01--;	
					}		
					
					_push_(DPCON);
					_push_(ER00);
		//��������ע�Ᵽ��ER01	
					dma_out_r_cur_virtual_buf_map_r_nf_page_ptr--;//������ѭ��
		//get lba		
					DPTR0 = sd_virtual_data_buf_lba;
					B = ER01; 						//���֧��128 �� ����buf					
					ACC = 4;

					#pragma asm
					MUL	AB							//BA = A * B
					MOV R8, B
					MOV	B, A						//DPTR0 = DPTR0 +  4 * virtual_buf_ptr					
				
					ADDDP0							//DPTR0 + (R8 B)	
					
					MOV	DPCON, # 0x18			    //���, �ر�����, dptr0
					MOV32_ER1_EDP0					//ER1 = sd_virtual_data_buf_lba[host_to_sd_buf_ptr][4]  //get lba
				  #pragma endasm
//printHexSync(ER13);		//��ʼλ��LBA
//printHexSync(ER12);
//printHexSync(ER11);
//printHexSync(ER10);	
						
		//get cnt 
					DPTR0 = sd_virtual_data_buf_cnt;// + ER01;
					#pragma asm
					MOV R8, #0
					MOV	B, ER01						//DPTR0 = DPTR0 +  4 * virtual_buf_ptr					
					ADDDP0							//DPTR0 + (R8 B)	
					MOVX 	A,@DPTR				
					MOV R8,A
					#pragma endasm
					sectors_in_virtual_page_total = R8;
//					MOV  	R0,#LOW (sectors_in_virtual_page_total)		//����total
//					MOV  	@R0,A
					#pragma asm
PUSH 	ER01		
					//test er3-----ER1<=ER3<ER1+sectors_in_virtual_page_total
					SUB32_ER0_ER3_ER1
JB		EC,NOT_IN_RANGE	//ER3<ER1
					#pragma endasm
					
					dma_out_r_cur_virtual_buf_map_r_nf_sec_in_page_ptr = ER00;
//					MOV  	R0,#LOW (dma_out_r_cur_virtual_buf_map_r_nf_sec_in_page_ptr)
//					MOV 	A,ER00
//					MOV  	@R0,A			//����ƫ��
					#pragma asm
					CLR32_ER0
					#pragma endasm
					ER00 = sectors_in_virtual_page_total;
//					MOV  	R0,#LOW (sectors_in_virtual_page_total)
//					MOV  	ER00,@R0	//��ȡtotal
					#pragma asm
					ADD32_ER1_ER0_ER1		//base lba + total
					SUB32_ER0_ER3_ER1	//ER3<ER1
JNB		EC,NOT_IN_RANGE	//>=
					//����ƫ��
					SETB 	EZ
SJMP	IN_RANGE
NOT_IN_RANGE:	
					CLR 	EZ
IN_RANGE:
					POP		ER01
					#pragma endasm
					_pop_(ER00);		
					_pop_(DPCON);
					if (EZ) {			//EZ==1 -> Hs_buf_lba == cur_lba;vitual buf��������Ӧ���ݣ����أ���Ҫread data��������������ظ���������kick���̣����յ�һ�����ݴ���						
//						dma_out_r_cur_virtual_buf_map_r_nf_page_ptr = (virtual_sd_buf_map_w_nf_page_ptr - 1) - ER00 / VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE;
//						dma_out_r_cur_virtual_buf_map_r_nf_sec_in_page_ptr = VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE - 1 - ER00 % VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE;

						if ((virtual_sd_buf_map_r_nf_page_ptr == dma_out_r_cur_virtual_buf_map_r_nf_page_ptr) && (dma_out_r_cur_virtual_buf_map_r_nf_sec_in_page_ptr < virtual_to_nf_buf_in_per_page_sector_ptr)) {
								//��������ķ�Χ�պ����Ѿ��ͷŵľͲ�����С��������
						} else {
							
//prints("div");//data in virtual 
//printHexSync(dma_out_r_cur_virtual_buf_map_r_nf_page_ptr);//page
//printHexSync(dma_out_r_cur_virtual_buf_map_r_nf_sec_in_page_ptr);	//sector						
//prints("\n");
							bReadDataInVirtualBuf = 1;	//data is in virutal buf.
							bSDStop = 1;				//data is in virtual buf.����һ��stop
							return;
						}
					}else {							//EZ==0 -> ER3 != cur_lba, continue search
 
					}
//printHexSync(ER01);
//printHexSync(ER00);
//printHexSync(dma_out_r_cur_virtual_buf_map_r_nf_page_ptr);						
					
				}// end of for(...){}

			}

#else			
//		   	bReadDataInVirtualBuf = 0;			  							//Ĭ��data ���� virtual buf��,Ĭ����Ϊ0
			if ( (! bReadDataInHsBuf) 
				&& (virtual_sd_data_buf_cnt != 0)
				&& (! bReadDataInVirtualBuf))									//2013-02-03����
				 {	//LBA's data is not in hs_buf && virtual buf is not empty && not in virtual buf.			 	
			
				bEnIsrDmaOut = 0; 				   		//Virtual buf �����ݣ��ر�dma out kict start ����
				
				//ER00: virtual_sd_data_buf_cnt (offset)
				//ER01: hs_to_virtual_buf_ptr

				for (ER00 = 0, ER01 = hs_to_virtual_buf_ptr; ER00 < virtual_sd_data_buf_cnt; ER00++ ){
					if (ER01 == 0) {		 						//hs_to_virtual_buf_ptr--
						ER01 = SD_VIRTUAL_BUF_CNT - 1; 			//[0,SD_VIRTUAL_BUF_CNT-1]
					}else {
						ER01--;	
					}

					DPTR0 = sd_virtual_data_buf_lba;
					B = ER01; 						//���֧��128 �� ����buf
					ACC = 4;
					
					#pragma asm
					MUL	AB							//BA = A * B
					MOV R8, B
					MOV	B, A						//DPTR0 = DPTR0 +  4 * virtual_buf_ptr					
				
					ADDDP0							//DPTR0 + (R8 B)	
					
					PUSH	DPCON
					MOV	DPCON, # 0x08			    //���, �ر�����, dptr0
					MOV32_ER1_EDP0					//ER1 = sd_virtual_data_buf_lba[host_to_sd_buf_ptr][4]
					POP		DPCON
					XRL32_ER1_ER3			 		//LBA(yBuffer_Index)
					#pragma endasm
					if (EZ) {						//EZ==1 -> Hs_buf_lba == cur_lba						
						dma_out_r_cur_virtual_buf_map_r_nf_page_ptr = (virtual_sd_buf_map_w_nf_page_ptr - 1) - ER00 / VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE;
						dma_out_r_cur_virtual_buf_map_r_nf_sec_in_page_ptr = VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE - 1 - ER00 % VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE;
						
						bReadDataInVirtualBuf = 1;	//data is in virutal buf.
						bSDStop = 1;				//data is in virtual buf.����һ��stop
					   	return;
					} else {							//EZ==0 -> ER3 != cur_lba, continue search
 
					}
				}// end of for(...){}

			}
				 
#endif			

#ifdef _MLC_
if (bReadNewBlockTrue/* && (!re_read_delaycnt)*/ && bMulRFlag)
{
	bSDStop = 1;
	bEnReadLBACnt = 0;
	SdDmaReadLBACnt = 0; 
	return;
}
#endif
			
			
			if (bBlockLenLess512Byte) {
				_push_(DP1H);
				_push_(DP1L);
				_push_(DPCON);
				
				ER02 = yBufIndexStartCopy;
				Sel_Buffer_Addr();
				DP1L = ER00;
				DP1H = ER01;						//DPTR1 = @buf


		#pragma asm		
//				R8 = LBATmp1 & 0x01;			//���ܴ���512
//				B =  LBATmp0;
				MOV 	DPTR,#(LBA_TMP+2)
				MOVX	A,@DPTR
				ANL		A,#0x01
				MOV		R8,A
				
				MOV 	DPTR,#(LBA_TMP+3)
				MOVX	A,@DPTR
				MOV		B,A
		#pragma endasm
				
				#pragma asm	
				ADDDP1							//DPTR1 = @buf + lba_offset
							
				CLR32_ER0
//				MOV	ER00, yBlockLen0
//				MOV	ER01, yBlockLen1
				MOV	ER00, #0xff
				MOV	ER01, #0x01		
				
				INC32_ER0					   //ER0[15:0] = blk_len
				MOV	ER02, ER20
				MOV	ER03, ER21 				   //ER2��n��data
				MUL16_ER0				   		//offset = ER0 = blk_len * n
				MOV	R8, ER01
				MOV B,  ER00
				ADDDP1						   //Src_DPTR1 = @buf + lba_offset + packet_offset
				#pragma endasm	
				
				ER02 =  yBuffer_Index;
				Sel_Buffer_Addr();
				DP0L = ER00;						//target buf
				DP0H = ER01;

				#pragma asm	
				CLR32_ER0
//				MOV	ER00, yBlockLen0
//				MOV	ER01, yBlockLen1
				MOV	ER00, #0xff
				MOV	ER01, #0x01
				
				INC32_ER0						//blk_len
			  MOV	DPCON,#0x31					//Enable DPTR0/DPTR1 Auto INC ,select toggle enable,select DPTR1	
				
				COPY_DATA_LOOP:					//@DPTR1 -> @DPTR0
				MOVX	A,@DPTR
				MOVX	@DPTR,A	
				DEC32_ER0
				JNB	EZ, COPY_DATA_LOOP

				#pragma endasm
				
				_pop_(DPCON);
				_pop_(DP1L);
				_pop_(DP1H);	
			}
			SDXADR1_P1 = SdReadDmaAddrH;
			SDXADR0_P1 = SdReadDmaAddrL;
//			SDDL0_P1 = yBlockLen0;
//			SDDL1_P1 = yBlockLen1;
			SDDL0_P1 = 0xff;  //��֧�ֱ䳤
			SDDL1_P1 = 0x01;

#if EN_CPRM	
			if (bVisitCprmDataMode) {			
				cprm_en_de_code_buf_point_to_cur_buf();
				
				bCPRM_E_D_Flag = 0;	
				cprm_en_de_code_data();
			}
#endif		
//putchar('v');
			SDOTK_P1 = 0xfe;	
		_push_(IE);			
		
			
			EA = 0;
			if ( (! bDataStop_Flag)) {

 				SDOCON_P1 |= (1<<0);
				EA = 1;
//P2 ^= (1<<6);			
				bDataOut_Flag = 0;

				yBuffer_Index++;
				if (yBuffer_Index == READ_BUF_NUM) {
					yBuffer_Index = 0;
				}
				cal_sd_dma_out_addr();	

				#pragma asm
				INC32_ER2
				INC32_ER3							   //updata LBA++.
				#pragma endasm						   
				update_er3_to_cur_lba_var();		   

				if ((! bBlockLenLess512Byte)){	 	
					ReadLBACnt--;
					if (ReadLBACnt == 0) {
						bEnReadLBACnt = 0;
					}
					if(bReadDataInHsBuf){			  
//						bSDStop = 1;				//data is in ram.����һ��stop
					}
				}else{								//blk_len < 512, Holdסflash�����������ܸı�ReadLBACnt && bSDStop
				}

			}else {
			 	EA = 1;
			}
			
	_pop_(IE);				
			
		}	
	}
}
/************************************************************************************************************************
* ��������void release_interrupt_reti(void)
* ���룺
* ���ܣ� ǿ���ͷ��ж�ռ�õ�isrʱ�䣬��������ȼ���ϵ����ȼ��жϣ������ȼ��ٴν���󣬲���������Ӧ�����⣨�����ȼ��ж��˳�ǰ��
* �����
************************************************************************************************************************/
//void release_interrupt_reti(void)
//{
//	#pragma asm
//	RETI
//	#pragma endasm	
//}
/************************************************************************************************************************
* ��������void timer_isr(void)
* ���룺
* ���ܣ�
* �����
************************************************************************************************************************/
extern u8 data yCMD_Index;
void timer_isr(void) interrupt 10 using 2
{	
	
	_push_(PAGEMAP); 	
	_push_(DPCON);
	_push_(R8);
									 		  				
	DPCON = 0;
	PAGEMAP = 0x01;
	#pragma asm
	MOV	DPTR, # TIMER_ER0_COPY
	MOV32_EDP0_ER0
	MOV	DPTR, # TIMER_ER1_COPY
	MOV32_EDP0_ER1
	#pragma endasm
	
	if (bDataIn_Flag) {
//	if (sd_dma_in_cnt != 0) {	//sd_dma_in_cnt;	//ע�Ᵽ��R0 ,sd_dma_in_cnt �����idata							
		switch (rcv_data_state)
		{
			case HS_RCV_DATA_IN_IDLE:
//				sd_dma_in_cnt = 0;
				break;
	
			case HS_RCV_DATA_IN_ING:   // bDataIn_Flag = 1; ˵��dma in isr��ûkist start rcv next 512 byte data��
				if ( (SDOTK_P1 != 0xfd) && ( ! bStopMulWriteData)) {					   			//CMD12 is not rcv.

	//-------------------------------------------------------------------------------						
//	P2 &= ~(1<<5);
					if ((sd_ready_for_nf_buf_cnt > (SD_HS_CACHE_BUF_USE_CACHE_CNT - 1)) || (virtual_sd_data_buf_cnt != 0) || (bForceDly)) {
						if ((sd_ready_for_nf_buf_cnt != 0) || (virtual_sd_data_buf_cnt != 0)) {		
							if (timer_dly_timeout > 0) {
					   			timer_dly_timeout--;
					   			break;							//����delay,ֱ��timeout									  
							}
						}else{								   // sd_ready_for_nf_buf_cnt == 0����ǰ�˳�dly
							disable_force_sd_bus_rcv_data_in_dly();
//							bLbaSeqInHsBuf = 1;					//hs buf ��û���ݣ�Ĭ��LBA����
						}		

					}
						
					//����buf����������һֱ�ȴ��п�bufΪֹ
					if (sd_ready_for_nf_buf_cnt == SD_HS_CACHE_BUF_CNT) {
	
		#if EN_VIRTUAL_BUF
#if (!DYNAMIC_VIRTUAL_SECTOR)						
						if ((virtual_sd_data_buf_cnt <= (SD_VIRTUAL_BUF_CNT - 1/*ֻҪ�ܱ���һ������ʱ���ǿ���*/) - SD_HS_CACHE_BUF_CNT/*keep for stop*/) && 		//��֤����buf��1��page�Ŀռ����sd hs buf������
#else
						if ((virtual_lbabuf_emptycnt > SD_HS_CACHE_BUF_CNT)  &&
#endif
							(virtual_sd_buf_map_w_nf_page_ptr < (*(unsigned char xdata *)(& SdVirtualBuf2NfUseMaxPage))) && 
							((*(unsigned char xdata *)(& SdVirtualBuf2NfUseMaxSector)) >= VIRTUAL_BUF_READ_MAX_SECS_IN_PER_PAGE) ){
							bTimeout = 1;							 //write timeout 
							bCopyNeedStop = 1;
						}else {
							bTimeout = 0;							 //write is not timeout. 
							bCopyNeedStop = 0; 						 //buf is full,don't interrupt write lba.
						}
		#endif
						break;					  
					}else {
						bTimeout = 0;							 //write is not timeout. 
						bCopyNeedStop = 0; 
					}
	//-------------------------------------------------------------------------------			
					if (bDataIn_Flag) {
						SDXADR1_P1 = *(char xdata *)(&W_BUF_ADDR_H);
						SDXADR0_P1 = *(char xdata *)(&W_BUF_ADDR_L);
#if 1
						cal_next_dma_in_addr(host_to_sd_buf_ptr);	  
#endif
//P2 ^= (1<<6);
						clr_d0_busy_in_rcv_ing();	  //rcv next packet data
	//					READY_FOR_DATA = 1;
						bDataIn_Flag = 0;
						
						SDIIE = 0;
						sd_dma_in_cnt--;
						if(sd_dma_in_cnt == 0){
							bDataIn_Flag = 0;
						}	
						SDIIE = 1;
					}					

				}
				else {

					rcv_data_state = HS_RCV_DATA_IN_STOP;
				}					
				break;	
	
			case HS_RCV_DATA_IN_STOP:
				if (bMulWriteTask) {
			 		stop_mul_write_fun();
				}
#if 1
				cmd12_stop_dly_times = 0;								//��ʼ��Ϊ0
				if (bMulWriteTask){
					cmd12_stop_dly_times = CMD12_STOP_EXTRN_DLY_TIMES_IN_TIMEOUT;
					timer_dly_timeout = SD_CMD12_STOP_DLY_TIMEOUT_CNT;		//stop timeout 2013-02-25
				}
#else
				cmd12_stop_dly_times = 0;
#endif
				rcv_data_state = HS_RCV_DATA_IN_STOP_DLY;
				break;		   
	
			case HS_RCV_DATA_IN_STOP_DLY:
											
				if ( ((sd_ready_for_nf_buf_cnt != 0) || (virtual_sd_data_buf_cnt != 0) || bCallWriteLBA) && 
					(timer_dly_timeout > 0) ) { //timer_dly_timeout == 0 �󣬽�����dly
				   
				   	timer_dly_timeout--;
					if((timer_dly_timeout == 0) && (cmd12_stop_dly_times > 0)){
						cmd12_stop_dly_times--;	
						timer_dly_timeout = SD_CMD12_STOP_DLY_TIMEOUT_CNT;
					}			
					break;	
				}

//	#if (SD_HS_CACHE_BUF_CNT == 1)
//
//				//ֻ��һ��buf��д�����˳���read data��������ǰ�˳�����
//				if ((sd_ready_for_nf_buf_cnt != 0) || bCallWriteLBA){
//					break;	 
//				}
//
//	#elif(SD_HS_CACHE_BUF_CNT > 1)
			
				//single/mul write stop�󣬰�buf�е���������д��flash�У��ͷ����е�buf
		#if EN_VIRTUAL_BUF
				//single/mul write stop�󣬰�buf�е���������д��flash�У��ͷ����е�buf
				if (sd_ready_for_nf_buf_cnt > 0) {
						//��֤virtual buf�Ŀռ���Դ���sd_ready_for_nf_buf_cnt �����ݵ�ǰ���£�timeoutʱ�䵽������timeout
#if (!DYNAMIC_VIRTUAL_SECTOR)	
					if ((virtual_sd_data_buf_cnt <= (u8)((SD_VIRTUAL_BUF_CNT - VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE/*����������stop����writeʹ��*/) - sd_ready_for_nf_buf_cnt)) &&  
#else 
					if ((virtual_lbabuf_emptycnt >= (SD_HS_CACHE_BUF_CNT)) &&
#endif					
						//��֤����buf��Ӧ��nf blk��д��pageָ��û�������ֵ������֤������һ����page����д��
						(virtual_sd_buf_map_w_nf_page_ptr < (*(unsigned char xdata *)(& SdVirtualBuf2NfUseMaxPage)) - sd_ready_for_nf_buf_cnt) &&
						//��֤ÿ��page ��д�����ݵ�sector�ﵽVIRTUAL_BUF_READ_MAX_SECS_IN_PER_PAGE�����ֵ
						((*(unsigned char xdata *)(& SdVirtualBuf2NfUseMaxSector)) >= VIRTUAL_BUF_READ_MAX_SECS_IN_PER_PAGE) ){
						bTimeout = 1;							 //write timeout 
						bCopyNeedStop = 1;
					}else {
						bTimeout = 0;							 //write is not timeout. 
						bCopyNeedStop = 0; 						 //buf is full,don't interrupt write lba.
					}	
					break;
				} 
				bTimeout = 0;							 		//write is not timeout.
				bCopyNeedStop = 0;   
		#else	//--------------------------------------------------------------------------------------------------------
				//mul wr 
				if (bMulWriteTask && sd_ready_for_nf_buf_cnt) {	//�ȴ�bufΪ�գ����ȴ�sd buf�����ݴ洢��flash��	
					break;
				}  
				
				//single wr
				if (bSingleWriteTask && sd_ready_for_nf_buf_cnt) { //�ȴ�bufΪ�գ����ȴ�sd buf�����ݴ洢��flash��	
					break;		  
				} 
				
				bTimeout = 0;							 		//write is not timeout.
				bCopyNeedStop = 0;  
		#endif 	//--------------------------------------------------------------------------------------------------------



#if EN_VIRTUAL_BUF
				//�ر�д���ݵ�nf�ĵ���
				bEnVirtualBuf2Nf = 0;						 //sd��idle״̬�£���ʹbEnVirtualBuf�����ݣ��ȴ�����д���ݺ󣬲Ÿ��µ�flash
				if (virtual_sd_data_buf_cnt != 0){			 //Virutal buf ������
					bCopyNeedStop = 1;  					
					if (write_virtual_sd_buf_data_to_nf_state != W_VIRTUAL_SD_BUF_DATA_TO_NF_IDLE){	//�ȴ�Virtual buf -> nf ����������ȫ�˳�
						break;
					}				   
				}
				bCopyNeedStop = 0;  
				
				if (write_hs_data_to_flash_state != W_HS_DATA_TO_FLASH_IDLE){	//��ǿ�ݴ��ԣ��ȴ�sd hs buf -> nf��������ȫ�˳� 
					break;
				}				
#endif			
			   	rcv_data_state = HS_RCV_DATA_IN_END;
				break;
					
			case HS_RCV_DATA_IN_END:
				write_block_tab();

				if (bSingleWriteTask) {					
//					SDICON_P1 &= ~(1<<0);	//;Disable receive data on SD bus.		
//					bStopEn = 0;
//					bDataIn_Flag = 0;
//					READY_FOR_DATA = 1;
//					rcv_one_packet_case_in_pro_state_process();	
					w_data_end_process();		 
					bSingleWriteTask = 0;				
				} 
				if (bMulWriteTask) {
					w_data_end_process();
//				  	change_state_machine_in_pro_dis_state();
//				  	clr_d0_busy_in_rcv_end();
				  	cprm_mul_write_end();
				  	bMulWriteTask = 0;
	
				}
				bStopMulWriteData = 0;
				bDataIn_Flag = 0; 
//				READY_FOR_DATA = 1;									   
				rcv_data_state = HS_RCV_DATA_IN_IDLE;
				sd_dma_in_cnt = 0;				
//				enable_force_sd_bus_rcv_data_in_dly();

				break;
	
			default:
				break;	
		}	
	}
	
	//----------------------------------------------------------------------------------------------------------------------------------------
		switch (write_hs_data_to_flash_state) {

			case W_HS_DATA_TO_FLASH_IDLE:
						
				if (bEnVirtualBuf2Nf && (sd_ready_for_nf_buf_cnt != 0) && ( ! bInReadLba) && 
					( ! bInWriteLbaFun) && (virtual_sd_data_buf_cnt == 0)) {	//���뱣֤�ڲ������ݵ�����£�дflash

					config_cur_buf_data_lba(sd_to_nf_buf_ptr);					//��Ӳ������LBA����ȡLBA�����CUR_LBA[4]��ER0
					if (ER03 == 0xff){
						sd_buf_2_nf_buf_cnt_dec();								//LBA �Ƿ���ֱ�Ӷ�����������
				
					}else{						  								//LBA �Ϸ�
//		yCMD_Index = 0xff;				
						cur_lba_dec();
						status_for_writing_lba_virtual_buf_lba = 0;
						write_hs_data_to_flash_state = W_HS_DATA_TO_FLASH_ING;			
					}
				}

				break; 


			case W_HS_DATA_TO_FLASH_WAIT_READY:  //�ڸ�״̬��CNT--��Ϊ�˷�ֹ����COPYBACK���޷���ʱ�������ݣ�ֻ�е��ܹ���������ʱ��CNT--
		
				if ((bRcvSDDataKickStart) && (! bInReadLba)) {				
					if ((!bCopyBackNotOver)) {						// bCopyBackNotOver == 0��flash����д������

//array_add_tail(0x68);

						sd_buf_2_nf_buf_cnt_dec();
//����sd virtual lba tab
						chk_writing_lba_and_sd_virtual_buf_lba();
#if 1//multi					 
						write_hs_data_to_flash_state = W_HS_DATA_TO_FLASH_ING;
#else
					//single write
						if (rcv_data_state == HS_RCV_DATA_IN_ING) {
							write_hs_data_to_flash_state = W_HS_DATA_TO_FLASH_END;
						} else {
							write_hs_data_to_flash_state = W_HS_DATA_TO_FLASH_ING;
						}
#endif
					}
					else {

					   	write_hs_data_to_flash_state = W_HS_DATA_TO_FLASH_END;

					}
				 
				}else if ( (! bCallWriteLBA)  || bInReadLba|| bTimeout) {		//((ActualRcvSDDataCnt == PlanRcvSDDataCnt) && д�������˳�) || in sd read || write timeout.
					write_hs_data_to_flash_state = W_HS_DATA_TO_FLASH_END;
				}else {			//bRcvSDDataKickStart == 0  && bCallWriteLBA == 1 && bInReadLba == 0					

				} 
				 
				break;
			
			case W_HS_DATA_TO_FLASH_ING:

				if ((sd_ready_for_nf_buf_cnt != 0) && ( ! bInReadLba)) {		   		//��֤������1������
					if (bRcvSDDataKickStart && (ActualRcvSDDataCnt < PlanRcvSDDataCnt)) {
						if (NfEmptyBufCnt != 0) {							//nf buf �п�buf ?	
							get_cur_lba_to_er1();						 //��CUR_LBA[4]��ȡLBA��ER1	,��һ��sd hs buf -> nf buf ��Ӧ��LBA	
							config_cur_buf_data_lba(sd_to_nf_buf_ptr);	 //����LBA,�����CUR_LBA[4]��ER0		
							#pragma asm
							INC32_ER1									 //last_lba++��LBA������������sd hs buf -> nf buf
							XRL32_ER0_ER1		  												   
							#pragma endasm
							if (EZ && (!bCopyBackNotOver)){				//EZ=1 -> last_lba++ == cur_lba	 && дδ��ǰ�˳�
						
								bCallWriteLBA = 1;						//In write lba ����
								copy_512byte_data(sd_to_nf_buf_ptr, yBuffer_Index_Start);	
								
								update_cur_lba_to_cur_map_lba_var();					
								
								yBuffer_Index_Start++;					//copy 1�����ݺ�nf buf��index����
								ActualRcvSDDataCnt++;					//�������ݰ�������
								NfEmptyBufCnt--;						//�յ�nf buf�����Լ�

								if (ActualRcvSDDataCnt == PlanRcvSDDataCnt) {	//copy sd hs buf -> nf buf �����ݰ����Ѵﵽnf ��Ҫ���յİ���	
									bRcvSDDataKickStart = 0;						//˵������ɱ���nf buf�������ݵ�����
								}
								write_hs_data_to_flash_state = W_HS_DATA_TO_FLASH_WAIT_READY;																
							}else {
								write_hs_data_to_flash_state = W_HS_DATA_TO_FLASH_END;
							}
						
						}else if (rcv_data_state != HS_RCV_DATA_IN_ING ){//NfEmptyBufCnt == 0	//�ȴ�nf bufΪ��
				#if EN_VIRTUAL_BUF		//�����������Ǳ��봦�����
							write_hs_data_to_flash_state = W_HS_DATA_TO_FLASH_END;		
				#endif	
						}					
					}else if (bCallWriteLBA){									//writing data in flash. 
						bRcvSDDataKickStart = 0;								//ActualRcvSDDataCnt ==  PlanRcvSDDataCnt
					}else {														//bRcvSDDataKickStart== 0 && bCallWriteLBA == 0,�Ѿ��˳�write lba ����
						write_hs_data_to_flash_state = W_HS_DATA_TO_FLASH_END;	
					}	 			
														
				} else if ((rcv_data_state != HS_RCV_DATA_IN_ING) || bInReadLba ){//sd_ready_for_nf_buf_cnt == 0 ,Hs buf ��û���� && ���ڽ�������״̬
				  write_hs_data_to_flash_state = W_HS_DATA_TO_FLASH_END;
				}
				break;

			case W_HS_DATA_TO_FLASH_END:
				enable_force_sd_bus_rcv_data_in_dly();

				bRcvSDDataKickStart = 0;	   					//stop ��������
				if ( (! bCallWriteLBA)){						//idle״̬�£�bCallWriteLBA ��ȻΪ0

//--------------------------------------------------------------------------------------------------------------------------------------------
#if EN_VIRTUAL_BUF
					if ((virtual_sd_data_buf_cnt == 0) &&					//LBAƥ��Virtual LBA�Ľ������Ч 
						(status_for_writing_lba_virtual_buf_lba == 0x01) ){	//LBAƥ��
					
						copy_last_virtual_sd_data_buf_cnt = 0;
					
						if ((virtual_sd_buf_map_w_nf_page_ptr < (*(unsigned char xdata *)(& SdVirtualBuf2NfUseMaxPage))) &&  
						   ((*(unsigned char xdata *)(& SdVirtualBuf2NfUseMaxSector)) >= VIRTUAL_BUF_READ_MAX_SECS_IN_PER_PAGE) ){					   	
							virtual_sd_buf_map_w_nf_page_ptr++;		//ponit to next page, ready for next time.
							virtual_sd_buf_map_r_nf_page_ptr++;		//ponit to next page, ready for next time.							
							virtual_to_nf_buf_in_per_page_sector_ptr = 0;		
							sectors_in_virtual_page_w = 1;
							hs_write_to_virtual_sd_buf_map_nf(sd_to_nf_buf_ptr, virtual_sd_buf_map_w_nf_page_ptr - 1, sectors_in_virtual_page_w);
//Ŀ����Ϊ�˰�virtual_sd_data_buf_cnt = 0������ȥ
								 
	#if 0 //debug virtual buf��ʱ�򣬿ɴ�ӡ���²�����ȷ���Ƿ����쳣
		uart_send_byte(0x77);
		uart_send_byte(SdVirtualBuf2NfUseMaxPage);				//�����nf blk ��Ӧ�����page
		uart_send_byte(SDBufBlockAddrH);						//��ǰnf blk��blk ��,��byte
		uart_send_byte(SDBufBlockAddrL);						//��ǰnf blk��blk ��,��byte
		uart_send_byte(virtual_sd_data_buf_cnt);					//virtual buf ��ŵ���Ч����sector����������virtual buf��δ�ͷŵ�nf ��sector��
		uart_send_byte(virtual_sd_buf_map_w_nf_page_ptr);		//д��page��ָ��, ָ������ֵΪSdVirtualBuf2NfUseMaxPage
	
//		uart_send_byte(0x78);			
//		uart_send_byte(virtual_sd_buf_map_r_nf_page_ptr);			//����page��ָ��,��ָ���ͷŵ�nf ��page
//		uart_send_byte(hs_to_virtual_buf_ptr);					//д��virtual lba tab ��ָ�룬���浱ǰ���ݶ�Ӧ��LBA
//		//
//		uart_send_byte(virtual_to_nf_buf_ptr);					//����virtual lba tab��ָ��, ��ȡ��ǰsector���ݶ�Ӧ��LBA
//		uart_send_byte(virtual_sd_data_buf_cnt);
//		uart_send_byte(virtual_to_nf_buf_in_per_page_sector_ptr);	//ÿ��page��sector��ָ��,��һ��page��1����Ч����(���˱��������sector)���ϣ����õ������һ��pageֻ����1��sector���ݣ���Ϊ1

	#endif

						}else{										   //sd vitual blk �������� 
							bEnForceEraseVirtualBufBlk = 1;				//Disable force erase nf blk
							erase_virtual_buf_map_blk();			 	//û��������nf�л���,����blk
	
							virtual_sd_buf_map_w_nf_page_ptr = 0;
							virtual_sd_buf_map_r_nf_page_ptr = 0;
							virtual_to_nf_buf_in_per_page_sector_ptr = 0;					
						}
								   				
					}else{													//˵��sd Virtual buf�����Ѹ��µ���һ��page�л�ƥ��LBA
					}
#endif
	 				bCopyBackNotOver = 0;

					initial_rcv_data_par();
					
					write_hs_data_to_flash_state = W_HS_DATA_TO_FLASH_IDLE;
 				}
				break;

			default:
				break;
		}
//	} 
//----------------------------------------------------------------------------------------------------------------------------------------

	save_virtual_sd_buf_data_to_nf();

	timer_tick_inc();
					  	
	if (( ! bDataStop_Flag) && (! bSDStop) && bEnReadLBACnt){
				
   		sd_kick_dma_out_data();
	}		



	#pragma asm
	MOV	DPTR, # TIMER_ER1_COPY
	MOV32_ER1_EDP0
	MOV	DPTR, # TIMER_ER0_COPY
	MOV32_ER0_EDP0
	#pragma endasm

	timer3_clr_tof();

	_pop_(R8);
	_pop_(DPCON);
	_pop_(PAGEMAP);	

	
		
}

/************************************************************************************************************************
* ��������void timer_timeout_dec(void)
* ���룺
* ���ܣ� 
* 
************************************************************************************************************************/
void timer_timeout_cnt_dec(void)
{
	if (timer_dly_timeout > 0){
		timer_dly_timeout--;
	}
}
/************************************************************************************************************************
* ��������void force_timer_enter_isr(void)
* ���룺
* ���ܣ����Ͻ���timer�ж�.   
* 
************************************************************************************************************************/
void force_timer_enter_isr(void)
{						 
	_push_(PAGEMAP);	
	sfrpage(3);
	
#if ( ! EN_CAL_TIME)
//	TOF = 1; 
	T3CON_P3 |= BIT(7);
	T3CNTL_P3 = 0;
#endif		   
	_pop_(PAGEMAP);
} 
/************************************************************************************************************************
* ��������void reset_timer_cnt(void)
* ���룺
* ���ܣ����¼���Timer�����жϵ�ʱ��, ʹtimer���ܴ��"��0x11�� -> NFC DMAǰ"�ȴ���ִ��.   
* 
************************************************************************************************************************/
void reset_timer_cnt(void)
{		 
	_push_(PAGEMAP);	
	sfrpage(3);
	
#if ( ! EN_CAL_TIME)
//	TOF = 0;
	T3CON_P3  &= ~BIT(7); 
	T3CNTL_P3 = 0;
#endif		   
	_pop_(PAGEMAP);
}

/************************************************************************************************************************
* ��������void disable_force_sd_bus_rcv_data_in_dly(void)
* ���룺
* ���ܣ�flash��Ǩ����ʱ�򣬽�� SD�����ڽ������ݵĹ����н��� delay ��״̬    
* 
************************************************************************************************************************/
void disable_force_sd_bus_rcv_data_in_dly(void)
{
	bForceDly = 0;
}


/************************************************************************************************************************
* ��������void printf_timer_n_10ms(void)
* ���룺
* ���ܣ�
* 
************************************************************************************************************************/
void printf_timer_n_10ms(void)
{
#if (EN_CAL_TIME)

	if (n_10ms != 0) {
		
//		uart_send_byte(0xbb);
	
//		uart_send_byte(copy_sd_ready_for_nf_buf_cnt);		  //��Ǩǰ��buf���ݰ���
//		uart_send_byte(sd_ready_for_nf_buf_cnt);			  //��Ǩ���buf���ݰ���
//		
//		uart_send_byte((unsigned char)(n_10ms>>8));
//		uart_send_byte((unsigned char)(n_10ms>>0));	
//			 
//		uart_send_byte(0xcc);	

		if (copy_sd_ready_for_nf_buf_cnt > before_cpy_max_sd_ready_for_nf_buf_cnt){
			before_cpy_max_sd_ready_for_nf_buf_cnt = copy_sd_ready_for_nf_buf_cnt;
		}
		if (sd_ready_for_nf_buf_cnt > max_sd_ready_for_nf_buf_cnt){
			 max_sd_ready_for_nf_buf_cnt = sd_ready_for_nf_buf_cnt;
		}
		if (n_10ms > max_n_10ms){
			max_n_10ms = n_10ms;
		}
	}


#endif	
}
/************************************************************************************************************************
* ��������void printf_sd_buf_cnt(void)
* ���룺
* ���ܣ�
* 
************************************************************************************************************************/
void printf_sd_buf_cnt(void)
{
#if (EN_CAL_TIME)

//	uart_send_byte(0xdd);
//	uart_send_byte(sd_ready_for_nf_buf_cnt);

		
#endif		 
}
/************************************************************************************************************************
* ��������void timer_tick_inc(void)
* ���룺
* ���ܣ�timer�Ļ�׼���ʱ��,��flash retry �ﵽtimeoutʱ��󣬽�bFlashRetryTimeOut = 1��   
* 
************************************************************************************************************************/
void timer_tick_inc(void)
{
	timer_tick++;
	if (timer_tick > (DELAY_10MS_TIMEOUT_CNT / 10)){		   //1ms
		timer_tick = 0;
		n_1ms++;

		if( n_1ms > (RETRY_TIMEOUT_N_MS) && (! bFlashRetryTimeOut)){
			bFlashRetryTimeOut = 1;

#if 1								//��ֹ���
			n_1ms = 0xffff;
#endif
		}

#if (EN_CAL_TIME)
		if (n_1ms >= 10){
			n_10ms++;
		}
#endif	
	
	}

}

void printf_n_1ms_cnt(void)
{
//#if BAUDRATE
//	#pragma asm
//	MOV  	A, R0	
//	PUSH	ACC	  
//	MOV  	A, R1	
//	PUSH	ACC	  
//	#pragma endasm
//	uart_send_byte((n_1ms >> 8) & 0xff);
//	uart_send_byte(n_1ms & 0xff);
//   	#pragma asm
//	POP		ACC
//	MOV		R1, A
//	POP		ACC
//	MOV		R0, A
//	#pragma endasm
//#endif

}
/************************************************************************************************************************
* ��������void timer_tick_inc(void)
* ���룺
* ���ܣ���timer�Ļ�׼���ʱ�������   
* 
************************************************************************************************************************/
void timer_tick_clr(void)
{
	#pragma asm
	MOV  	A, R0
	PUSH	ACC	  
	#pragma endasm
										 
	_push_(IE1);

	disable_timer_isr();
	timer_tick = 0;
	n_1ms = 0;
	bFlashRetryTimeOut = 0;

#if (EN_CAL_TIME)
	n_10ms = 0;
	copy_sd_ready_for_nf_buf_cnt = sd_ready_for_nf_buf_cnt;
#endif

	_pop_(IE1);	 

	#pragma asm
	POP		ACC
	MOV		R0, A
	#pragma endasm
}
/************************************************************************************************************************
* ��������void delay_n_sd_clk(unsigned char n_sd_clk)
* ���룺
* ���ܣ��ȴ� 2 * n sd clk
* ע�⣺������� 1 <= n_sd_clk <= 127
************************************************************************************************************************/
void delay_2n_sd_clk(unsigned char n_sd_clk)
{
	SDSPICNT_P1 = n_sd_clk;		  
	while( !(SDSPICNT_P1 & 0x80)){}
}
/************************************************************************************************************************
* ��������void erase_virtual_buf_map_blk(void)
* ���룺
* ���ܣ���ŵ�page����VIRTUAL_BUF_MAP_ERASE_MIN_LG_PAGE_CNT�����������ڴ���ڵ�blk
* �����
************************************************************************************************************************/
void erase_virtual_buf_map_blk(void)
{
	_push_(DPCON);
	
	DPCON = 0x10;						//DPTR0 ����

	erase_sdbuf_block();
				
	_pop_(DPCON);
}
/************************************************************************************************************************
* ��������void config_cur_virtual_buf_data_lba(unsigned char virtual_buf_ptr)
* ���룺
* ���ܣ���sd_virtual_data_buf_lba[virtual_buf_ptr][4]��ȡ��LBA����ŵ�CUR_LBA[4]�У���Ϊflash����ڲ���
* �����CUR_LBA[4],ER0.  ER0 = CUR_LBA[4] = LBA.
************************************************************************************************************************/
void config_cur_virtual_buf_data_lba(unsigned char virtual_buf_ptr_cp /*xdata*/)
{
	unsigned char idata virtual_buf_ptr = virtual_buf_ptr_cp;
 	_push_(DPCON);
 	
	DPCON = 0x18;					//���, ����, dptr0

	DPTR0 = sd_virtual_data_buf_lba;
	B = virtual_buf_ptr; 			//���֧��128 �� ����buf	
	ACC = 4;
	#pragma asm
	MUL	AB							//BA = A * B
	MOV R8, B
	MOV	B, A						//DPTR0 = DPTR0 +  4 * virtual_buf_ptr
	
	ADDDP0							//DPTR0 + (R8 B)	
	
	MOV32_ER0_EDP0    //��ȡ��ַ
	#pragma endasm
	
	DPTR0 = sd_virtual_data_buf_cnt + virtual_buf_ptr;
	#pragma asm
	MOVX 	A,@DPTR	
	MOV 	R8,A	
	#pragma endasm
	sectors_in_virtual_page_total = R8;
//	MOV		R0,#LOW(sectors_in_virtual_page_total)	
//	MOV		@R0,A		//��ȡ�ܳ���
	#pragma asm
	CLR32_ER1
	#pragma endasm
	ER10 = virtual_to_nf_buf_in_per_page_sector_ptr;
//	MOV 	R0,#LOW(virtual_to_nf_buf_in_per_page_sector_ptr)
//	MOV 	ER10,@R0//��������lba
	#pragma asm
	ADD32_ER0_ER1_ER0
	
	MOV	 DPTR, # CUR_LBA   //�����ⲿ���������
	MOV32_EDP0_ER0					//��˴��LBA
	#pragma endasm
			
	_pop_(DPCON);
}


/************************************************************************************************************************
* ��������void get_consistent_virtual_buf_data_lba(unsigned char virtual_buf_ptr)
��ȡ��ǰһ������һ����LBA,�����浽cur lba 
************************************************************************************************************************/
void get_consistent_virtual_buf_data_lba(unsigned char virtual_buf_ptr)
{
#if EN_MUL_RELEASE_VBUF
 	_push_(DPCON);
 	
	DPCON = 0x18;					//���,����, dptr0
	
	DPTR0 = sd_virtual_data_buf_lba;
	if (virtual_buf_ptr) {
		B = virtual_buf_ptr - 1; 			//���֧��128 �� ����buf
		ACC = 4;

		#pragma asm
		MUL	AB							//BA = A * B
		MOV R8, B
		MOV	B, A						//DPTR0 = DPTR0 +  4 * virtual_buf_ptr

		ADDDP0							//DPTR0 + (R8 B)	
		MOV32_ER0_EDP0
		MOV32_ER1_EDP0
		DEC32_ER1
		XRL32_ER1_ER0
		#pragma endasm
	} else {
		ER03 = 0xff;
	}	
	_pop_(DPCON);
#else 
	virtual_buf_ptr = 0;
#endif	
}


/************************************************************************************************************************
* ������void config_cur_buf_data_lba_to_virtual_buf(unsigned char hs_buf_ptr, unsigned char virtual_buf_ptr)
* ���룺
* ���ܣ���sd_hs_cache_data_buf_lba[buf_ptr][4]��ȡ��LBA����ŵ�CUR_LBA[4]�У�����ŵ������ڴ��Ӧ��LBA buf
* �����sd_hs_cache_data_buf_lba[buf_ptr][4]-> CUR_VIRTUAL_LBA[4]
* Tmp: ER0, R8, B
* ע�⣺���֧��256 �� ����buf
************************************************************************************************************************/
void config_cur_buf_data_lba_to_virtual_buf(unsigned char  hs_buf_ptr, unsigned char  virtual_buf_ptr)
{
	unsigned char idata virtual_buf_ptr_cpy;
#if (!EN_VIRTUAL_BUF) 
	sectors_in_virtual_page_w = 0;
#endif
 	_push_(DPCON);
   		
   	virtual_buf_ptr_cpy = virtual_buf_ptr;		//copy,	���������ʹ��XDATA ��Ϊ�ֲ�����	
	
	DPCON = 0x08;								//���, �ر�����, dptr0	
	//���»���buf��Ӧ��LBA TABLE, sd_hs_cache_data_buf_lba[buf_ptr][4] = ER3	
	DPTR0 =  sd_hs_cache_data_buf_lba;	
	R8 = 0;
	B = hs_buf_ptr << 2;

	#pragma asm
	ADDDP0										//DPTR0 + (R8 B)	
	MOV32_ER0_EDP0
	#pragma endasm

	DPTR0 = sd_virtual_data_buf_lba;
	B = virtual_buf_ptr_cpy; 					//virtual_buf_ptr//���֧��128 �� ����buf
	ACC = 4;
	#pragma asm
	MUL	AB							 			//BA = A * B
	MOV R8, B
	MOV	B, A						 			//DPTR0 = DPTR0 +  4 * virtual_buf_ptr
	ADDDP0										//DPTR0 + (R8 B)	
	MOV32_EDP0_ER0
	#pragma endasm
	
	DPTR0 = sd_virtual_data_buf_cnt + virtual_buf_ptr_cpy;
	R8 = sectors_in_virtual_page_w;
	#pragma asm
	MOV 	A,R8
	MOVX 	@DPTR,A	
	#pragma endasm	
			
	_pop_(DPCON);
}

/************************************************************************************************************************
* ������: void hs_write_to_virtual_sd_buf_map_nf(unsigned char hs_buf_ptr, unsigned char w_nf_page_index, savecnt)
* ���룺
* ���ܣ�
* �����
* Tmp:
* ע�⣺
************************************************************************************************************************/
void hs_write_to_virtual_sd_buf_map_nf(unsigned char hs_buf_ptr, unsigned char  w_nf_page_index, unsigned char savecnt) //reentrant
{
	unsigned char idata hs_buf_ptr_cpy, w_nf_page_index_cpy;
	unsigned char idata i, savecntcpy;

	_push_(DPCON);
	_push_(DP1H);
	_push_(DP1L); 
	savecntcpy = savecnt;
	hs_buf_ptr_cpy =  hs_buf_ptr;
	w_nf_page_index_cpy =  w_nf_page_index;

//cpy sd buf ��nf buf��SAVE_IN_SAVE_VIRTUAL_BUF_DATA_2_NF_BUF_OFFSET ~ VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE ����
	
	for (i = SAVE_IN_SAVE_VIRTUAL_BUF_DATA_2_NF_BUF_OFFSET; 
		 i < SAVE_IN_SAVE_VIRTUAL_BUF_DATA_2_NF_BUF_OFFSET + savecntcpy;//VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE; 
		 i++) {
			 
		//src
		DPTR1 = sd_hs_cache_data_buf;				//hs_cache_data_buf
		R8 = hs_buf_ptr_cpy;
		#pragma asm
		CLR32_ER0
		MOV		ER00, R8
		MOV		ER03, #0x02 		  						
		MUL16_ER0									//ER0 = hs_buf_ptr_cpy * 0x0200
		MOV		R8, ER01									
		MOV		B,  ER00									
		ADDDP1
		#pragma endasm
		
		hs_buf_ptr_cpy++;							//Point to next buf
		if (hs_buf_ptr_cpy == SD_HS_CACHE_BUF_CNT) {
			hs_buf_ptr_cpy = 0;	
		}
	
		//target
		ER02 =  i;								   //[0, VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE]
		Sel_Buffer_Addr();
		DP0H = ER01;
		DP0L = ER00;
		//copy	
		_push_(DPCON);
		DPCON = 0x31;							//Enable DPTR0/DPTR1 Auto INC ,select toggle enable,select DPTR1	
		Buf1_2_Buf0();							//@DPTR1 -> @DPTR0
		_pop_(DPCON);

	}

//virtual buf lba tab -> nf buf(SAVE_VIRTUAL_BUF_MAP_LBA_TAB_2_NF_BUF)
	//src
	DPTR1 = sd_virtual_data_buf_lba;				//sd virtual buf lba tab
	
	//target
	
	ER02 =  SAVE_VIRTUAL_BUF_MAP_LBA_TAB_2_NF_BUF; 	//nf buf (SAVE_VIRTUAL_BUF_MAP_LBA_TAB_2_NF_BUF)				

	Sel_Buffer_Addr();
	DP0H = ER01;
	DP0L = ER00;

	//len
	#pragma asm
	CLR32_ER0
//	MOV		ER01, # HIGH(SD_VIRTUAL_BUF_CNT * 4)
//	MOV		ER00, # LOW (SD_VIRTUAL_BUF_CNT * 4)
	#pragma endasm

	ER01 = (SD_VIRTUAL_BUF_CNT * 5)>>8;
	ER00 = (SD_VIRTUAL_BUF_CNT * 5);

	//copy
	dptr1_cpy_to_dptr0();

	cpy_virtual_buf_var_2_nf_buf();					//copy ����buf��Ҫ�������ز�����nf buf��
				
	DPCON = 0x10;							//DPTR0 ����
	SDBufPageAddr = w_nf_page_index_cpy;
	
//prints("ed");	
//printHexSync(virtual_sd_buf_map_w_nf_page_ptr);			
//printHexSync(sectors_in_virtual_page_w);	
	ProgramCMD1 = 0x10;  //�̶�0x10
	program_sdbuf_block();

	_pop_(DP1L);
	_pop_(DP1H);	
	_pop_(DPCON);
	

}


/************************************************************************************************************************
* ��������unsigned char get_consistant_lbas(unsigned char search_start, unsigned char maxLen)
* ���룺
* ���ܣ������������i��lba
* 
************************************************************************************************************************/
unsigned char get_consistant_lbas(unsigned char search_start_cp, unsigned char maxLen_cp)
{
	u8 idata i, search_start, maxLen;//ʹ��idata,�������Ļ�������ֱ��ʹ��xdata���������dptr��
	search_start = search_start_cp;
	maxLen = maxLen_cp;
	
	
	_push_(DPCON);
	DPCON = 0x18;								//���, ����, dptr0		
	DPTR0 =  sd_hs_cache_data_buf_lba;		
	R8 = 0;
	B = search_start << 2;			//��ȡ��һ��

#pragma asm
	ADDDP0										//DPTR0 + (R8 B)	
#pragma endasm
#if HW_W_LBA_TAB_SMALL_ENDIAN
	DPCON = 0x10;								//С��, ����, dptr0
#endif
#pragma asm
	MOV32_ER0_EDP0		//lba���
#pragma endasm	
	search_start++;

	
	for (i = 1; i < maxLen; i++, search_start++)
	{			
		if (search_start == SD_HS_CACHE_BUF_CNT) {
			search_start = 0;	
			DPTR0 =  sd_hs_cache_data_buf_lba;
//prints("loop");			
//			R8 = 0;		//Ŀǰ��ʱ������,ֱ�Ӹ�ֵ
//			B = search_start << 2;			//��ȡ��һ��
//			#pragma asm
//				ADDDP0										//��������
//			#pragma endasm
		}
		//ER0������һ��
		#pragma asm
		INC32_ER0 //last lba++
		MOV32_ER1_ER0
		XRL32_ER1_EDP0		//lba���
		#pragma endasm	
		if (!EZ ) 
		{
			break;
		}
	}
	_pop_(DPCON);	
	return i;
}

/************************************************************************************************************************
* ��������void save_hs_buf_data_to_virtual_sd_buf(void)
* ���룺
* ���ܣ���֤�����ͷ�һ��hs buf��SD����ʹ��
* 
************************************************************************************************************************/
void save_hs_buf_data_to_virtual_sd_buf(void)
{	
#if EN_VIRTUAL_BUF

	unsigned char idata i, sd_to_nf_buf_ptr_cpy, w_sec_cnt;

	w_sec_cnt = 0;	//д��sd virtual buf �����ݰ���
			
	_push_(IE);
	_push_(IE1);

	//sd hs buf -> sd virtual buf�����У����ܱ�timer isr/dma in isr��ϣ�����������벻���ĺ��
	disable_dma_in_isr();	//SDIIE   = IE^2;
	disable_timer_isr();		//IE1 &= ~ BIT(3);
	

	if(bTimeout){					//timeout������£����data�������ڴ�δ����save data to sd virtual buf 
			
		while((sd_ready_for_nf_buf_cnt != 0) &&					   //����1page��ʹ��n��sector����� 	
#if DYNAMIC_VIRTUAL_SECTOR
				virtual_lbabuf_emptycnt &&	
#else 
			  (virtual_sd_data_buf_cnt <= (SD_VIRTUAL_BUF_CNT - VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE)) &&
#endif
			  (virtual_sd_buf_map_w_nf_page_ptr < (*(unsigned char xdata *)(& SdVirtualBuf2NfUseMaxPage))) && 
			  ((*(unsigned char xdata *)(& SdVirtualBuf2NfUseMaxSector)) >= VIRTUAL_BUF_READ_MAX_SECS_IN_PER_PAGE) ){						  
					
		  sd_to_nf_buf_ptr_cpy = sd_to_nf_buf_ptr;				 //copy	
#if DYNAMIC_VIRTUAL_SECTOR	
			//�������ƣ���ȡ��Сֵ
			sectors_in_virtual_page_w	=  sd_ready_for_nf_buf_cnt > VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE?	VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE:sd_ready_for_nf_buf_cnt;
			sectors_in_virtual_page_w = get_consistant_lbas(sd_to_nf_buf_ptr, sectors_in_virtual_page_w);//��ȡ������lba����
//prints("\nYY");
//printHexSync(virtual_sd_buf_map_w_nf_page_ptr);			
//printHexSync(sectors_in_virtual_page_w);
//printHexSync(sd_to_nf_buf_ptr);	
//printHexSync(hs_to_virtual_buf_ptr);	
//printHexSync(virtual_sd_data_buf_cnt);
//printHexSync(sd_ready_for_nf_buf_cnt);								
			config_cur_buf_data_lba_to_virtual_buf(sd_to_nf_buf_ptr, hs_to_virtual_buf_ptr);	//������lba��ͬsectors_in_virtual_page_w
			for (i = 0; i < sectors_in_virtual_page_w; i++) {
				sd_buf_2_nf_buf_cnt_dec();
				w_sec_cnt++;				
				virtual_sd_data_buf_cnt++;			//д�����ݵ�virtual buf��cnt++
			}
			hs_to_virtual_buf_ptr++;				//virtual lbaָ��ֻ��һ
			virtual_lbabuf_emptycnt--;
			if (hs_to_virtual_buf_ptr == SD_VIRTUAL_BUF_CNT) {
				hs_to_virtual_buf_ptr = 0;
//prints("led\n");//loop end��ʱ������л���û�����꣬��Ӧ������timeout
			}	
//prints("JJ");
//printHexSync(sectors_in_virtual_page_w);
//printHexSync(sd_to_nf_buf_ptr);	
//printHexSync(hs_to_virtual_buf_ptr);	
//printHexSync(virtual_sd_data_buf_cnt);
//printHexSync(sd_ready_for_nf_buf_cnt);	
//prints("\n");			
#else 			
			for(i = 0; i < VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE; i++) {
				config_cur_buf_data_lba_to_virtual_buf(sd_to_nf_buf_ptr, hs_to_virtual_buf_ptr);		
				sd_buf_2_nf_buf_cnt_dec();		
				hs_to_virtual_buf_ptr++;						
				if (hs_to_virtual_buf_ptr == SD_VIRTUAL_BUF_CNT){
					hs_to_virtual_buf_ptr = 0;
				}	
				virtual_sd_data_buf_cnt++;			//д�����ݵ�virtual buf��cnt++

				w_sec_cnt++;							//��¼����д�뵽����buf��sector��				
			}  //end for(i=0;...)
#endif
			virtual_sd_buf_map_w_nf_page_ptr++;		//ponit to next page, ready for next time.
					
			//�������ݺ���ز�����nf virtual buf ��,ע��virtual_sd_buf_map_w_nf_page_ptr -1����д������
			hs_write_to_virtual_sd_buf_map_nf(sd_to_nf_buf_ptr_cpy, virtual_sd_buf_map_w_nf_page_ptr - 1, sectors_in_virtual_page_w);
		
	
		} //end while(...)
#if 0
		uart_send_byte(0x44);
		uart_send_byte(SdVirtualBuf2NfUseMaxPage);
		uart_send_byte(SDBufBlockAddrH);
		uart_send_byte(SDBufBlockAddrL);
		uart_send_byte(virtual_sd_data_buf_cnt);
		uart_send_byte(virtual_sd_buf_map_w_nf_page_ptr);
		
		uart_send_byte(0x45);		
		uart_send_byte(virtual_sd_buf_map_r_nf_page_ptr);
		uart_send_byte(hs_to_virtual_buf_ptr);

		uart_send_byte(virtual_to_nf_buf_ptr);
		uart_send_byte(virtual_sd_data_buf_cnt);
		uart_send_byte(virtual_to_nf_buf_in_per_page_sector_ptr);

		uart_send_byte(0x66);
		

#endif

	}//end if (bTimeout)

#if EN_CAL_TIME
		if (virtual_sd_data_buf_cnt > cal_max_virtual_buf_cnt) {
			 	cal_max_virtual_buf_cnt =  virtual_sd_data_buf_cnt;
		}
#endif


	_pop_(IE1);
	_pop_(IE);


#endif
	
}
/************************************************************************************************************************
* ��������void updata_cur_virtual_sd_buf_data_to_nf(unsigned char r_virtual_buf_ptr, unsigned char r_virtual_buf_sec_in_page_ptr, unsigned char w_nf_buf)
* ���룺
r_virtual_buf_ptr: ����ǰpage indexָ���page���ݣ���nf buf 0 ~ buf n  
* ���ܣ���ȡ�����ڴ�����ݣ���copy��ָ����buf. (nf buf)
* 
************************************************************************************************************************/
void updata_cur_virtual_sd_buf_data_to_nf(unsigned char r_virtual_buf_ptr, unsigned char r_virtual_buf_sec_in_page_ptr, unsigned char w_nf_buf)
{	
	unsigned char idata r_virtual_buf_sec_in_page_ptr_cpy, w_nf_buf_cpy;

  	_push_(DPCON);
	
	//��ȡ���ݵ�ʱ�򣬼���ƫ��SAVE_IN_SAVE_VIRTUAL_BUF_DATA_2_NF_BUF_OFFSET
	r_virtual_buf_sec_in_page_ptr_cpy = SAVE_IN_SAVE_VIRTUAL_BUF_DATA_2_NF_BUF_OFFSET + r_virtual_buf_sec_in_page_ptr;
	w_nf_buf_cpy = w_nf_buf;

	DPCON = 0;
	//update data to nf buf.
	
	SDBufPageAddr = r_virtual_buf_ptr;
	DPCON = 0x10;						//DPTR0 ����
	read_sdbuf_block();	
	
	//src 
	ER02 = r_virtual_buf_sec_in_page_ptr_cpy;							 //copy data from buf_0 to w_nf_buf
	Sel_Buffer_Addr();
	DP1H = ER01;
	DP1L = ER00;

	//target
	ER02 =  w_nf_buf_cpy;
	Sel_Buffer_Addr();

	DP0H = ER01;
	DP0L = ER00;
	
	//copy	
	DPCON = 0x31;						//Enable DPTR0/DPTR1 Auto INC ,select toggle enable,select DPTR1	
	Buf1_2_Buf0();						//@DPTR1 -> @DPTR0

//copy var
	ER02 =  SAVE_CTL_VIRTUAL_BUF_VAR_2_NF_BUF; 		//nf buf (SAVE_CTL_VIRTUAL_BUF_VAR_2_NF_BUF)				
	Sel_Buffer_Addr();
	DP0H = ER01;
	DP0L = ER00;

	DPCON = 0x18;									//DPTR0 ����,���
	#pragma asm
	INC4DP0
	MOV32_ER1_EDP0
	#pragma endasm
		
	copy_last_virtual_sd_data_buf_cnt = ER12; //virtual_to_nf_buf_in_per_page_sector_ptr

	_pop_(DPCON);
}

extern void SDBuf_Block_Init_Zone(void);
extern void Read_Sectors(void);
extern volatile unsigned char idata  sdbuf_planCopyPackets;
extern u8 code FirstValidZone; 
void updata_cur_virtual_sd_buf_data_to_nf2(unsigned char r_virtual_buf_ptr, unsigned char r_virtual_buf_sec_in_page_ptr, unsigned char w_nf_buf)
{	
#if EN_MUL_RELEASE_VBUF
	unsigned char idata r_virtual_buf_sec_in_page_ptr_cpy, w_nf_buf_cpy;
	unsigned char idata ZoneLBA_backup;

		
  _push_(DPCON);
	
	ZoneLBA_backup = ZoneLBA;
	//��ȡ���ݵ�ʱ�򣬼���ƫ��SAVE_IN_SAVE_VIRTUAL_BUF_DATA_2_NF_BUF_OFFSET
	r_virtual_buf_sec_in_page_ptr_cpy = SAVE_IN_SAVE_VIRTUAL_BUF_DATA_2_NF_BUF_OFFSET + r_virtual_buf_sec_in_page_ptr;
	w_nf_buf_cpy = w_nf_buf;

	DPCON = 0;
	//update data to nf buf.
//read sd buf sector				
	SDBufPageAddr = r_virtual_buf_ptr;
//	DPCON = 0x10;						//DPTR0 ����	
	
	_push_(PAGEMAP);	
	
//	_push_(DPCON);
	
	PAGEMAP = 0x02;
// 	DPCON = 0x10;			//DPTR0����

if (ZoneLBA != (*(u8 xdata *)(&FirstValidZone)))   //wrs���ѻ�ȡ��   //zone1�����ܴ�����  ��Ҫ�Ż�
{
	SDBuf_Block_Init_Zone();  //����ֱ�ӵ��ã������ı�zonelba��ֵ  
} 

	SectorNum = VIRTUAL_BUF_READ_MAX_SECS_IN_PER_PAGE - virtual_to_nf_buf_in_per_page_sector_ptr; //����������Ϣ/  //����,��Ϊsdbuf_planCopyPackets = total - ptr,��Ϊtotal���ܲ���save_max_sex_in_page���²���
	//�����������,�ⲿ�����ܹ�Ҫ��֤��ȫ����total�ſ���
	

	if (SectorNum&0x01)
		SectorNum++;																				//1k���ٱ�����ô���sector��ȥ��

	
	SDBufPageAddr = SDBufPageAddr;	  //���������Զ��Ż�
	R3_BlockAddrH = SDBufBlockAddrH;
	R2_BlockAddrL = SDBufBlockAddrL;
	
	#pragma asm
		CLR32_ER1
	#pragma endasm
	ER10 = SDBufPageAddr;	
	if (b2PlaneTrue) {
		#pragma asm
			MOV 	R8,#1
			ROTL32_ER1_ER8
		#pragma endasm
	}
	R4_PageAddrH = ER11;
	R0_PageAddrL = ER10;  //page����Ҫ��������һ��2p
	
	R1_Sector = r_virtual_buf_sec_in_page_ptr_cpy>>1;
	bBlockMode = 0;//SLC
	DataCoDecKeyIndex = R0_PageAddrL;
	R8Tmp = w_nf_buf;		//read data to nf

//prints("rdSdBuf\n");
	
	Read_Sectors();

//	_pop_(DPCON);
	_pop_(PAGEMAP);	
	
//read end 	
	
//copy var		//���������Ϣƫ��λ��   
	ER02 =  w_nf_buf + SAVE_CTL_VIRTUAL_BUF_VAR_2_NF_BUF - r_virtual_buf_sec_in_page_ptr_cpy; 		//nf buf (SAVE_CTL_VIRTUAL_BUF_VAR_2_NF_BUF)				
	Sel_Buffer_Addr();
	DP0H = ER01;
	DP0L = ER00;

	DPCON = 0x18;									//DPTR0 ����,���
	#pragma asm
	INC4DP0
	MOV32_ER1_EDP0
	#pragma endasm
		
	copy_last_virtual_sd_data_buf_cnt = ER12;   //,nf2����ȡ������Ϣ�����Ҫ��ֵ
	
if (ZoneLBA != ZoneLBA_backup) {	 //��ԭ����ȷֵ
	ZoneLBA = ZoneLBA_backup;
	Get_CurPlaneCfg(); 
}	

	_pop_(DPCON);	
#else 
	r_virtual_buf_ptr = 0;
	r_virtual_buf_sec_in_page_ptr = 0;
	w_nf_buf = 0;
#endif
}

/************************************************************************************************************************
* ��������void save_virtual_sd_buf_data_to_nf(void)
* ���룺
* ���ܣ���֤�����ͷ�һ��hs buf��SD����ʹ��
* 
************************************************************************************************************************/
extern volatile unsigned char idata  sdbuf_planCopyPackets;
extern bit bVirtuallba_continue_in_page;
void save_virtual_sd_buf_data_to_nf(void)
{
	switch (write_virtual_sd_buf_data_to_nf_state)
	{
		case W_VIRTUAL_SD_BUF_DATA_TO_NF_IDLE:
			if (bEnVirtualBuf2Nf && ( ! bInReadLba) && ( ! bInWriteLbaFun) && (virtual_sd_data_buf_cnt != 0)){			//��stopҲ������������bug
				#if (EN_CAL_TIME)			
				if (virtual_buf_w_to_nf_thread_tick < 1){					//DELAY_10MS_TIMEOUT_CNT
					virtual_buf_w_to_nf_thread_tick++;
				}else{					
					use_debug_lba_cnt = 0;										//debug��ֻҪд���֣����debug cnt			
				}
		  		#endif

				config_cur_virtual_buf_data_lba(virtual_to_nf_buf_ptr);		//updata virtual buf lba to LBA.
				if (ER03 == 0xff){										   	//LBA �Ƿ���ֱ�Ӷ�����������
					virtual_buf_2_nf_buf_cnt_dec();
#if EN_CAL_TIME
					virtual_buf_w_to_nf_thread_tick = 0;					//���¼���
#endif
				}else{
					bCallWriteLBA = 1;													//In write lba ����																		 //LBA �Ϸ�
					updata_cur_virtual_sd_buf_data_to_nf(virtual_sd_buf_map_r_nf_page_ptr, virtual_to_nf_buf_in_per_page_sector_ptr, yBuffer_Index_Start);
					update_cur_lba_to_cur_map_lba_var();
					
					bVirtuallba_continue_in_page = 0;
					
	
		//			yBuffer_Index_Start++;	
					ActualRcvSDDataCnt++;					//�������ݰ���
					NfEmptyBufCnt--;
		//			if (ActualRcvSDDataCnt == PlanRcvSDDataCnt) {
		//				bRcvSDDataKickStart = 0;
		//			}
					bRcvSDDataKickStart = 0;				
					write_virtual_sd_buf_data_to_nf_state =  W_VIRTUAL_SD_BUF_DATA_TO_NF_ING;

				}
			}
			break;

		case W_VIRTUAL_SD_BUF_DATA_TO_NF_ING:
															
			if ((bRcvSDDataKickStart) && (! bInReadLba)) {				
				if (( ! bCopyBackNotOver)) {						// bCopyBackNotOver == 0��flash����д������																		
					virtual_buf_2_nf_buf_cnt_dec();						
				}
				write_virtual_sd_buf_data_to_nf_state = W_VIRTUAL_SD_BUF_DATA_TO_NF_END; 
			}else if ( (! bCallWriteLBA) || bInReadLba) {	
//			}else if ( (! bCallWriteLBA) || bInReadLba || bTimeout) {	
				write_virtual_sd_buf_data_to_nf_state = W_VIRTUAL_SD_BUF_DATA_TO_NF_END;
			}else {			//bRcvSDDataKickStart == 0  && bCallWriteLBA == 1 && bInReadLba == 0 && bTimeout == 0					
			
			} 
			break;

		case W_VIRTUAL_SD_BUF_DATA_TO_NF_END:
			bRcvSDDataKickStart = 0;	   					
			if ( (! bCallWriteLBA)){								//idle״̬�£�bCallWriteLBA ��ȻΪ0 
				
				bCopyBackNotOver = 0;

				if (virtual_sd_data_buf_cnt == 0){
					
					//�������sd virtual buf blk����Сpage��ֵ
					if ((*(unsigned char xdata *)(& SdVirtualBuf2NfUseMaxPage)) > 100){	   //ͨ������page����
						B = (*(unsigned char xdata *)(& SdVirtualBuf2NfUseMaxPage)) / 2;
					}else{
						B = (*(unsigned char xdata *)(& SdVirtualBuf2NfUseMaxPage)) / 2;
					}
//					B = VIRTUAL_BUF_MAP_ERASE_MIN_LG_PAGE_CNT;							  //���ù̶���ֵ
//					B = 10;

//#if 1		   //����ǿ�Ʋ�����,����PCдͬ���ĵ�ַд���µ����ݣ������ϵ�󣬻�����Ϊsd virtual buf�е�����Ϊ����
//					bEnForceEraseVirtualBufBlk = 0;
//#endif
					if (( ! bEnForceEraseVirtualBufBlk ) || (virtual_sd_buf_map_w_nf_page_ptr > B)) {	//bEnForceEraseVirtualBufBlk=0,�ϵ���һ�β���ǿ��
						bEnForceEraseVirtualBufBlk = 1;				//Disable force erase nf blk
						erase_virtual_buf_map_blk();			 	//û��������nf�л���,����blk

#if EN_CAL_TIME
						cal_erase_virtual_sd_buf_map_blk_cnt++;		//ͳ����Ϣ
						if (virtual_sd_buf_map_w_nf_page_ptr > cal_map_blk_max_page_number) {
							cal_map_blk_max_page_number =  virtual_sd_buf_map_w_nf_page_ptr;
						}
#endif
						virtual_sd_buf_map_w_nf_page_ptr = 0;
						virtual_sd_buf_map_r_nf_page_ptr = 0;
						virtual_to_nf_buf_in_per_page_sector_ptr = 0;
//						sectors_in_virtual_page_total = 0;
						copy_last_virtual_sd_data_buf_cnt = 0;		 //����blk�����³�ʼ��Ϊ0
					}
				}
									
				initial_rcv_data_par();
					
				write_virtual_sd_buf_data_to_nf_state = W_VIRTUAL_SD_BUF_DATA_TO_NF_IDLE;
#if EN_CAL_TIME
				virtual_buf_w_to_nf_thread_tick = 0;						//���¼���
#endif
			}
			break;
	}
		
}

/************************************************************************************************************************
* ��������void cpy_virtual_buf_var_2_nf_buf(void)
* ���룺 nf buf index (SAVE_CTL_VIRTUAL_BUF_VAR_2_NF_BUF)
* ���ܣ������������buf��Ӧ�ı���������buf�У����ڵ���ָ���Ϣ
* 
//byte
// 1  0x5a											//flag	
// 1  virtual_sd_buf_map_w_nf_page_ptr = 0;		   	//Cur write page for saving sd buf data.
// 1  virtual_sd_buf_map_r_nf_page_ptr = 0;		   	//Cur read page for saving virtual buf data. 
// 1  hs_to_virtual_buf_ptr = 0;					//lba tab ptr for wrting	

// 1  virtual_to_nf_buf_ptr = 0;					//lba tab ptr for reading.
// 1  virtual_sd_data_buf_cnt = 0;    			   	//virtual buf sectors for wating for saving. 
// 1  virtual_to_nf_buf_in_per_page_sector_ptr = 0; //offset sector in page read. 
// 1  chksum_1.									   	//chksum

// 2  crc16(sd_virtual_data_buf_lba[][4])			//crc16
// 2  0x00, 0x00

// 4*n virutal_buf_blk_map_lg_nf_blk[n]

// 1   0x00
// 1   virutal_buf_blk_map_lg_nf_blk_r_ptr
// 1   virutal_buf_blk_map_lg_nf_blk_w_ptr
// 1   chksum_2.									//chksum
************************************************************************************************************************/
void cpy_virtual_buf_var_2_nf_buf(void)
{	
	_push_(DPCON);

	DPCON = 0x18;									//DPTR0 ����,���

//cal sd_virtual_data_buf_lba[] crc16
	
	#pragma asm									   //len
	CLR32_ER0
//	MOV		ER01, # HIGH(SD_VIRTUAL_BUF_CNT * 4)
//	MOV		ER00, # LOW (SD_VIRTUAL_BUF_CNT * 4)
	#pragma endasm				

	ER01 = (SD_VIRTUAL_BUF_CNT * 5)>>8;
	ER00 = (SD_VIRTUAL_BUF_CNT * 5);

	//�������������֧��crc16��
	DPTR0 = (u16)(&sd_virtual_data_buf_lba);
	cal_cac16();	// {R8,B} = crc16
//-----------------------------------------------------------------------------------------------------------
//
	//target
	ER02 =  SAVE_CTL_VIRTUAL_BUF_VAR_2_NF_BUF; 		//nf buf (SAVE_CTL_VIRTUAL_BUF_VAR_2_NF_BUF)				
	Sel_Buffer_Addr();								//���ı�R8��B��ֵ
	DP0H = ER01;
	DP0L = ER00;

	ER03 = 0x5a;									   //flag.

	ER02 = virtual_sd_buf_map_w_nf_page_ptr;	  
	ER01 = virtual_sd_buf_map_r_nf_page_ptr;
	ER00 = hs_to_virtual_buf_ptr;
	
	ER13 = virtual_to_nf_buf_ptr;
	ER12 = virtual_sd_data_buf_cnt;
	ER11 = virtual_to_nf_buf_in_per_page_sector_ptr;
									
	ER10 = ER03 + ER02 + ER01 + ER00 + ER13 + ER12 + ER11;   //check sum.

	#pragma asm										 //4 byte
	MOV32_EDP0_ER0									 //4 byte
	MOV32_EDP0_ER1
//----------------------------------------------------------------------------------------------------------	
	CLR32_ER0										 //crc16_h
	MOV	ER03, R8										 //crc16_l
	MOV	ER02, B
	MOV32_EDP0_ER0									 //4 byte
	#pragma endasm
//-----------------------------------------------------------------------------------------------------------
	_pop_(DPCON);	
}
/************************************************************************************************************************
* ��������void sd_buf_2_nf_buf_cnt_dec(void)
* ���룺
* ���ܣ�����д��һ�����ݺ�ָ��++
* 
************************************************************************************************************************/
void sd_buf_2_nf_buf_cnt_dec(void)
{		
	sd_to_nf_buf_ptr++;										//sd hs buf��ָ��; ָ����һ��buf
	if (sd_to_nf_buf_ptr == SD_HS_CACHE_BUF_CNT) {
		sd_to_nf_buf_ptr = 0;	
	}
	
	_push_(IE);									//ԭ�Ӳ���
	SDIIE = 0;
	sd_ready_for_nf_buf_cnt--;					//д�����ݰ���cnt--;  sd hs buf �İ����Լ�		
	_pop_(IE);	
	
}
/************************************************************************************************************************
* ��������void virtual_buf_2_nf_buf_cnt_dec(void)
* ���룺
* ���ܣ�����д��һ�����ݺ�ָ��++
* 
************************************************************************************************************************/
void virtual_buf_2_nf_buf_cnt_dec(void)
{
#if !DYNAMIC_VIRTUAL_SECTOR
	virtual_to_nf_buf_ptr++;						 //sd virtual buf ptr ����, point to next buf
	if (virtual_to_nf_buf_ptr == SD_VIRTUAL_BUF_CNT) {
		virtual_to_nf_buf_ptr = 0;
	}
#endif
	
	virtual_to_nf_buf_in_per_page_sector_ptr++;		//ָ����һ��sector��sector���˵�ǰpage���һ����Чsector���л�����һ��page
#if DYNAMIC_VIRTUAL_SECTOR
	if (virtual_to_nf_buf_in_per_page_sector_ptr == sectors_in_virtual_page_total){
#else	
	if (virtual_to_nf_buf_in_per_page_sector_ptr == VIRTUAL_BUF_SAVE_SECS_IN_PER_PAGE){
#endif
		virtual_to_nf_buf_in_per_page_sector_ptr = 0;
		virtual_sd_buf_map_r_nf_page_ptr++;			//point to next page for next time.

#if DYNAMIC_VIRTUAL_SECTOR
		virtual_to_nf_buf_ptr++;
		virtual_lbabuf_emptycnt++;
		if (virtual_to_nf_buf_ptr == SD_VIRTUAL_BUF_CNT) {
			virtual_to_nf_buf_ptr = 0;
		}
#endif
	}					
	virtual_sd_data_buf_cnt--;					//д�����ݰ���cnt--
}
/************************************************************************************************************************
* ��������void chk_sd_virtual_buf_lba(void)
* ���룺
* �����status_for_writing_lba_virtual_buf_lba 
* ���ܣ�LBAƥ�䣬status_for_writing_lba_virtual_buf_lba = 0x01
* TMP : ER0/ER1
************************************************************************************************************************/
void chk_writing_lba_and_sd_virtual_buf_lba(void)
{
	if (status_for_writing_lba_virtual_buf_lba &= 0x01) {		//����Ѿ��������˾Ͳ���������
		return;
	}
	
	_push_(DPCON);	
   
   DPCON = 0x08;									//���, �ر�����, dptr0

	for (ER00 = 0, ER01 = hs_to_virtual_buf_ptr/*w ptr*/; ER00 < copy_last_virtual_sd_data_buf_cnt/*r ptr*/; /*ER00++ �������ȸĳ�total,�ŵ����*/){//����lba page ptr,�Ӻ���ǰ
//ER1 lba	
		get_cur_lba_to_er1();						//cur lba for wrting ; ER1 = write lba.

		if (ER01 == 0) {		 						//hs_to_virtual_buf_ptr--
			ER01 = SD_VIRTUAL_BUF_CNT - 1; 			//[0,SD_VIRTUAL_BUF_CNT-1]
		}else {
			ER01--;	
		}	
		_push_(ER00);
		_push_(ER01);
		
//�����̱���ER01		
		DPTR0 = sd_virtual_data_buf_lba;
		B = ER01; 									//���֧��128 �� ����buf
		ACC = 4;
	
		#pragma asm
		MUL	AB										//BA = A * B
		MOV R8, B
		MOV	B, A									//DPTR0 = DPTR0 +  4 * virtual_buf_ptr					
		ADDDP0										//DPTR0 + (R8 B)
		MOV32_ER0_EDP0			//virtual base LBA store in ER0
		SUB32_ER1_ER1_ER0
JB	EC,NEWSD_NOT_IN_RANGE			//ER1<ER0,��Ȼ��EZ
		#pragma endasm
		//ER1>=ER0
//��δ���Ըöδ���
		DPTR0 = sd_virtual_data_buf_cnt;
		#pragma asm
			POP 	ACC
			PUSH	ACC         //er01
			MOV 	R8,#0
			MOV		B,A
			ADDDP0
			MOVX	A,@DPTR  //��ȡtotal
			//ER0<=ER1<ER0+total
			CLR32_ER1
			MOV 	ER10,A
			ADD32_ER0_ER1_ER0		//ER0+total
	
			MOV	 DPTR, # CUR_LBA  
			MOV32_ER1_EDP0

			SUB32_ER1_ER1_ER0
			CLR 	EZ
JNB		EC,NEWSD_NOT_IN_RANGE				
			SETB	EZ
NEWSD_IN_RANGE:	
NEWSD_NOT_IN_RANGE:	
		#pragma endasm
		
		_pop_(ER01);
		_pop_(ER00);
	
		if (EZ) {									//EZ==1 -> Hs_buf_lba == cur_lba	
			status_for_writing_lba_virtual_buf_lba |= 0x01;		//��ǰ���ϴ�erase�󵽸ô�,���vbuf��ʹ�ù��Ļ�
			break;
		}				
		DPTR0 = sd_virtual_data_buf_cnt;
		#pragma asm
			MOV R8, #0
			MOV	B, ER01									//DPTR0 = DPTR0 +  4 * virtual_buf_ptr					
			ADDDP0	
			MOVX 	A,@DPTR	//total //ֻҪadd total����
//			MOV		ER02,A
			ADD		A,ER00	
			MOV 	ER00,A	//add
		#pragma endasm
	}
	_pop_(DPCON);
}

	



