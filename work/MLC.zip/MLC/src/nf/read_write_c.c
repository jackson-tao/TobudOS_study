#include "absacc.h"
#include "intrins.h"
#include "inc\common.h"	
#include "inc\ax215_exinst.h"
#include "inc\sd_spi_com_define.h"
#include "inc\nand_flash.h"	
#include "inc\extern_data.h"
#include "inc\read_write_c.h"
#include "inc\mrom_func.h"

extern void Uart_Send_Byte(u8 dat);
extern void printHexSync(u8 dat);
extern void prints(u8 *p);

/*============================================================
* �Ρ�����:SectorInLargePage,  B
*		   PageLBA
* ��������:
============================================================*/
extern u8 data yScrtyUnitCnt;
void Get_LgAddr(void)     //��δ�޸�
{
	_push_(DPCON);
	DPCON = 0x08;			//���, �ر�����, dptr0			

	if(bStr_MulRead || bStr_MulWrite){
		
		DPTR0 = (u16)(& CUR_MAP_LBA);
	
		#pragma asm
		MOV32_ER0_EDP0					//ER0 = LBA
		#pragma endasm
#if BAUDRATE
//if (bStr_MulWrite || bStr_MulRead)
////if (!bLg2PhVerifyError)		
//{		
//  prints("lba:");
//	printHexSync(ER03);
//	printHexSync(ER02);	 
//	printHexSync(ER01);
//	printHexSync(ER00);
//	prints("\n");			
//}	
#endif
		ZoneLBA = 0;
		while(1){
			while (*((u16 xdata *)(&_ZoneLgBlockNumBuf + ZoneLBA * 2)) == 0)
			{
				ZoneLBA++;
if (ZoneLBA > 8) 
{
	ZoneLBA = *((u8 xdata *)(&FirstValidZone));  //���������ȡ��������,read lba��ǰ��ȡ�ᳬ������
}				
			}
			
			
			Get_CurPlaneCfg();			   	//;����ı�ER0
			ER13 = LargePagePerBlockH;
			ER12 = LargePagePerBlockL;

			ER11 = 0;
			ER10 = (SectorPerSmallPageTotal + 1)>>1;   //������2����,����ᵼ�����,zhiyou 
			#pragma asm
			MUL16_ER1			//�����з�����16k page 2p or 1p�������num buf����Ϊ1023
			#pragma endasm	
			
			ER13 = (u8)(*((u16 xdata *)(&_ZoneLgBlockNumBuf + ZoneLBA * 2)) >> 8);
			ER12 = (u8)(*((u16 xdata *)(&_ZoneLgBlockNumBuf + ZoneLBA * 2)) >> 0);			
			
			R8 = 1;
			#pragma asm
			MUL16_ER1					 //;_ZoneLgBlockNumBuf[ZoneLBA] * SectorPerBlockPlaneH/L
			
			ROTL32_ER1_ER8
			
			SUB32_ER1_ER0_ER1
			#pragma endasm
					
			if( ! EC){
				#pragma asm
				MOV32_ER0_ER1
				#pragma endasm	
				ZoneLBA++;


			}else{
				break;
			}		
		}
		Get_CurPlaneCfg();	 //;�ֲ�������ER1
		//Get_BlockLBA
	
		R8 = 0;		
		B =  SectorPerSmallPageTotal + 1;
		#pragma asm			  //	;ER0 = �ڵ���Zone��ƫ��LBA��ַ
	   	DIV16_ER0	
		#pragma endasm 
		//get��all page+sector
		SectorInLargePage = B;

		R8 = LargePagePerBlockH;		
		B =  LargePagePerBlockL;
		#pragma asm			  //	;ER0 = �ڵ���Zone��ƫ��LBA��ַ
	   	DIV16_ER0				//�̼�������
		#pragma endasm
		
		PageLBAH = R8;
		PageLBAL = B;
		
		BlockLBAH = ER01;   //���block
		BlockLBAL = ER00;	

		if(ZoneLBA){  
			ER01 = BlockLBAH;
			ER00 = BlockLBAL;
			DPCON = 0x10;
			DPTR0 = (u16)(&_ZoneLgBlockNumBuf);
			#pragma asm
			MOV 	B,ZoneLBA
	plus_loop:
			MOVX	A,@DPTR
			MOV 	ER11,A
			MOVX	A,@DPTR
			MOV 	ER10,A
			
			ADD32_ER0_ER0_ER1
			DJNZ	B,plus_loop
			#pragma endasm

			BlockLBAH = ER01;
			BlockLBAL = ER00;				
		}	
	}else{ //bStr_MulRead = 0 or bStr_MulWrite = 0
		SectorInLargePage = (u8)(B + SectorInLargePage);	//���ܵ���0����SectorPerSmallPage+1��	
		if(SectorInLargePage >= (u8)(SectorPerSmallPageTotal + 1)){		
			SectorInLargePage -= (u8)(SectorPerSmallPageTotal + 1);	  
			if(++PageLBAL == 0){
				PageLBAH++;	
			}
			ER01 = PageLBAH;
			ER00 = PageLBAL;
			ER11 = LargePagePerBlockH;
			ER10 = LargePagePerBlockL;
			Compare_wData();
			if(EZ){
				if(++BlockLBAL == 0){
					BlockLBAH++;	
				}				
				
				ER00 = 0;
				DPTR1 = 0;
				do {
					DPTR1 += *((u16 xdata *)(&_ZoneLgBlockNumBuf + ER00 * 2));
					ER00++;
				} while (ER00 <= ZoneLBA);
				
	
				if ((DP1H == BlockLBAH) && (DP1L == BlockLBAL)) {  //�л�zone
					while (1) {
						ZoneLBA++;	
						if (*((u16 xdata *)(&_ZoneLgBlockNumBuf + ZoneLBA * 2)) != 0)
						{
							break;
						}
						if (ZoneLBA == 8) //���16��zone
						{
							ZoneLBA = *((u8 xdata *)(&FirstValidZone));  //���������ȡ��������,read lba��ǰ��ȡ�ᳬ������
							BlockLBAH = 0;
							BlockLBAL = 10;   //�ص�ǰһ��zone,�˴�ֻ��ȷ��������û����
							break;
						}
					}	
					Get_CurPlaneCfg();		
				}					
				PageLBAH = 0;
				PageLBAL = 0;			    
			}
		}
	}
 	_pop_(DPCON);
}



#pragma asm
EXTRN CODE(Retry_Register_Addr_Table_SAMSUNG_ABGDU0B)
#pragma endasm
extern u8 code  Retry_Register_FLASH_RetryCnt, Retry_Register_Addr_Table, Retry_Register_Data_Table, Retry_Register_Number, Retry_Register_CMD;
void NF_Set_Feature(u8 FeatureAddr)
{
	u8 idata FeatureAddrTMP = FeatureAddr, i = 0;
	u8 tmp;
	
	_push_(DPCON);
	_push_(PAGEMAP);
	sfrpage(2);

 	DPCON = 0x00;			//DPTR0����	
//	NF_Reset();
//	_push_(NMCON1_P2);			//PHASY  ddr
//	_push_(NTCON0_P2);  		//ʱ��
//	_push_(NMCON0_P2);				//CE ALWAYS
//	NMCON1_P2 &= ~(1<<4);//�л���SDR�ӿ�
//	NTCON0_P2 = 0xFF;   		//
	
	ER43 = RetryCnt;
	ER40 = *(u8 xdata *)(&Retry_Register_FLASH_RetryCnt);

	tmp = ER43 / ER40;
	ER43 = ER43 % ER40;		//ȡ��
	
	bNeedSend5DCMDSLC = 0;

if ( FlashReTryType) {
	
	if (RetryCnt > RETRY_NUBER)
	{
			ER43 = 0;//set default retry data 
	}	
	
	
	#pragma asm	
		MOV 	DPTR,#(Retry_Register_CMD)
		MOVX	A,@DPTR	
	#pragma endasm
	NF_Send_CMD_Only();	

	#pragma asm
		MOV 	DPTR,#(Retry_Register_CMD+1)
		MOVX	A,@DPTR
	#pragma endasm
	NF_Send_CMD_Only();	
	

	
	ER42 = 4;  //ADDR����������ݳ��ȡ�	
	if (FeatureAddrTMP == *(u8 code *)(&Retry_Register_Addr_Table + 0)) {
		ER40 = 0;  
		ER41 = 4;
		//��0��ʼ4��data
	} else if (FeatureAddrTMP == *(u8 code *)(&Retry_Register_Addr_Table + 4)) {
		ER40 = 4;
		ER41 = 8;
		//��4��ʼ4��data
	} else if (FeatureAddrTMP == *(u8 code *)(&Retry_Register_Addr_Table + 7)) {
		if (FeatureAddrTMP == 0) {
			goto set_feature_end;
		}
		 
		i = 1;
		ER42 = 4;
		ER40 = 7;
		ER41 = 8;
		XBYTE[_SPARE_AREA_BUF+1] = 0;
		XBYTE[_SPARE_AREA_BUF+2] = 0;
		XBYTE[_SPARE_AREA_BUF+3] = 0;
		XBYTE[_SPARE_AREA_BUF+4] = 0;
		XBYTE[_SPARE_AREA_BUF+5] = 0;
		XBYTE[_SPARE_AREA_BUF+6] = 0;
		XBYTE[_SPARE_AREA_BUF+7] = 0;
		XBYTE[_SPARE_AREA_BUF+8] = 0;
		//��7��ʼ1��data
	}	
	
	
	if ((FlashReTryType == 10) || (FlashType == HYNIX) || ((FlashType == TOSHIBA) && (*(u8 code *)(&Retry_Register_CMD+2) == 0x55) )) { //ss u0B   / hy  / tc 55
		ER42 = 1;
		ER41 = Retry_Register_Number;
		if (ER40 != 0) { goto set_feature_end; }
	}

	
	NPGSZ0_P2 = ER42;
	if (bToggleTrue) {
		NPGSZ0_P2 = ER42*2;  //TOGGLE��ʱ������ҪDOUBLE  ʱ����Ҫ�л���SDR?????
	}
	NPGSZ1_P2 = 0x00;	
	NXADR2_P2 = _SPARE_AREA_BUF;
	NXCNT0_P2 = 0;
	NXCNT1_P2 = 0;		
	
for (/*ER40 = 0*/; ER40 < ER41; /*ER40++*/) {
	
	#pragma asm
		MOV 	DPTR,#(Retry_Register_CMD+2)
		MOVX	A,@DPTR
	#pragma endasm
	NF_Send_CMD_Only();		
	
	
	if (FlashReTryType == 10) {  //samsung U0B regiseter 2 byte
		#pragma asm	
			MOV		DPTR,#(Retry_Register_Addr_Table_SAMSUNG_ABGDU0B)  //��ʱ��ô����
			MOV 	ACC,#2
			MOV		B,ER40
			CALL	dptr_add_ab_maskrom
			MOVX	A,@DPTR	
			MOV 	B,A
			INCDP0
			MOVX	A,@DPTR
			MOV 	NFIFO1_P2,A		//ADDR
			MOV 	NFIFO0_P2,B		//ADDR
		#pragma endasm		
	
		DPTR0 = (u16)(&Retry_Register_Data_Table + ER43*Retry_Register_Number + ER40);
	} else {
		ER01 = *(u8 code *)(&Retry_Register_Addr_Table + ER40);
		NFIFO0_P2 = ER01;
//printHexSync(ER01);		
		DPTR0 = (u16)(&Retry_Register_Data_Table + ER43*Retry_Register_Number + ER40);	
	}
	
	DPTR1 = (u16)(_SPARE_AREA_BUF);	
for (ER10 = 0; ER10 < ER42; ER10++)  //data����
{
	#pragma asm
		MOVX	A,@DPTR
		INCDP0

		ORL 	DPCON,#0x01
		MOVX	@DPTR,A		
		INCDP1	
		JNB	bToggleTrue,NOT_TOGGLE		
		MOVX	@DPTR,A		
		INCDP1	
NOT_TOGGLE:		
		ANL		DPCON,#0xfe
//mov B,A	
	#pragma endasm
	
	ER40++;
//printHexSync(B);	
	if (i) break;
}				

		if (FlashReTryType == 10) {	//����addr 2 byte
			
		NPCON_P2 = 0x28;
		} else {
		NPCON_P2 = 0x18;
		}	
		while( ! NTSKD){}
		_N_NOP_
		NTSKD = 0;

}
	
	
	
	
	
	if (FlashReTryType == 9) 	  //ss U0E
	{
		if((tmp & 0x01) == 0)
		{
		
	//prints("A::");	
	//printHexSync(tmp);
	//prints("\n");	

		}else	{
	//prints("B::");	
	//printHexSync(tmp);

			#pragma asm
			MOV 	DPTR,#(Retry_Register_CMD+3)
			MOVX	A,@DPTR
			MOV		B,A	
			#pragma endasm
			NF_Send_CMD_Only();	

	//printHexSync(B);
	//prints("\n");	

		}
	}
	else
	{
		#pragma asm
			MOV 	DPTR,#(Retry_Register_CMD+3)
			MOVX	A,@DPTR	
		#pragma endasm
		NF_Send_CMD_Only();	
	}

	
	#pragma asm
	MOV 	DPTR,#(Retry_Register_CMD+4)
	MOVX	A,@DPTR
	#pragma endasm
	NF_Send_CMD_Only();	

	bNeedSend5DCMDSLC = 1;	
	
	
	
} else {	
	NF_Reset();	
}	
	
set_feature_end:
//	_pop_(NMCON0_P2);
//	_pop_(NTCON0_P2);
//	_pop_(NMCON1_P2);

	_pop_(PAGEMAP);
	_pop_(DPCON);


}

void Set_Retry_Register_Data(void)
{
	
		NF_Set_Feature(*((u8 xdata *)((&Retry_Register_Addr_Table) + 0)));//(0x89);
	if (Retry_Register_Number != 4) {
		NF_Set_Feature(*((u8 xdata *)((&Retry_Register_Addr_Table) + 4)));//(0x8A);
		NF_Set_Feature(*((u8 xdata *)((&Retry_Register_Addr_Table) + 7)));//(0x8D);
	}	
	
//	NF_Get_Feature(*((u8 xdata *)((&Retry_Register_Addr_Table) + 4)));
}

//void NF_Get_Feature(u8 addr)
//{

//prints("\n");	
//	
//prints("read pare\:");	
////printHexSync(ER43);
//ACC = 0xEE;
//NF_Send_CMD_Only();		
////for (ER40 = 7; ER40 < 8; ER40++)
//{	
//		#pragma asm	
//			MOV		DPTR,#(Retry_Register_Addr_Table)
//			MOV		R8,#0//��ַΪ1byte
//			MOV		B,#7//ER40
//			ADDDP0
//			MOVX	A,@DPTR
//			MOV 	NFIFO0_P2,A		//ADDR
//		#pragma endasm
//		
//		
//			NPCON_P2 = 0x14;  //read 
//			while( ! NTSKD){}
//			_N_NOP_
//			NTSKD = 0;	

//		#pragma asm	
//			MOV		DPTR,#(_SPARE_AREA_BUF)
//			MOVX	A,@DPTR	
//		#pragma endasm
//			
//				
//}
//printHexSync(XBYTE[_SPARE_AREA_BUF+0]);
//printHexSync(XBYTE[_SPARE_AREA_BUF+1]);
//printHexSync(XBYTE[_SPARE_AREA_BUF+2]);
//printHexSync(XBYTE[_SPARE_AREA_BUF+3]);
//printHexSync(XBYTE[_SPARE_AREA_BUF+4]);
//printHexSync(XBYTE[_SPARE_AREA_BUF+5]);
//printHexSync(XBYTE[_SPARE_AREA_BUF+6]);
//printHexSync(XBYTE[_SPARE_AREA_BUF+7]);
//prints("\n");

//}	



extern u8 data yBufIndexCopyTmp;
void Chk_Data(void)
{
#if 1
	_push_(DPCON);

	push_reg_bank_0();	
	
	DPCON = 0x00;

	DPTR0 = (u16)(&_PagePhAddr_Buf);
if(RandomIndex)
	B = (RandomIndex - 2);   //��Ӧ�Ĵ洢��ʱ��ҲҪ��1k=2 sector��
else	
	B = (READ_BUF_NUM - 2);//RandomIndex=0
	ACC = _PagePhAddr_Buf_SIZE;
	DPTR_Add_AB();
	#pragma asm
	MOVX	A,@DPTR//PageLBAL or R0_PageAddrL;//SLCģʽ�����߼�page��Ϊ����	
	INC		DPTR
	MOV		ER13,A
	MOVX	A,@DPTR
	INC		DPTR
	MOV		ER03,A//R1
	MOVX	A,@DPTR
	INC		DPTR
	MOV		ER02,A//R3
	MOVX	A,@DPTR//�����ж�
	INC		DPTR
	MOV		ER01,A//R2
	MOVX	A,@DPTR
	INC		DPTR
	MOV		ER12,A//PageLBAH
	MOVX	A,@DPTR
	INC		DPTR
	MOV		ER00,A//R4//|= 0x80;	//SLC
	MOVX	A,@DPTR
	INC		DPTR
	MOV		ER11,A//R0 R0_PageAddrL;
	#pragma endasm
//printHexSync(ER00);
	if((CurLg2PhTableAddrH == 0xFF) || (CurLg2PhTableAddrH == 0x0f)){
		
#if BAUDRATE		
if(ER02 != 0xFF)
{
//yScrtyUnitCnt = 100;	
		printHexSync(BECNTTmp);
		prints("r f");
		printHexSync(CurLg2PhTableAddrL);
		printHexSync(ER02);/*R3_BlockAddrH*/
		printHexSync(ER01);/*R2_BlockAddrL*/
		printHexSync(R4_PageAddrH);/*R4_PageAddrH*/
		printHexSync(R0_PageAddrL);/*R0_PageAddrL*/
		printHexSync(ER03);/*R1_Sector*/
prints("|");
printHexSync(ZoneLBA);
printHexSync(BlockLBAH);
printHexSync(BlockLBAL);	 
printHexSync(PageLBAH);
printHexSync(PageLBAL);
		prints("\n");  		
}
#endif
	}else if (CurLg2PhTableAddrH == 0x0d){

	}else if (CurLg2PhTableAddrH == 0x0a){

	}else if (CurLg2PhTableAddrH == 0x0b){

#if 0//BAUDRATE
		prints("D p");
		printHexSync(BECNTTmp);/*BECNTTmp*/
		printHexSync(ER02);/*R3_BlockAddrH*/
		printHexSync(ER01);/*R2_BlockAddrL*/
		printHexSync(ER00);/*R4_PageAddrH*/
		printHexSync(ER11);/*R0_PageAddrL*/
		printHexSync(ER03);/*R1_Sector*/
		prints("\n");  		
#endif
	}else if (CurLg2PhTableAddrH == 0x00){
#if BAUDRATE
		printHexSync(BECNTTmp);
		prints("r p");
		printHexSync(CurLg2PhTableAddrL);/*BECNTTmp*/
		printHexSync(ER02);/*R3_BlockAddrH*/
		printHexSync(ER01);/*R2_BlockAddrL*/
		printHexSync(ER00);/*R4_PageAddrH*/
		printHexSync(ER11);/*R0_PageAddrL*/
		printHexSync(ER03);/*R1_Sector*/
prints("|");
printHexSync(ZoneLBA);
printHexSync(BlockLBAH);
printHexSync(BlockLBAL);	 
printHexSync(PageLBAH);
printHexSync(PageLBAL);

		prints("\n");  		
#endif
	}
	
	pop_reg_bank_0();
	_pop_(DPCON);
#endif

}

void Get_RdCurZone_Lg2PhTable(void)
{

}

void Get_WrCurZone_Lg2PhTable(void)
{

}

void Get_WrLg2phTableL_P1(void)
{
	_push_(DPCON);
	DPCON = 0x10;
	DPTR0 = (u16)(&MAP_BOUNDARY + (boundIndex&0x03)*2);
	#pragma asm
		MOVX	A,@DPTR	
		MOV		B,A
		MOVX	A,@DPTR
		MOV 	DP0H,B
		MOV 	DP0L,A
	#pragma endasm
		
	_pop_(DPCON);
} 

void Get_WrLg2phTableL(void)
{
	DPTR0 = _WrLg2phTableL;
	ER03 = 0;
	ER02 = 0;
}

void get_bound_block(void)
{
	if (*((u8 xdata *)(&_PLANE_MODE+ZoneLBA)))  //2P OR 4P
	{		
		ER03 = 0;
		ER02 = 0;
		ER01 = R3_BlockAddrH;
		ER00 = R2_BlockAddrL;
		Get_WrLg2phTableL_P1();
		R8 = 0;
#ifdef _8MXX_
		B = 4;
#else 		
		B = 2;
#endif		
		#pragma asm
			DIV16_ER0
		#pragma endasm
		Get_Block_PhAddr();
		R3_BlockAddrH_P1 = ER11;
#ifdef _MLC_		
	ER10++;//2PLANE��ZoneLBA=0��ȡplane1����ʱ��ô����//block��ַ����2,�ú�����ȡ2 planeʱ��plane1��ַ,����Ҫ+1,�ѵ�ַ�������	
#endif
		R2_BlockAddrL_P1 = ER10;
	}	
}

/*============================================================
* �Ρ�����:_WrLg2phTableL _RdLg2phTable
* ��������: 
============================================================*/
void Get_OldBlockPhAddr(void)
{
	ER01 = BlockLBAH;
	ER00 = BlockLBAL;
	Get_WrLg2phTableL();
	Get_Block_PhAddr();
	OldBlockPhAddrH = ER11;
	OldBlockPhAddrL = ER10;
}

static void Rw_DataBlock_SpareArea(void)
{

}
/*============================================================
* �Ρ�����:

* ��������: ��old����cache��һ��page��1~SectorPerSmallPage��sector��
============================================================*/
void Copy_A_Page(void)
{
	R4_PageAddrH = PageLBAH;//=0~257
	R0_PageAddrL = PageLBAL;
	DataCoDecKeyIndex = R0_PageAddrL;//=0~257

	Get_Block_WL_Stage_Addr();
	Read_Sectors();
}

/*============================================================
* �Ρ�����:
	Input��
		R4 R0=0~257
	OutPut:
		R4 R0
		R3 R2
		bBlockMode
	Function��

	���ϵ���������ж������ȵ��ú���

* ��������: 
============================================================*/
extern bit bMulRFlag;
void Get_Block_WL_Stage_Addr(void)//�ĳɴ��ݲ���
{

	if(bReadingCacheBlock)//Write_LBAʱ��bitһ������1(��Ϊ�����������ʱ���Ȼ�Ѿ�֪�����ڷ���SawpIndex)��Read LBAʱ�������������д��block����bit=1������=0
	{
		Get_PagePh2LgTable_StartAddr();
		
		ER01 = R4_PageAddrH;		
		ER00 = R0_PageAddrL;

		Get_Page_PhAddr();

		if ((ER11 != 0x0f) && (ER11 != 0x0e)){		   //HIGH PH_MAX_ADDR_H  in cache 
			bBlockMode = 0;
			R4_PageAddrH = ER11;		
			R0_PageAddrL = ER10;		
			Get_CacheBlock_Addr();
			return;
		}
//		else if((CacheLgPage != 0xffff) && (CacheLgPage/*=�ǻ�ûд����*/ > (R4_PageAddrH * 0x100 + R0_PageAddrL)))
		else if (ER11 == 0x0e)  //�߼�block��ʱ��֧�ֳ���512,��ER11  
//֮���Բ�����CacheLgPage���ж��Ƿ����new�����ڲ�һ����read writing buf 
		{
			bBlockMode = 1;
			R3_BlockAddrH = NewBlockPhAddrH;
			R2_BlockAddrL = NewBlockPhAddrL;
			
#ifdef _MLC_

			DP0H = R4_PageAddrH;
			DP0L = R0_PageAddrL;
			
		#pragma asm
			MOV 	R8,#0
			MOV 	B,#12 //NEED_COPY_PAGE_CNT
			ADDDP0

			JNB		b2PlaneTrue,cal_end				//?????debug 2p��û����
			ADDDP0 			//2p double
			MOV		A,DP0L		//2p�ܵ�����double+,��ż���Բ���			
			ANL 	A,#0x01
			JZ		cal_end
			DECDP0  
cal_end:
			
			MOV		ER11,DP0H
			MOV 	ER10,DP0L
		#pragma endasm

			if ((ER11*0x100+ER10) >= (LargePagePerBlockH * 0x100 + LargePagePerBlockL))
			{
					ER11 = LargePagePerBlockH;
					ER10 = LargePagePerBlockL;
//					{  //�������һ����д,ʹ����Ҫ����
//						ER10--;			//??????debug11
//						if (ER10 == 0xff)
//							ER11--;  
//					}					
			}
			if ((CacheLgPage + 1) < (ER11*0x100+ER10))
			{	
				if (!bReadNewBlockTrue && bMulRFlag) {
					bReadNewBlockTrue = 1;  //�˴���ʹ������Ҳ���������㣬�������				
					_push_(DPCON);
					DPCON = 0;
					*(u8 xdata *)(&COPYLBA_M_TMP+0) = BlockLBAH;
					*(u8 xdata *)(&COPYLBA_M_TMP+1) = BlockLBAL;
					*(u8 xdata *)(&COPYLBA_M_TMP+2) = PageLBAH;
					*(u8 xdata *)(&COPYLBA_M_TMP+3) = PageLBAL;
					_pop_(DPCON);		
					
//ֱ�ӱ���swap index���߼�page,����new block��ֱ�ӻ��block��lgPage,end page,��ȫ��care lba
//read data��ֱ���˳���ȫ��care lba,���õ�ǰ���dma���care��Ҫ��dma���ٰ��Ի����ȷ��lba��ֱ�Ӿ����˳�															
//��õİ취�ǽ���ǰ��lba��������					
					
//??????debug
prints("MMP:");	
//printHexSync(ER31);
//printHexSync(ER30);							
//printHexSync(R4_PageAddrH);			
//printHexSync(R0_PageAddrL);				
//printHexSync(CacheLgPage>>8);	
//printHexSync(CacheLgPage);
//printHexSync(ER11);			
//printHexSync(ER10);	
//printHexSync(SectorInLargePage);					
prints("\n");		
				}
			}

#endif	

		}
		else
		{
			//Get_Block_WL_Stage_Addr_From_OldBlock
			bBlockMode = 1;	 //TLC
			R3_BlockAddrH = OldBlockPhAddrH;
			R2_BlockAddrL = OldBlockPhAddrL;
		
//prints("nns\n");
//printHexSync(OldBlockPhAddrH);
//printHexSync(OldBlockPhAddrL);			
//prints("r o 1");
//Uart_Send_Byte('\n');			
		}

	}
	else
	{
		//Get_Block_WL_Stage_Addr_From_OldBlock
		bBlockMode = 1;	 //TLC
		R3_BlockAddrH = OldBlockPhAddrH;
		R2_BlockAddrL = OldBlockPhAddrL;	
	}

	//R4 R0=0~257����ת����WL��stage
	//����ݸ���bBlockMode��R4 R0����WL��Lower/Middle/Upper
	ER03 = 0;
	ER02 = 0;
	ER01 = R4_PageAddrH;		
	ER00 = R0_PageAddrL;

}

/*============================================================
* �Ρ�����:BlockAddrTmpH/L
* ��������:
	�ж�BlockAddrTmpH/L == 0xFFFF
		 = ����Ҫ����
		!= ����BlockAddrTmpH/L,��BlockAddrTmpH/L���յ��տ��	
============================================================*/
void Write_a_Block_Over(void)
{
	if((BlockAddrTmpH*0x100+BlockAddrTmpL)<0xFFFF){
		R3_BlockAddrH = BlockAddrTmpH;	
		R2_BlockAddrL = BlockAddrTmpL;	
	
		NF_Erase_Block();
		Mark_A_Blank_Block();
	} 
}

void Updata_WrLg2phTable(void)
{
	ER01 = BlockLgAddrH;
	ER00 = BlockLgAddrL;
	Get_WrLg2phTableL();
	ER11 = NewBlockPhAddrH;
	ER10 = NewBlockPhAddrL;

//	if(NewBlockPhAddrH == 0xff){
//		ER11 = 0x0f;
//		ER10 = 0xff;
//	}
  	Set_Block_PhAddr();
}

//Ŀǰ���ڵ�ȱ��
//2:2p AB�в���ǰ��--->AB�з�0��ʼ����2p,

extern u8 code _PageLg2PhTable, _PageLg2PhTable_SLC_Plane1,_PageLg2PhTable_Plane1;
static void WrPage_With_Bad(void)
{
		//bNeedWrBadPage 	BIT 0
		//bWrLastPage			BIT 1
		//bToggle2pPage		BIT	2
		u8 idata CtlVar;
		u16 idata searchIndex, curPhPage, nextPhPage;
#ifdef _MLC_
		unsigned int data wholePageTab;
#endif
	
		#pragma asm
		MOV		C,bEnReleaseNfBufRcvData
		MOV 	ACC.0,C
		PUSH	ACC
		#pragma endasm
		bEnReleaseNfBufRcvData = 0;
	
//prints("G:");
//printHexSync(R4_PageAddrH);		 
//printHexSync(R0_PageAddrL);		 		
		
		//page���ܳ���256
if ((!b2PlaneTrue) || (b2PlaneTrue && (R0_PageAddrL&0x01))) {   

		searchIndex = R4_PageAddrH*0x100 + R0_PageAddrL;
		if (b2PlaneTrue) {
			searchIndex >>= 1;
		} 
		
		if (bBlockMode == 0)
		{
			DPTR1 = *(u16 xdata *)(&PLANE_REFERENCE + ZoneLBA*4 + 2);
		} else {  //tlc
			//page���ܳ���256		
			bNeedChkBlockPageModeIndex = 1;
			Get_PageLg2PhTable();  			
			DPTR1 = *(u16 xdata *)(_FLASH_BLOCK_PAGE_MODE_TABLE + ZoneLBA*4);
		}	//tlc table	

		DPTR0 = DPTR1;
		ER01 = searchIndex>>8;
		ER00 = searchIndex;
		bit_search();
		curPhPage = ER11*0x100 + ER10;	
		DPTR0 = DPTR1;  
		ER01 = (searchIndex+1)>>8;
		ER00 = (searchIndex+1);
		bit_search();
		nextPhPage = ER11*0x100 + ER10;		
	
		//�жϵ�ǰpage�Ƿ������һ��page	
		if (bPageGroupSLC || (bBlockMode == 0)) {  //A or B��

#ifdef _MLC_
		
				//�˴�MP���
				//[dptr 2 byte] [������ģ�͵�page��]
				DPTR0 = (u16)(_FLASH_GOODPAGES_TAB + ZoneLBA*4);
				#pragma asm	
				MOVX	A, @DPTR   
				MOV		R8, A
				INCDP0
				MOVX  A, @DPTR	
				MOV		B, A	//pointer
					  
				INCDP0
				MOVX	A, @DPTR   
				MOV 	ER01,A  
				INCDP0
				MOVX  A, @DPTR	
				MOV 	ER00,A    //�������Чpage����
				DEC32_ER0
				
				MOV 	DP0H,R8
				MOV		DP0L,B	
				#pragma endasm
				
				wholePageTab = DPTR0;   //�ο�������ģ��,ָ��A��B��
				bit_search();
#endif				
		
						
				//�����һ��page
				if (bBlockMode == 0) {
					if ((searchIndex + 1) != WordLineNumber) {
						goto Cal_NextPhPage_End;
					} 
				} else if ((searchIndex + 1) != WordLineNumberTLC) {
					goto Cal_NextPhPage_End;	
				}		
				
				//���һ��page
#ifdef _MLC_
				nextPhPage = ER11*0x100 + ER10;	
#else							
				nextPhPage = WORD_LINE_NUMBER;
#endif				
//				nextPhPage = curPhPage;  //���һ��page���page��ʱ����
				
				goto Cal_NextPhPage_End;
						
		} else {  //MLCģʽ,AB��
		
#ifdef _MLC_
			wholePageTab = (u16)(&WholePageTabAB);  //Ĭ�ϴ��ڵı���			
			if ((searchIndex + 1) == WordLineNumberTLC) {
				nextPhPage = WORD_LINE_NUMBER - 1;  //MLC���һ��page����������
				goto Cal_NextPhPage_End;
			}	
#else 		
			if ((searchIndex + 1) == WordLineNumberTLC) {
				nextPhPage = WORD_LINE_NUMBER;  
				goto Cal_NextPhPage_End;
			}
#endif
		}
	
		
Cal_NextPhPage_End:
	
		
		//��һ��page,�ӵ�0��index��ʼд��
		if ((searchIndex == 0) && !b2PlaneTrue) {	
			searchIndex = 0;
		} else {  
		//�ǵ�һ��page.�ҵ�Ҫд������page��������page�������λ��,���������page����������A �б��н��� 
#ifdef _MLC_
			ER01 = curPhPage>>8;
			ER00 = curPhPage;
			DPTR0 = wholePageTab;
			bit_cal();	
			searchIndex = ER11*0x100 + ER10;	
#else						
				searchIndex = curPhPage;			
#endif			
		}
		
		CtlVar = BIT(0);

} else {   //����Ҫ��page
		
		CtlVar = 0;
}



	CtlVar |= BIT(2);
	do {

		if (bBlockMode)   //��һ��ѭ����һ��Ҫ����Чpage
		{
			//���¹�����Ϣ//Ҳ��������plane1���ø��¹�����Ϣ
			XBYTE[_SPARE_AREA_BUF + 0] = BlockLgAddrL;
			XBYTE[_SPARE_AREA_BUF + 1] = BlockLgAddrH | DATA_BLOCK;			
			XBYTE[_SPARE_AREA_BUF + 2] = R0_PageAddrL;  		
		} else {	
			//���¹�����Ϣ
			XBYTE[_SPARE_AREA_BUF + 0] = BlockLgAddrL;
			XBYTE[_SPARE_AREA_BUF + 1] = BlockLgAddrH | DATA_CACHE_BLOCK;			
			XBYTE[_SPARE_AREA_BUF + 2] = SpareArea2 | ((R0_PageAddrL&0x0f)<<4);  //�˴���Ϊ�������벻һ��			
		}	

		DataCoDecKeyIndex = PageLBAL;
		
		if (CtlVar & BIT(0)) {			
			bSLC2TLCProg = 1;
#ifdef _MLC_	
			DPTR0 = wholePageTab;
			ER01 = searchIndex>>8;
			ER00 = searchIndex;
			bit_search();			
			R4_PageAddrH = ER11;
			R0_PageAddrL = ER10;
#else 			
			R4_PageAddrH = searchIndex>>8;
			R0_PageAddrL = searchIndex;			
#endif			
			if ((R4_PageAddrH*0x100+R0_PageAddrL) != curPhPage) {
				DataCoDecKeyIndex = 0x27 - DataCoDecKeyIndex - R0_PageAddrL;   //�������
//printHexSync(DataCoDecKeyIndex);				
			}
				
			if (CtlVar & BIT(2)) {
				searchIndex++;		
			} else { //2pдplane 0
				goto ReleaseNfBufEnd;
			}
			
			if ((R4_PageAddrH*0x100+R0_PageAddrL) != nextPhPage) {  
#ifdef _MLC_	
				DPTR0 = wholePageTab;
				ER01 = searchIndex>>8;
				ER00 = searchIndex;
				bit_search();
				
				if ((ER11*0x100+ER10) != nextPhPage) {
#else 						
				if (searchIndex != nextPhPage) {	
#endif				
					goto ReleaseNfBufEnd;
				}
			} 		
		}	
		
		#pragma asm
		POP		ACC
		MOV		C,ACC.0
		MOV		bEnReleaseNfBufRcvData,C
		#pragma endasm
		
		CtlVar |= BIT(1);  //���һ��page������
		
ReleaseNfBufEnd:				
		
		if ((CtlVar & BIT(0)) && b2PlaneTrue) { 
			ER03 = 0;
			ER02 = 0;
			ER01 = R4_PageAddrH;
			ER00 = R0_PageAddrL;
			R8 = 1;
			#pragma asm
			ROTL32_ER0_ER8
			#pragma endasm
			if (CtlVar & BIT(2)) {
				#pragma asm
				INC32_ER0
				#pragma endasm
			}
			R4_PageAddrH = ER01;
			R0_PageAddrL = ER00;
			
			CtlVar ^= BIT(2);
		} 
		
		//�ж��Ƿ������һ��д,�ͷ�buf

//prints("A:");
//printHexSync(searchIndex);
//printHexSync(wholePageTab>>8);
//printHexSync(wholePageTab);
//printHexSync(R4_PageAddrH);
//printHexSync(R0_PageAddrL);
//printHexSync(curPhPage);
//printHexSync(nextPhPage);		
//prints("\n");	
		
		SectorNum = SectorPerSmallPage + 1;
		R8Tmp = R1_Sector = R8 = 0;
		Prog_A_Page_CacheBlock();
		
		if (CtlVar & BIT(1)) {
			break;
		}
		
	} while(1);
	
	bSLC2TLCProg = 0;
}
	
	
	
void Prog_NewBlock_Page(void)//page��ַ��CacheLgPage//R8Tmp = 0;bEnReleaseNfBufRcvData = 1;R1_Sector�ں�����������
{
//	unsigned char tmp;

	_push_(DPCON);
	DPCON = 0x00;			//DPTR0������
//	tmp = R1_Sector;//����		
	bProgCacheBlockPageTrue = 1;

	if((NewBlockPhAddrH*0x100+NewBlockPhAddrL) >= 0xFFFF){//����0x0F 0xFF
		NF_Read_Status(0);
		bBlockMode = 1;
		Find_A_Blank_Block();

//if ((BlockLgAddrH == 0)	 && (BlockLgAddrL == 5))   //?????debug
//{
//	BlockAddrTmpH = 0x01;
//	BlockAddrTmpL = 0x05;
//		R3_BlockAddrH = BlockAddrTmpH;
//		R2_BlockAddrL = BlockAddrTmpL;	
//	
//		NF_Erase_Block();  
//		NF_Erase_Block(); 
//	
//}  

		NewBlockPhAddrH = BlockAddrTmpH;
		NewBlockPhAddrL = BlockAddrTmpL;
		
		prints("F N TLC");
		printHexSync(BlockLgAddrH);
		printHexSync(BlockLgAddrL);
		printHexSync(NewBlockPhAddrH);
		printHexSync(NewBlockPhAddrL);
		Uart_Send_Byte('\n');	
	}

	Get_PagePh2LgTable_StartAddr();	   //����Pageӳ���
	ER01 = CacheLgPage >> 8;//PageLBAH;
	ER00 = CacheLgPage & 0xFF;//PageLBAL;
	ER11 = 0x0e;  //�ĳ�0x0f����  //д��page�Ÿ���
	ER10 = 0xFF;
	Set_Page_PhAddr();

	//���
	bBlockMode = 1;
	R4_PageAddrH = CacheLgPage >> 8;//Prog_NewBlock_Page�ں��������Լӣ���Ϊ2plane��ʱ���Ǵ�page
	R0_PageAddrL = CacheLgPage & 0xFF;
	R3_BlockAddrH = NewBlockPhAddrH;
	R2_BlockAddrL = NewBlockPhAddrL;
	
	WrPage_With_Bad();
	
	_pop_(DPCON);
}


void Prog_CacheBlock_Page(void)
{
	_push_(DPCON);
	DPCON = 0x00;			//DPTR0������
  
  	bProgCacheBlockPageTrue = 1;
	

		if(((CacheBlockNextPagePhAddrH*0x100+CacheBlockNextPagePhAddrL) % (WordLineNumber * PlaneNum)) == 0){
			NF_Read_Status(0);
			bBlockMode = 0;
			Find_A_Blank_Block();

prints("F N SLC");
printHexSync(BlockLgAddrH);
printHexSync(BlockLgAddrL);
printHexSync(R3_BlockAddrH);
printHexSync(R2_BlockAddrL);				
Uart_Send_Byte('\n');			
			
				ER10 = (CacheBlockNextPagePhAddrH*0x100+CacheBlockNextPagePhAddrL) / (WordLineNumber * PlaneNum);
				DPTR0 = _WritingBlockBuf + CacheBlockPhAddrH_INDEX;
				B = SWAPIndex;
				ACC = WritingBlockBuf_SIZE;
				DPTR_Add_AB();

				B = ER10; 
				ACC = 2;
				DPTR_Add_AB();
	
				ACC = BlockAddrTmpH;
				#pragma asm
				MOVX	@DPTR,A
				#pragma endasm
			
				ACC = BlockAddrTmpL;
				#pragma asm
				INC		DPTR
				MOVX	@DPTR,A
				#pragma endasm			
		}	

	Get_PagePh2LgTable_StartAddr();	   //����Pageӳ���
	ER01 = PageLBAH;
	ER00 = PageLBAL;  //0~511
	ER11 = CacheBlockNextPagePhAddrH;
	ER10 = CacheBlockNextPagePhAddrL;
	Set_Page_PhAddr();

	//���
	R4_PageAddrH = CacheBlockNextPagePhAddrH; 
	R0_PageAddrL = CacheBlockNextPagePhAddrL;

	Get_CacheBlock_Addr();

	WrPage_With_Bad();

	if(++CacheBlockNextPagePhAddrL == 0){			//�����ɼ��л�����һ��page
		CacheBlockNextPagePhAddrH++;	
	}	

	bProgCacheBlockPageTrue = 0;
	_pop_(DPCON);
}

void Get_CacheBlock_Addr(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����	
	

	ER03 = WordLineNumber>>8;
	ER02 = WordLineNumber;
	ER01 = 0;
	ER00 = PlaneNum;
	#pragma asm
	MUL16_ER0
	#pragma endasm
	R8 = ER01;
	B = ER00;
	
	
	ER03 = 0;
	ER02 = 0;
	ER01 = R4_PageAddrH;
	ER00 = R0_PageAddrL;
	#pragma asm
	DIV16_ER0
	#pragma endasm
	R4_PageAddrH = R8;//MUST BE 0
	R0_PageAddrL = B;//WL
	SpareArea2 = ER00;//��n��CacheBlock��Prog_CacheBlock_Page��Ҫ�õ�

	DPTR0 = _WritingBlockBuf + CacheBlockPhAddrH_INDEX;	
	#pragma asm
	MOV		B,SWAPIndex
	MOV		A,#WritingBlockBuf_SIZE
	CALL	dptr_add_ab_maskrom
	MOV		B,SpareArea2//��B��CacheBlock
	MOV		A,#2//CacheBlockPhAddrH/L
	CALL	dptr_add_ab_maskrom
	MOVX	A,@DPTR
	MOV		B,A
	MOVX	A,@DPTR
	MOV		R8,A
	#pragma endasm
	bBlockMode = 0;
	R3_BlockAddrH = B;
	R2_BlockAddrL = R8;	
				
	_pop_(DPCON);
}

/*============================================================
* �Ρ�����:SWAPIndex
* ��������:��SwapBuf��ȡ��DATA_RAM�У��������ʹ��
============================================================*/
void Read_WritingBlockBuf(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����

	Get_WritingBlockBuf_BlockLgAddrH_INDEX();

	#pragma asm
	MOV32_ER0_EDP0
	#pragma endasm
	BlockLgAddrH = ER00;
	BlockLgAddrL = ER01;
	CacheBlockNextPagePhAddrH = ER02;
	CacheBlockNextPagePhAddrL = ER03;

	#pragma asm
	MOV32_ER0_EDP0
	#pragma endasm
	
	CacheLgPage = ER02 * 0x100 + ER03;   //new next page * 2

	#pragma asm
	MOV32_ER0_EDP0
	#pragma endasm
	NewBlockPhAddrH = ER00;
	NewBlockPhAddrL = ER01;
	_pop_(DPCON);
}

void Write_WritingBlockBuf(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����

	Get_WritingBlockBuf_BlockLgAddrH_INDEX();

	ER00 = BlockLgAddrH;
	ER01 = BlockLgAddrL;
	ER02 = CacheBlockNextPagePhAddrH;
	ER03 = CacheBlockNextPagePhAddrL;
	#pragma asm
	MOV32_EDP0_ER0
	#pragma endasm


//	ER00 = Order >> 8;
//	ER01 = Order & 0xFF;
	ER02 = CacheLgPage >> 8;
	ER03 = CacheLgPage & 0xFF;
	#pragma asm
	MOV32_EDP0_ER0
	#pragma endasm

	#pragma asm
	MOV		A,NewBlockPhAddrH
	MOVX	@DPTR,A
	MOV		A,NewBlockPhAddrL
	MOVX	@DPTR,A
	#pragma endasm
	_pop_(DPCON);
}

void Get_PagePh2LgTable_StartAddr(void)
{
	DPTR0 = PAGE_PH2LG_TABLE_ADDR;

	ER01 = (u8)(PAGE_PH2LG_TABLE_SIZE >> 8);		
	ER00 = (u8)(PAGE_PH2LG_TABLE_SIZE >> 0);	
	ER03 = 0;
	ER02 = SWAPIndex;

	#pragma asm
	MUL16_ER0
	MOV		R8,ER01
	MOV		B ,ER00
	ADDDP0								//;DPTR0 + (R8 B)	
	#pragma endasm	
}
/*============================================================
* �Ρ�����:ER02
* ��������:
============================================================*/
void Sel_Buffer_Addr(void)
{
	ER11 = (u8)(BUFFER_START_ADDR >> 8);
	ER10 = (u8)(BUFFER_START_ADDR >> 0);

	ER01 = (u8)(512 >> 8);				
	ER00 = (u8)(512 >> 0);				

	ER03 = 0;
	
	#pragma asm
	MUL16_ER0
	ADD32_ER0_ER0_ER1
	#pragma endasm

}

/*============================================================
* �Ρ�����:ER02
* ��������:
============================================================*/
void Sel_DMA_Addr(void)
{
	ER11 = (u8)((BUFFER_START_ADDR / 4) >> 8);
	ER10 = (u8)((BUFFER_START_ADDR / 4) >> 0);

	ER01 = (u8)((512 / 4) >> 8);			
	ER00 = (u8)((512 / 4) >> 0);		

 	ER03 = 0;
	#pragma asm
	MUL16_ER0
	ADD32_ER0_ER0_ER1
	#pragma endasm	
}
/*============================================================
* �Ρ�����:ER01 ER00 = LgAddr ER11 ER10 = PhAddr
* ��������: 
============================================================*/
//static 
void Get_Lg2PhAddr(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����	
	
	#pragma asm
	//*3
	MOV		ER03,#0
	MOV		ER02,#3
	MUL16_ER0
	//2
	MOV		R8,#0
	MOV		B,#2
	DIV16_ER0
	PUSH	B		//����
	MOV		R8,ER01
	MOV		B ,ER00
	ADDDP0			
	MOVX	A,@DPTR
	MOV		ER00,A
	MOVX	A,@DPTR
	MOV		ER01,A
	POP		ACC	
	#pragma endasm

	if(ACC & (1 << 0)){
		R8 = 4;
		#pragma asm
		ROTR32_ER0_ER8
		#pragma endasm		
	}
	ER01 &= 0x0f;
	ER10 = ER00;
	ER11 = ER01;

	_pop_(DPCON);
}

void Get_Page_PhAddr(void)
{
	Get_Lg2PhAddr();
}
/*============================================================
* �Ρ�����: ER01 ER00 = LgAddr ER11 ER10 = PhAddr
* ��������: 
============================================================*/	
void Set_Lg2PhAddr(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����	

	#pragma asm
	//*3
	MOV		ER03,#0
	MOV		ER02,#3
	MUL16_ER0
	//2
	MOV		R8,#0
	MOV		B,#2
	DIV16_ER0
	PUSH	B		//����	
	MOV		R8,ER01
	MOV		B ,ER00
	ADDDP0
	MOVX	A,@DPTR//��ԭ��������ȡ����������R01 ER00
	MOV		ER00,A
	MOVX	A,@DPTR
	MOV		ER01,A
	DECDP0
	DECDP0
	POP		ACC
	#pragma endasm
	
	if(ACC & (1 << 0)){
		ER13 = 0;
		#pragma asm
		MOV		R8,#4
		ROTL32_ER1_ER8	
		MOV		ER01,#0
		ANL		ER00,#0x0F
		ANL		ER10,#0xF0
		#pragma endasm	
	}else{
		#pragma asm	
		ANL		ER01,#0xF0
		MOV		ER00,#0
		ANL		ER11,#0x0F
		#pragma endasm		
	}

	#pragma asm
	ORL32_ER1_ER0
	MOV		A,ER10
	MOVX	@DPTR,A
	MOV		A,ER11
	MOVX	@DPTR,A
	#pragma endasm

	_pop_(DPCON);
}

void Set_Page_PhAddr(void)
{
	Set_Lg2PhAddr();
}

void Set_Block_PhAddr(void)
{

//			prints("SET:\n");
//			printHexSync(ZoneLBA);		
//			printHexSync(ER11);
//			printHexSync(ER10);	
//			prints("\n");

	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����	

	if(ER11 == 0xff){
		ER11 = 0x0f;
		ER10 = 0xff;
	} else {
#ifdef _MLC_	
	#ifndef _HALFPAGE_
	if((!bPlaneMag) || b2PlaneTrue)	
	#endif
	{		//��������,��Ӧ��get block��ַʱҲ���ܴ���
		ER13 = 0;
		ER12 = 0;
		R8 = 1;	

		#pragma asm
		ROTR32_ER1_ER8
		#pragma endasm
	}
#endif		
	}	
	
 	
	Set_Lg2PhAddr();
	_pop_(DPCON);
}


void Get_Block_PhAddr(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����	
	
	Get_Lg2PhAddr();

	if((ER11 == 0x0f) && (ER10 == 0xff)) {//=0x0FFF ����ΪĿǰ��12bit���洢
		ER11 = 0xff;	
		ER10 = 0xff;
	}else{
#ifdef _MLC_		
		#ifndef _HALFPAGE_
		if((!bPlaneMag) || b2PlaneTrue)
		#endif
		{
			ER13 = 0;
			ER12 = 0;
			R8 = 1;
			#pragma asm
			ROTL32_ER1_ER8
			#pragma endasm	 
			if (ZoneLBA) {
				ER10 += 1;
			}
		}
#endif		
	}

//			prints("GET:\n");
//			printHexSync(ZoneLBA);
//			printHexSync(ER11);
//			printHexSync(ER10);	
//			prints("\n");

	_pop_(DPCON);
}




void Get_ZoneLBA(void)
{
	_push_(DPCON);
	DPCON = 0x10;		

	ZoneLBA = 0;
	ER03 = 0;
	ER02 = 0;
	ER01 = BlockLgAddrH;
	ER00 = BlockLgAddrL;

	ER13 = 0;
	ER12 = 0;
	DPTR0 = (u16)(&_ZoneLgBlockNumBuf);
	ZoneLBA = 0xff;
	do 	{
		#pragma asm
		MOVX	A,@DPTR
		MOV 	ER11,A
		MOVX	A,@DPTR
		MOV 	ER10,A
		SUB32_ER0_ER0_ER1
		INC 	ZoneLBA  
		#pragma endasm
	} while(!EC);

	_pop_(DPCON);	
}

void Get_WritingBlockBuf_BlockLgAddrH_INDEX(void)
{
	DPTR0 = _WritingBlockBuf + BlockLgAddrH_INDEX;
	B = SWAPIndex;
	ACC = WritingBlockBuf_SIZE;
	DPTR_Add_AB();
}



