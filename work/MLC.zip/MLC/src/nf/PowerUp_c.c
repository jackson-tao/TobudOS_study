#include "absacc.h"
#include "intrins.h"
#include "inc\common.h"	
#include "inc\ax215_exinst.h"
#include "inc\sd_spi_com_define.h"
#include "inc\nand_flash.h"	
#include "inc\extern_data.h"
#include "inc\mtd_c.h"
#include "inc\power_up_c.h"
#include "inc\mrom_func.h"

extern bit(bFirstEnDecodeData);

void get_dqs_phase(void);
void SLC_Find_Reserved_Blocks(void);
void Update_Lg2phTableL(void);
static void Get_Seed(void);
extern void Uart_Send_Byte(u8 dat);
extern void printHexSync(u8 dat);
extern void prints(u8 *p);
extern xdata unsigned int SwapBuf[SWAP_SIZE];
static unsigned char HyGetPara(unsigned char addr);
static void HySetPara(unsigned char addr, unsigned char dat);




static void homs_init(void)
{

	_push_(PAGEMAP);

	sfrpage(0);

	CLKCON0_P0 |= (1<<7);  //release  RDG
	CLKCON1_P0 |= (1<<7);  //release  HOMO

	sfrpage(4);

	//LFSR0~7 ����ʽ����
	HORDER0_P4 = 13;
	HORDER1_P4 = 17;
	HORDER2_P4 = 19;
	HORDER3_P4 = 23;
 	HORDER4_P4 = 13;
	HORDER5_P4 = 17;
	HORDER6_P4 = 19;
	HORDER7_P4 = 23;

	//LFSR0 ����ʽ(top 13bit : 0x1b00(0->12bit)  x^0 + x^1 + x^3 + x^4 + x^13)  
    HPOLY00_P4     =   0x00; 
    HPOLY01_P4     =   0x1b; 
    HPOLY02_P4     =   0x00; 
    HPOLY03_P4     =   0x00; 

	//LFSR1 ����ʽ(top 17bit : 0x12000(0->16bit)  x^0 + x^3 + x^17)
    HPOLY10_P4     =   0x00; 
    HPOLY11_P4     =   0x20; 
    HPOLY12_P4     =   0x01; 
    HPOLY13_P4     =   0x00;
	
	//LFSR2 ����ʽ(top 19bit : 0x72000(0->18bit)  x^0 + x^1 + x^2 + x^5 + x^19) 
    HPOLY20_P4     =   0x00; 
    HPOLY21_P4     =   0x20; 
    HPOLY22_P4     =   0x07; 
    HPOLY23_P4     =   0x00; 

	//LFSR3 ����ʽ(top 23bit : 0x72000(0->22bit)  x^0 + x^5 + x^23)
    HPOLY30_P4     =   0x00; 
    HPOLY31_P4     =   0x00; 
    HPOLY32_P4     =   0x42; 
    HPOLY33_P4     =   0x00; 

	//LFSR4 ����ʽ
    HPOLY40_P4     =   0x00; 
    HPOLY41_P4     =   0x1b; 
    HPOLY42_P4     =   0x00; 
    HPOLY43_P4     =   0x00; 

	//LFSR5 ����ʽ
    HPOLY50_P4     =   0x00; 
    HPOLY51_P4     =   0x20; 
    HPOLY52_P4     =   0x01; 
    HPOLY53_P4     =   0x00; 

	//LFSR6 ����ʽ
    HPOLY60_P4     =   0x00; 
    HPOLY61_P4     =   0x20; 
    HPOLY62_P4     =   0x07; 
    HPOLY63_P4     =   0x00; 

	//LFSR7 ����ʽ
    HPOLY70_P4     =   0x00; 
    HPOLY71_P4     =   0x00; 
    HPOLY72_P4     =   0x42; 
    HPOLY73_P4     =   0x00; 

	//homogeous base seed0~7 table addr
    HBADR00_P4    =   0x00; 
    HBADR01_P4    =   0x10; 

    HBADR10_P4    =   0x00; 
    HBADR11_P4    =   0x20; 

    HBADR20_P4    =   0x00; 
    HBADR21_P4    =   0x30;
	 
    HBADR30_P4    =   0x00; 
    HBADR31_P4    =   0x40; 

    HBADR40_P4    =   0x00; 
    HBADR41_P4    =   0x10;
	 
    HBADR50_P4    =   0x00; 
    HBADR51_P4    =   0x20;
	 
    HBADR60_P4    =   0x00; 
    HBADR61_P4    =   0x30; 

    HBADR70_P4    =   0x00; 
    HBADR71_P4    =   0x40;

		sfrpage(2);
		//homogeous seed table length
		HTABLEL_P2     =   4;

		HPAGE0_P2  = 0;
		HPAGE1_P2  = 0;//10bit
		HFRAME_P2  = 0;//DataCoDecKeyIndex1; //homogeous frame
		HSEEDINIT0_P2 = 0;//DataCoDecKeyIndex;
		HSEEDINIT1_P2 = 0;//DataCoDecKeyIndex1;
		HSEEDINIT2_P2 = 0;//DataCoDecKeyIndex;
		HSEEDINIT3_P2 = 0;//DataCoDecKeyIndex1;
#if MODE_1K_EN
		HDMAMT1_P2 = (u8)(((1024+0) / 4 - 1) >> 8);
		HDMAMT0_P2 = (u8)(((1024+0) / 4 - 1) >> 0);
#else
		HDMAMT1_P2 = (u8)(((512+0) / 4 - 1) >> 8);   
		HDMAMT0_P2 = (u8)(((512+0) / 4 - 1) >> 0);
#endif
//		HDMAMT1_P2 = (u8)(((0x230) / 4 - 1) >> 8);
//		HDMAMT0_P2 = (u8)(((0x230) / 4 - 1) >> 0);


		_pop_(PAGEMAP);
		
}

#pragma asm
	EXTRN CODE(ChkSlcMode)
#pragma endasm
static void NF_Init(void)
{
	bch_initial();
	homs_init();
	
#if 1//DIS_NF_FUNCTION
//����IO
//	P2 = 0xff;
//	P2DIR = 0x00;

//	P0 = 0xff;
//	P0DIR = 0x00;
//	P3 = 0xf9;
//	P3DIR = 0x60;
//	SCADDR = P3PLP;
//	SCDATA = 0x60;

	_push_(PAGEMAP);
	sfrpage(0);

//	CLKCON0_P0 |= BIT(4);	//release nfc
	CLKCON0_P0 = 0xff;

	CLKCON1_P0 |= (1<<7);  //release  HOMO
	
	P0DIR_P0 = 0x00;
	P0_P0 = 0xff;
	
	P3_P0 = 0xf9;
	P3DIR_P0 = 0x60;
	P3PLP_P0 = 0x60;

	P1DIR_P0 = 0xff;
	
	_pop_(PAGEMAP);
#endif

//	;��ʼ��Flash������
	NMCON0_P2 = 0xc0;//8; //8
	if(_FLASH_CHIPNUM != 1){
		NMCON0_P2 = 0xc8;	   // 2CEʱ��CE active
	}
	NTCON0_P2 = _FLASH_RWCYCLE;
	#pragma asm
	MOV		DPTR,#ChkSlcMode
	MOV		A,#0xff
	MOVX	@DPTR,A
	#pragma endasm
	NTCON1_P2 = 0x0f;	 //5  05��DDR������ ��ȷ��
	NTCON2_P2 = 0x02;   // ;ddr clk :sys clk div 2; Twpre/Twpst 8 sys clks ; Tcad 4 sys clks  

	NCEE_P2 = BIT(4) | BIT(3) | BIT(2);	//enable nfc dma channel 2 / 1 /0
	NF_Reset_CE();	

//// 	��flash����ԭ��fwֻ����SDR modeʱ�򿪸�ģʽ	
////	//Ĭ��SDR��fw,�������TOGGLE����ΪflashĬ����toglgeģʽ
//������У��峢�������¶˴���
	if (((FlashType == TOSHIBA) || (FlashType == TLC_SLC)) && (_DEFAULT_TOGGLE==1)) 
	{  //���SDR
		NMCON1_P2  = 0;   
		NMCON1_P2 |= BIT(4); //DDR mode
		
		B  = 0x80;
		R8 = 0x01;
		PowerUp_NF_Set_Feature();

		NMCON1_P2 &= ~(1<<4);  //SDR 
		
		B  = 0x80;
		R8 = 0x01;
		PowerUp_NF_Set_Feature();	

		bToggleTrue = 0;		//ǿ��ת��SDR
	}	
	
	NF_Read_ID();	
	
	
//#ifdef _8MXX_
	B = 0x10;
	NF_Reset();
	PowerUp_NF_Get_Feature();

	B = 0x10;
	R8 = 0x02;
	NF_Reset();
	PowerUp_NF_Set_Feature();

 	B = 0x10;
	NF_Reset();
  PowerUp_NF_Get_Feature();
//#endif

	if(bToggleTrue){
	
#ifdef _8MXX_	
		NMCON0_P2 = 0xc8;
		NF_Reset_CE();

		B = 0x02;  //0x80;//Toggle DDR
		R8 = 0x00;
		PowerUp_NF_Set_Feature();
		
		B = 0x01;  //0x80;//Toggle DDR
		R8 = 0x20;
		PowerUp_NF_Set_Feature();
#else 
		if (FlashType == MICRON) {
			//ֻ֧��nv -DDR2��֧��sync DDR
			//ע���ϵ�micron flash��֧��
			B = 0x01;//Toggle DDR
			R8 = 0x22;			
			PowerUp_NF_Set_Feature();
			
			NMCON0_P2 = 0xc8;
			NF_Reset_CE();
			
		}
		
	if ((FlashType == TOSHIBA)) {
			NMCON0_P2 = 0xc8;
			NF_Reset_CE();
			
			B = 0x80;//Toggle DDR
			R8 = 0x00;			
			PowerUp_NF_Set_Feature();
		}
#endif

		
		prints("NFC use DDR interface. \n\n");
		
		get_dqs_phase();		//�޸Ļ�ȡdps��ʽ,���Ӷ����ݳ��ȵó���phase��׼ȷ
		
	} else {
//		prints("NFC use SDR interface. \n\n");

		NF_Read_ID();	
	}

}

static void PowerUp_NF_Set_Feature(void)
{
	_push_(DPCON);
	
	DPCON = 0;

	XBYTE[_SPARE_AREA_BUF + 0] = R8;
	if (NMCON1_P2 & BIT(4)) {
		XBYTE[_SPARE_AREA_BUF + 1] = R8;
		NPGSZ0_P2 = 0x08;
		NPGSZ1_P2 = 0x00;		
	} else {
		XBYTE[_SPARE_AREA_BUF + 1] = 0x00;
		NPGSZ0_P2 = 0x04;
		NPGSZ1_P2 = 0x00;		
	}
 	XBYTE[_SPARE_AREA_BUF + 2] = 0x00;
 	XBYTE[_SPARE_AREA_BUF + 3] = 0x00;
 	XBYTE[_SPARE_AREA_BUF + 4] = 0x00;
 	XBYTE[_SPARE_AREA_BUF + 5] = 0x00;
	XBYTE[_SPARE_AREA_BUF + 6] = 0x00;
 	XBYTE[_SPARE_AREA_BUF + 7] = 0x00;

	NXADR2_P2 = _SPARE_AREA_BUF;
	NXCNT0_P2 = 0;
	NXCNT1_P2 = 0;

	NFIFO1_P2 = B;	   //#0x80//ADDR
	NFIFO0_P2 = 0xEF;
	BCON1_P2 = 0;
	NPCON_P2 = 0x19;
	while( ! NTSKD){}
	_N_NOP_
	NTSKD = 0;
		
	_pop_(DPCON);
}

static void PowerUp_NF_Get_Feature(void)
{
	NPGSZ0_P2 = 0x04;
	NPGSZ1_P2 = 0x00;
	
#if 1//DIS_NF_FUNCTION	
	NXADR2_P2 = _SPARE_AREA_BUF;
	NXCNT0_P2 = 0;
	NXCNT1_P2 = 0;
#endif	

	NFIFO1_P2 = B;
	NFIFO0_P2 = 0xEE;
	BCON1_P2 = 0;
	NPCON_P2= 0x15;
	while( ! NTSKD){}
	_N_NOP_
	NTSKD = 0;
}

static void NF_Read_ID(void)
{	
#if 1    //DIS_NF_FUNCTION	
	NXADR2_P2 = _SPARE_AREA_BUF;
	NXCNT0_P2 = 0;
	NXCNT1_P2 = 0;
#endif
	
 	NPGSZ0_P2 = 0x06;
	NPGSZ1_P2 = 0x00;
if (FlashType == MICRON) {
	NFIFO1_P2 = 0x40;
} else {	
	NFIFO1_P2 = 0x00;
}
	NFIFO0_P2 = NF_READ_ID;
	NPCON_P2 = 0x15;
	while( ! NTSKD){}
	_N_NOP_
	NTSKD = 0;

//�ж��Ƿ�֧��sync ddr or NV-DDR2
//215f��֧��sync ddr		
//0x01:only async
//0x05:sync ddr
//0x19:NVDDR2/DDR3
//if (FlashType == MICRON) {
//	if (XBYTE[_SPARE_AREA_BUF+5] != 0x05) {
//		bToggleTrue = 0;
//	} else {
//		bToggleTrue = 1;
//	}
//}
		
//	prints("\n");
}

static void NF_Reset_CE(void)
{
	select_ce(CE0);
	NMCON0_P2 &= ~(1<<4); //				;RB0
	NF_Reset();
}


extern code u8 _FLASH_LARGEPAGEPERBLOCKPLN1H[];
static void NF_Cfg(void)
{
	_push_(DPCON);
	DPCON = 0;
	
//	FlashCfg = _FLASH_DUALCHIPMODE;
	BitData = _FLASH_BITDATA;
	FunctionCfg = _FLASH_FUNCTIONEXT;

	FlashReTryType = _FLASH_RetryTypes;
	FlashType = _FLASH_TYPE;
	
	
	WORD_LINE_NUMBER = _FLASH_WLNUMH*0x100 + _FLASH_WLNUML;
	bWriteLastLgPage = 0;
	
	if((FunctionCfg & 0x30) == 0x20){
		bToggleTrue = 1;	
	}
	PlaneNum = 1;


#ifndef _MLC_
	if(_FLASH_TWOPLANEMODE == 1){	 
		b2PlaneTrue = 0;
		bPlaneMag = 0;	
	}	
	PlaneNum = 1;
	
	#ifndef _8MXX_
		*(u8 xdata *)(&_FLASH_TWOPLANEMODE) = 0;
	#else 
		bPlaneMag = 0;
	#endif
	
#else 	
	
	if(_FLASH_TWOPLANEMODE == 1){	  	//;Sumsung
		b2PlaneTrue = 1;
		PlaneNum = 2;
		prints("2P\n");
	}	
#endif
	
prints("\n");	
if(b2PlaneTrue == 1){	  	//;Sumsung
	prints("2P\n");
}	
if (bCacheCmd) {
	prints("cache\n");
}
prints("mlc\n");

specialBit = 0;

	_pop_(DPCON);
}

extern void Get_WrLg2phTableL_P1(void);
static void power_up_set_bound(void)
{
	if (*((u8 xdata *)(&_PLANE_MODE+ZoneLBA))) { //4p	
		ER03 = 0;
		ER02 = 0;
		ER01 = R3_BlockAddrH;
		ER00 = R2_BlockAddrL;	
		Get_WrLg2phTableL_P1();			
		R8 = 0;
#ifdef _8MXX_
		B = 4;
#else 		
		B = 2;
#endif	
		#pragma asm
		DIV16_ER0
		#pragma endasm
		ER11 = R3_BlockAddrH_P1;
		ER10 = R2_BlockAddrL_P1;	
		Set_Block_PhAddr();				
	}
}


static void bound_slc_block(void)
{		
	
	u8 data planeMode;
	planeMode = *((u8 xdata *)(&_PLANE_MODE+ZoneLBA));
	
prints("bound slc:\n");
	
	BlankBlockIndexL = 0;
	if (planeMode) {
		while (1) {
			DPTR0 = (u16)(SLC_BLOCK_TABLE + ZoneLBA*128);  //���ϵ�ʹ��
			#pragma asm	
			MOV		B,BlankBlockIndexL
			MOV		A,#2	
			CALL	dptr_add_ab_maskrom
			CLR32_ER0
			MOVX	A,@DPTR				//2 byte
			MOV		ER01,A
			INCDP0
			MOVX	A,@DPTR
			MOV		ER00,A
			#pragma endasm

			if (ER01 == 0xFF) 	//find end,��ȡ���ܳ���63��block
				break;
				
			R3_BlockAddrH	= ER01;
			R2_BlockAddrL	= ER00;
//printHexSync(R3_BlockAddrH);		
//printHexSync(R2_BlockAddrL);			
			DPTR0 = (u16)(SLC_BLOCK_TABLE+(ZoneLBA+1)*128);//slc plane2   128);	//slc plane1
			#pragma asm	
			MOV		B,BlankBlockIndexL
			MOV		A,#2	
			CALL	dptr_add_ab_maskrom
			CLR32_ER0
			MOVX	A,@DPTR				//2 byte
			MOV		ER01,A
			INCDP0
			MOVX	A,@DPTR
			MOV		ER00,A
			#pragma endasm
			R3_BlockAddrH_P1	= ER01;
			R2_BlockAddrL_P1	= ER00;	
#if BAUDRATE
#if PRINT_BOUND_BLOCK			
printHexSync(R3_BlockAddrH);
printHexSync(R2_BlockAddrL);
printHexSync(ER01);
printHexSync(ER00);		
prints("\n");			
#endif
#endif 

			boundIndex = 0;
			if ((*((u8 xdata *)(&_PLANE_MODE)) == 1) && (*((u8 xdata *)(&_PLANE_MODE+2)) == 1)) {
				if ((R2_BlockAddrL&0x03) == 2)
				{
					boundIndex = 1;
				}
			}
			power_up_set_bound();
			
			BlankBlockIndexL++;				
		}
	}
}


extern bit bFlashMode2;
void nf_power_up(void)
{
	_push_(PAGEMAP);
	_push_(DPCON);

	sfrpage(2);	
	DPCON = 0;

//prints("power up start. \n\n");
	
	NF_Cfg();
	
	NF_Init();
		
	bFlashRetryTimeOut = 0;

	ProgramCMD0 = NF_PAGE_PROGRAM_1; //�ϵ�Ĭ�Ϸ�0x80
	ProgramCMD1 = NF_PAGE_PROGRAM_2;  //�ϵ�Ĭ�ϲ���2plane���

	*((u8 xdata *)(&FirstValidZone)) = 0xff;
	bNeedRandomizer = 1;
	bNeedChkBlockPageModeIndex = 0;

	bSLC2TLCProg = 0;
	bNeedSend5DCMDSLC = 0;
	bNeedSend5DCMDTLC = 0;
	lastCmdProgPage = 0;
	bProgCacheBlockPageTrue = 0;
	bCopyBackNotOver = 0;
	
	SDBufBlockAddrH = 0xff;
	SDBufBlockAddrL = 0xff;
	SDBufPageAddr = 0;

	//��ʼ��ָ��
	BlankBlockIndexH = 0;
	BlankBlockIndexL = 0;
	
	ZoneLBA = 0xff;
	BBTIndex = 0xff;		
	Init_WrLg2phTable();

	BBTIndex = 0;
	bBlockMode = 0;
	chk_slcMode_switch();
	//Get_BBTBlock();

	Update_BBT();

	bch_initial();
	
#ifdef _8MXX_	
	NFIFO0_P2 = 0xBE ; 
	NPCON_P2 = 0x01;
	while( ! NTSKD){};
	_N_NOP_
	NTSKD = 0;
#endif	

	//��ʱ���Ƚ���,֮ǰ���Ե�ʱ���õ����Լ��Ĳ���
	if(*(u8 xdata *)(&_FLASH_TWOPLANEMODE) & 0x04){	  //4p	 
		*(u8 xdata *)(&_FLASH_TWOPLANEMODE) = 0x03; //��֧��4p,ת2p
	}
	if(_FLASH_TWOPLANEMODE & 0x01){
		*((u8 xdata *)(&_PLANE_MODE+0)) = 1;
	} 
	if(_FLASH_TWOPLANEMODE & 0x02){
		*((u8 xdata *)(&_PLANE_MODE+2)) = 1;
	}

	*(u16 xdata *)(&PLANE_REFERENCE + 0*4) = (u16)(&_Fill_Sec_Gap_P0);
	*(u16 xdata *)(&PLANE_REFERENCE + 1*4) = (u16)(&_Fill_Sec_Gap_P1);
	*(u16 xdata *)(&PLANE_REFERENCE + 2*4) = (u16)(&_Fill_Sec_Gap_P2);
	*(u16 xdata *)(&PLANE_REFERENCE + 3*4) = (u16)(&_Fill_Sec_Gap_P3);

	*(u16 xdata *)(&PLANE_REFERENCE + 0*4 + 2) = (u16)(&_PageLg2PhTable); ; 
	*(u16 xdata *)(&PLANE_REFERENCE + 1*4 + 2) = (u16)(&_PageLg2PhTable_SLC_Plane1); 
	*(u16 xdata *)(&PLANE_REFERENCE + 2*4 + 2) = (u16)(&_PageLg2PhTable_Plane2); 
	*(u16 xdata *)(&PLANE_REFERENCE + 3*4 + 2) = (u16)(&_PageLg2PhTable_Plane3); 

#ifdef _8MXX_
	*(u16 xdata *)((&MAP_BOUNDARY) + 0*2) = (u16)(_WrLg2phTableL + (WrLg2phTable_SIZE>>2)*3);
	*(u16 xdata *)((&MAP_BOUNDARY) + 1*2) = (u16)(_WrLg2phTableL + (WrLg2phTable_SIZE>>2)*2); 
	*(u16 xdata *)((&MAP_BOUNDARY) + 2*2) = (u16)(_WrLg2phTableL + (WrLg2phTable_SIZE>>2)*1); 
	
	if (1) {
		_push_(DPCON);
//ע�͵������ѷŵ�MP TOOL����		
		if (*((u8 xdata *)(&_PLANE_MODE+0))!= 0) {  //2p or 4p
			*((u8 xdata *)(&_FLASH_SECTORPERSMALLPAGE)) = *((u8 xdata *)(&_FLASH_SECTORPERSMLPAGEPLN1)) + *((u8 xdata *)(&_FLASH_SECTORPERSMLPAGEPLN2));				
			*((u16 xdata *)((&_ZoneLgBlockNumBuf) + 1 * 2)) = 0;
		}  //��BCM��sectorģ���ȸ�һ��	
			
		if (*((u8 xdata *)(&_PLANE_MODE+2))!= 0) {   //2p or 4p
			*((u8 xdata *)(&_FLASH_SECTORPERSMLPAGEPLN4)) = *((u8 xdata *)(&_FLASH_SECTORPERSMLPAGEPLN5)) + *((u8 xdata *)(&_FLASH_SECTORPERSMLPAGEPLN6));		
			*((u16 xdata *)((&_ZoneLgBlockNumBuf) + 3 * 2)) = 0;
		}
		
		DPCON = 0;	
		if (*((u8 xdata *)(&_PLANE_MODE+0))== 2) {  //4p
			*((u16 xdata *)((&_ZoneLgBlockNumBuf) + 2 * 2)) = 0;
		}	
		_pop_(DPCON); 

	}
	
#else 
	*(u16 xdata *)((&MAP_BOUNDARY) + 0*2) = (u16)(_WrLg2phTableL + (WrLg2phTable_SIZE>>1)*1);
	if (b2PlaneTrue) {
		*((u16 xdata *)((&_ZoneLgBlockNumBuf) + 1 * 2)) = 0;	
		#ifdef _HALFPAGE_
		*((u8 xdata *)(&_FLASH_SECTORPERSMALLPAGE)) = *((u8 xdata *)(&_FLASH_SECTORPERSMLPAGEPLN1)) + *((u8 xdata *)(&_FLASH_SECTORPERSMALLPAGE));				
		*((u16 xdata *)((&_ZoneLgBlockNumBuf) + 1 * 2)) = 0;
		*(u8 xdata *)(&_PLANE_MODE) = 1;
		b2PlaneTrue = 0;
		PlaneNum = 1;
		#endif
	}
#endif


	
	prints("MLC\n");
	
	*((u8 xdata *)(& Cur_ZoneLBA)) = 0xff;
	ZoneLBA = 0;
	while(1){
		if(*((u16 xdata *)((&_ZoneLgBlockNumBuf) + ZoneLBA * 2)) == 0){
			goto Chk_Zone_Again;	
		}	
		if (FirstValidZone == 0xff){
			*((u8 xdata *)(&FirstValidZone)) = ZoneLBA;					
		}
	

		Get_CurPlaneCfg();	

		BlockAddrTmpH = 0;
		BlockAddrTmpL = ZoneLBA;
		bound_slc_block();		
		SLC_Find_Reserved_Blocks();

		BlockAddrTmpH = 0;
		BlockAddrTmpL = ZoneLBA;
		Find_Reserved_Blocks();
		
		Update_Lg2phTableL();	
		
		Chk_Zone_Again:
		ZoneLBA++;
		if (ZoneLBA >= 4)
			break;
	}
	Fix_WritingBlockBuf();
	Fix_TimingBuf();
	Fix_Lg2PhTable();
	
	//��ʼ��SD BUF ������ʹ�� FirstValidZone
	INTIAL_SD_BUF_2_NF_USE_MAX_PAGE();
		
	//		;ȫ�ֱ�����ʼ��
	SWAPIndexTmp1 = 0xFF; 	//Ĭ�ϲ�ָ����Ǩĳ��
	CacheBlockLgPageNumH = 0;
	CacheBlockLgPageNumL = 0;
	RetryCnt = 0;
bFirstEnDecodeData = 0;
//	prints("power up end \n\n");
BlockLBAHTmp = 0xFF;
BlockLBALTmp = 0xFF;
PlanCopyBackNum = 0xFFFF;
#ifdef  SPI_MODE
DelayCopyCnt = 40;
#else 
DelayCopyCnt = 0;//��ʼ��
#endif 
 	_pop_(DPCON);
 	_pop_(PAGEMAP);	
	
}

static void Fix_Lg2PhTable(void)
{

}

static void Fix_TimingBuf(void)
{
	_push_(DPCON);
	DPCON = 0x00;
	
	for(SWAPIndex = 0; SWAPIndex != SWAP_SIZE; SWAPIndex++){
		
		Read_WritingBlockBuf();

	   	if(BlockLgAddrH == 0xff)
		{
		 	SwapBuf[SWAPIndex] = 0xFFFF;
		}
		else if((BlockLgAddrH * 0x100 + BlockLgAddrL) < 2)//�ļ�ϵͳ����
		{
			SwapBuf[SWAPIndex] = 0x01;//���ܳ�ʼ����0����Ϊupdate_timingbuf�и��������жϵ�cnt����0������cnt�����1
		}
		else
		{
			SwapBuf[SWAPIndex] = CacheBlockNextPagePhAddrH * 0x100 + CacheBlockNextPagePhAddrL;
		}
	}
	_pop_(DPCON);
}



void swap_old_new(void)
{
		if (NewBlockPhAddrH == 0xff)
		{
			bBlockMode = 1;
			Find_A_Blank_Block();
			NewBlockPhAddrH = BlockAddrTmpH;
			NewBlockPhAddrL = BlockAddrTmpL;					
		}	
		
	
		//ָ�򲻶ԣ�swap old new
		//new block update to mapping
		Updata_WrLg2phTable();
		//swap old new block
		BlockAddrTmpH = NewBlockPhAddrH;
		BlockAddrTmpL = NewBlockPhAddrL;
		
		NewBlockPhAddrH = OldBlockPhAddrH;
		NewBlockPhAddrL = OldBlockPhAddrL;
		
		OldBlockPhAddrH = BlockAddrTmpH;
		OldBlockPhAddrL = BlockAddrTmpL;
}



/****************************************
old new--->old is old,new is new
old	x  --->old is old
x		new--->old is new 
*****************************************/
static void Fix_WritingBlockBuf(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����

	for(SWAPIndex = 0; SWAPIndex != SWAP_SIZE; SWAPIndex++){
		Read_WritingBlockBuf();	
	
		if(BlockLgAddrH != 0xff){
		
				BlockLBAH = BlockLgAddrH;
				BlockLBAL = BlockLgAddrL;
				Get_ZoneLBA();		//  ���豣��ZoneLBA����ز���
				Get_CurPlaneCfg();
				Get_OldBlockPhAddr();
		
//				bBlockMode = 1;	 //TLC
//				R3_BlockAddrH = OldBlockPhAddrH;
//				R2_BlockAddrL = OldBlockPhAddrL;  //2PʱΪ��block
//				get_bound_block();
//				R1_Sector = 0;		
//				R4_PageAddrH = 0;
//				R0_PageAddrL = 0;
//				DataCoDecKeyIndex=0;
//				bNeedRetryTrue = 0;//0;
//				PowerUp_Read_Sector();
//				if(!bReadBlankBlock)	
//				{
//cache
//{
//old--->cache can point
//new--->cache can point any one.
//old new---->cache can point
//blank old
//none block
//}
//cache decide

//old new
//{
//old new all full,no exist when normal powerDown
//old new,one full decide
//old new,all not full,point decide
//}

//		if (OldBlockPhAddrH != 0xff)
		{
						//no new,have cache (old), check cache
						bBlockMode = 0;//SLC read
						R4_PageAddrH = 0;
						R0_PageAddrL = 0;
						Get_CacheBlock_Addr(); //����R4 R0��������Ҫ���ʵ�Block��ַ��R3 R2����WL��ַ��R0����stage��ַ��R4��
						if (R3_BlockAddrH != 0xff) { //cache decide
							
							
						} else {	//old new decide

							bBlockMode = 1;	 //TLC
							R3_BlockAddrH = OldBlockPhAddrH;
							R2_BlockAddrL = OldBlockPhAddrL;  //2PʱΪ��block
							get_bound_block();
							R1_Sector = 0;		
							R4_PageAddrH = (LargePagePerBlockH*0x100+LargePagePerBlockL-1) >> 8;
							R0_PageAddrL = (LargePagePerBlockH*0x100+LargePagePerBlockL-1) & 0xFF;
							DataCoDecKeyIndex=0;
							bNeedRetryTrue = 0;//0;
							PowerUp_Read_Sector();
							if(!bReadBlankBlock)				
							{
								goto end;
							}
							
							bBlockMode = 1;	 //TLC
							R3_BlockAddrH = NewBlockPhAddrH;
							R2_BlockAddrL = NewBlockPhAddrL;  //2PʱΪ��block
							get_bound_block();
							R1_Sector = 0;		
							R4_PageAddrH = (LargePagePerBlockH*0x100+LargePagePerBlockL-1) >> 8;
							R0_PageAddrL = (LargePagePerBlockH*0x100+LargePagePerBlockL-1) & 0xFF;
							DataCoDecKeyIndex=0;
							bNeedRetryTrue = 0;//0;
							PowerUp_Read_Sector();
							if(!bReadBlankBlock)				
							{
								swap_old_new();
								goto end;
							}
							
							//old new is not full,point decide
						}
						
						R1_Sector = 2;		
						R4_PageAddrH = 0;
						R0_PageAddrL = 0;
						DataCoDecKeyIndex=0;
						bNeedRetryTrue = 0;//0;
						PowerUp_Read_Sector();
						
						
						DPCON = 0;		
						if ((XBYTE[_SPARE_AREA_BUF + 1] != OldBlockPhAddrH) || 
								(XBYTE[_SPARE_AREA_BUF + 2] != OldBlockPhAddrL))		
						{
							swap_old_new();
						}
						DPCON = 0x10;			//DPTR0����
	
		
				}
		end:		
		
				//new-->old,cache
				Fix_OldBlock_NewBlock_CacheBlock();	
		}


		Write_WritingBlockBuf();			
	}
   	_pop_(DPCON);


}

static void Fix_OldBlock_NewBlock_CacheBlock(void)
{	
	Update_NewBlockNextPagePhAddr();	
	Update_CacheBlockNextPagePhAddr();	
}

static void Update_CacheBlockNextPagePhAddr(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����


	CacheBlockNextPagePhAddrL = 0;
	while(1){
	   	if( *((u8 xdata *)((_WritingBlockBuf + CacheBlockPhAddrH_INDEX) + (SWAPIndex * WritingBlockBuf_SIZE) + (CacheBlockNextPagePhAddrL * 2))) != 0xff){
			OrderAddr = CacheBlockNextPagePhAddrL;	 // ��ʱ��OrderAddr��ʾ���һ����Чcache block��λ��
		}
		CacheBlockNextPagePhAddrL++;
		if(CacheBlockNextPagePhAddrL == (u8)(PageGroupNumber + 2 + PageGroupNumber)){
			break;
		}		
	}
//OrderAddr��Чcache����
	CacheBlockNextPagePhAddrH = 0;
	CacheBlockNextPagePhAddrL = 0;	
	while(1){

		R4_PageAddrH = CacheBlockNextPagePhAddrH;
		R0_PageAddrL = CacheBlockNextPagePhAddrL;
		Get_CacheBlock_Addr(); //����R4 R0��������Ҫ���ʵ�Block��ַ��R3 R2����WL��ַ��R0����stage��ַ��R4��
		
		CopyWLNumber = SpareArea2; //��ʱ��CopyWLNumber
		
		if(R3_BlockAddrH == 0xff){
			if(CopyWLNumber >= OrderAddr){
				break;
			}
		}else{
		//��ȡBlockAddrTmpH/L sector1��������
		R1_Sector = 1; //sector 1
		DataCoDecKeyIndex=0;//Ĭ��   //��retry,����û��ϵ
		bNeedRetryTrue = 0;//SLC����ʱ����retry
		bBlockMode = 0;//SLC read

		PowerUp_Read_Sector();
		DataCoDecKeyIndex = XBYTE[_SPARE_AREA_BUF + 0];

			R1_Sector = 1; //��һ��sector���¹���pageӳ��,��0��sector���¹���blockӳ��
			bBlockMode = 0; //SLC
			bNeedRetryTrue = 1;

//yScrtyUnitCnt = 100;
			PowerUp_Read_Sector();	
			SpareAreaH &= LG_ADDR_MAX_H;
			if(bReadBlankBlock == 1){//(bTerribleError){//����������δ�������ʱ�����ַ�ʽ�ж�
				if(CopyWLNumber == OrderAddr){
					break;
				}
			}else{

if(((NewBlockPhAddrH*0x100+NewBlockPhAddrL) >= 0xFFFF) || ((SpareAreaH * 0x100 + SpareAreaL)>=CacheLgPage))				
{
//prints("True");

				Get_PagePh2LgTable_StartAddr();	
				ER01 = SpareAreaH; 
				ER00 = SpareAreaL;
				ER11 = CacheBlockNextPagePhAddrH;
				ER10 = CacheBlockNextPagePhAddrL;
				Set_Page_PhAddr();
}
//prints("\n");

			}
		}
		//Update_CacheBlockNextPagePhAddr_Again
		CacheBlockNextPagePhAddrL++;

		if( !CacheBlockNextPagePhAddrL){
			CacheBlockNextPagePhAddrH++;	
		}
//		ER01 = 0;
//		ER00 = 7 + 1;
//		ER03 = 0;
//		ER02 = WordLineNumber;
//		#pragma asm
//		MUL16_ER0
//		#pragma endasm
//		if((CacheBlockNextPagePhAddrL == ER00) && (CacheBlockNextPagePhAddrH == ER01)){//�̶�ȥ��8��cache block
//			break;
//		}	
		if((CacheBlockNextPagePhAddrL == CacheBlockMaxPageL) && (CacheBlockNextPagePhAddrH == CacheBlockMaxPageH)){//�̶�ȥ��8��cache block
prints("brk\n")	;			
			break;
		}	
	}
	_pop_(DPCON);
}

extern u8 data yScrtyUnitCnt;
static void Update_NewBlockNextPagePhAddr(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����


if((NewBlockPhAddrH*0x100+NewBlockPhAddrL) < 0xFFFF)
{
  CacheLgPage = 0;

	while(1){			
		bBlockMode = 1;//SLC read
		R3_BlockAddrH = NewBlockPhAddrH;
		R2_BlockAddrL = NewBlockPhAddrL;

//		R3_BlockAddrH = NewBlockPhAddrH;
//		R2_BlockAddrL = NewBlockPhAddrL;
		R4_PageAddrH = CacheLgPage >> 8;
		R0_PageAddrL = CacheLgPage & 0xFF;
		R1_Sector = 0; //sector 0
		DataCoDecKeyIndex=0;//Ĭ��
		bNeedRetryTrue = 0;

		PowerUp_Read_Sector();

		if(!bReadBlankBlock)
		{
//prints("gg\n");	
//printHexSync(R0_PageAddrL);			
			Get_PagePh2LgTable_StartAddr();	
			ER01 = CacheLgPage >> 8;
			ER00 = CacheLgPage & 0xFF;

			ER11 = 0x0e;  //�޸�����
			ER10 = 0xFF;
			Set_Page_PhAddr();
			CacheLgPage++;
		}
		else
		{
			break;
		}

		if(CacheLgPage == (LargePagePerBlockH * 0x100 + LargePagePerBlockL)){//���������ж�
			break;
		}	
		}		
}
else
{
		CacheLgPage = 0xFFFF;
}
	_pop_(DPCON);

//prints("new:");
//printHexSync(R3_BlockAddrH);
//printHexSync(R2_BlockAddrL);
//printHexSync(CacheLgPage>>8);
//printHexSync(CacheLgPage);
//prints("\n");
}

static void Init_WrLg2phTable(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����

	DPTR0 = 0xC000; //�豣֤�߼������ǿ�load��������0xff
	#pragma asm
	CLR32_ER1
	CLR32_ER0
	NOT32_ER0
	#pragma endasm
	ER11 = (u8)(((_EndBuf - 0xC000)/16) >> 8);;//(u8)(Lg2phTable_SIZE >> 8);
	ER10 = (u8)(((_EndBuf - 0xC000)/16) >> 0);;//(u8)(Lg2phTable_SIZE >> 0);
	do{
		#pragma asm
		MOV32_EDP0_ER0
		MOV32_EDP0_ER0
		MOV32_EDP0_ER0
		MOV32_EDP0_ER0
		DEC32_ER1
		#pragma endasm
	}while( ! EZ);
	
	_pop_(DPCON);
}

static void PowerUp_Read_Sector(void)
{
	_push_(DPCON);
 	DPCON = 0x10;			//DPTR0����
	RetryCnt = 0;
	
	while(1){

		unsigned char tmp = R1_Sector;

		B = R1_Sector;
		if(bBlockMode == 1)//TLC��Ҫretry��ʱ�򣬶���page��Ϊlg 0������Ҳ��Ϊ0������ʱ���ݲ���retry����ΪĿ��ֻ��Ϊ���ж��Ƿ�Ϊ��FF
		{
			DataCoDecKeyIndex = 0;//tlc��������Զ=0����
		}

		DataCoDecKeyIndex1 = B;
		R8Tmp = _PowerUp_ReadBuf_INDEX;
		NF_Read_Start();
		NF_Read_Data();
		NF_Wait_Read_Over();	

		Chk_Blank_Block();

		BCH_MODE_DC_Wait_Over();
		DataCoDecKeyIndex++;

	    DPCON = 0x00;			//DPTR0������
		SpareAreaL = XBYTE[_SPARE_AREA_BUF + 0];
		SpareAreaH = XBYTE[_SPARE_AREA_BUF + 1];
		SpareArea2 = XBYTE[_SPARE_AREA_BUF + 2] & CACHE_BLOCK_TOTAL_NUM_MAX;

  		DPCON = 0x10;			//DPTR0����
		R1_Sector = tmp;
		if(bReadBlankBlock){
			SpareAreaH = 0xFF;
			SpareAreaL = 0xFF;
			SpareArea2 = CACHE_BLOCK_TOTAL_NUM_MAX;	
		}

		if(/* (! bNeedRetryTrue) || */bReadBlankBlock){

//prints("blank:");
//printHexSync(R3_BlockAddrH);
//printHexSync(R2_BlockAddrL);
//prints("\n");
			
//			bLg2PhVerifyError = 0;
			break;
		}

		if(! bNeedRetryTrue){
//prints("No need retry:");
//prints("\n");
			break;
		}

		Chk_Need_Retry(); //��ʱ�ص��ϵ��retry
		if( ! bLg2PhVerifyError){
			if(RetryCnt > 0)
			{
			_push_(DPCON);
			DPCON = 0;
//			prints("Retry1:");
//			printHexSync(RetryCnt>>8);
//			printHexSync(RetryCnt&0xff);
//			printHexSync(DataCoDecKeyIndex>>8);
//			printHexSync(DataCoDecKeyIndex&0xff);	
//			prints("\n");
////			prints("R3,R2,SpareAreaL,SpareAreaH,SpareArea2:");
////			printHexSync(BlockAddrTmpH>>8);
//			printHexSync(BlockAddrTmpH&0xff);
////			printHexSync(BlockAddrTmpL>>8);
//			printHexSync(BlockAddrTmpL&0xff);	
////			printHexSync(SpareAreaL>>8);
//			printHexSync(SpareAreaL&0xff);	
////			printHexSync(SpareAreaH>>8);
//			printHexSync(SpareAreaH&0xff);	
////			printHexSync(SpareArea2>>8);
//			printHexSync(SpareArea2&0xff);	
//			prints("\n");
							
			_pop_(DPCON);
			}			

			break;
		}			
	}
	_pop_(DPCON);
}

static void Chk_Need_Retry(void)
{
	_push_(DPCON);
 	DPCON = 0x10;			//DPTR0����

#if	RETRY_EN
#else
	RetryCnt = 0;
	bLg2PhVerifyError = 0; //bTerribleError
#endif
	
	if( ! bLg2PhVerifyError){
		if(RetryCnt){  //������ȷ����retry��
//			RetryCnt = 0;
			bLg2PhVerifyError = 0;	//���ڿ��ƣ���ǰsector����������ȷ������retry
		}	
	}else{			//����ʧ��
	
if ((!FlashReTryType) && (!RetryCnt))
{	
	RetryCnt = RETRY_NUBER;//û��retry��ֻretry 1��
}

		RetryCnt++;


		if(RetryCnt != (RETRY_NUBER+1)){//retry 256�Σ����߼���ַ����һ��	
			bRetryBlockMode = bBlockMode;
			Set_Retry_Register_Data();	
		}else{			//Chk_Need_Retry_GiveUp
			bLg2PhVerifyError = 0;	//���ڿ��ƣ���ǰsector����������ȷ������retry		
		}

	}
	_pop_(DPCON);
}

#define		BBT_LENGTH_SECTOR		528//(440 + 7 + 2 + 2 + 77)

static void Get_BBTBlock(void)
{
	_push_(DPCON);

	DPCON = 0;

	prints("BBT ECC:");
	prints("\n");
	BTSEL_P2 = 46;
	BCON1_P2 |= BIT(2);					//cal encode polynomial.
	while(!(BTSEL_P2 & BIT(7))) {}	
	BCON1_P2 = 0;

	BBTBlockIndex = 0;
	do{
	    DPTR0 = (u16)(&_BadBlockAddrTable);
		DPCON = 0x10;			//DPTR0����
		#pragma asm
		MOV		B,BBTBlockIndex//0 or 1
		MOV		A,#(7*8)//���֧��16k��block����8��bbt sector
		CALL	dptr_add_ab_maskrom
		MOV		B,BBTIndex//=0~7
		MOV		A,#7
		CALL	dptr_add_ab_maskrom
		MOVX	A,@DPTR
		MOVX	A,@DPTR
		MOVX	A,@DPTR
		MOV		ER00,A					
		MOVX	A,@DPTR
		MOV		ER01,A					
		MOVX	A,@DPTR
		MOV		ER02,A					
		MOVX	A,@DPTR
		MOV		ER03,A					
		MOVX	A,@DPTR
		MOV		ER10,A	
		#pragma endasm
		DPCON = 0;
		
#if 1//DIS_NF_FUNCTION
//		NXADR1 = (u8)((_BadBlockTable / 4) >> 8);
//		NXADR1 = (u8)((_BadBlockTable / 4) >> 0);
//		BXADR1 = (u8)((_BadBlockTable / 4) >> 8);
//		BXADR1 = (u8)((_BadBlockTable / 4) >> 0);
//		BXADR2 = (u8)(((((BBT_LENGTH_SECTOR - 1) / 4) + (_BadBlockTable / 4))) >> 8);
//		BXADR2 = (u8)(((((BBT_LENGTH_SECTOR - 1) / 4) + (_BadBlockTable / 4))) >> 0);

		NXADR2_P2 = _BadBlockTable;
#endif		

		bTerribleError = 0;
	
		NF_Read_BadBlockTable();

		DPCON = 0x10;			//DPTR0����
		DPTR0 = _BadBlockTable + 440;
		#pragma asm
//		MOV		DPTR,#(_BadBlockTable + 440)
		MOVX	A,@DPTR
		MOVX	A,@DPTR
		MOVX	A,@DPTR
		MOV		ER00,A					
		MOVX	A,@DPTR
		MOV		ER01,A					
		MOVX	A,@DPTR
		MOV		ER02,A					
		MOVX	A,@DPTR
		MOV		ER03,A					
		MOVX	A,@DPTR
		MOV		ER10,A
		#pragma endasm
		DPCON = 0;
			
#if 1//DIS_NF_FUNCTION	
//		NXADR1 = (u8)(((_BadBlockTable + 440) / 4) >> 8);
//		NXADR1 = (u8)(((_BadBlockTable + 440) / 4) >> 0);
//		BXADR1 = (u8)(((_BadBlockTable + 440) / 4) >> 8);
//		BXADR1 = (u8)(((_BadBlockTable + 440) / 4) >> 0);
//		BXADR2 = (u8)(((((BBT_LENGTH_SECTOR - 1) / 4) + ((_BadBlockTable + 440) / 4))) >> 8);
//		BXADR2 = (u8)(((((BBT_LENGTH_SECTOR - 1) / 4) + ((_BadBlockTable + 440) / 4))) >> 0);

		NXADR2_P2 = _BadBlockTable + 440;
#endif
		NF_Read_BadBlockTable();

		BBTBlockIndex++;
		if(BBTBlockIndex == 2){
			break;
		}
	}while(bTerribleError);

//	prints("read bbt end,  BBTBlockIndex:");
//	printHexSync(BBTBlockIndex);
//	Uart_Send_Byte('\n');
//while(1);

	_pop_(DPCON);
}

static void NF_Read_BadBlockTable(void)
{

	chk_slcMode_switch();

		
#if 1//DIS_NF_FUNCTION	
//	NXCNT0 = 0;
//	NXCNT0 = 0;
	NXCNT0_P2 = 0;
	NXCNT1_P2 = 0;
	
	NPGSZ1_P2 = (u8)(BBT_LENGTH_SECTOR >> 8);
	NPGSZ0_P2 = (u8)(BBT_LENGTH_SECTOR >> 0);


	BPSZ_P2 = BBT_LENGTH_SECTOR;

 
////[6]: 1-data from nfc; 
////[5:4]:0-idle; 1-encode; 2-decode.
////[1]: 0-hardware auto error correct
////[0]: kict start	
	BCON1_P2 = BIT(6) | BIT(5) | BIT(0);		//data from nfc, decode, hardware auto error correct, kict start.
		
#endif	

//	NFIFO6_P2 = NF_READ_2ND;		//;command 1 = 0x30 (start read)
	NACMD1_P2 = NF_READ_2ND;		//;command 1 = 0x30 (start read)
	NFIFO5_P2 = ER00;
	NFIFO4_P2 = ER01;
	NFIFO3_P2 = ER02;
	NFIFO2_P2 = ER03;
	NFIFO1_P2 = ER10;
	NFIFO0_P2 = NF_READ_1ST;
	NPCON_P2 = 0xD1;
	while( ! NTSKD){};
	_N_NOP_
	NTSKD = 0;


	NFIFO3_P2 = NF_RANDOM_DATA_OUTPUT_2;
	NFIFO2_P2 = ER03;
	NFIFO1_P2 = ER10;
	NFIFO0_P2 = NF_RANDOM_DATA_OUTPUT_1;
	NPCON_P2 = 0x27;
	while( ! NTSKD){};
	_N_NOP_
	NTSKD = 0;

#if 1//DIS_NF_FUNCTION
//	bTerribleError = 0;
	while(! (BCON0_P2 & (1 << 7))){}
//	prints("read bbt data ecc correct completely.\n\n");
//	printf("BCON0_P2 = 0x%x\n\n", (int)BCON0_P2);
	
     if((BCON0_P2 & (1 << 5))){	//has err

//		prints("ecc has err !!!\n\n");
	
		if((BCON0_P2 & (1 << 6))){	//too much err

//			prints("ecc too much err.!!!!!!!!!!!!!!!!!!!!!!!\n\n");		
			
			bTerribleError = 1;
		}else{
		
//			prints("ecc  err bits:");
//			printHexSync(BECNT_P2);
//			Uart_Send_Byte('\n');
		}
	}else{	//no err	
//		prints("ecc no err.\n\n");
	}
	
//	BCTL0 &= ~(1 << 7);
//	BCTL1 &= 0X7F;
//	GPDMACON = 0x08;
	BCON0_P2 &= ~(1 << 7);		//clr done.
#endif	
}


void SLC_Find_Reserved_Blocks(void)
{
	u16 idata blank_blk_cnt;
	u16 idata cache_blk_cnt;
	u16 idata unknown_blk_cnt;
	u16 idata sd_buf_blk_cnt;
	
	blank_blk_cnt = 0;
	cache_blk_cnt = 0;
	unknown_blk_cnt = 0;
	sd_buf_blk_cnt = 0;

	_push_(DPCON);
 	DPCON = 0x10;			//DPTR0����
	BlankBlockIndexH = 0;
	BlankBlockIndexL = 0;
	while (1) 
	{		
		DPTR0 = (u16)(SLC_BLOCK_TABLE+128*ZoneLBA);	//slc plane1
	#pragma asm	
		MOV		B,BlankBlockIndexL
		MOV		A,#2	
		CALL	dptr_add_ab_maskrom
		CLR32_ER0
		MOVX	A,@DPTR				//2 byte
		MOV		ER01,A
		MOVX	A,@DPTR
		MOV		ER00,A
	#pragma endasm

		if (ER01 == 0xFF) 	//find end,��ȡ���ܳ���63��block
			break;

		BlockAddrTmpH = ER01;
		BlockAddrTmpL = ER00;
	
 		Get_Seed();//SpareAreaL = XBYTE[_SPARE_AREA_BUF + 0];		
		DataCoDecKeyIndex = XBYTE[_SPARE_AREA_BUF + 0];

		//��ȡBlockAddrTmpH/L sector0��������	
		R3_BlockAddrH = BlockAddrTmpH;
		R2_BlockAddrL = BlockAddrTmpL;	

		R4_PageAddrH = 0; //tlc stage
		R0_PageAddrL = 0; //wl 
		R1_Sector = 0; //sector 0

		bNeedRetryTrue = 1;//1;	//???
		bBlockMode = 0;//SLC read				
		PowerUp_Read_Sector();
		
//Uart_Send_Byte('B');
//printHexSync(SpareAreaL);	
//printHexSync(SpareAreaH);
//printHexSync(SpareArea2);		
//Uart_Send_Byte('\n');			

		if (!bTerribleError)
		{ 	//not blank block
Uart_Send_Byte('Q');
printHexSync(SpareAreaH);//Find_DATA_CACHE_BLOCK������ı���Щֵ
printHexSync(SpareAreaL);
printHexSync(SpareArea2);
printHexSync(R3_BlockAddrH);	
printHexSync(R2_BlockAddrL);
Uart_Send_Byte('\n');	
/*
slc block:
		1:cache DATA_CACHE_BLOCK 
		2:sd buf OTHER_BLOCK
		3:blank block
*/			
			B = SpareAreaH & OTHER_BLOCK;	//��ȡblock����
			SpareAreaH &= LG_ADDR_MAX_H;	//��ȡblockӳ��

			if (B == DATA_CACHE_BLOCK	){  //0x80
				cache_blk_cnt++;
				Find_DATA_CACHE_BLOCK();		
			} else if (B == OTHER_BLOCK){		//0xc0
				if (SDBufBlockAddrH != 0xFF)	//������ҵ�SD BUF�µĵ��տ鴦��
				{
					goto SLC_BLANK_BLOCK_Task;		
				}	
				sd_buf_blk_cnt++;
				SDBufBlockAddrH = BlockAddrTmpH;
				SDBufBlockAddrL = BlockAddrTmpL;
//Uart_Send_Byte('S');
//	printHexSync(SpareAreaH);
//	printHexSync(SpareAreaL);
//	printHexSync(SpareArea2);
//		
//printHexSync(BlockAddrTmpH);	
//printHexSync(BlockAddrTmpL);
//Uart_Send_Byte('\n');	
			} else {

//	Uart_Send_Byte('s');
//	Uart_Send_Byte('U');
//	printHexSync(R3_BlockAddrH);
//	printHexSync(R2_BlockAddrL);	
//	printHexSync(SpareAreaH);
//	printHexSync(SpareAreaL);
//	Uart_Send_Byte('\n');				

				unknown_blk_cnt++;
//				Write_a_Block_Over();  	
				goto SLC_BLANK_BLOCK_Task;
			}
		} else {
			blank_blk_cnt++;
			
SLC_BLANK_BLOCK_Task:	
		#pragma asm
				CLR32_ER0
				MOV 	ER01,#(_BlankBlockTable>>8)//���¿տ��
				MOV 	ER00,#(_BlankBlockTable&0xff)
				CLR32_ER1
				MOV		A,ZoneLBA
				MOV		B,#((SLC_BLANK_MAX+BLANK_MAX)*3/2)
				MUL		AB		//[ slc / tlc ]
		//���֧������zone
				MOV 	ER11,B
				MOV 	ER10,A
				ADD32_ER0_ER0_ER1		//���㵱ǰzone��ƫ��
		#pragma endasm
				DP0H = ER01;
				DP0L = ER00;

				ER03 = 0;
				ER02 = 0;
				ER01 = 0;
				//CLR32_ER0
				ER00 = BlankBlockIndexH;	//blank block index
				ER11 = BlockAddrTmpH;
				ER10 = BlockAddrTmpL;	
				Set_Block_PhAddr();		//���֧��72 * (2/3) = 48��	

				BlankBlockIndexH++; //SLC cache�¼�¼�տ���  //SLC blank block num + 1
		}			
			BlankBlockIndexL++;
	}	
				

//SLC_Find_Reserved_Blocks_End:
//��ʼ��SLC find,markָ��
		DPTR0 = (u16)(_BlankBlockIndexBuf);
	//_BlankBlockIndexBuf[zonelba][2][2][4] = [zonelba]{slc,tlc}{find,mark}[4] = {index,fullIndex,addrH,addrL}
		B = ZoneLBA<<1;
		B <<= 3;
		ACC = 1;
		DPTR_Add_AB	();
	
	#pragma asm
		MOV 	A,#0							//find cnt
		MOVX	@DPTR,A 
		MOV 	A,#SLC_BLANK_MAX  //max find cycle
		MOVX 	@DPTR,A
	
		//����find addr
		CLR32_ER0
		CLR32_ER1
		MOV 	ER01,#(_BlankBlockTable>>8)//���¿տ��
		MOV 	ER00,#(_BlankBlockTable&0xff)
		MOV		A,ZoneLBA	
		MOV		B,#((SLC_BLANK_MAX+BLANK_MAX)*3/2)
		MUL		AB
		//���֧������zone
		MOV 	ER11,B
		MOV 	ER10,A
		ADD32_ER0_ER0_ER1	  
		MOV		A,ER01		
		MOVX	@DPTR,A
		MOV		A,ER00
		MOVX	@DPTR,A     			//mark base addr(fix) 
		//ͬʱ����mark index
		MOV		A,BlankBlockIndexH  //mark cnt
		MOVX	@DPTR,A
		MOV		A,#SLC_BLANK_MAX  	//mark cycle
		MOVX	@DPTR,A
		MOV 	A,ER01
		MOVX	@DPTR,A
		MOV 	A,ER00
		MOVX	@DPTR,A							//mark base addr(fix)
	#pragma endasm		//���㵱ǰzone��ƫ��
	

/*
[zonelba][2][8]=
{
	FIND INDEX,
	48,
	high(_BlankBlockTable+ high(ZoneLBA*2*72)		
	low(_BlankBlockTable+ high(ZoneLBA*2*72))
}
*/

#if 0		

	DPCON = 0;
#if 0//BAUDRATE
//	prints("\nslc");
	prints("\nblank block:");
	printHexSync(blank_blk_cnt>>8);
	printHexSync(blank_blk_cnt&0xff);
//	prints("\ncache:");
//	printHexSync(cache_blk_cnt>>8);
//		printHexSync(cache_blk_cnt&0xff);
	prints("\nu know:");
	printHexSync(unknown_blk_cnt>>8);
		printHexSync(unknown_blk_cnt&0xff);
//	prints("\nsd buf:");
//	printHexSync(sd_buf_blk_cnt>>8);
//		printHexSync(sd_buf_blk_cnt&0xff);
	Uart_Send_Byte('\n');
#endif
//	printf("sd buf blk cnt  \n\n");
//	printf("slc total blk of ZONE %d:%d \n\n",	ZoneLBA, blank_blk_cnt);
//	printf("blank blk cnt   : 0x%x \n\n", blank_blk_cnt);
//	printf("cache blk cnt   : 0x%x \n\n", cache_blk_cnt);
//	printf("unknown blk cnt : 0x%x \n\n", unknown_blk_cnt);
//	printf("sd buf blk cnt  : 0x%x \n\n", sd_buf_blk_cnt);
#endif

	_pop_(DPCON);
}

static void Get_Seed(void)
{
		//��ȡBlockAddrTmpH/L sector1��������
		R4_PageAddrH = 0; //tlc stage
		R0_PageAddrL = 0; //wl 
		R3_BlockAddrH = BlockAddrTmpH;
		R2_BlockAddrL = BlockAddrTmpL;		
		R1_Sector = 1; //sector 1
		DataCoDecKeyIndex=0;//Ĭ��
		bNeedRetryTrue = 0;
		bBlockMode = 0;//SLC read
		PowerUp_Read_Sector();

}



u8 code BoundPlane_tmp[6];
static void Find_Reserved_Blocks(void)
{
	u16 idata blank_blk_cnt;
	u16 idata unknown_blk_cnt;
	u16 idata data_blk_cnt;
	u16 idata Unkown_Index;
	u16 idata good_blk;
	u16  idata BoundPlane1;
	u8 data planeMode, cnt;
	
	planeMode = *((u8 xdata *)(&_PLANE_MODE+ZoneLBA));
	
	blank_blk_cnt = 0;
	unknown_blk_cnt = 0;
	data_blk_cnt = 0;
	BlankBlockIndexL = 0;
	BlankBlockIndexH = 0;		//����tlc�տ���
#ifdef _8MXX_
	BoundPlane1 = ZoneLBA +1 -4;
#else 
	BoundPlane1 = 0xffff;
#endif	
	
	good_blk = 0;
	
	_push_(DPCON);
 	DPCON = 0x10;			//DPTR0����
	
	do{
		cnt = 0;
	
		ER01 = BlockAddrTmpH;
		ER00 = BlockAddrTmpL;
		ER03 = 0;
		ER02 = 0;
		DPTR0 = _BadBlockTable;
		Addr_Block2Bit();
		#pragma asm
		MOVX	A,@DPTR	
		ANL		A,ER10
		#pragma endasm
		if(ACC){  //good block
good_blk++;	
			
			if (planeMode) {	//good block	
				
//	if (!b2pSymmetryDatBlk) {			
				
	while(1) {
#ifdef _8MXX_					
		BoundPlane1 += 4; 
#else 
		BoundPlane1 += 2; 
#endif					
		ER01 = BoundPlane1>>8;
		ER00 = BoundPlane1;
		ER03 = 0;
		ER02 = 0;		

		ER11 = (u8)(ZonePhBlockNum >> 8);
		ER10 = (u8)(ZonePhBlockNum >> 0);
		ER13 = 0;
		ER12 = 0;
		#pragma asm
		SUB32_ER1_ER0_ER1
		#pragma endasm			
				
		if (!EC) {  //p1�����������С��д�뻵����ܺ���ZonePhBlockNum��Χ������block��
			goto find_res_end;
		}
		
		DPTR0 = _BadBlockTable;
		Addr_Block2Bit();
		#pragma asm
		MOVX	A,@DPTR
		ANL		A,ER10
		#pragma endasm
		if(ACC){  //good block
			break;
		}
	
			}
//	}	else {
//		BoundPlane1 = BlockAddrTmpH*0x100 + BlockAddrTmpL+1;
//	}
				
				
								
			R3_BlockAddrH	= BlockAddrTmpH;
			R2_BlockAddrL	= BlockAddrTmpL;
			boundIndex = 0;
			if ((*((u8 xdata *)(&_PLANE_MODE)) == 1) && (*((u8 xdata *)(&_PLANE_MODE+2)) == 1)) {
				if ((R2_BlockAddrL&0x03) == 2)
				{
					boundIndex = 1;
				}
			}
			R3_BlockAddrH_P1	= BoundPlane1>>8;
			R2_BlockAddrL_P1	= BoundPlane1;					
			power_up_set_bound();	
	
				
			boundIndex++;
			cnt++;
	#if BAUDRATE			
	#if PRINT_BOUND_BLOCK
	prints("B:");
	printHexSync(BlockAddrTmpH);
	printHexSync(BlockAddrTmpL);
	printHexSync(BoundPlane1>>8);
	printHexSync(BoundPlane1);				
	prints("\n");
	#endif
	#endif					
	
		
			}
		
		
			R4_PageAddrH = 0;//stage
			R3_BlockAddrH = BlockAddrTmpH;
			R2_BlockAddrL = BlockAddrTmpL;  //2PʱΪ��block
			R1_Sector = 0;
			R0_PageAddrL = 0;
			DataCoDecKeyIndex=0;
			
			bNeedRetryTrue = 1;//0;
			bBlockMode = 1;	 //TLC
			PowerUp_Read_Sector();

			if(bReadBlankBlock)	//blank block
			{
				goto Find_TLC_Blank_Block;	
			}

			if(bLg2PhVerifyError/*bTerribleError*/){		//���ǳ������ǿտ�				

//			prints("error:");
//  			prints("\n");

					unknown_blk_cnt++;
					Unkown_Index = 1;
					goto  Find_UnKnown_Block;						
//						goto Find_TLC_Blank_Block;
			}//TLC error

			//tlc right,other block
			B = SpareAreaH & OTHER_BLOCK;		//block character
			SpareAreaH &= LG_ADDR_MAX_H;		//block mapping
			if( B == DATA_BLOCK){												//data block
				data_blk_cnt++;
			
			                                      
//R3_BlockAddrH = BlockAddrTmpH;
//R2_BlockAddrL = BlockAddrTmpL;
//NF_Erase_Block();	
			
//	Uart_Send_Byte('T');
//	Uart_Send_Byte('U');
//	printHexSync(R3_BlockAddrH);
//	printHexSync(R2_BlockAddrL);	
//	printHexSync(SpareAreaH);
//	printHexSync(SpareAreaL);
//	Uart_Send_Byte('\n');				
			
				
				Find_DATA_BLOCK();	
				goto	Deal_Block_Next;
			}
Find_UnKnown_Block:	
//			Write_a_Block_Over();		//����û���,��call
#if REDUCE_ERASE_NEW
			bBlockMode = 1;
			R3_BlockAddrH	= BlockAddrTmpH;
			R2_BlockAddrL	= BlockAddrTmpL;
			
			R3_BlockAddrH_P1	= BoundPlane1>>8;
			R2_BlockAddrL_P1	= BoundPlane1;					

			NF_Erase_Block();
#endif			
Find_TLC_Blank_Block:			
			blank_blk_cnt++;	
			DPTR0 = (u16)(_Lg2PhTableTmp); //�ϵ���ʱ����տ���������
			ER01 = BlankBlockIndexH;
			ER00 = BlankBlockIndexL;	
			ER11 = BlockAddrTmpH;
			ER10 = BlockAddrTmpL;	
			Set_Block_PhAddr();					//����ӳ���
			BlankBlockIndexL++;
			if (BlankBlockIndexL == 0) {
				BlankBlockIndexH++;	
			}	//����TLC�տ���
//		  Mark_A_Blank_Block();							
		}
Deal_Block_Next:						
		// Find_Reserved_Blocks_Again:
#ifdef _8MXX_
		ER01 = BlockAddrTmpH;
		ER00 = BlockAddrTmpL;
		#pragma asm
		CLR32_ER1
		MOV 	ER10,#4
		ADD32_ER0_ER1_ER0
		#pragma endasm
		BlockAddrTmpH = ER01;		
		BlockAddrTmpL = ER00;  			
#else 		
		BlockAddrTmpL++;
		if( ! BlockAddrTmpL){
			BlockAddrTmpH++;	
		}
		if((!bPlaneMag) || (*(u8 xdata *)(&_PLANE_MODE+ZoneLBA)))
		{
			BlockAddrTmpL++;
			if( ! BlockAddrTmpL){
				BlockAddrTmpH++;	
			}			
		}
		ER01 = BlockAddrTmpH;
		ER00 = BlockAddrTmpL;
#endif

		ER03 = 0;
		ER02 = 0;

		ER11 = (u8)(ZonePhBlockNum >> 8);
		ER10 = (u8)(ZonePhBlockNum >> 0);
		ER13 = 0;
		ER12 = 0;
		#pragma asm
		SUB32_ER0_ER0_ER1
		#pragma endasm

	}while(EC);
	
find_res_end:	
	
prints("tlc:");	
printHexSync(good_blk>>8);
printHexSync(good_blk);


	_pop_(DPCON);
}



void Update_Lg2phTableL(void)
{
	_push_(DPCON);
	DPCON = 0x10;
	BlockLBAH = 0;
	BlockLBAL = 0;

	BlockAddrTmpH = 0;
	BlockAddrTmpL = 0;
	
	ER31 = 0;
	ER30 = 0;
	if (ZoneLBA)  //����ƫ�ƻ�׼
	{
		DPTR0 = (u16)(&_ZoneLgBlockNumBuf);
		#pragma asm
			CLR32_ER0
			CLR32_ER3
			MOV 	B,ZoneLBA	
		plus_block_loop:		
			MOVX	A,@DPTR
			MOV		ER01,A
			MOVX	A,@DPTR
			MOV		ER00,A		
			ADD32_ER3_ER3_ER0
			DJNZ	B,plus_block_loop
		#pragma endasm
	}  //lg block start 
		
	
	while (1)
	{
			ACC = BlockLBAH;
			_push_(ACC);
			ACC = BlockLBAL;
			_push_(ACC);
		#pragma asm
			CLR32_ER0		//get zone num of zone0
			MOV		ER01,BlockLBAH
			MOV		ER00,BlockLBAL
			ADD32_ER0_ER0_ER3		//get real lgBlock after zone0
		#pragma endasm
			BlockLBAH = ER01;
			BlockLBAL = ER00;  //zone + lgBlock  //ʵ�ʵ�device�ڵ�lg block

			
			Get_OldBlockPhAddr();//BlockLBA OldBlockPhAddrH

			if (OldBlockPhAddrH == 0xff)  //δ����������ַ����������ַָ���Լ�
			{
		//��û�з���
				DPTR0 = (u16)(_Lg2PhTableTmp);//����ʱ����Ļ�ȡ����
				ER01 = BlockAddrTmpH;
				ER00 = BlockAddrTmpL; //blank block index
				Get_Block_PhAddr();		
				NewBlockPhAddrH = ER11;
				NewBlockPhAddrL = ER10;		//������ַ						
				BlockLgAddrH = BlockLBAH;
				BlockLgAddrL = BlockLBAL;	//�߼���ַ(zone0,zone1����)		

//	printHexSync(BlockLBAH);
//	printHexSync(BlockLBAL);
//	printHexSync(NewBlockPhAddrH);
//	printHexSync(NewBlockPhAddrL);
//	Uart_Send_Byte('\n');			
				
				Updata_WrLg2phTable();//CurLg2PhTableAddr BlockLgAddr NewBlockPhAddr
				BlockAddrTmpL++;
				if (BlockAddrTmpL == 0)
					BlockAddrTmpH++;		//blank block index++		
			}

		_pop_(ACC);
		BlockLBAL = ACC;
		_pop_(ACC);
		BlockLBAH = ACC;
				
		BlockLBAL++;
		if (BlockLBAL == 0)
			BlockLBAH++;
		#pragma asm
			MOV		DPTR,#_ZoneLgBlockNumBuf
			MOV		B,ZoneLBA
			MOV		A,#2
			CALL	dptr_add_ab_maskrom
			MOVX	A,@DPTR
			MOV 	ER01,A
			MOVX	A,@DPTR
			MOV 	ER00,A
		#pragma endasm
		if ((ER01 == BlockLBAH) && (ER00 == BlockLBAL))		//zone num����ʱ����block,ȫ��update��ӳ���,ӳ���\�տ���ֿ�
			break;
	}		
		
	BlockLBAL = 0;//��ʣ���blank block����,zone num����ʱblank block
	while (1) 
	{

		DPTR0 = (u16)(_Lg2PhTableTmp);
		ER01 = BlockAddrTmpH;
		ER00 = BlockAddrTmpL;
		Get_Block_PhAddr();
		NewBlockPhAddrH = ER11;
		NewBlockPhAddrL = ER10;
		
	#pragma asm
		CLR32_ER0
		CLR32_ER1
		
		MOV		A,ZoneLBA
		MOV		B,#((SLC_BLANK_MAX+BLANK_MAX)*3/2)	//72//48*15
		MUL		AB   //[zone][S/TLC][(BLANK_MAX*3/2)]
		MOV		ER11,B//��λ
		MOV		ER10,A
		MOV		ER00,# (SLC_BLANK_MAX*3/2)
		ADD32_ER1_ER0_ER1	
	
		MOV		ER01,#HIGH _BlankBlockTable
		MOV		ER00,#LOW  _BlankBlockTable
		ADD32_ER0_ER0_ER1	
	
		MOV		DPH,ER01
		MOV		DPL,ER00
//	#pragma asm
		CLR32_ER0
		MOV		ER00,BlockLBAL		//index
		MOV		ER11,NewBlockPhAddrH		
		MOV		ER10,NewBlockPhAddrL		//pgBlocks
		CALL	Set_Block_PhAddr
	#pragma endasm
	
		BlockLBAL++;
		BlockAddrTmpL++;
		if (BlockAddrTmpL == 0)
			BlockAddrTmpH++;

		if ((BlockLBAL == (BLANK_MAX/*48*/-1)) || ((BlockAddrTmpH == BlankBlockIndexH) && (BlockAddrTmpL == BlankBlockIndexL)))	//���ٱ���һ��λ�ø��������ĵ�һ�����ͷŵĿտ�
			break;   //TLC �տ������
	}
	
//prints("tlc blank:");
//printHexSync(ZoneLBA);	
//printHexSync(BlockLBAL);		//�����BLANK_MAX=64Ӧ���Ѿ��㹻 
//prints("\n");	

//����tlc����������find,markָ��
	#pragma asm
//		DPTR0 = (u16)(_BlankBlockTable + ((ZoneLBA<<1) + 1)*72);
//	#pragma asm
//		PUSH	DP0L
//		PUSH	DP0H
//	#pragma endasm	
			CLR32_ER0	
			CLR32_ER1
			MOV		A,ZoneLBA
			MOV		B,#((SLC_BLANK_MAX+BLANK_MAX)*3/2)//72//48*15
			MUL		AB				
			MOV		ER11,B
			MOV		ER10,A
			MOV		ER00,# (SLC_BLANK_MAX*3/2)
			ADD32_ER1_ER0_ER1	
	
			MOV		ER01,#HIGH _BlankBlockTable
			MOV		ER00,#LOW  _BlankBlockTable
			ADD32_ER0_ER0_ER1

			PUSH		ER00
			PUSH		ER01
	#pragma endasm
	
	
//		DPTR0 = (u16)(_BlankBlockIndexBuf+0 + (((ZoneLBA<<1)+1)<<3));//find blank blockָ��	
	#pragma asm
			MOV 	DPTR,#(_BlankBlockIndexBuf)
			MOV		A,ZoneLBA
			MOV		B,#2
			MUL		AB
			INC		A
			MOV		B,A
			MOV		A,#(4*2)
			CALL	dptr_add_ab_maskrom

			CLR 	A		//Find blank block��ָ��
			MOVX	@DPTR,A
			MOV		A,#BLANK_MAX//48
			MOVX	@DPTR,A
	POP		ACC				//��ʼ��ַ
			MOVX	@DPTR,A
			MOV		B,A//�ݴ�  
	POP		ACC
			MOVX	@DPTR,A
			MOV		ER40,A//�ݴ�
			
			MOV		A,BlockLBAL   //markָ��,find�ܱ�mark��Ҫ��
			MOVX	@DPTR,A
			MOV		A,#BLANK_MAX	//mark cycle
			MOVX	@DPTR,A		//ͬ����mark buf
			MOV		A,B//�ָ�
			MOVX	@DPTR,A
			MOV		A,ER40//�ָ�
			MOVX	@DPTR,A		
	#pragma endasm

	_pop_(DPCON);
}

//chking
static void Find_DATA_BLOCK(void)
{
	_push_(DPCON);
 	DPCON = 0x10;			//DPTR0����
 	
	BlockLBAH = SpareAreaH;
	BlockLBAL = SpareAreaL;  //lgBlock mapping
	Get_OldBlockPhAddr();   
	if(OldBlockPhAddrH != 0xff){ 

prints("Find 2 data block\n");
//printHexSync(OldBlockPhAddrH);
//printHexSync(OldBlockPhAddrL);
printHexSync(BlockLBAH);
printHexSync(BlockLBAL);
printHexSync(BlockAddrTmpH);
printHexSync(BlockAddrTmpL);
prints("\n");	


//bBlockMode = 1;	 //TLC
//R3_BlockAddrH = BlockAddrTmpH;
//R2_BlockAddrL = BlockAddrTmpL;  //2PʱΪ��block
//get_bound_block();		
//R1_Sector = 0;
//R4_PageAddrH = (LargePagePerBlockH*0x100+LargePagePerBlockL-1) >> 8;
//R0_PageAddrL = (LargePagePerBlockH*0x100+LargePagePerBlockL-1) & 0xFF;
//DataCoDecKeyIndex=0;
//bNeedRetryTrue = 0;//0;

//PowerUp_Read_Sector();

	SpareAreaH = BlockLBAH;
	SpareAreaL = BlockLBAL;
	Chk_WritingBlockBuf_BlockLgAddr();//�������SpareAreaH/L//��鵱ǰ�߼�block�Ƿ���ռ��һ��SWAP//���������޸ĸ��������
	if(SWAPIndex == SWAP_SIZE){//û�ж�Ӧ
	 	if(SWAPIndexTmp == 0xff){//�ݴ�����
		}else{
			SWAPIndex = SWAPIndexTmp;	
		}
	}
	
	Read_WritingBlockBuf();//BlockLgAddr CacheBlockNextPagePhAddr Order CacheLgPage NewBlockPhAddr
	
	BlockLgAddrH = BlockLBAH;
	BlockLgAddrL = BlockLBAL; 	//����ӳ��

//if(bReadBlankBlock)	//blank block
//{

////	printHexSync(BlockLBAL);
////	prints("KK\n");
////	printHexSync(BlockAddrTmpH);
////	printHexSync(BlockAddrTmpL);
////	prints("\n");	
	NewBlockPhAddrH = BlockAddrTmpH;
	NewBlockPhAddrL = BlockAddrTmpL;
//}
//else
//{  //swap old/new
////	prints("Change OLD\n");
//	NewBlockPhAddrH = BlockAddrTmpH;
//	NewBlockPhAddrL = BlockAddrTmpL;
//	Updata_WrLg2phTable();//BlockLgAddr
//	NewBlockPhAddrH = OldBlockPhAddrH;
//	NewBlockPhAddrL = OldBlockPhAddrL;
//}

		Write_WritingBlockBuf();

	}else{	 //ӳ�����û��OldBlock������BlockAddrTmp��ӳ�����
		BlockLgAddrH = SpareAreaH;
		BlockLgAddrL = SpareAreaL; 	//����ӳ��
		NewBlockPhAddrH = BlockAddrTmpH;
		NewBlockPhAddrL = BlockAddrTmpL;
		Updata_WrLg2phTable();
		
		
//prints("");		
	}
	_pop_(DPCON);
}


static void Find_DATA_CACHE_BLOCK(void)
{
	_push_(DPCON);
 	DPCON = 0x10;			//DPTR0����

//prints("find data cache:");

 	if(SpareArea2 < (7 + 1)){
		Chk_WritingBlockBuf_BlockLgAddr();//��鵱ǰ�߼�block�Ƿ���ռ��һ��SWAP
		if(SWAPIndex == SWAP_SIZE){
		 	if(SWAPIndexTmp == 0xff){
			 	bBlockMode = 0;
//				Write_a_Block_Over();
				_pop_(DPCON);
				return;
			}else{
				SWAPIndex = SWAPIndexTmp;	
			}
		}
		//Find_DATA_CACHE_BLOCK_Next
		Read_WritingBlockBuf();
		BlockLgAddrH = SpareAreaH;
		BlockLgAddrL = SpareAreaL;

		DPTR0 = (_WritingBlockBuf + CacheBlockPhAddrH_INDEX);
		#pragma asm
		MOV		B,SWAPIndex
		MOV		A,#WritingBlockBuf_SIZE
		CALL	dptr_add_ab_maskrom
		MOV		B,SpareArea2//��N��cache block
		MOV		A,#2
		CALL	dptr_add_ab_maskrom
		MOVX	A,@DPTR

		#pragma endasm
		if(ACC == 0xff){
			#pragma asm
			DECDP0
			MOV		A,BlockAddrTmpH
			MOVX	@DPTR,A
			MOV		A,BlockAddrTmpL
			MOVX	@DPTR,A
			#pragma endasm
			Write_WritingBlockBuf();
			_pop_(DPCON);
			return;
		}
	}
	//Find_DATA_CACHE_BLOCK_Error:
	bBlockMode = 0;
//	Write_a_Block_Over();

	_pop_(DPCON);
}

static void Chk_WritingBlockBuf_BlockLgAddr(void)
{
	_push_(DPCON);
 	DPCON = 0x00;			//DPTR0����

	SWAPIndexTmp = 0xff;
	for(SWAPIndex = 0; SWAPIndex != SWAP_SIZE; SWAPIndex++){
		ER41 = (*((u16 xdata *)(_WritingBlockBuf + BlockLgAddrH_INDEX + SWAPIndex * WritingBlockBuf_SIZE + 0))) >> 8;
		ER40 = (*((u16 xdata *)(_WritingBlockBuf + BlockLgAddrH_INDEX + SWAPIndex * WritingBlockBuf_SIZE + 0))) >> 0;
		if(ER41 != 0xff){
			if((ER41 == SpareAreaH) && (ER40 == SpareAreaL)){
				break;
			}		
		}else{
			SWAPIndexTmp = SWAPIndex;	
		}	
	}	
 	_pop_(DPCON);
}

static void INTIAL_SD_BUF_2_NF_USE_MAX_PAGE(void)
{
	_push_(DPCON);
 	DPCON = 0x10;			//DPTR0����
	ZoneLBA = FirstValidZone;
	Get_CurPlaneCfg();

 	DPCON = 0x00;			//DPTR0����
	*((u8 xdata *)(&SdVirtualBuf2NfUseMaxPage)) = WordLineNumber;  //��ʱ���ܳ���255   //??????debug����������256 wl��
	if (WordLineNumber > 240)
	{
		*((u8 xdata *)(&SdVirtualBuf2NfUseMaxPage)) = 240;
	}
	*((u8 xdata *)(&SdVirtualBuf2NfUseMaxSector)) = SectorPerSmallPage;
	 _pop_(DPCON);
}

static void Get_BCM_Table(void)
{
#if 1//DIS_NF_FUNCTION

#else
	DPTR_Add_AB();	//compiler
#endif
}


static void Update_BBT(void)
{
//	u16 data i;
	
	_push_(DPCON);
 	DPCON = 0x10;			//DPTR0����

	for(ER40 = 0; ER40 != 21; ER40++){
		DPTR0 = (u16)(& Reserved_Blocks_Buf);
		#pragma asm
		MOV		A,#3			//;ÿ�������ռ��3Byte ��ַ
		MOV		B,ER40
		CALL	dptr_add_ab_maskrom
		CLR32_ER0
		MOVX	A,@DPTR
		#pragma endasm		
		if(ACC == 0xff){
			continue;
		} 
		#pragma asm
		MOVX	A,@DPTR
		MOV		ER01,A
		MOVX	A,@DPTR
		MOV		ER00,A
		#pragma endasm

//		ER41 = 1;
//		if(bPlaneMag){   //plane1�İ󶨵�plane0,ֻ��plane0���ο�
//			ER00 &= 0xfe;
////			ER41 = 0;	
//		}

		
//		while(1){  //2 planʱ��2 p,chk zoneʱֻҪcheckһ������
//			#pragma asm
//			PUSH	ER01
//			PUSH	ER00
//			#pragma endasm

		DPTR0 = _BadBlockTable;
		#pragma asm
		CALL	addr_block2bit_maskrom	
		MOVX	A,@DPTR
		XRL		ER10,#0xFF			
		ANL		A,ER10
		DECDP0
		MOVX	@DPTR,A				
			
//			POP		ER00
//			POP		ER01
			#pragma endasm
			
//			ER41++;	
//			if(ER41 == 2){
//				break;
//			}
//			ER00 |= 0x01;	
//		}	
	}

#ifdef _8MXX_
		for(ER40 = 0; ER40 != 63*4/*64*4��ֹ���,��ʱ�Ĵ�����ʽ*/; ER40++){   //plane0 + plane1 2 3
#else 			
		for(ER40 = 0; ER40 != 128; ER40++){   //plane0 + plane1
#endif
			DPTR0 = (u16)(SLC_BLOCK_TABLE);
			#pragma asm
			MOV		A,#2			
			MOV		B,ER40
			CALL	dptr_add_ab_maskrom
			CLR32_ER0
			MOVX	A,@DPTR
			MOV		ER01,A
			#pragma endasm		
			if(ER01 == 0xff){
				continue;
			} 
			#pragma asm
			MOVX	A,@DPTR
			MOV		ER00,A
			#pragma endasm
			
			DPTR0 = _BadBlockTable;
			#pragma asm
			CALL	addr_block2bit_maskrom	
			MOVX	A,@DPTR
			XRL		ER10,#0xFF			
			ANL		A,ER10
			DECDP0
			MOVX	@DPTR,A				
			#pragma endasm
	}

	_pop_(DPCON);
}




static void bch_initial(void)
{
	_push_(PAGEMAP);

	sfrpage(2);

	PCON |= (BIT(5) | BIT(4));
	BCON0_P2 &= ~ BIT(7);		
	reset_bch();
	
	_pop_(PAGEMAP);
}


static void wait_pending(void)
{
   if (NPCON_P2 == 0)//					;npctl3Ϊ0ʱ��Ҫ���� ����NTSKD������λ  
	   return;
	
	#pragma asm
		CLR32_ER0
 	   MOV ER03, #0
	   MOV ER02, #0
	   MOV ER01, #0x80
	   MOV ER00, #0x00
_DELAY_WAIT0:
	   DEC32_ER0
	   JNB	NTSKD ,  _DELAY_WAIT0
	   CLR	NTSKD
	#pragma endasm
}


static void get_dqs_phase(void)
 {
	u8  phase , valid;
	
	sfrpage(2);
	/*reset ce0*/
	NF_Reset(); 
	NTSKD = 0;	    // clear pending
  	/*check ddr phase*/
	NCEE_P2  |= BIT(0);
	 
 	/*check ddr phase*/
	NCEE_P2  |= BIT(0);
	 
	NMCON0_P2 |= 0x0C; //ce task only & TGDDRTM
if (FlashType == MICRON) {
	NMCON0_P2 |= 0x01;
}	 
	NTCON2_P2  = 0x00; //ʹ��Ĭ��ֵ

	valid = 0;
	for(phase=3/*4*/ ; phase<16/*12*/ ;++phase)	/*����IC �Ľ��ž� ���鷶Χ 3~15 */
	{
		NMCON1_P2  = phase;
		NMCON1_P2 |= BIT(4);

#ifndef _MLC_	
		/*issue pre cmd*/
		NFIFO0_P2 = NF_SLC_MODE_TOSHIBA;  
	  NPCON_P2  = 0x01;		//toshiba
		wait_pending();
#endif	
		/*issue 00 5a 30*/ 
	    NFIFO6_P2 = 0x30;  	 
	    NFIFO5_P2 = 0x00;
	    NFIFO4_P2 = 0x00;
	    NFIFO3_P2 = phase; //����A/B/C ��ͬ��PAGE������DQS��һ��
	    NFIFO2_P2 = 0x00;
	    NFIFO1_P2 = 0x00;
	    NFIFO0_P2 = 0x00;    
	    NPCON_P2  = 0x53;
		wait_pending();	 /*��rb�账��*/
		
		/*only dma*/
		NPGSZ_P2 = 512;
		NXADR2_P2 = BUFFER_START_ADDR;
		NPCON_P2   = 0x04;

		wait_pending();    //ע�⣺�˴���RB���ض�����false

		if((NMCON1_P2 & 0x80)==0)
		{
		  valid = 1;
		  break;
		}
	}
			
	NMCON1_P2  = valid?(phase>>1):9; //ȡ�м����ֵ-
	NMCON1_P2 |= BIT(4);    //set phase and ddr mode
	NMCON0_P2 |= BIT(3);    //ce active
	
//	prints("\nphase ok\n");
}

static void HySetPara(unsigned char addr, unsigned char dat)
{
	_push_(DPCON);
	DPCON = 0;

prints("HySetPara:");
printHexSync(addr);
printHexSync(dat);
prints("\n");	

	XBYTE[_SPARE_AREA_BUF + 0] = dat;

	NPGSZ0_P2 = 0x01;
	NPGSZ1_P2 = 0x00;
	
	NXADR2_P2 = _SPARE_AREA_BUF;
	NXCNT0_P2 = 0;
	NXCNT1_P2 = 0;
	
	NFIFO1_P2 = addr;
	NFIFO0_P2 = 0x36;
	BCON1_P2 = 0;
	NPCON_P2 = 0x19;
	while( ! NTSKD){}
	_N_NOP_
	NTSKD = 0;
	_pop_(DPCON);
}

static unsigned char HyGetPara(unsigned char addr)
{
	NPGSZ0_P2 = 0x01;
	NPGSZ1_P2 = 0x00;
	
	NXADR2_P2 = _SPARE_AREA_BUF;
	NXCNT0_P2 = 0;
	NXCNT1_P2 = 0;

	NFIFO1_P2 = addr;
	NFIFO0_P2 = 0x37;
	BCON1_P2 = 0;
	NPCON_P2= 0x15;
	while( ! NTSKD){}
	_N_NOP_
	NTSKD = 0;

prints("HyGetPara:");
printHexSync(addr);
printHexSync(XBYTE[_SPARE_AREA_BUF]);
prints("\n");	

	return XBYTE[_SPARE_AREA_BUF];
}

