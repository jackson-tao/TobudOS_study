#include "absacc.h"
#include "intrins.h"
#include "inc\common.h"	
#include "inc\ax215_exinst.h"
#include "inc\sd_spi_com_define.h"		
#include "inc\nand_flash.h"	
#include "inc\extern_data.h"
#include "inc\mtd_c.h"
#include "inc\mrom_func.h"
//static void Read_Sectors_NFF(void);
void Chk_RB(unsigned char index,unsigned int TimeOutTime);

extern bit(bFirstEnDecodeData);
extern void xrl_p3(u8 dat);

#if NFFUSING
#define		NFFINBuf_SIZE	 48//32
xdata unsigned char NFFINBuf[NFFINBuf_SIZE*16] _at_ NFF_BUF;
code unsigned char NFFINBuf_tmp[NFFINBuf_SIZE*16] _at_ NFF_BUF;
#endif

extern void Uart_Send_Byte(u8 dat);
extern void printHexSync(u8 dat);
extern void prints(u8 *p);
extern u8 code SectorPerBlock;
extern u8 data yScrtyUnitCnt;
static void MLC_Buf_Data_Codec(void)
{
#if RANDOMIZE_NF
	if(bNeedRandomizer){

		HCON_P2 = 0;
#if 1
		ER13 = DataCoDecKeyIndex ^ 0xA5;		
		ER12 = DataCoDecKeyIndex ^ 0x5A;		
		ER11 = DataCoDecKeyIndex1 ^ 0xA5;		
		ER10 = DataCoDecKeyIndex1 ^ 0x5A;		

#pragma asm
		MOV		DPTR,#(_SPARE_AREA_BUF + 16)
		RAN32_EDP0_ER1;//Store ERn to XRAM, and ERn updated with 32-bit pseudo random algorithm	
MOV		DPTR,#(_SPARE_AREA_BUF + 16)
RAN32_EDP0_ER1;
MOV		DPTR,#(_SPARE_AREA_BUF + 16)
RAN32_EDP0_ER1;
#pragma endasm

		HPAGE0_P2  = ER10;
		HPAGE1_P2  = ER11 & 0x03;//10bit
		HFRAME_P2  = ER12; //homogeous frame
		HSEEDINIT0_P2 = ER10;
		HSEEDINIT1_P2 = ER11;
		HSEEDINIT2_P2 = ER12;
		HSEEDINIT3_P2 = ER13;


#else
		HPAGE0_P2  = DataCoDecKeyIndex; //pgae

		HFRAME_P2  = DataCoDecKeyIndex1; //homogeous frame
#endif

		HCON_P2 = BIT(2) | BIT(0); 
	
	}
#endif
}



#pragma asm
	EXTRN CODE(ChkSlcMode)
#pragma endasm
void chk_slcMode_switch(void)  
{
#ifndef _MLC_
	
	if (FlashType == SAMSUNG) {
		ACC = 0xDA;
		NF_Send_CMD_Only();			
	} else {
		ACC = 0xA2;
		NF_Send_CMD_Only();			
	}
	
#else
	
	if (FlashType == SAMSUNG) {
		if(bPageGroupSLC || !bBlockMode){ 
			#pragma asm 
				MOV		DPTR,#ChkSlcMode
				MOVX	A,@DPTR
			#pragma endasm
			if (ACC != 0)
			{	
	//prints("DA\n");		
				ACC = 0xDA;	//A2 CMD
				NF_Send_CMD_Only();	
			#pragma asm			
				MOV		DPTR,#ChkSlcMode
				MOV		A,#0
				MOVX	@DPTR,A
			#pragma endasm
			}
		} else {
			#pragma asm 
				MOV		DPTR,#ChkSlcMode
				MOVX	A,@DPTR
			#pragma endasm
			if (ACC != 1)
			{	
	//prints("DF\n");			
				ACC = 0xDF;	//A2 CMD
				NF_Send_CMD_Only();	
			#pragma asm 				
				MOV		DPTR,#ChkSlcMode
				MOV		A,#1
				MOVX	@DPTR,A
			#pragma endasm
			}	
		}
	} 
#endif	
}


#pragma asm
		EXTRN CODE(_FLASH_SHIFTCNT)
#pragma endasm
void Change_CE(void)
{
	_push_(DPCON);
	_push_(ER40);  //plan num
		
	DPCON = 0x10;			//DPTR0����		

#ifdef _8MXX_

ER00 = (HalfSectorPerSmallPage>>1);
if ((R1_Sector == ER00) || ((boundIndex==0xff)&&(R1_Sector > ER00))) {
	boundIndex = 0;
	if ((*((u8 xdata *)(&_PLANE_MODE)) == 1) && (*((u8 xdata *)(&_PLANE_MODE+2)) == 1)) {
		if ((R2_BlockAddrL&0x03) == 2)
		{
			boundIndex = 1;
		}
	}
	get_bound_block();
}
get_bound_end:			
#else 

boundIndex = 0;
get_bound_block();
#endif
	Get_PageLg2PhTable();
	#pragma asm
	CLR32_ER0
	CLR32_ER1
	#pragma endasm
	if( ! bSLC2TLCProg){
		ER01 = R4_PageAddrH;
		ER00 = R0_PageAddrL;		
		if (b2PlaneTrue) {	
			#pragma asm
			MOV		R8,#1
			ROTR32_ER0_ER8
			#pragma endasm		
		}	
		if (!bBlockMode)
		{		
			DPTR0 = (u16 xdata *)(&PLANE_REFERENCE + ZoneLBA*4 + 2);
			
		} else {
		
			DPTR0 = (_FLASH_BLOCK_PAGE_MODE_TABLE + ZoneLBA*4);
		}	
		#pragma asm	
		MOVX	A, @DPTR     //ȡ��ַ
		MOV		B, A
		MOVX  A, @DPTR	
		MOV		DPH, B
		MOV		DPL, A
		#pragma endasm
		bit_search();
	}//Get_PageLg2PhTable_End
	else
	{
		ER11 = R4_PageAddrH;
		ER10 = R0_PageAddrL;	
if (b2PlaneTrue) {	
	#pragma asm
	MOV		R8,#1
	ROTR32_ER1_ER8
	#pragma endasm		
}	
	}

DataCoDecKeyIndex = ER10;//200709��������page��Ϊ����

	ER13 = 0;
	ER12 = 0;
	
 	//����3byte��ַ
	ER03 = 0;
	ER02 = 0;	
	ER01 = R3_BlockAddrH;
	ER00 = R2_BlockAddrL;
#ifdef _HALFPAGE_

	if 	(R1_Sector >= (HalfSectorPerSmallPage>>1)) {    	
		ER01 = R3_BlockAddrH_P1;
		ER00 = R2_BlockAddrL_P1;
	}	
#else
	if(b2PlaneTrue && (R0_PageAddrL & 0x01 == 0x01))
	{
		ER00 = R2_BlockAddrL_P1;
		ER01 = R3_BlockAddrH_P1;
	}
#endif

	#pragma asm
	MOV		DPTR, # _FLASH_SHIFTCNT
	MOVX	A, @DPTR
	MOV		R8,A 
	ROTL32_ER0_ER8
	ADD32_ER0_ER0_ER1//3BYTE��ַ�����R02 ER01 ER00
	#pragma endasm
	
#ifndef _8MXX_	
	if(FlashType == _TOSHIBA_19NM_)//TOSHIBA 19NM����LP RP  shift cnt = 9
	{
		if (R1_Sector >= (HalfSectorPerSmallPage>>1)) {   //p0
	 		ER01 |= 0x01;  //rp
		}
	}
#endif
	_pop_(ER40);
	_pop_(DPCON);
}

static void Dptr0_Point_To_BlockPageMode_Tab(void)
{
#if EN_MUL_PAGES_MODE
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����

	#pragma asm
	MOVX	A, @DPTR   
	MOV		B, A
	MOVX   	A, @DPTR
	MOV		DPL, A
	MOV		DPH, B
    #pragma endasm
	 
 	_pop_(DPCON);
#endif
}

/*============================================================
* �Ρ�����:	
IN��R3/R2 BlockPageModeIndex
Out��BlockPageModeIndex _PageLg2PhTable
* ��������:
BlockPageModeIndex_Buf[2] == ��ǰģ�Ͷ�Ӧ��zone
_FLASH_BLOCK_PAGE_MODE_TABLE[zone][4]==[2:tlc bad wl tab dptr][2:]
WORD_LINE_NUMBER:slc wl
WordLineNumberTLC:tlc wl
_PageLg2PhTable_Plane1:��һ�׶�����bad wordlineתgood wordline,tlc table
_PageLg2PhTable:zone 0 slc table 
_PageLg2PhTable_SLC_Plane1:zone 1 slc table 
_PageLg2PhTable_ph:�������߼�wordlineӳ�� zone0 or zone1
============================================================*/
void Get_PageLg2PhTable(void)
{
#if EN_MUL_PAGES_MODE
	if( ! bNeedChkBlockPageModeIndex){
		return;
	}
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����
	bNeedChkBlockPageModeIndex = 0;	
	if(*((u8 xdata *)(& BlockPageModeIndex_Buf + 2)) == ZoneLBA){
		 _pop_(DPCON);
		 return;	
	}
	*((u8 xdata *)(& BlockPageModeIndex_Buf + 2)) = ZoneLBA;
	

 	_pop_(DPCON);	
#endif
}

void NF_Send_CMD0_5ByteAddr(void)
{
	NF_Config_5ByteAddr();
	NPCON_P2 = 0x51;
	Wait_Flash_Ready();
}

static void NF_Config_5ByteAddr(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����

	DPTR0 = (u16)(&NF_DATA);

	#pragma asm
 	MOV32_ER0_EDP0
	#pragma endasm
	NFIFO5_P2 = ER00;
	NFIFO4_P2 = ER01;
	NFIFO3_P2 = ER02;
	NFIFO2_P2 = ER03;

	#pragma asm
 	MOV32_ER0_EDP0
	#pragma endasm
	NFIFO1_P2 = ER00;
	NFIFO0_P2 = ER01;

	_pop_(DPCON);
}

static void change_col(void)
{
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����

	DPTR0 = (u16)(&NF_DATA);

	#pragma asm
 	MOV32_ER0_EDP0
	#pragma endasm
	NFIFO2_P2 = ER03;
//if (yScrtyUnitCnt == 100)	
//printHexSync(ER03);
	#pragma asm
 	MOV32_ER0_EDP0
	#pragma endasm
	NFIFO1_P2 = ER00;
//if (yScrtyUnitCnt == 100)	
//{
//	printHexSync(ER00);
//	prints("\n");	
//	yScrtyUnitCnt = 0;
//}
	_pop_(DPCON);
}



/**********************************************
ÿ��sectorǰ��column
***********************************************/
unsigned char Wr_Badcolumn_AfterData(void)
{
	_push_(DPCON);
	DPCON  = 0;
	
#ifdef _8MXX_

	if (R1_Sector > ((SectorPerSmallPage+1)>>1)) {  //4p
			DPTR0 = *(u16 xdata *)(&PLANE_REFERENCE + 2*4);
			B = R1_Sector - ((SectorPerSmallPage+1)>>1);
	} else {
			DPTR0 = *(u16 xdata *)(&PLANE_REFERENCE + ZoneLBA*4);
			B = R1_Sector;
	}	
#else	
	#ifdef _HALFPAGE_

	if (R1_Sector >= (HalfSectorPerSmallPage>>1)) {	
		DPTR0 = (u16 xdata *)(&_Fill_Sec_Gap_P1);		
		B = R1_Sector - (HalfSectorPerSmallPage>>1);	
	} else {
		if (ZoneLBA) {
			DPTR0 = (u16 xdata *)(&_Fill_Sec_Gap_P1);
		} else { 
			DPTR0 = (u16 xdata *)(&_Fill_Sec_Gap_P0);		
		}
		B = R1_Sector;	
	}	
	
	#else
	if (ZoneLBA) {
		DPTR0 = (u16 xdata *)(&_Fill_Sec_Gap_P1);
	} else {
		if (b2PlaneTrue && ((R0_PageAddrL&0x01) == 0)) {	
			DPTR0 = (u16 xdata *)(&_Fill_Sec_Gap_P0);		
		} else {
			DPTR0 = (u16 xdata *)(&_Fill_Sec_Gap_P1);		
		}
	}		
	B = R1_Sector;
	#endif
#endif	

	ACC = 2;
	DPTR_Add_AB();
	#pragma asm
	MOVX	A,@DPTR
	MOV 	NPGSZ1_P2,A
	MOV 	B,A	
//MOV ER01,A	
	INCDP0
	MOVX	A,@DPTR
	MOV 	NPGSZ0_P2,A	
//MOV ER00,A	
	ORL  	B,A
	#pragma endasm
	
	
	_pop_(DPCON);
		
	if (B) {  
		MLC_Buf_Data_Codec();//seed
		BCON1_P2 = 0;
	//	NPGSZ1_P2 = 3;
	//	NPGSZ0_P2 = 0;
		BCMCON_P2 = 0;
		NPCON_P2 = 0x08;
		Wait_Flash_Ready();
		
		HCON_P2 = 0;
	
//prints("br\n");		
		return 1;
	}
	
	return 0;
}


void NF_Prog_Data(void)
{
#if 1//DIS_NF_FUNCTION
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����
	MLC_Buf_Data_Codec();
	
	DPTR0 = (u16)(& NF_DATA + 8);	
	#pragma asm
	MOV32_ER0_EDP0
	MOV32_ER1_EDP0
	#pragma endasm

	BXADR0H_P2 = ER01;//��������
	BXADR0L_P2 = ER00;

//[6]: 1-data from sram to nfc;
//[5:4]:1-encode mode
//[0]:1-kict start
//	BCON1_P2 = BIT(6) | BIT(4) | BIT(0);

	BCON1_P2 = ER03;//ER03 = BIT(6) | BIT(4) | BIT(0);
#ifndef _8MXX_
if ((FlashType == TLC_SLC)||(FlashType == _TOSHIBA_19NM_)){  //8T2X
	NF_Config_5ByteAddr();	
} else 
#endif
{
	change_col();
}

	NFIFO0_P2 = NF_RANDOM_DATA_INPUT;
	BCM_KickStart();
	
#if EN_NF_RANDOM_WR_CMD
#ifndef _8MXX_
if ((FlashType == TLC_SLC)||(FlashType == _TOSHIBA_19NM_)) {  //8T2X
	NPCON_P2 = 0x59;	 //5BYTE ADDR
} else 
#endif
{
	NPCON_P2 = 0x29;
}

#else
	if(bSendReadRandomCmd==0){
		NPCON_P2 = 0x08;
	}else{
		bSendReadRandomCmd = 0;
		NPCON_P2 = 0x59; //5BYTE ADDR
	}

#endif

	_pop_(DPCON);
	
#endif
}

void NF_Prog_Data_Wait(void)
{
#if 0//DIS_NF_FUNCTION
	
	Wait_Flash_Ready();	

	while(! (BCON1_P2 & (1 << 7))){};
	BCON1_P2 &= 0x7f;	   //;Clr done
	BCMCON_P2= 0;
	
#endif
}



void NF_Prog_Stop(void)
{

	if(ProgramCMD1){
		NACMD1_P2 = ProgramCMD1;	
		NPCON_P2 = 0x80;
		Wait_Flash_Ready();
//		Chk_RB(0x01,0x2000);
	}
	
	BCON1_P2 = 0;//�ر�BCM��������data�޹صĺ����Ͳ���Ҫ��ֵ
	BCMCON_P2= 0;
}



void Buf_Data_CoDec(void)
{
#if RANDOMIZE_NF
	_push_(DPCON);
	DPCON = 0x10;			//DPTR0����

	if(bReadBlankBlock){  //��page
		ER02 = RandomIndex;
		Sel_Buffer_Addr();
		DP0H = ER01;
		DP0L = ER00;
		ER03 = 0xff;
		ER02 = 0xff;
 		ER01 = 0xff;
		ER00 = 0xff;
	#if MODE_1K_EN
		B = (u8)((1024 / (4 * 4)));
	#else
		B = (u8)((512 / (4 * 4)));
	#endif
		do{
			#pragma asm
			MOV32_EDP0_ER0
			MOV32_EDP0_ER0
			MOV32_EDP0_ER0
			MOV32_EDP0_ER0
			#pragma endasm		
			B--;
		}while(B);	
	 }
	_pop_(DPCON);
#else

#endif
}

void BCH_Config_Decode1time(void)//������β���Ҫִ�����������֮ǰ����Ϊax215e���쳣��tankӦ��û������
{
}

void BCH_MODE_DC_Wait_Over(void)
{
	
#if 1 //DIS_NF_FUNCTION
	
	bTerribleError = 0;
	bLg2PhVerifyError = 0;

	while( ! (BCON0_P2 & (1 << 7))){}; 	// done

#if PRINTF_ERR_EN
	BECNTTmp = 0;
#endif

	if(BCON0_P2 & (1 << 5)){		//has err

#if PRINTF_ERR_EN
		BECNTTmp = 0xff;
#endif
		if( !(BCON0_P2 & (1 << 6))){	//correctable

			BECNTTmp = BECNT_P2;

		}else{		
			bTerribleError = 1;
			bLg2PhVerifyError = 1;
		}	
	}

	BCON0_P2 &= ~(1 << 7);		//kict start next packet.

#endif

//	 if (BlockLBAL == 0)   //??????debug11
//	{
//prints("ready retry\n");		
//			bTerribleError = 1;
//			bLg2PhVerifyError = 1;
////		if (!RetryCnt) {
////			RetryCnt =31;
////		}
//	}
}


void Chk_Blank_Block(void)
{
	if( ! bReadNeedChkBankBlk){
		return;	
	}
	
	bReadNeedChkBankBlk = 0;		//Ĭ��1��pageֻcheckһ��sector���������Ƿ����blank blk���ص�
#if 1
	if(NDCTCNT1_P2*0x100+NDCTCNT0_P2 > 0x200/*��������,*/)//��0�ĸ���//���ֲ���flash�ò���Ϊ0x40���ң�Ӧ���ǿտ�
	{
		bReadBlankBlock = 0;	
#if RANDOMIZE_NF		
//Double_Check_Erase00:
	_push_(DPCON);
 	DPCON = 0x10;			//DPTR0����

	DPTR0 = (_SPARE_AREA_BUF+12);  //�ܿ���������
	#pragma asm
//	CLR32_ER0
	MOV32_ER0_EDP0
	
	XRL32_EDP0_ER0
	JNB 	EZ,chk_erase00_end
	XRL32_EDP0_ER0
	JNB 	EZ,chk_erase00_end
	XRL32_EDP0_ER0
	JNB 	EZ,chk_erase00_end
	XRL32_EDP0_ER0
	JNB 	EZ,chk_erase00_end
chk_erase00_end:	
	#pragma endasm
	if (EZ) {  //����16��0
		bReadBlankBlock = 1;
		prints("BL_ERASE00\n");
	}
	_pop_(DPCON);		
#endif				
	}
	else
	{
		bReadBlankBlock = 1;
	}
#else	
	_push_(DPCON);
 	DPCON = 0x10;			//DPTR0����

	//����00��FF�ĸ���
	bReadBlankBlock = 0;
//	bReadBlankBlock_0 = 0;

	DPTR0 = (_SPARE_AREA_BUF+8); 

	ER41 = 0;   //FF
	ER42 = 0;   //00
	for(ER40 = 16; ER40 != 0; --ER40){
		#pragma asm
		 MOVX	A,@DPTR
		 MOV	R8, A
		#pragma endasm
		if( ! R8){
			ER42++;		//=0x00
		}else if(R8 == 0xff){
		   	ER41++;		//=0xff
		}	
	}


	//����FF�ĸ����ж��Ƿ�Ϊ�տ�
	if(ER41 < (16 - 3)){
		//����00�ĸ����ж��Ƿ�Ϊ�տ�
		if(ER42 >= (16 - 3)){
//			bReadBlankBlock = 1;	//��page//MT29F8G16ABBCAд00����ʱ�ᴥ����bit��������δ�ҵ�ԭ����ʱ�ر�
//			bReadBlankBlock_0 = 1;
		}
	}else{
		bReadBlankBlock = 1;  //��page
	}
	_pop_(DPCON);
#endif
}

/*============================================================
* �Ρ�����: R0--ubPhLargePageAddr 
*			R1--ubPhSectorAddr
*	    	R3 R2-----uwPhBlockAddr
* ��������: Read a sector
============================================================*/
#pragma asm
		EXTRN CODE(Retry_Register_CMD)
#pragma endasm
void NF_Read_Start(void)
{
//NTCON1_P2=0x0f;
	unsigned char idata tmp=R1_Sector;

	boundIndex = 0xff;//�п��ܲ��Ǵ�һ��page��ʼ������
	
	select_ecc_bits(DECODE | R1_Sector);

	bNeedChkBlockPageModeIndex = 1;

	if(bNeedSend5DCMDSLC){
		#pragma asm
		MOV 	DPTR,#(Retry_Register_CMD+4)
		MOVX	A,@DPTR
		#pragma endasm
		NF_Send_CMD_Only();	
	}
	
	chk_slcMode_switch();
	NF_Write_Addr();
	
	//��00 5byte addr 30������������column��ַ����R1����
	NACMD1_P2 = NF_READ_2ND;	   //;command 1 = 0x30 (start read)
	NF_Config_5ByteAddr();
//	NFIFO2_P2 = 0;
//	NFIFO1_P2 = 0;
	NFIFO0_P2 = NF_READ_1ST;
	NPCON_P2 = 0xD1;
	Wait_Flash_Ready();

	NXADR1_P2 = _SPARE_AREA_BUF;
	NXCNT0_P2 = 1024 / 4;   //1k change
	NXCNT1_P2 = 160/4;			//use NXADR2_P2   

	bReadNeedChkBankBlk = 1;
	bSendReadRandomCmd = 1;

	R1_Sector = tmp;
}


void NF_Read_Start_Copy(void)
{
	
}


void NF_Read_Data(void)
{
	_push_(DPCON);
	
	DPCON = 0x00;

	DataCoDecKeyIndex1 = R1_Sector;	

	MLC_Buf_Data_Codec();	
	
	ER02 = R8Tmp;
	Sel_Buffer_Addr();
	NXADR0H_P2 = ER01;
	NXADR0L_P2 = ER00;

	BCON1_P2 = BIT(6) | BIT(5) | BIT(0);		//data from nfc, decode, hardware auto error correct, kict start.

#ifdef _HALFPAGE_

if (R1_Sector == (HalfSectorPerSmallPage>>1)) {  //1p(2p�ϲ�)  2p(4p�ϲ�)
	#ifdef _8MXX_
	ACC = NF_SLC_MODE_TOSHIBA;
	NF_Send_CMD_Only();   //ǰ׺cmd
	#endif

	NF_Write_Addr();   //���һ��ʼ������������µ����ٷ�һ��


	//��00 5byte addr 30������������column��ַ����R1����
	NACMD1_P2 = NF_READ_2ND;	   //;command 1 = 0x30 (start read)
	NF_Config_5ByteAddr();
	NFIFO0_P2 = NF_READ_1ST;
	NPCON_P2 = 0xD1;
	Wait_Flash_Ready();
} else {
	
	Get_ColAddr();		
}
	NFIFO3_P2= NF_RANDOM_DATA_OUTPUT_2;
	change_col();
	NFIFO0_P2 = NF_RANDOM_DATA_OUTPUT_1;
	BCM_KickStart();

	bSendReadRandomCmd = 0;
	NPCON_P2 = 0x27; //5BYTE ADDR
#else 

	#ifndef _MLC_
	NF_Write_Addr();
	NFIFO6_P2= NF_RANDOM_DATA_OUTPUT_2;
	NF_Config_5ByteAddr();
	NFIFO0_P2 = NF_RANDOM_DATA_OUTPUT_1;
	BCM_KickStart();
	bSendReadRandomCmd = 0;
	NPCON_P2 = 0x57; //5BYTE ADDR		
	
	#else 
	Get_ColAddr();	
	NFIFO3_P2= NF_RANDOM_DATA_OUTPUT_2;
	change_col();
	NFIFO0_P2 = NF_RANDOM_DATA_OUTPUT_1;
	BCM_KickStart();
	bSendReadRandomCmd = 0;
	NPCON_P2 = 0x27; //5BYTE ADDR	
	#endif

#endif

	R1_Sector++;

	_pop_(DPCON);
}


/*============================================================
* �Ρ�����: R3 R2 = unsigned int uwPhBlockAddr
* ��������: Performs a Block Erase operation	
============================================================*/
void NF_Erase_Block(void)
{
//prints("PP:");	
//printHexSync(R3_BlockAddrH);
//printHexSync(R2_BlockAddrL);
//prints("\n");	
NF_Reset();	
	R1_Sector = 0;
	R4_PageAddrH = 0;
	R0_PageAddrL = 0;

#ifdef _MLC_

	chk_slcMode_switch();	
if (FlashType == SAMSUNG) {
	ACC = 0xDF;	
	NF_Send_CMD_Only();	
	#pragma asm 				
	MOV		DPTR,#ChkSlcMode
	MOV		A,#1 
	MOVX	@DPTR,A
	#pragma endasm
}
#else 
	if (FlashType == SAMSUNG) {
		ACC = 0xDA;
		NF_Send_CMD_Only();			
	}
//	chk_slcMode_switch();	 //����ss,��������tlc��
#endif


	
	ER40 = 0;
	do{
		bSLC2TLCProg = 1;
		Change_CE();

#ifdef _HALFPAGE_	
		if (HalfSectorPerSmallPage == (SectorPerSmallPage+1)) {  //1p
			ER40++;
		} else {  //1p(2p�ϲ�) or 2p(4p�ϲ�)
			R8 = R1_Sector;
			if (R8 == 0) {
				R1_Sector = (HalfSectorPerSmallPage>>1);  //NOT OUT
			} else if (R8 == (HalfSectorPerSmallPage>>1)) {
				R1_Sector = ((SectorPerSmallPage+1) >> 1);
				ER40++;
			} 
		} 			
#else 		
		ER40++;
		R1_Sector = 0;
		R0_PageAddrL++;
#endif		
		NACMD1_P2 = NF_BLOCK_ERASE_2;
		NFIFO3_P2 = ER02;
		NFIFO2_P2 = ER01 ;//| ER40;
		NFIFO1_P2 = ER00;
		NFIFO0_P2 = NF_BLOCK_ERASE_1;
		B = 0x31;
		if(ER40 == PlaneNum){
			B = 0xB1;	//���D0
		}
		NPCON_P2 = B;
		Wait_Flash_Ready();		 	
	}while(ER40 != PlaneNum);		
	bSLC2TLCProg = 0;
	R1_Sector =	0;
	R0_PageAddrL = 0;

#ifndef _8MXX_
 //L73��Щblock erase rb̫��	

		Chk_RB(0x02,0x8000);
#endif

		NF_Read_Status(0);

}

void Chk_RB(unsigned char index,unsigned int TimeOutTime)
{
//TimeOutTime=255;
	unsigned int idata TimeOutCnt = 0;
	_push_(PAGEMAP);
	sfrpage(0);
	do {
		TimeOutCnt++;
	} while(((P3_P0 & BIT(5)) != BIT(5)) && (TimeOutCnt!=TimeOutTime));	 
	_pop_(PAGEMAP);		

//	if (TimeOutCnt==TimeOutTime) 
	{
//prints("ep:");
//printHexSync(index);printHexSync(TimeOutTime>>8);printHexSync(TimeOutTime&0xFF);
//prints("|");
//printHexSync(TimeOutCnt>>8);printHexSync(TimeOutCnt&0xFF);
//prints("\n");
		_push_(NMCON0_P2); 
		NMCON0_P2 &= 0xCF;
		NMCON0_P2 |= 0x30;
		NF_Reset();
		_pop_(NMCON0_P2);
//			NPGSZ_P2 = 2;
//			NXADR0_P2 = _SPARE_AREA_BUF;// + 80;//�޸�buf��ַ�����+80����slc+copy backд��
//			NXCNT0_P2 = 160 / 4;  //�������NPGSZ1_P2 NPGSZ0_P2
//			NFIFO0_P2 = NF_READ_STATUS;
//			BCON1_P2 = 0;//��data
//			NPCON_P2 = 0x05;
//			Wait_Flash_Ready();
//			prints("sts:");printHexSync(XBYTE[_SPARE_AREA_BUF + 0]);prints("\n");
		wait_rbx_ready(NFRB0);
	}	
}

/*============================================================
* �Ρ�����: R0--ubPhPageAddr 
*			R1--ubPhSectorAddr
*	    	R3 R2-----uwPhBlockAddr
* ��������: 
============================================================*/
void NF_Write_Addr(void)
{

	_push_(DPCON);
 	DPCON = 0x10;			//DPTR0����	
	
	Change_CE();
	DPTR0 = (u16)(& NF_DATA);
	
	#pragma asm
	MOV		A,ER02
	MOVX	@DPTR,A//NFIFO5_P2
	MOV		A,ER01
	MOVX	@DPTR,A//NFIFO4_P2
	MOV		A,ER00
	MOVX	@DPTR,A//NFIFO3_P2
	#pragma endasm

//	if (yScrtyUnitCnt == 100)
//	{
//		prints("KK:");
//		printHexSync(ER02);
//		printHexSync(ER01);
//		printHexSync(ER00);	
//		prints("\n");
//	yScrtyUnitCnt = 0;
//	}	
	
	Get_ColAddr();

	_pop_(DPCON);	
}


/*============================================================
* �Ρ�����:R1-->ER01 ER00
* ��������: 
============================================================*/
static void Get_ColAddr(void)
{
	_push_(DPCON);
 	DPCON = 0x10;			//DPTR0����

#ifdef _MLC_HALFPAGE_
	R8 = R1_Sector;
	if 	(R1_Sector < (HalfSectorPerSmallPage>>1)) {   
		if(ZoneLBA == 1) {
			DPTR0 = (u16)(&_SectorLg2PhTable_Plane1);
		} else {		
			DPTR0 = (u16)(&_SectorLg2PhTable);
		}
		B = R1_Sector;
	}else{	// >=															//plane1	
		DPTR0 = (u16)(&_SectorLg2PhTable_Plane1);		
		B = R1_Sector - (HalfSectorPerSmallPage>>1);
	}	

#else

	if(! b2PlaneTrue){
		if(ZoneLBA == 0) {
			DPTR0 = (u16)(&_SectorLg2PhTable);		
		} else if(ZoneLBA == 1) {
			DPTR0 = (u16)(&_SectorLg2PhTable_Plane1);
		} else if(ZoneLBA == 2) {
			DPTR0 = (u16)(&_SectorLg2PhTable_Plane2);
		} else if(ZoneLBA == 3) {
			DPTR0 = (u16)(&_SectorLg2PhTable_Plane3);			
		}
		B = R1_Sector;	

	}else{
		R8 = R1_Sector;
		if ((R0_PageAddrL&0x01) == 0){ //plane0
			DPTR0 = (u16)(&_SectorLg2PhTable);
			B = R1_Sector;
		}else{	// >=															//plane1	
			DPTR0 = (u16)(&_SectorLg2PhTable_Plane1);		
			B = R1_Sector;
		}	
	}
#endif	
	
	ACC = 2;
	
	DPTR_Add_AB();
	#pragma asm
	MOVX	A,@DPTR
//	MOV		NFIFO2_P2,A
	MOV		ER01,A
	MOVX	A,@DPTR
//	MOV		NFIFO1_P2,A
	MOV		ER00,A
	#pragma endasm

	DPTR0 = (u16) (& NF_DATA + 3);
	#pragma asm
	MOV		A,ER01
	MOVX	@DPTR,A//NFIFO2_P2
	MOV		A,ER00
	MOVX	@DPTR,A//NFIFO1_P2
	#pragma endasm

	_pop_(DPCON);

}

void Get_R1_Addr(void)
{

	if(R8 < (u8)(SectorPerSmallPage + 1)){  //plane0

	}else{																	//plane1
		R8 = R8 - (u8)(SectorPerSmallPage + 1);	
	}	
}

/*============================================================
* �Ρ�������ZoneLBA
* ��������:
				��ȡZoneLBA��
				_PageLg2PhTable
				_SectorLg2PhTable
				SectorPerSmallPage
				LargePagePerBlock
				SectorPerBlockH/L
============================================================*/
void Get_CurPlaneCfg(void)
{
	_push_(DPCON);
 	DPCON = 0x00;			//DPTR0������

	if (ZoneLBA != *((u8 xdata *)(& Cur_ZoneLBA))){
		*((u8 xdata *)(& Cur_ZoneLBA)) = ZoneLBA;
		_push_(ER00);	
		_push_(ER01);
		_push_(ER02);
		_push_(ER03);
	
		if (ZoneLBA == 0) {
			DPTR0 = (u16)(& _FLASH_SECTORPERSMALLPAGE);
		} else if (ZoneLBA == 1) {
			DPTR0 = (u16)(& _FLASH_SECTORPERSMLPAGEPLN2);
		} else if (ZoneLBA == 2) {
			DPTR0 = (u16)(& _FLASH_SECTORPERSMLPAGEPLN4);
		} else if (ZoneLBA == 3) {
			DPTR0 = (u16)(& _FLASH_SECTORPERSMLPAGEPLN6);
		}
		DPCON = 0x10;			//DPTR0����
		#pragma asm
		MOVX	A,@DPTR		
		MOV		SectorPerSmallPage,A
		MOVX	A,@DPTR
		MOV 	ER01,A
		MOVX	A,@DPTR
		MOV 	ER00,A			
		MOVX	A,@DPTR
		MOV		PageGroupNumber,A
		MOVX	A,@DPTR
		MOV		HalfSectorPerSmallPage,A
		MOVX	A,@DPTR
		MOV		ER13,A
		MOVX	A,@DPTR
		MOV		ER12,A
		#pragma endasm					
		WordLineNumberTLC = (ER13*0x100 + ER12);  
		WordLineNumber = (ER01*0x100 + ER00);		
#ifdef _MLC_		
	if (PageGroupNumber == 1)   //ֻ�����ж��ǲ���ֻдA��
	{
		bPageGroupSLC = 1;
	} else {
		bPageGroupSLC = 0;
	}
#else 
	bCacheCmd = 0;
	bPageGroupSLC = 0;
#endif	
	
PageGroupNumber = 1;  //�ĳ�����ֵ

		ER13 = 0;
		ER12 = PlaneNum;
		ER11 = WordLineNumberTLC>>8;
		ER10 = WordLineNumberTLC;
		#pragma asm
		MUL16_ER1
		#pragma endasm
		LargePagePerBlockH = ER11;
		LargePagePerBlockL = ER10;
		

		
		ER13 = 0;
		ER12 = 3;//PageGroupNumber + 1;  
		//2p��ʱ��ȡ��cache��Զ����ȡ��zone0�ģ�����ֻ����һ��zone����������
		ER11 = WordLineNumber>>8;
		ER10 = WordLineNumber;		
		#pragma asm
		MUL16_ER1
		#pragma endasm
		*(u8 xdata *)(&CacheBlockMaxPageH) = ER11;//mlc��Page��ص�Ҫ��2
		*(u8 xdata *)(&CacheBlockMaxPageL) = ER10;

		SectorPerSmallPageTotal = SectorPerSmallPage;
		ER11 = 0;
		ER10 = SectorPerSmallPageTotal + 1;
		ER13 = LargePagePerBlockH;
		ER12 = LargePagePerBlockL;
		#pragma asm
		MUL16_ER1
		#pragma endasm
		DPCON = 0x10;   //setors in block̫����
		DPTR0 = (u16)(&SectorPerBlock);
		#pragma asm
		MOV 	A,ER13
		MOVX	@DPTR,A
		MOV 	A,ER12
		MOVX	@DPTR,A
		MOV 	A,ER11
		MOVX	@DPTR,A
		MOV 	A,ER10
		MOVX	@DPTR,A
		#pragma endasm
		
		_pop_(ER03);
		_pop_(ER02);
		_pop_(ER01);
		_pop_(ER00);		 					
	}

	_pop_(DPCON);
}


static void Prog_Lg2PhTable_Page(void)
{

}

static void Buf_Lg2PhTable_2_0(void)
{

}

static void Read_Lg2PhTable_Page(void)
{

}

static void Buf_0_2_Lg2PhTable(void)
{

}

void Read_Sectors(void)
{
	if(SectorNum){
			timer_tick_clr();

			RandomIndex = R8Tmp;
			
			R1_SectorTmp = R1_Sector;
			
			while(1){
				if( ! SectorNum){
					break;
				}

			RdCurZone = SectorNum;
			R1_Sector = R1_SectorTmp;
			R8Tmp = RandomIndex;
			NF_Read_Start();
			NF_Read_Data();
			   
			R8Tmp++;
			R8Tmp++;
			NF_Wait_Read_Over();			
			Chk_Blank_Block();			
			RdCurZone--;
			RdCurZone--;

			if(RdCurZone){
				NF_Read_Data();			   
			   	R8Tmp++;
				R8Tmp++;
			}
//Read_Sectors_Loop
		   	do{
				if(RdCurZone){
					NF_Wait_Read_Over();
//					Chk_Blank_Block();	
	
					RdCurZone--;
					RdCurZone--;
				}
	
				if( ! SectorNum){
					break;
				}
	
				if(RdCurZone){
					NF_Read_Data();
				   	R8Tmp++;
					R8Tmp++;
				}
				BCH_MODE_DC_Wait_Over();

//				if((BECNTTmp < 0xFF) && (BECNTTmp > 0x10))
//				{
//					if(bBlockMode)
//					{
//							prints("NoRe TLC:");
//					}
//					else
//					{		
//							prints("NoRe SLC:");}
//							//printHexSync(UartIndex);
//							printHexSync(BECNTTmp);
//							printHexSync(BlockLgAddrH);
//							printHexSync(BlockLgAddrL);
//							printHexSync(PageLBAH);
//							printHexSync(PageLBAL);
//								
//							printHexSync(R3_BlockAddrH);
//							printHexSync(R2_BlockAddrL);		
//							printHexSync(R4_PageAddrH);
//							printHexSync(R0_PageAddrL);
//							prints("\n");
//					//}
//				}
				Chk_Need_Retry();			
			}while( ! bLg2PhVerifyError);	 	//���ж������Ƿ���ȷ	
		}
	}
		
//bNfInReadLbaFun=0;
	reset_bch();

}


static void Chk_Need_Retry(void)
{
	//���ж��Ƿ��δд����block
if (RetryCnt > 0) 
	bReadBlankBlock = 0;   //�������ݱ�try��ff	


	if (!bReadBlankBlock){  
#if	RETRY_EN
#else
	if (bLg2PhVerifyError)		
		prints("read fail\n");		
		 RetryCnt = 0;
		 bLg2PhVerifyError = 0;
#endif
//		if(bReadBlankBlock || bLg2PhVerifyError){
		if(bLg2PhVerifyError){

			if ((!FlashReTryType) && (!RetryCnt))
			{
				RetryCnt = RETRY_NUBER - 4;//ֻretry 1��
			}
			
//Chk_Need_Retry_Data_Fail:
			if(bFlashRetryTimeOut){
				RetryCnt = RETRY_NUBER;	
			}
			RetryCnt++;
			if(RetryCnt == RETRY_NUBER + 1){
			//Chk_Need_Retry_GiveUp
				Set_Retry_Register_Default_Data();
				bLg2PhVerifyError = 0;
 #if BAUDRATE
if(bBlockMode)
		prints("Give TLC:");
else
		prints("Give SLC:");
		printHexSync(RetryCnt);			
		printHexSync(BlockLgAddrH);
		printHexSync(BlockLgAddrL);
		printHexSync(PageLBAH);
		printHexSync(PageLBAL);
			
		printHexSync(R3_BlockAddrH);
		printHexSync(R2_BlockAddrL);		
		printHexSync(R4_PageAddrH);
		printHexSync(R0_PageAddrL);
			
		prints("\n");
#endif
				return;
			}else{
				bLg2PhVerifyError = 1;
				Set_Retry_Register_Offset_Data();
				return;
			}					
		}else{	//������ȷ
			if(RetryCnt){	 //������ȷ�����Ѿ�retry��
#if BAUDRATE

if(bBlockMode)
{
		prints("Pass TLC:");
}
else
{		
		prints("Pass SLC:");
}
		printHexSync(RetryCnt);
		printHexSync(BlockLgAddrH);
		printHexSync(BlockLgAddrL);
		printHexSync(PageLBAH);
		printHexSync(PageLBAL);
			
		printHexSync(R3_BlockAddrH);
		printHexSync(R2_BlockAddrL);		
		printHexSync(R4_PageAddrH);
		printHexSync(R0_PageAddrL);
printHexSync(BECNTTmp);
		prints("\n");
#endif
				Set_Retry_Register_Default_Data();	
				return;
			}
		}	
	}
	//Chk_Need_Retry_NoNeedRetry_1:
	//����Ҫretry��ֱ�ӷ���
	RetryCnt = 0;
	Buf_Data_CoDec();
	R1_SectorTmp++;

	RandomIndex++;
	RandomIndex++;
	SectorNum--;
	SectorNum--;
	
	bLg2PhVerifyError = 0;
}

static void Set_Retry_Register_Default_Data(void)
{
	Buf_Data_CoDec();
	DataCoDecKeyIndex1++;
	
	R1_SectorTmp++;

	RandomIndex++;
	RandomIndex++;
	SectorNum--;
	SectorNum--;
	
	RetryCnt = 0;
}

static void Set_Retry_Register_Offset_Data(void)
{
	reset_bch();
	bRetryBlockMode = bBlockMode;
	Set_Retry_Register_Data();
}

void Prog_A_Page_CacheBlock(void)
{
#if !NFFUSING
	_push_(DPCON);
 	DPCON = 0x00;			//DPTR0������

	select_ecc_bits(ENCODE | R1_Sector);

	BXADR1H_P2 = (u8)((_SPARE_AREA_BUF ) >> 8);
	BXADR1L_P2 = (u8)((_SPARE_AREA_BUF ) >> 0);

	BPT0SZ_P2 = 1024 / 4;
	BPT1SZ_P2 = 160/4; 

	bSendReadRandomCmd = 1;
	lastCmdProgPage = 1;
	chk_slcMode_switch();	
	
  bNeedChkBlockPageModeIndex = 1;

//yScrtyUnitCnt = 100;	
	NF_Write_Addr();
//row:NF_DATA[0], NF_DATA[1],NF_DATA[2],
//col :NF_DATA[3],NF_DATA[4]    
	Get_Config_Data();

	//80+5BYTES ADDR
	*((u8 xdata *)(& NF_DATA + 5)) = ProgramCMD0;  //2pʱ��81	
	ProgramCMD0 = 0x80;
	NF_Send_CMD0_5ByteAddr();
	NF_Prog_Data();				//��һ��sector(����1K),�������¹�����Ϣ(�ⲿ����)
	
	R1_Sector++;             //1kʱ,R1��ʾ2��sector
	
	R8Tmp++;                 //1k change
	R8Tmp++; 

	if(SectorNum != 2){	//SectorNumΪ��ǰ��program��sector,���һ�β�����������
		Get_Config_Data();			
	}

	do{
		ECC_Step1_isr();	//ÿ�θ��¹�����Ϣ  //���һ��SectorNum=1.��stop
	}while(SectorNum);

	bEnReleaseNfBufRcvData = 0;

//if (!bCacheCmd && !b2PlaneTrue) {	
//	NF_Read_Status();		
//}	

if (ProgramCMD1 == 0x15)
{	
	NF_Read_Status(2);
} else if (ProgramCMD1 == 0x10)
{	
	NF_Read_Status(0);
} 
	
	
	_pop_(DPCON);

#else
//	unsigned char i = 0;
	unsigned char idata NFFAMT_P2Tmp;
	_push_(DPCON);
 	DPCON = 0x00;			//DPTR0������

	select_ecc_bits(ENCODE | R1_Sector);

	BPT0SZ_P2 = 1024 / 4;												
	BPT1SZ_P2 = 160 / 4;

	if(bProgCacheBlockPageTrue)
	{
		XBYTE[_SPARE_AREA_BUF+8 + 0] = PageLBAL;	
		XBYTE[_SPARE_AREA_BUF+8 + 1] = PageLBAH | DATA_CACHE_BLOCK;
		XBYTE[_SPARE_AREA_BUF+8 + 2] = SpareArea2;	
	}

	DataCoDecKeyIndex1 = R1_Sector;	//��sector

  	bNeedChkBlockPageModeIndex = 1;
	chk_slcMode_switch();
	
	NF_Write_Addr();
	Fill_NFFINBuf();
	
	*((u8 xdata *)(& NF_DATA + 5)) = ProgramCMD0;
	ProgramCMD0 = 0x80;
	NF_Send_CMD0_5ByteAddr();

	HPAGE0_P2 = DataCoDecKeyIndex;

	NFFINBADR_P2 = NFFINBuf;
	NFFOUTBADR_P2 =NFFOutBuf;

//	NFFSTCNT_P2 = 0;
		 
//	NFFENCNT_P2	= 32;
		NFFAMT_P2 = (((SectorPerSmallPage+1)>>1)-1);//(16-1);			


	NFFLEN_P2 = NFFINBuf_SIZE/4;
	NfEmptyBufCntTmp = 0x00;

	NFFCON_P2 = 0x01;		
		
	while((NFFCON_P2&0x80)==0)     //all done  
	{		
		Fill_NFFINBuf();
		if(bEnReleaseNfBufRcvData)
		{
			NFFAMT_P2Tmp = NFFAMT_P2; //loop 
   		if(NfEmptyBufCntTmp != NFFAMT_P2Tmp)
			{  
				_push_(IE1);
				disable_timer_isr();				
					NfEmptyBufCnt+=NFFAMT_P2Tmp - NfEmptyBufCntTmp;
					NfEmptyBufCnt+=NFFAMT_P2Tmp - NfEmptyBufCntTmp;  		//�Ѿ��ͷŹ��� 					
					_pop_(IE1);	
				NfEmptyBufCntTmp = NFFAMT_P2Tmp;
			}
		}
  }		

		if(bEnReleaseNfBufRcvData)
		{

			NFFAMT_P2Tmp = NFFAMT_P2;
   		if(NfEmptyBufCntTmp != NFFAMT_P2Tmp)
			{			
				_push_(IE1);
				disable_timer_isr();				
				NfEmptyBufCnt+=NFFAMT_P2Tmp - NfEmptyBufCntTmp;	

				NfEmptyBufCnt+=NFFAMT_P2Tmp - NfEmptyBufCntTmp;  

				_pop_(IE1);	
				NfEmptyBufCntTmp = NFFAMT_P2Tmp;
			}
		}
		
	NTSKD = 0;			// clear pending

BSIE = 0;
NF_Prog_Stop();	

	bEnReleaseNfBufRcvData = 0;

	_pop_(DPCON);
	
#endif

}


static void ECC_Step1_isr(void)
{
#if 1//DIS_NF_FUNCTION
	
	_push_(DPCON);
 	DPCON = 0x00;			//DPTR0������

	Wait_Flash_Ready();
	
	if(bEnReleaseNfBufRcvData)
	{
		_push_(IE1);
		disable_timer_isr();
		NfEmptyBufCnt++;		//ԭ�Ӳ���	
		NfEmptyBufCnt++;	    //1k change
		_pop_(IE1);	
	}	
	
	if(bProgCacheBlockPageTrue){
		XBYTE[_SPARE_AREA_BUF + 0] = PageLBAL;	
		XBYTE[_SPARE_AREA_BUF + 1] = PageLBAH | DATA_CACHE_BLOCK;
		XBYTE[_SPARE_AREA_BUF + 2] = SpareArea2 | ((R0_PageAddrL&0x0f)<<4);		
	}
	
	
	if (R1_Sector == 2)
	{
		
		XBYTE[_SPARE_AREA_BUF + 0] = R0_PageAddrL;  	
		XBYTE[_SPARE_AREA_BUF + 1] = OldBlockPhAddrH;
		XBYTE[_SPARE_AREA_BUF + 2] = OldBlockPhAddrL;			
	}
	BCMCON_P2 = 0;
	BCON1_P2 &= 0x7f;
	BCON0_P2 &= ~(1 << 7);


	if (Wr_Badcolumn_AfterData() && SectorNum  && (FlashType != _TOSHIBA_19NM_/*��Խ������*/))   
	{
		Get_Config_Data();  //column������Ҫ��������
	}
	
	if(SectorNum != 2){
		if((SectorPerSmallPage+1) != HalfSectorPerSmallPage)//TOSHIBA 19NM����LP RP
		{
			if(R1_Sector == (HalfSectorPerSmallPage>>1))
			{
					NACMD1_P2 = 0x11;	
					NPCON_P2 = 0x80;
					Wait_Flash_Ready();
#ifdef _8MXX_  //��plane
					NF_Write_Addr();			
					*((u8 xdata *)(& NF_DATA + 5)) = 0x81;  //2pʱ��81
#else 		   //��LP RP	
	#ifdef _HALFPAGE_ 
					NF_Write_Addr();			
					*((u8 xdata *)(& NF_DATA + 5)) = 0x80; 
	#else
					*((u8 xdata *)(& NF_DATA + 5)) = 0x80;
					*((u8 xdata *)(& NF_DATA + 1)) |= 0x01;
	#endif				
#endif
					NF_Send_CMD0_5ByteAddr();
			}
		}
		NF_Prog_Data();	
	}


	SectorNum--;
	SectorNum--;	

	if(SectorNum){
		R8Tmp++;
		R8Tmp++;	

		R1_Sector++;

		if(SectorNum != 2){
			Get_Config_Data();
		}	
	}
	//ISR_Prog_A_Page_CacheBlock_END
	if( ! SectorNum){
#ifdef _8MXX_		
		R1_Sector++;
		Wr_Badcolumn_AfterData();  
		R1_Sector--;
#endif		
		BSIE = 0;
		NF_Prog_Stop();	
	}
	_pop_(DPCON);
	
#endif
	
}




void Prog_A_Page_NewBlock(void)
{

}

void Get_Config_Data(void)
{
	_push_(DPCON);
 	DPCON = 0x00;			//DPTR0������

	RandomIndex = R8Tmp;
	DataCoDecKeyIndex1 = R1_Sector;
	ER02 = R8Tmp;
	
	Sel_Buffer_Addr();
		
//[6]: 1-data from sram to nfc;
//[5:4]:1-encode mode
//[0]:1-kict start
 	ER03 = BIT(6) | BIT(4) | BIT(0);

	DPCON = 0x10;			//DPTR0����
	DPTR0 = (u16)(& NF_DATA + 8);
	#pragma asm
	MOV32_EDP0_ER0		//nf data buf addr
	MOV32_EDP0_ER1		//BUFFER_START_ADDR,BXADR2		
	#pragma endasm

	Get_ColAddr();		  //NF_Write_Addr//�ȸ���R1����2byte column addr

	_pop_(DPCON);
}

unsigned char NF_Read_Status(unsigned char tmp)
{
	u8 idata cnt = 0;
	
	_push_(DPCON);
	DPCON = 0x00;
	
	NPGSZ_P2 = 2;
	do{
			NXADR0_P2 = _SPARE_AREA_BUF;// + 80;//�޸�buf��ַ�����+80����slc+copy backд��
			NXCNT0_P2 = 160 / 4;  //�������NPGSZ1_P2 NPGSZ0_P2

			NFIFO0_P2 = NF_READ_STATUS;
			BCON1_P2 = 0;//��data
			NPCON_P2 = 0x05;
			Wait_Flash_Ready();

			if(tmp == 1)
				goto read_status_end;
				
			if (tmp == 2) {
		//			if ((!bCacheCmd) || !lastCmdProgPage)	{
					if (XBYTE[_SPARE_AREA_BUF + 0] & BIT(6)) {   //flash cache ready
						break; 
					}
		//			}
			}		
			
			cnt++;
	
		}while(!(XBYTE[_SPARE_AREA_BUF + 0] & BIT(5))); //flash array ready
	
	lastCmdProgPage = 0;	
read_status_end:			
	_pop_(DPCON);	
	return (XBYTE[_SPARE_AREA_BUF]);
}



void erase_sdbuf_block(void)
{
#if EN_VIRTUAL_BUF
	unsigned char ZoneLBA_backup;
	
	_push_(PAGEMAP);	
	_push_(DPCON);
		
	PAGEMAP = 0x02;
 	DPCON = 0x0;//10;			//DPTR0����
	ZoneLBA_backup = ZoneLBA;

	SDBuf_Block_Init_Zone();
	BlockAddrTmpH = SDBufBlockAddrH;
	BlockAddrTmpL = SDBufBlockAddrL;

	bBlockMode = 0;
	Write_a_Block_Over();
	SDBufBlockAddrH = 0xff;
	SDBufBlockAddrL = 0xff;

	
	if (ZoneLBA != ZoneLBA_backup) {	 //��ԭ����ȷֵ
		ZoneLBA = ZoneLBA_backup;
		Get_CurPlaneCfg(); 
	}	
	
	_pop_(DPCON);
	_pop_(PAGEMAP);
#endif
}

void program_sdbuf_block(void)
{	
#if EN_VIRTUAL_BUF
	unsigned char ZoneLBA_backup;
	_push_(PAGEMAP);	
	_push_(DPCON);
	
	PAGEMAP = 0x02;
 	DPCON = 0x00;			//DPTR0������

	ZoneLBA_backup = ZoneLBA;
	SDBuf_Block_Init_Zone();
	bEnReleaseNfBufRcvData = 0;

	if(SDBufBlockAddrH == 0xff){
		bBlockMode = 0;
		Find_A_Blank_Block();	
		SDBufBlockAddrH = BlockAddrTmpH;
		SDBufBlockAddrL = BlockAddrTmpL;
	}
	//���¹�����Ϣ
	XBYTE[_SPARE_AREA_BUF + 0] = (u8)(SDBUF_BLOCK >> 0);
	XBYTE[_SPARE_AREA_BUF + 1] = (u8)(SDBUF_BLOCK >> 8);
 	XBYTE[_SPARE_AREA_BUF + 2] = 0xff;
	bProgCacheBlockPageTrue=1;	
	SectorNum = SectorPerSmallPage + 1;
	SDBuf_Block_Init_Addr();
  	PageLBAL=DataCoDecKeyIndex;//�����ϵ�ʱ�����ҵ�����
	ProgramCMD1 = 0x10;  	
	Prog_A_Page_CacheBlock();
	bProgCacheBlockPageTrue=0;
	
	if (ZoneLBA != ZoneLBA_backup) {	 //��ԭ����ȷֵ
		ZoneLBA = ZoneLBA_backup;
		Get_CurPlaneCfg(); 
	}	
	
	_pop_(DPCON);
	_pop_(PAGEMAP);
#endif
}

void read_sdbuf_block(void)
{
#if EN_VIRTUAL_BUF
	unsigned char ZoneLBA_backup;
	
	_push_(PAGEMAP);	
	_push_(DPCON);
	
	PAGEMAP = 0x02;
 	DPCON = 0x00;//10;			//DPTR0����

	ZoneLBA_backup = ZoneLBA;
	SDBuf_Block_Init_Zone();
	SectorNum = VIRTUAL_BUF_READ_MAX_SECS_IN_PER_PAGE;
		
#if MODE_1K_EN	  //����1K
	if (SectorNum&0x01)
		SectorNum++;
#endif 
	
  SDBuf_Block_Init_Addr();
	Read_Sectors();

	if (ZoneLBA != ZoneLBA_backup) {	 //��ԭ����ȷֵ
		ZoneLBA = ZoneLBA_backup;
		Get_CurPlaneCfg(); 
	}	
	_pop_(DPCON);
	_pop_(PAGEMAP);
#endif
}


void SDBuf_Block_Init_Zone(void)
{
#if EN_VIRTUAL_BUF
	ZoneLBA = *(u8 xdata *)(&FirstValidZone);
	Get_CurPlaneCfg();	
#endif
}

static void SDBuf_Block_Init_Addr(void)
{
#if EN_VIRTUAL_BUF
	SDBufPageAddr = SDBufPageAddr;	  //���������Զ��Ż�

	R3_BlockAddrH = SDBufBlockAddrH;
	R2_BlockAddrL = SDBufBlockAddrL;

	#pragma asm
		CLR32_ER1
	#pragma endasm
	ER10 = SDBufPageAddr;	
	if (b2PlaneTrue) {
		#pragma asm
			MOV 	R8,#1
			ROTL32_ER1_ER8
		#pragma endasm
	}
	R4_PageAddrH = ER11;
	R0_PageAddrL = ER10;  //page����Ҫ��������һ��2p
	
	R1_Sector = 0;
	bBlockMode = 0;//SLC
	DataCoDecKeyIndex = R0_PageAddrL;
	R8Tmp = 0;
#endif
}

static void BCM_KickStart(void)			
{
	_push_(DPCON);
 	DPCON = 0x10;			//DPTR0����

#ifdef _HALFPAGE_

	ER00 = R1_Sector<<1;
	if (ER00 < HalfSectorPerSmallPage) {
		DPTR0 = (u16)(& BCH_MODE_DC_TAB + ZoneLBA*2);
	} else if (ER00 < (SectorPerSmallPage+1)) {
		DPTR0 = (u16)(& BCH_MODE_DC_TAB + (ZoneLBA+1)*2);
	} 
	#pragma asm	
	CLR32_ER0
	MOVX	A,@DPTR
	MOV		ER01,A	  
	MOVX	A,@DPTR
	MOV		ER00,A
	#pragma endasm
	
	#ifdef _8MXX_	
	DPTR0 = _FLASH_BCMCfg_ADDR_Tmp;  //ȡBCM ���õ�ַ
	#pragma asm
	MOV		A,#4
	MOV 	B,ZoneLBA
	MUL		AB  //�����A
	MOV		B,#16		//32  �ĳ�16��sector
	CALL	dptr_add_ab_maskrom
	#pragma endasm	
	if((!b2PlaneTrue) || (b2PlaneTrue && ((R0_PageAddrL&0x01) == 0)))
	{
		B = R1_Sector;
	}
	else
	{
		B = R1_Sector + 16;   //1k change  //��δ�޸�
	}
	
	#else 
	DPTR0 = _FLASH_BCMCfg_ADDR_Tmp;  //ȡBCM ���õ�ַ
	#pragma asm
	MOV		A,#4
	MOV 	B,ZoneLBA
	MUL		AB  //�����A
	MOV		B,#16
	CALL	dptr_add_ab_maskrom
	#pragma endasm	
	if 	(R1_Sector < (HalfSectorPerSmallPage>>1)) {    	
		B = R1_Sector;
	}else{	// >=															//plane1	
		B = R1_Sector - (HalfSectorPerSmallPage>>1) + 16;
	}		
	#endif
		
#else 
	if((!b2PlaneTrue) || (b2PlaneTrue && ((R0_PageAddrL&0x01) == 0)))
	{
		DPTR0 = (u16)(& BCH_MODE_DC_TAB + ZoneLBA*2);//1P, 2P+plane0
	}
	else
	{
		DPTR0 = (u16)(& BCH_MODE_DC_TAB + 1*2);//2P+plane1//4P��ʱ��Ҫ��������
	}
	#pragma asm	
	CLR32_ER0
	MOVX	A,@DPTR
	MOV		ER01,A	  
	MOVX	A,@DPTR
	MOV		ER00,A
	#pragma endasm
	DPTR0 = _FLASH_BCMCfg_ADDR_Tmp;  //ȡBCM ���õ�ַ
	if((! b2PlaneTrue) && ZoneLBA){  //ʹ�õ�plane  
		DPTR0 = _FLASH_BCMCfg_ADDR_Tmp;
		#pragma asm
		MOV		A,#4
		MOV		B,#16	
		CALL	dptr_add_ab_maskrom
		#pragma endasm
	} 
	
	if((!b2PlaneTrue) || (b2PlaneTrue && ((R0_PageAddrL&0x01) == 0)))
	{
		B = R1_Sector;
	}
	else
	{
		B = R1_Sector + 16;   //1k change  //��δ�޸�
	}
		
#endif



#pragma asm
		CLR32_ER1
		MOV		A, #4 
		CALL	dptr_add_ab_maskrom	
		MOVX	A,@DPTR//����
		MOV		ER11,A //�����ݴ�
		MOVX	A,@DPTR//����
		MOV		ER10,A //�����ݴ�
#if !EN_BCM
		MOV		ER11,#0
		MOV 	ER10,#0
#endif 
		MOVX	A,@DPTR//�ߵ�ַ
		MOV		BCMADRH_P2,A
		MOVX	A,@DPTR//�͵�ַ
		MOV		BCMADRL_P2,A
		MOV		BCMDAT_P2,#0xFF		//Ŀǰ��δ���ݲ������

		ADD32_ER0_ER0_ER1
		MOV		NPGSZ1_P2,ER01	//����BCM cnt 
		MOV		NPGSZ0_P2,ER00

		MOV BCMCON_P2,#0x04  //1��ʾ���У�bcm disable,�������random��homos��δ����BCM����clear bcm pending
		#pragma endasm
		if(ER10 || ER11){	//bcm kick start
			BCMCON_P2 |= 0x01;	
		}else {
			BCMCON_P2 = 0;//������һ��
		}
	
	_pop_(DPCON);

}


void Config_Parameter_NPGSZ(void)
{
	if (bToggleTrue) {
		NPGSZ0_P2 = 0x02;
	} else {
		NPGSZ0_P2 = 0x01;
	}
	NPGSZ1_P2 = 0;
}


void NF_Reset(void)
{
#ifndef _8MXX_

if (bToggleTrue|| _DEFAULT_TOGGLE) {
	if (FlashType == MICRON) {
		NFIFO0_P2 = ASYNC_NF_RESET;
	} else {
		return;
	}
} else { 	
	NFIFO0_P2 = NF_RESET;
}
	NPCON_P2 = 0x01;
	Wait_Flash_Ready();

	lastCmdProgPage = 0;

#endif	
	
	
}



void reset_bch(void)
{
	_push_(PAGEMAP);

	sfrpage(2);
	NTSKD = 1;
	_nop_();
	_nop_();
	_nop_();
	NTSKD = 0;
	HCON_P2 = 0;
	BCMCON_P2 = 0;	
	BCON1_P2 = 0;
	sfrpage(0);
	
	CLKCON0_P0 &= ~ BIT(3);
	_nop_();
	_nop_();
	_nop_();	
	CLKCON0_P0 |= BIT(3);	

	_pop_(PAGEMAP);

}


//u8 idata ecc_encode_bits;
	
//input: u8 config
//config[6:0]: ecc bits
//config[7:7]: 0-encode; 1-decode.
void select_ecc_bits(u8 config)//ֻ��ѡ��ECC��������������Ҫ������Encode����Decode
{
	u8 idata ZoneLBATmp;
	_push_(PAGEMAP);
	sfrpage(2);

#ifdef _8MXX_

	ER00 = (config & 0x7F)<<1;
	if (ER00 < HalfSectorPerSmallPage) {
		ZoneLBATmp = ZoneLBA;
	} else if (ER00 < (SectorPerSmallPage+1)) {
		ZoneLBATmp = ZoneLBA+1;
	}

#else 

	if((!b2PlaneTrue) || (b2PlaneTrue && ((R0_PageAddrL&0x01) == 0)))
	{
		ZoneLBATmp = ZoneLBA;
	}
	else//2P+plane1
	{
	   	ZoneLBATmp = 1;
	}

#endif

if((BTSEL_P2 & 0x7F) != (*(u8 xdata *)(& NF_SECTOR_SIZE_TAB + ZoneLBATmp)))
{
//	prints("ECC:");
//	printHexSync(BTSEL_P2 & 0x7F);
//	printHexSync((*(u8 xdata *)(& NF_SECTOR_SIZE_TAB + ZoneLBATmp)));
//	prints("\n");
	BTSEL_P2 = (*(u8 xdata *)(& NF_SECTOR_SIZE_TAB + ZoneLBATmp));

	BCON1_P2 |= BIT(2);					//cal encode polynomial.
	while(!(BTSEL_P2 & BIT(7))) {}	
}


	if((config & 0x80) == ENCODE)
	{
		BPSZH_P2 = *(u8 xdata *)(& BCH_MODE_EC_TAB + ZoneLBATmp*2 + 0);	
		BPSZL_P2 = *(u8 xdata *)(& BCH_MODE_EC_TAB + ZoneLBATmp*2 + 1);	
	}
	else
	{
		BPT0SZ_P2= (1024 >> 2);//�ϵ縳ֵһ�ζ���
		BPT1SZ_P2 = 0; //using BXADR0_P2, BXADR2_P2//read���ó�0
		BPSZH_P2 = *((u8 xdata *)(& BCH_MODE_DC_TAB + ZoneLBATmp*2 + 0));//read  
		BPSZL_P2 = *((u8 xdata *)(& BCH_MODE_DC_TAB + ZoneLBATmp*2 + 1));
		BCON1_P2 = BIT(6) | BIT(5);		//data from nfc, decode, hardware auto error correct.//������ʱ����ʼ����read data�ḳֵ
	}

	_pop_(PAGEMAP);
}

//inpput: u8 ce
///0: select CE0
///1:select CE1
void select_ce(u8 ce)
{
	if(ce == 0){
		NCEE_P2 = (NCEE_P2 & 0xfc) | BIT(0) | BIT(6) | BIT(5);
	}else{
		NCEE_P2 = (NCEE_P2 & 0xfc) | BIT(1) | BIT(6);
	}
}






















