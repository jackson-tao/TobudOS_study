#include "inc\tank.h"
#include "intrins.h" 
#include "inc\common.h"

#define BIT(X)	(1<<X)
/*!	\fn		void delay(unsigned int cnt)
 *	\brief	A time delay function	  
 *	\param	cnt Delay count, when touch the value, delay finished 
 *	\return No return value
 */
void delay(u16 cnt)
{
	while(cnt--);
}


/*============================================================
* ���룺��Ҫ�л���SFR PAGE
* ���: 
* ��������:  sfrpage
============================================================*/
void sfrpage(u8 pgnum)
{
	 PAGEMAP &= 0xf8;
	 PAGEMAP |= pgnum;

//#pragma asm
//	 anl PAGEMAP , #0xf8
//	 mov a       , r7
//	 anl a       , #0x07
//	 orl PAGEMAP , a
//#pragma endasm

}

/*============================================================
* ���룺��Ҫ�л���DATA PAGE
* ���: 
* ��������:  datapage
============================================================*/
void datapage(u8 pgnum)
{
	 PAGEMAP &= 0x3F;
	 PAGEMAP |= (pgnum<<6);
}

///*
// * putchar (basic version): expands '\n' into CR LF
// */
//char putchar (char c)  
//{
//  _push_(PAGEMAP);
//  	  
//  sfrpage(3);				   //����sfrpage�ֳ�

//#if 0
//	while((TMRCON_P3 & BIT(3)) == 0);	//�ȴ��ϴ�uart��pending
//	TMRCON_P3 &= ~BIT(3);
//	
//	if (c == '\n')  
//	{	
//		TMRSPBUF_P3 = 0x0d;
//		TMRCON_P3 |= BIT(3); 	            //kick
//		while((TMRCON_P3 & BIT(3)) == 0);
//		TMRCON_P3 &= ~BIT(3);
//	}

//	TMRSPBUF_P3 = c;
//	TMRCON_P3 |= BIT(3); 	//kick
//	
//#else
//	
//  if (c == '\n')  
//  {	
//	TMRSPBUF_P3 = 0x0d;
//	TMRCON_P3 |= BIT(3); 	            //kick
//    while((TMRCON_P3 & BIT(3)) == 0);
//    TMRCON_P3 &= ~BIT(3);
//  }

//  TMRSPBUF_P3 = c;
//  TMRCON_P3 |= BIT(3); 	//kick
//  while((TMRCON_P3 & BIT(3)) == 0x00);
//  TMRCON_P3 &= ~BIT(3);
//  
//#enidf
//  
//  _pop_(PAGEMAP);

//  return (c);
//}

//						   
//char xdata HexTable[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
//void PrintHex(u8 dat)
//{
//	putchar(HexTable[(dat>>4)&0x0f]);
//	putchar(HexTable[dat&0x0f]);
//	putchar(' ');
//}
//void NewLine(void)
//{
//	printf("\r\n");
//}
///*!	\fn		void sim_end()
// *	\brief	Use to end the RTL simulation	
// *	\param	None
// *	\return None
// */
////void sim_end()
////{
////	#pragma asm
////	DB 0xa5;
////	DB 0xa5;
////	DB 0xa5;
////	DB 0xa5;
////	#pragma endasm
////}









